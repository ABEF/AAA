from pathlib import Path
import ast,hashlib,json
R=Path(r'C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
E=Path(__file__).resolve().parent
def sha(raw):return hashlib.sha256(raw).hexdigest()
old=(E/'deployment-sequence-cli-before-abbrev.py').read_bytes()
new=(R/'scripts/prepare-deployment-sequence.py').read_bytes()
before=ast.parse(old);after=ast.parse(new)
node_before={n.name:n for n in before.body if isinstance(n,(ast.ClassDef,ast.FunctionDef))}
node_after={n.name:n for n in after.body if isinstance(n,(ast.ClassDef,ast.FunctionDef))}
assert set(node_before)==set(node_after)
normal=ast.parse(new)
main=next(n for n in normal.body if isinstance(n,ast.FunctionDef) and n.name=='main')
constructor=main.body[0].value
assert isinstance(constructor,ast.Call) and isinstance(constructor.func,ast.Name) and constructor.func.id=='Parser'
keyword=[k for k in constructor.keywords if k.arg=='allow_abbrev']
assert len(keyword)==1 and isinstance(keyword[0].value,ast.Constant) and keyword[0].value.value is False
constructor.keywords=[k for k in constructor.keywords if k.arg!='allow_abbrev']
assert ast.dump(before,include_attributes=False)==ast.dump(normal,include_attributes=False)
tests=(R/'tests_python/test_deployment_sequence_cli.py').read_bytes()
tree=ast.parse(tests);cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='DeploymentSequenceCliTests')
methods={n.name:sha(ast.dump(n,include_attributes=False).encode())for n in cls.body if isinstance(n,ast.FunctionDef)and n.name.startswith('test_')}
stage1=json.loads((E/'sequence-cli-representative-01.json').read_bytes())
stage2=json.loads((E/'sequence-cli-remaining-01.json').read_bytes())
stage3=json.loads((E/'sequence-cli-abbreviation-fixed-01.json').read_bytes())
failed={t.split(' (',1)[0].rsplit('.',1)[1]for t,_ in stage2['failures']}
assert len(failed)==1 and set(stage3['selected_methods'])==failed and stage3['successful']
first=set(stage1['selected_methods']);second=set(stage2['selected_methods'])-failed
assert not first & second and len(first|second|failed)==20==len(methods)
for stage in (stage1,stage2,stage3):
 for method,digest in stage['selected_case_ast_sha256'].items():assert methods[method]==digest
report=dict(scope='Source/case AST and disjoint-stage proof; no test execution.',
 original_cli_sha256=sha(old),final_cli_sha256=sha(new),
 cli_change='Only Parser constructor allow_abbrev=False; all other module AST identical.',
 final_new_test_sha256=sha(tests),selected_case_ast_sha256=methods,
 distinct_new_methods_passed=20,
 stages={'representative':sorted(first),'initial_remaining_successes':sorted(second),'affected_repeated_after_fix':sorted(failed)},
 unchanged_methods_rerun=0,production_approved=False)
with (E/'sequence-cli-final-pins.json').open('x',encoding='utf-8',newline='\n')as f:json.dump(report,f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps(dict(distinct_new_methods_passed=20,constructor_only_ast_delta=True,tests_executed=0)))
