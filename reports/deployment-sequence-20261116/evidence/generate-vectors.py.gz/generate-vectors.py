from pathlib import Path
import datetime,hashlib,json,os,re,subprocess
R=Path(r'C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
E=Path(__file__).resolve().parent
CAST=E.parent/'foundry-v1.4.4/cast.exe'
sender='0x6ac7ea33f8831ea9dcc53393aaa88b25a785dbf0'
env={k:v for k,v in os.environ.items() if k.upper() in ('SYSTEMROOT','WINDIR','TEMP','TMP')}
env['PATH']=str(CAST.parent)+os.pathsep+str(Path(env.get('SystemRoot',env.get('SYSTEMROOT','C:/Windows')))/'System32')
def run(args):
 p=subprocess.run([str(CAST),*args],capture_output=True,text=True,timeout=10,env=env)
 return {'arguments':args,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
version=run(['--version']);assert version['exit_code']==0
values=(0,1,2,3,127,128,255,256,65535,65536,(1<<32)-1,1<<32,(1<<64)-2)
records=[]
for nonce in values:
 row=run(['compute-address',sender,'--nonce',str(nonce)])
 row['nonce']=nonce;records.append(row)
 assert row['exit_code']==0,row
 addresses=re.findall(r'0x[0-9a-fA-F]{40}',row['stdout'])
 assert len(addresses)==1,row
 row['address']=addresses[0].lower()
record={'observed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'kind':'offline_cast_create_address_vectors','sender':sender,'cast_sha256':hashlib.sha256(CAST.read_bytes()).hexdigest(),
 'cast_version':version,'vectors':records,'network_calls':0,'transactions':0,'tests_executed':0,
 'environment':'minimal public system/temp/PATH only; no RPC/signing variables inherited',
 'notice':'Independent local CREATE calculation only, not EVM execution, live nonce/address admission or deployment qualification.'}
with (E/'cast-create-vectors.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(record,f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps({r['nonce']:r['address'] for r in records},indent=2))
