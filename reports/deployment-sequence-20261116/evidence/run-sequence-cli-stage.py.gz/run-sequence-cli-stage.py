from pathlib import Path
import ast,datetime,hashlib,io,json,sys,unittest
R=Path(r'C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
E=Path(__file__).resolve().parent
sys.path.insert(0,str(R))
from tests_python.test_deployment_sequence_cli import DeploymentSequenceCliTests
from zzz_ops import deployment_sequence as S

def sha(raw):return hashlib.sha256(raw).hexdigest()
def pins():
 names=[*S.PRODUCER_FILES,'tests_python/test_deployment_sequence_cli.py']
 return {n:sha((R/n).read_bytes().replace(b'\r\n',b'\n')) for n in names}
mode=sys.argv[1]
representative='test_complete_result_publishes_exact_review_without_any_execution_authority'
allnames=unittest.defaultTestLoader.getTestCaseNames(DeploymentSequenceCliTests)
names=([representative] if mode=='representative' else
       ['test_no_key_signer_rpc_nonce_reservation_deploy_or_seal_switch_exists'] if mode=='abbreviation-fixed' else
       [n for n in allnames if n!=representative])
before=pins();log=io.StringIO()
suite=unittest.TestSuite(DeploymentSequenceCliTests(n) for n in names)
result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
after=pins()
module=ast.parse((R/'tests_python/test_deployment_sequence_cli.py').read_bytes())
cls=next(n for n in module.body if isinstance(n,ast.ClassDef) and n.name=='DeploymentSequenceCliTests')
methods={n.name:sha(ast.dump(n,include_attributes=False).encode())for n in cls.body if isinstance(n,ast.FunctionDef) and n.name in names}
report=dict(observed_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 scope='Only NEW sequence CLI contracts; constructor preparation injected, real bounded parsing/rendering/exclusive-file operations. No old test body, RPC, compiler, EVM or deployment.',
 selected_methods=names,executed_methods=names,tests_run=result.testsRun,
 failures=[(t.id(),s)for t,s in result.failures],errors=[(t.id(),s)for t,s in result.errors],
 skips=[(t.id(),s)for t,s in result.skipped],source_sha256_before=before,source_sha256_after=after,
 source_changes_during_run=before!=after,selected_case_ast_sha256=methods,
 successful=result.wasSuccessful() and before==after,production_approved=False)
base=E/f'sequence-cli-{mode}-01'
with base.with_suffix('.log').open('x',encoding='utf-8',newline='\n')as f:f.write(log.getvalue())
with base.with_suffix('.json').open('x',encoding='utf-8',newline='\n')as f:json.dump(report,f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps({'mode':mode,'tests_run':result.testsRun,'successful':report['successful'],'errors':len(result.errors),'failures':len(result.failures),'skips':len(result.skipped)}))
raise SystemExit(0 if report['successful'] else 1)
