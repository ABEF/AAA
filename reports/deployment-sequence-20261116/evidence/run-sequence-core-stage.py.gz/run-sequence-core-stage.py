from pathlib import Path
import ast,datetime,hashlib,io,json,sys,time,unittest
R=Path(r'C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
E=Path(__file__).resolve().parent
sys.path.insert(0,str(R))
from tests_python.test_deployment_sequence import DeploymentSequenceTests
stage=sys.argv[1];names=sys.argv[2:]
if not names:
 names=[n for n in unittest.defaultTestLoader.getTestCaseNames(DeploymentSequenceTests)]
 if stage.startswith('remaining'):
  names=[n for n in names if n not in ('test_offline_cast_vectors_cover_rlp_length_and_uint64_boundaries',
                                     'test_prepare_fills_only_matching_assignments_and_preserves_input_object')]
assert len(names)==len(set(names)) and names
def sha(raw):return hashlib.sha256(raw).hexdigest()
paths=['zzz_ops/deployment_sequence.py','scripts/prepare-deployment-sequence.py','zzz_ops/deployment_plan.py',
       'zzz_ops/abi.py','tests_python/test_deployment_sequence.py']
def pins():return {n:sha((R/n).read_bytes().replace(b'\r\n',b'\n')) for n in paths}
before=pins();source=(R/'tests_python/test_deployment_sequence.py').read_bytes()
node={n.name:sha(ast.dump(n,include_attributes=False).encode()) for c in ast.parse(source).body if isinstance(c,ast.ClassDef)
      for n in c.body if isinstance(n,ast.FunctionDef) and n.name in names}
methods=[]
class Result(unittest.TextTestResult):
 def startTest(self,test):super().startTest(test);methods.append(test.id())
stream=io.StringIO();start=time.monotonic()
result=unittest.TextTestRunner(stream=stream,verbosity=2,resultclass=Result).run(unittest.TestSuite(DeploymentSequenceTests(n) for n in names))
after=pins();raw=stream.getvalue().encode()
with (E/f'sequence-core-{stage}.log').open('xb') as f:f.write(raw)
record={'observed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'scope':'Only selected NEW offline deployment-sequence methods. No old test bodies/compiler/RPC/signing/node/deployment.',
 'selected_methods':['tests_python.test_deployment_sequence.DeploymentSequenceTests.'+n for n in names],
 'executed_methods':methods,'selected_case_ast_sha256':node,'source_sha256_before':before,'source_sha256_after':after,
 'source_changes_during_run':[n for n in paths if before[n]!=after[n]],'tests_run':result.testsRun,
 'failures':[(t.id(),s)for t,s in result.failures],'errors':[(t.id(),s)for t,s in result.errors],
 'skipped':[(t.id(),s)for t,s in result.skipped],'elapsed_seconds':time.monotonic()-start,
 'successful':result.wasSuccessful() and before==after,'production_approved':False}
with (E/f'sequence-core-{stage}.json').open('x',encoding='utf-8',newline='\n')as f:json.dump(record,f,sort_keys=True,indent=2);f.write('\n')
print(stream.getvalue());print(json.dumps({'stage':stage,'new_methods':result.testsRun,'successful':record['successful']}))
raise SystemExit(0 if record['successful']else 1)
