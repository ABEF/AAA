from pathlib import Path
import ast,hashlib,json
R=Path(r'C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
E=Path(__file__).resolve().parent
def sha(raw):return hashlib.sha256(raw).hexdigest()
stages=[json.loads((E/f'sequence-core-{name}.json').read_bytes()) for name in
        ('representative-math-01','representative-prepare-01','remaining-01')]
selected={}
for stage in stages:
 assert stage['successful'] and not stage['source_changes_during_run']
 assert stage['selected_methods']==stage['executed_methods']
 assert not stage['failures'] and not stage['errors'] and not stage['skipped']
 for identity in stage['selected_methods']:
  assert identity not in selected
  short=identity.rsplit('.',1)[1]
  selected[identity]=stage['selected_case_ast_sha256'][short]
assert len(selected)==18
paths=stages[0]['source_sha256_after']
for stage in stages:
 assert stage['source_sha256_before']==paths==stage['source_sha256_after']
for name,pin in paths.items():assert sha((R/name).read_bytes().replace(b'\r\n',b'\n'))==pin
base=json.loads((E/'BASELINE.json').read_bytes())
for name in ('zzz_ops/deployment_plan.py','zzz_ops/abi.py'):
 assert sha((R/name).read_bytes())==base['files'][name]['sha256']
record={'distinct_new_methods_passed':18,'stages':[dict(selected_methods=x['selected_methods'],
  source_sha256=x['source_sha256_after'],elapsed_seconds=x['elapsed_seconds']) for x in stages],
 'method_ast_sha256':selected,'final_sources':paths,
 'reference_inputs_sha256':{name:sha((R/name).read_bytes()) for name in
  ('reports/local-deployment-rehearsal-20261115/GAS_SUMMARY.json','reports/local-deployment-rehearsal-20261115/evidence.zip')},
 'offline_cast_vector_sha256':sha((E/'cast-create-vectors.json').read_bytes()),
 'existing_planner_and_abi_byte_identical_to_baseline':True,'tests_rerun_for_pin_check':0,
 'unchanged_test_methods_executed':0,'rpc_calls':0,'public_transactions':0,
 'scope':'Composed1+1+16NEW methods, not an all18repeat. Historical actual44receipts authenticate address/noncemath only, not fresh-build EVM or release approval. Cast runs only explicit-nonce public math.',
 'production_approved':False}
with (E/'sequence-core-18-final-pins.json').open('x',encoding='utf-8',newline='\n') as f:json.dump(record,f,sort_keys=True,indent=2);f.write('\n')
print(json.dumps({'distinct_new_methods_passed':18,'tests_executed':0,'stage_sources_stable':True}))
