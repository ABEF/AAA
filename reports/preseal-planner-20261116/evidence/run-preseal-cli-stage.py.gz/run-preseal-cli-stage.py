"""Run selected NEW pre-seal CLI cases; no existing method or core build runs."""
import ast, datetime, hashlib, importlib, io, json, pathlib, sys, time, unittest

R=pathlib.Path(r'C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
E=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(R))
stage=sys.argv[1]
assert stage in ('representative','remaining')
paths=('scripts/prepare-preseal.py','tests_python/test_preseal_cli.py','zzz_ops/preseal_plan.py',
       'zzz_ops/deployment_plan.py','zzz_ops/abi.py')
def pins():return {p:hashlib.sha256((R/p).read_bytes()).hexdigest() for p in paths}
before=pins()
tree=ast.parse((R/paths[1]).read_bytes())
classes=[n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='PresealCliTests']
assert len(classes)==1
methods=[n.name for n in classes[0].body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]
assert len(methods)==18
representative='test_complete_review_publishes_exact_bytes_with_no_execution_or_permission_claim'
selected=[representative] if stage=='representative' else [n for n in methods if n!=representative]
identities=['tests_python.test_preseal_cli.PresealCliTests.'+name for name in selected]
output=E/('preseal-cli-'+stage+'.json');log=E/('preseal-cli-'+stage+'.log')
assert not output.exists() and not log.exists()
module=importlib.import_module('tests_python.test_preseal_cli')
suite=unittest.TestSuite(module.PresealCliTests(name) for name in selected)
stream=io.StringIO();start=time.perf_counter()
result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
raw=stream.getvalue().encode('utf-8');log.write_bytes(raw)
after=pins()
record={'stage':stage,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'methods':identities,'tests_run':result.testsRun,'successful':result.wasSuccessful(),
    'failures':len(result.failures),'errors':len(result.errors),'skips':len(result.skipped),
    'elapsed_seconds':time.perf_counter()-start,'source_sha256_before':before,
    'source_sha256_after':after,'sources_unchanged_during_stage':before==after,
    'log_sha256':hashlib.sha256(raw).hexdigest(),
    'scope':'New CLI/publication only; preparation injected, no real ABI/build/contract/provider acceptance.',
    'old_test_methods_selected':[]}
output.write_bytes((json.dumps(record,indent=2)+'\n').encode('utf-8'))
print(json.dumps({k:record[k] for k in ('stage','tests_run','successful','failures','errors','skips','elapsed_seconds','sources_unchanged_during_stage')}))
sys.exit(0 if result.wasSuccessful() and before==after else 1)
