"""Record one owned subprocess, without invoking any previous test suite."""
import ctypes, datetime, hashlib, json, os, pathlib, subprocess, sys, time
from ctypes import wintypes

root = pathlib.Path(r'C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
out = pathlib.Path(__file__).resolve().parent
name, *arguments = sys.argv[1:]
assert name and all(c.isalnum() or c in '-_' for c in name)
assert arguments
command = [sys.executable, *arguments]
log = out/(name+'.log')
record = out/(name+'.json')
assert not log.exists() and not record.exists()
env = {k:v for k,v in os.environ.items() if k.upper() in {
    'SYSTEMROOT','WINDIR','PATH','TEMP','TMP','USERPROFILE','APPDATA','LOCALAPPDATA'}}
env.update(PYTHONDONTWRITEBYTECODE='1', PYTHONIOENCODING='utf-8')
class Memory(ctypes.Structure):
    _fields_ = [('cb',wintypes.DWORD),('PageFaultCount',wintypes.DWORD),
        *[(n,ctypes.c_size_t) for n in ('PeakWorkingSetSize','WorkingSetSize',
          'QuotaPeakPagedPoolUsage','QuotaPagedPoolUsage','QuotaPeakNonPagedPoolUsage',
          'QuotaNonPagedPoolUsage','PagefileUsage','PeakPagefileUsage')]]
peak = 0; memory_observed = False
start = time.perf_counter(); utc = datetime.datetime.now(datetime.timezone.utc).isoformat()
with log.open('xb') as stream:
    child = subprocess.Popen(command,cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT)
    while True:
        if os.name == 'nt':
            metrics = Memory(); metrics.cb = ctypes.sizeof(metrics)
            ok = ctypes.windll.psapi.GetProcessMemoryInfo(wintypes.HANDLE(int(child._handle)),
                                                        ctypes.byref(metrics),metrics.cb)
            if ok:
                memory_observed = True; peak = max(peak,metrics.PeakWorkingSetSize)
        status = child.poll()
        if status is not None: break
        if time.perf_counter()-start > 1200:
            child.kill(); child.wait(); status = child.returncode; break
        time.sleep(.2)
result = {'utc':utc,'command':command,'exit_code':status,
    'elapsed_seconds':time.perf_counter()-start,'windows_peak_working_set_bytes':peak,
    'windows_memory_observed':memory_observed,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),
    'kind':'new_unsigned_preseal_stage','old_test_suites_run':False,
    'network_or_chain_action_authorized':False}
record.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result)); sys.exit(status or 0)
