import hashlib,json,os,pathlib,subprocess,sys
R=pathlib.Path(r'C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
sys.path.insert(0,str(R))
from zzz_ops import deployment_plan as D
E=pathlib.Path(__file__).resolve().parent;CAST=E.parent/'foundry-v1.4.4/cast.exe'
assert hashlib.sha256(CAST.read_bytes()).hexdigest()=='610eab893dfb497ad358f7c99b81f4fb0001a5ee8f4f02c0a0ea0a7ec35c90a8'
env={k:v for k,v in os.environ.items() if k.upper() in ('SYSTEMROOT','WINDIR','TEMP','TMP')}
env['PATH']=str(CAST.parent)+os.pathsep+'C:/Windows/System32'
def cast(args):
    p=subprocess.run([str(CAST),*args],capture_output=True,text=True,encoding='utf-8',timeout=10,env=env)
    return dict(arguments=args,exit_code=p.returncode,stdout=p.stdout,stderr=p.stderr)
version=cast(['--version']);assert version['exit_code']==0
artifacts=D.Artifacts();plan=json.loads((E/'wire/complete-review.json').read_bytes());records=[]
def argument(item,value,nested=False):
    typ=item['type']
    if typ.endswith('[]'):return '['+','.join(argument(dict(item,type=typ[:-2]),x,True) for x in value)+']'
    if typ=='tuple':return '('+','.join(argument(x,value[x['name']],True) for x in item['components'])+')'
    if typ=='string':return json.dumps(value,ensure_ascii=False) if nested else value
    if typ=='bool':return 'true' if value else 'false'
    return str(value)
for family in plan['steps']:
    for call in family['calls']:
        _,obj,_=artifacts.contract(call['contract'])
        abi=[x for x in obj['abi'] if x['type']=='function' and x['name']==call['function']]
        assert len(abi)==1
        args=[argument(item,row['value']) for item,row in zip(abi[0]['inputs'],call['arguments'])]
        row=cast(['calldata',call['signature'],*args]);row.update(step=family['id'],contract=call['contract'],function=call['function'])
        row['expected_calldata']=call['calldata'];row['matches']=row['exit_code']==0 and row['stdout'].strip()==call['calldata']
        records.append(row)
result=dict(kind='independent_offline_cast_preseal_calldata',cast_sha256=hashlib.sha256(CAST.read_bytes()).hexdigest(),
    cast_version=version,records=records,calls=len(records),all_match=all(x['matches'] for x in records),
    network_calls=0,transactions=0,scope='ABI bytes only; no simulation, deployment, signer or live authority verification.',
    environment='Minimal public SystemRoot/temp/PATH only; no signing/RPC variables inherited.')
(E/'CAST_CALLS.json').write_bytes((json.dumps(result,indent=2,ensure_ascii=False)+'\n').encode())
print(json.dumps({'calls':len(records),'all_match':result['all_match'],'failures':[x['function'] for x in records if not x['matches']]}))
assert len(records)==24 and result['all_match']
