import json,pathlib,sys
R=pathlib.Path(r'C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
sys.path.insert(0,str(R))
from zzz_ops import preseal_plan as P
from tests_python.preseal_fixture import complete
E=pathlib.Path(__file__).resolve().parent;out=E/'wire';out.mkdir()
blank=P.example();config=R/'config/preseal-preparation.example.json'
assert not config.exists();config.write_bytes((json.dumps(blank,indent=2)+'\n').encode())
value=complete(out);value['settings']['seadrop_upstream']['dropURI']+='/é'
(out/'complete-input.json').write_bytes((json.dumps(value,indent=2,ensure_ascii=False)+'\n').encode())
print(json.dumps({'blank_input':str(config),'complete_input_bytes':(out/'complete-input.json').stat().st_size,
                  'scope':'Controlled unqualified inputs only; no RPC/code/authority admission.'}))
