import datetime,hashlib,json,pathlib,subprocess
R=pathlib.Path(r'C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
E=pathlib.Path(__file__).resolve().parent
def git(*args):return subprocess.check_output(['git',*args],cwd=R).decode('utf-8')
files={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in git('ls-files','-z').split('\0') if n and (R/n).is_file()}
docs=['AGENTS.md','PROJECT_CONTEXT.md','README.md','TODO.md','reports/README.md']+[p.relative_to(R).as_posix() for p in (R/'docs').glob('*.md')]
archive=E/'original-docs';archive.mkdir()
mapped={}
for name in docs:
    dest=hashlib.sha256(name.encode()).hexdigest()+'.bin';(archive/dest).write_bytes((R/name).read_bytes());mapped[name]=dest
baseline={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':git('rev-parse','HEAD').strip(),
 'branch':git('branch','--show-current').strip(),'status':git('status','--porcelain=v1'),
 'files':files,'archived_docs':mapped,'authorization':'Unsigned preseal configuration planner; preserve safeguards/unknownblocked; no signing/deploy/seal/oldtests.'}
(E/'BASELINE.json').write_bytes((json.dumps(baseline,indent=2)+'\n').encode())
print(json.dumps({'head':baseline['head'],'branch':baseline['branch'],'tracked_files':len(files),'archived_docs':len(mapped)}))
