import ast,gzip,hashlib,json,pathlib,re,sys,zipfile
R=pathlib.Path(r'C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
sys.path.insert(0,str(R))
from zzz_ops import preseal_plan as P, deployment_plan as D
E=pathlib.Path(__file__).resolve().parent;report=R/'reports/preseal-planner-20261116';B=json.loads((E/'BASELINE.json').read_bytes())
def sha(raw):return hashlib.sha256(raw).hexdigest()
new=['zzz_ops/preseal_plan.py','scripts/prepare-preseal.py','tests_python/preseal_fixture.py',
     'tests_python/test_preseal_plan.py','tests_python/test_preseal_cli.py']
before=json.loads((E/'FINAL_SOURCE_PINS_BEFORE_TESTS.json').read_bytes())
assert all(sha((R/n).read_bytes())==h for n,h in before.items())
assert before[new[0]]=='b3911ed5b62f2900e957c4cad5242da2868977b7544bffe5d353b6235ddaa0bf'
case_pins={}
for name in new[-2:]:
    tree=ast.parse((R/name).read_bytes());methods={}
    for cls in tree.body:
        if isinstance(cls,ast.ClassDef):
            for method in cls.body:
                if isinstance(method,ast.FunctionDef) and method.name.startswith('test_'):
                    methods[name.replace('/','.').removesuffix('.py')+'.'+cls.name+'.'+method.name]=sha(ast.dump(method,include_attributes=False).encode())
    case_pins.update(methods)
assert len(case_pins)==45
core_stage_names=['core-fixed-targeted-01','core-remaining-01']
selected=[]
for name in core_stage_names:
    stage=json.loads((E/(name+'.json')).read_bytes());assert stage['exit_code']==0
    selected.extend(s for s in stage['command'] if s.startswith('tests_python.test_preseal_plan.'))
assert len(selected)==len(set(selected))==27
cli=json.loads((E/'preseal-cli-case-pins.json').read_bytes())
# CLI fixture/argument tests inject preparation and retain their exact raw bytes.
assert sha((R/new[1]).read_bytes())=='46ea49ae9c1177b4936bf5f04121eb3e1055487c8a3a48ecd0091c1ac022b0e3'
assert sha((R/new[-1]).read_bytes())=='14df7b4f6580fd5fc1072f8b468bfba5faf9937676cd7035795d4810ddb6234d'
for name in ('preseal-cli-representative','preseal-cli-remaining'):
    stage=json.loads((E/(name+'.json')).read_bytes())
    assert stage.get('successful',stage.get('exit_code')==0),stage
for name,code in (('cli-wire-complete-01',0),('cli-wire-blocked-01',2)):
    assert json.loads((E/(name+'.json')).read_bytes())['exit_code']==code
cast=json.loads((E/'CAST_CALLS.json').read_bytes());assert cast['all_match'] and cast['calls']==24
blank=P.example();(E/'wire/blocked-input.json').write_bytes((json.dumps(blank,indent=2)+'\n').encode())
blocked=json.loads((E/'wire/blocked-review.json').read_bytes())
assert blocked['input_sha256']==D.sha(D.canonical(P.validate(blank)))
allowed=set(B['archived_docs'])|{'docs/project-todo.json'}
changed=[n for n,h in B['files'].items() if sha((R/n).read_bytes())!=h]
assert set(changed)<=allowed,changed
assert all(sha((R/n).read_bytes())==h for n,h in B['files'].items() if n.endswith('.py') or n.startswith('src/') and n.endswith('.sol'))
protected=['reports/source-checks.json','scripts/run-fork-checks.py','tests_python/test_fork_runner.py','tests_python/test_frontend_history.py']
assert all(sha((R/n).read_bytes())==B['files'][n] for n in protected)
proof={'baseline_head':B['head'],'baseline_sha256':sha((E/'BASELINE.json').read_bytes()),
 'old_tracked_files':len(B['files']),'permitted_changed_docs':sorted(changed),
 'old_python_files_unchanged':sum(n.endswith('.py') for n in B['files']),
 'solidity_files_unchanged':sum(n.startswith('src/') and n.endswith('.sol') for n in B['files']),
 'old_report_files_unchanged':sum(n.startswith('reports/') and n!='reports/README.md' for n in B['files']),
 'protected_dirty_files':{n:B['files'][n] for n in protected},
 'live_actions_performed':False,'old_tests_run':False,'constructor_and_sequence_planners_byte_identical':True}
(E/'PRESERVATION.json').write_bytes((json.dumps(proof,indent=2)+'\n').encode())
pins={'new_source_raw_sha256':{n:sha((R/n).read_bytes()) for n in new},'tested_sources':before,
 'case_ast_sha256':case_pins,'unique_new_methods':45,'final_core_methods':selected,
 'core_source_scope':'27methods at exact final source;3targeted+24disjointremaining',
 'cli_source_scope':'18injected-preparation methods retain exact CLI/test source and separately recorded core-import pins; final actualCLI wire checks separately.'}
(E/'FINAL_SOURCE_PINS.json').write_bytes((json.dumps(pins,indent=2)+'\n').encode())
names=['BASELINE.json','ABI_REVIEW.json','ABI_CORE_REVIEW.json','CORE_REVIEW.json','PRESERVATION.json',
 'FINAL_SOURCE_PINS_BEFORE_TESTS.json','FINAL_SOURCE_PINS.json',
 'core-before-execution-decimals.py','core-before-native-pins.py','core-final.py',
 'preseal-cli-case-pins.json','run-preseal-cli-stage.py','run_stage.py','baseline.py','prepare_wire_inputs.py',
 'check_cast_calls.py','CAST_CALLS.json','update_docs.py','finalize_evidence.py']
for name in ('core-representative-01','core-execution-decimals-baseline-01','core-native-pins-baseline-01',
 'core-fixed-targeted-01','core-remaining-01','preseal-cli-representative','preseal-cli-remaining',
 'cli-wire-complete-01','cli-wire-blocked-01'):
    names.extend([name+'.json',name+'.log'])
entries=[];(report/'evidence').mkdir(exist_ok=True)
for name in names:
    raw=(E/name).read_bytes();compressed=gzip.compress(raw,mtime=0);target='evidence/'+name+'.gz'
    (report/target).write_bytes(compressed);assert gzip.decompress(compressed)==raw
    entries.append({'source':name,'path':target,'bytes':len(compressed),'sha256':sha(compressed),
                    'original_bytes':len(raw),'original_sha256':sha(raw)})
archive=report/'evidence/wire-artifacts.zip';members=[]
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for file in sorted((E/'wire').glob('*.json')):
        raw=file.read_bytes();info=zipfile.ZipInfo(file.name,(2026,11,16,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
        z.writestr(info,raw);members.append({'path':file.name,'bytes':len(raw),'sha256':sha(raw)})
with zipfile.ZipFile(archive) as z:
    assert z.namelist()==[x['path'] for x in members]
    assert all(sha(z.read(x['path']))==x['sha256'] for x in members)
raw=archive.read_bytes();entries.append({'source':'wire/','path':'evidence/wire-artifacts.zip','bytes':len(raw),'sha256':sha(raw),'members':members})
(report/'EVIDENCE.json').write_bytes((json.dumps({'schema':1,'baseline_head':B['head'],'entries':entries},indent=2)+'\n').encode())
print(json.dumps({'new_methods':45,'core':27,'cli':18,'old_python_unchanged':proof['old_python_files_unchanged'],
 'solidity_unchanged':proof['solidity_files_unchanged'],'evidence_files':len(entries),'wire_members':len(members)}))
