import difflib,json,pathlib,subprocess,sys
R=pathlib.Path(r'C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
sys.path.insert(0,str(R))
from zzz_ops import preseal_plan as P
E=pathlib.Path(__file__).resolve().parent;B=json.loads((E/'BASELINE.json').read_bytes());family='preseal-planner-20261116'
def original(n):return (E/'original-docs'/B['archived_docs'][n]).read_bytes()
def text(n):return original(n).decode('utf-8').replace('\r\n','\n')
def write(n,value):
    old=original(n).splitlines(keepends=True);new=value.splitlines(keepends=True)
    a=[x.decode('utf-8').rstrip('\r\n') for x in old];b=[x.rstrip('\r\n') for x in new];same={}
    for i,j,count in difflib.SequenceMatcher(a=a,b=b,autojunk=False).get_matching_blocks():
        for k in range(count):same[j+k]=old[i+k]
    (R/n).write_bytes(b''.join(same.get(i,line.encode()) for i,line in enumerate(new)))
for name in ('AGENTS.md','PROJECT_CONTEXT.md','README.md','docs/WORK_HANDOFF.md','docs/IMPLEMENTATION_STATUS.md',
             'docs/ROADMAP.md','docs/AUDIT_FINDINGS.md','reports/README.md'):
    old=text(name);paragraph=old.split('\n\n',2)[1]
    assert paragraph.startswith('The [isolated 1,000-NFT history rehearsal]')
    prefix='../' if name.startswith(('docs/','reports/')) else ''
    current=(f'The [unsigned pre-seal planner]({prefix}reports/{family}/REVIEW.md) now prepares twelve ordered configuration\n'
      'families against the trusted current ABI. Unknown own/dependent inputs retain\n'
      'blocked/null calldata; actual bootstrap/code/state and all readiness/approval\n'
      'flags stay unverified/false. It includes the separate human-price orientation\n'
      'write, NFT-forwarded SeaDrop setup, declared native-pin/18-decimal consistency\n'
      'checks and explicit operating-stop diagnostics. No source contract, safeguard,\n'
      'default, signer, existing chain/DB/journal, site/service or paused heartbeat\n'
      'changes. There is no RPC/signing/deployment/sealing/adoption path. Earlier\n'
      f'[1,000-NFT recovery evidence]({prefix}reports/history-scale-rehearsal-20261116/REVIEW.md) retains its finite controlled scope. Actual release\n'
      'inputs, market/provider/VRF/OpenSea/fees/operating acceptance and independent\n'
      'approval remain open; static preparation never supplies those approvals.')
    write(name,old.replace(paragraph,current,1))

manual=text('docs/OPERATOR_MANUAL.md');needle='### Isolated local construction rehearsal'
section=f'''### Prepare unsigned pre-seal configuration

After reviewing constructors/bindings, use the [fresh configuration planner](PRESEAL_CONFIGURATION.md).
It covers twelve setup families with fixed current ABI calls, actual bootstrap
as the conditional pre-seal caller and missing inputs explicitly blocked.

| Tool/action | Required inputs | Example | Effect |
| --- | --- | --- | --- |
| Prepare setup review | Reviewed copy of `config/preseal-preparation.example.json`; NEW output path | `python scripts/prepare-preseal.py --input /review/preseal.json --output /review/NEW-review.json` | Review conditional setup calls |
| Pin current build | Exact supported current build | Add `--build-profile metadata2-20261116` | Freeze current ABI selection |
| Inspect missing values | Output `missing_inputs` and each step's fields | Review `steps[].missing_inputs` | Resolve explicit setup blockers |
| Inspect deliberate stops | Output `explicit_operating_stops` | Empty venues, converterOFF, maximumGap0 | Identify intentionally stopped operations |

Keep unknowns null; exact booleans/decimal strings, nonzero code/review hashes and
all tuple fields are explained in the owning guide. The existing OpenSea proof
artifact is separately digest-pinned/rebuilt, not regenerated from guessed terms.
Supply actual getter-derived helper addresses; never infer factory addresses.
Before seal, governance is not automatically the authorized bootstrap.

Pool admission is followed by `Strategy.setRangeOrientation(poolId,1)` for the
approved ZZZ-in-ETH widths. Original-currency royalties stay separate. No loss,
range, feed, gas or sale default is silently loosened. Exact inputs and declared
stops are visible; static completeness is not operational readiness.

Exit0 is a complete conditional unsigned review;2 is a saved blocked preview;1
is invalid/unavailable/uncertain publication. All approval/runtime/permission
flags remain false. Output is preserved/exclusive; inspect possible complete
output after late failure before choosing another new path. Manifest SHA is not
an on-chain reviewHash or permission. No nonce/gas/signature/seal is prepared.

Independently verify actual fresh/unsealed/zero-mint state, bootstrap/canConfigure,
code/getters/bindings, feeds/markets/VRF and empty upstream SeaDrop lists. Recheck
current sale price/payee/payers/windows and future `setMintEnd` at inclusion;
simulate and review full fees before separately authorized execution. This tool
does not clear/restart a partial setup or adopt an old profile. Existing services,
chains, journals, public-signing restrictions and paused monitoring remain.

'''
assert manual.count(needle)==1;write('docs/OPERATOR_MANUAL.md',manual.replace(needle,section+needle,1))

for name in ('docs/DEPLOYMENT_PREPARATION.md','docs/DEPLOYMENT_SEQUENCE.md','docs/PRODUCTION_PREFLIGHT.md',
             'docs/OPENSEA_MINT.md','docs/RELEASE_CHECKLIST.md'):
    old=text(name)
    paragraph=('\nThe separate [unsigned pre-seal configuration planner](PRESEAL_CONFIGURATION.md) now\n'
        'validates/orders the twelve configuration families using the trusted current\n'
        'ABI, while leaving unknown inputs blocked and live-state/authority/readiness\n'
        'unverified. It includes human-price orientation and fixed NFT-forwarded\n'
        'SeaDrop setup. Constructor/sequence tools and old evidence stay unchanged;\n'
        'no configuration is installed, no seal call prepared and no release approved.\n')
    write(name,old+paragraph)

index=text('docs/README.md')
write('docs/README.md',index+'\n[Unsigned pre-seal configuration](PRESEAL_CONFIGURATION.md): typed current-ABI calls, required inputs, setup order, blocked unknowns and explicit live prerequisites.\n')
ledger=json.loads((R/'docs/project-todo.json').read_bytes())
for area in ledger['areas']:
    for task in area['tasks']:
        if task['id'] not in ('deployment-initcode','native-production-preflight'):continue
        assert task['status']=='progress'
        task['acceptance'].append(f'[Unsigned pre-seal planner](reports/{family}/REVIEW.md): twelve source-defined families '
          'prepare conditional current-ABI calls after constructors/bindings. Unknown own/dependent values block/null calldata; '
          'actual bootstrap, getter-derived helpers, code/state/runtime/authority and all release flags remain unverified. '
          'Human-price orientation1, admitted source18-decimal/native-pin consistency, fixed ETH/ZZZ, bounded venue/converter/confirmation/VRF '
          'and digest-rebuilt source-bound OpenSea/NFT-forwarded upstream setup are explicit. '
          '45distinct new methods pass (27core/18injectedCLI); two actualCLI outcomes and24offlineCast call comparisons pass separately, '
          'not additional test-method counts. Baseline accepted-invalid planner candidates and corrections remain scoped. '
          'No contracts/compiler/defaults/limits, RPC/sign/deploy/seal/nonce/operating adoption or unchanged suites. '
          'Real release inputs, current-state simulations/fees, independent markets/providers/services and release approval remain open.')
        task['text']+=' A separate unsigned pre-seal planner now validates/orders twelve typed configuration families; missing inputs and live prerequisites remain blocked/unverified.'
write('docs/project-todo.json',json.dumps(ledger,indent=2,ensure_ascii=False)+'\n') if 'docs/project-todo.json' in B['archived_docs'] else None
# JSON ledger was not in the Markdown archive: preserve its baseline bytes separately.
if 'docs/project-todo.json' not in B['archived_docs']:
    path=R/'docs/project-todo.json';original_json=path.read_bytes();(E/'original-project-todo.json').write_bytes(original_json)
    normalized=(json.dumps(ledger,indent=2,ensure_ascii=False)+'\n').splitlines(keepends=True)
    before=original_json.splitlines(keepends=True);same={}
    for i,j,n in difflib.SequenceMatcher(a=[x.decode().rstrip('\r\n') for x in before],b=[x.rstrip('\r\n') for x in normalized],autojunk=False).get_matching_blocks():
        for k in range(n):same[j+k]=before[i+k]
    path.write_bytes(b''.join(same.get(i,line.encode()) for i,line in enumerate(normalized)))
subprocess.run([sys.executable,'scripts/sync-project-todo.py'],cwd=R,check=True)
write('TODO.md',(R/'TODO.md').read_text(encoding='utf-8').replace('\r\n','\n'))
example=P.example();example['settings']=P.setting_templates();P.validate(example)
(R/'config/preseal-preparation.example.json').write_bytes((json.dumps(example,indent=2)+'\n').encode())
print(json.dumps({'updated':20,'planner_example_unknowns_retained':True,'broad_tasks_remain_progress':True}))
