from pathlib import Path
import datetime, hashlib, importlib, json, platform, sys, unittest

R=Path(r'C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
E=Path(__file__).resolve().parent;sys.path.insert(0,str(R))
stage=sys.argv[1];names=sys.argv[2:]
module=importlib.import_module('tests_python.test_history_recovery')
if names==['remaining']:
    names=[n for n in unittest.defaultTestLoader.getTestCaseNames(module.HistoryRecoveryTests)
           if n not in ('test_restore_into_new_directory_preserves_every_row_and_exact_reporting',
                        'test_checkpoint_and_profile_bytes_cannot_be_written_beyond_the_package_ceiling',
                        'test_repinned_import_review_cannot_detach_the_full_day_graph_or_producer_shape')]
assert names and len(names)==len(set(names))
paths=['frontend_api/history_recovery.py','scripts/history-recovery.py','tests_python/test_history_recovery.py']
from frontend_api.earnings_checkpoint_v3 import sources
def pins():return {name:hashlib.sha256((R/name).read_bytes()).hexdigest() for name in paths}
before=pins();semantics=sources();caseids=[]
class Result(unittest.TextTestResult):
    def startTest(self,test):caseids.append(test.id());super().startTest(test)
tests=unittest.TestSuite(module.HistoryRecoveryTests(name) for name in names)
log=E/f'history-recovery-{stage}.log'
with log.open('x',encoding='utf-8',newline='\n') as handle:
    result=unittest.TextTestRunner(stream=handle,verbosity=2,resultclass=Result).run(tests)
after=pins();semantic_after=sources()
report=dict(stage=stage,observed_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    python=platform.python_version(),selected_methods=names,executed_methods=caseids,
    tests_run=result.testsRun,failures=[t.id() for t,_ in result.failures],errors=[t.id() for t,_ in result.errors],
    skipped=[(t.id(),why) for t,why in result.skipped],successful=result.wasSuccessful(),
    source_sha256_before=before,source_sha256_after=after,semantic_sources_before=semantics,
    semantic_sources_after=semantic_after,sources_unchanged=before==after and semantics==semantic_after,
    scope='Only new recovery methods. Temporary real SQLite/WAL and synthetic getter/lifecycle truths; no live database, RPC, service, signing or old test methods.')
with (E/f'history-recovery-{stage}.json').open('x',encoding='utf-8',newline='\n') as handle:
    json.dump(report,handle,indent=2,sort_keys=True);handle.write('\n')
print(json.dumps({k:report[k] for k in ('stage','tests_run','successful','sources_unchanged','failures','errors','skipped')}))
if not result.wasSuccessful():print(log.read_text())
raise SystemExit(0 if result.wasSuccessful() and report['sources_unchanged'] else 1)
