from pathlib import Path
import ast, datetime, hashlib, importlib, json, sys, unittest

R=Path(r'C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
E=Path(__file__).resolve().parent
sys.path.insert(0,str(R))
module=importlib.import_module('tests_python.test_history_recovery_cli')
cls=module.HistoryRecoveryCliTests
all_names=unittest.defaultTestLoader.getTestCaseNames(cls)
stage=sys.argv[1]
representative='test_backup_forwards_reviewed_config_and_fresh_paths_with_defaults'
if stage=='representative':names=[representative]
elif stage=='remaining':names=[n for n in all_names if n!=representative]
else:names=sys.argv[2:]
assert names and len(names)==len(set(names)) and set(names)<=set(all_names)
stem='history-cli-'+stage+'-01'
if (E/(stem+'.json')).exists() or (E/(stem+'.log')).exists():raise FileExistsError(stem)
from frontend_api.earnings_checkpoint_v3 import sources
semantic=sources()
source_paths=['frontend_api/history_recovery.py','scripts/history-recovery.py','tests_python/test_history_recovery_cli.py']
def sha(raw):return hashlib.sha256(raw).hexdigest()
def pins():return {n:sha((R/n).read_bytes()) for n in source_paths}
before=pins()
tree=ast.parse((R/source_paths[-1]).read_bytes())
case_ast={n.name:sha(ast.dump(n,include_attributes=False).encode()) for c in tree.body if isinstance(c,ast.ClassDef)
          for n in c.body if isinstance(n,ast.FunctionDef) and n.name in names}
class Results(unittest.TextTestResult):
    def __init__(self,*a,**kw):super().__init__(*a,**kw);self.executed=[]
    def startTest(self,test):super().startTest(test);self.executed.append(test.id())
with (E/(stem+'.log')).open('x',encoding='utf-8',newline='\n') as log:
    result=unittest.TextTestRunner(stream=log,verbosity=2,resultclass=Results).run(unittest.TestSuite(cls(n) for n in names))
after=pins();semantic_after=sources()
data=dict(observed_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    scope='Only new history recovery CLI contracts. Operations injected; no old test bodies, network, live DB, services, signing or deployment.',
    stage=stage,selected_methods=['tests_python.test_history_recovery_cli.HistoryRecoveryCliTests.'+n for n in names],
    selected_case_ast_sha256=case_ast,executed_methods=result.executed,tests_run=result.testsRun,
    failures=[(a.id(),str(b)) for a,b in result.failures],errors=[(a.id(),str(b)) for a,b in result.errors],
    skips=[(a.id(),str(b)) for a,b in result.skipped],source_sha256_before=before,source_sha256_after=after,
    semantic_sources=semantic,semantic_sources_unchanged=semantic==semantic_after,
    successful=result.wasSuccessful() and before==after and semantic==semantic_after,
    production_approved=False)
with (E/(stem+'.json')).open('x',encoding='utf-8',newline='\n') as out:json.dump(data,out,sort_keys=True,indent=2);out.write('\n')
print(json.dumps(dict(stage=stage,tests=result.testsRun,successful=data['successful'],failures=len(result.failures),errors=len(result.errors))))
raise SystemExit(not data['successful'])
