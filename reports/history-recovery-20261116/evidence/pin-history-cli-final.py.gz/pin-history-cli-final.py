from pathlib import Path
import ast,copy,datetime,hashlib,json,sys
R=Path(r'C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
E=Path(__file__).resolve().parent
sys.path.insert(0,str(R))
def sha(raw):return hashlib.sha256(raw).hexdigest()
def nodes(raw):
    return {n.name:sha(ast.dump(n,include_attributes=False).encode()) for c in ast.parse(raw).body if isinstance(c,ast.ClassDef)
            for n in c.body if isinstance(n,ast.FunctionDef)}
current=(R/'scripts/history-recovery.py').read_bytes().replace(b'\r\n',b'\n').decode()
prior=current[:current.index('class SafeArgumentParser(')]+current[current.index('def main('):]
prior=prior.replace("parser=SafeArgumentParser(prog='history-recovery',description=__doc__)",
                    'parser=argparse.ArgumentParser(description=__doc__)')
old_pin=json.loads((E/'history-cli-representative-01.json').read_bytes())['source_sha256_before']['scripts/history-recovery.py']
assert sha(prior.encode())==old_pin
old_tree=ast.parse(prior);new_tree=ast.parse(current)
new_tree.body=[n for n in new_tree.body if not isinstance(n,ast.ClassDef) or n.name!='SafeArgumentParser']
main=next(n for n in new_tree.body if isinstance(n,ast.FunctionDef) and n.name=='main')
parser_call=main.body[0].value
assert isinstance(parser_call.func,ast.Name) and parser_call.func.id=='SafeArgumentParser'
parser_call.func=ast.Attribute(value=ast.Name(id='argparse',ctx=ast.Load()),attr='ArgumentParser',ctx=ast.Load())
parser_call.keywords=[k for k in parser_call.keywords if k.arg!='prog']
assert ast.dump(new_tree,include_attributes=False)==ast.dump(old_tree,include_attributes=False)
prior_path=E/'history-recovery-cli-pre-parser-fix.py'
if prior_path.exists():assert prior_path.read_bytes()==prior.encode()
else:
    with prior_path.open('x',encoding='utf-8',newline='\n') as out:out.write(prior)
test=(R/'tests_python/test_history_recovery_cli.py').read_bytes()
before_test=(E/'test_history_recovery_cli-final.py').read_bytes()
before_nodes,final_nodes=nodes(before_test),nodes(test)
new_method='test_argument_parser_rejects_without_echoing_private_values_and_keeps_valid_control'
assert set(final_nodes)-set(before_nodes)=={new_method}
assert all(final_nodes[n]==digest for n,digest in before_nodes.items())
baseline=json.loads((E/'history-cli-credential-baseline-01.json').read_bytes())
fixed=json.loads((E/'history-cli-credential-fixed-01.json').read_bytes())
assert not baseline['successful'] and len(baseline['failures'])==4 and not baseline['errors']
assert fixed['successful'] and fixed['tests_run']==1 and fixed['selected_case_ast_sha256'][new_method]==final_nodes[new_method]
assert baseline['selected_case_ast_sha256']==fixed['selected_case_ast_sha256']
core=json.loads((E/'history-recovery-remaining27-source2-01.json').read_bytes())
module_sha=sha((R/'frontend_api/history_recovery.py').read_bytes())
assert core['successful'] and core['source_sha256_before']['frontend_api/history_recovery.py']==module_sha
assert core['source_sha256_before']['scripts/history-recovery.py']==old_pin
from frontend_api.earnings_checkpoint_v3 import sources
from frontend_api.history_recovery import producer_sources
assert sources()==fixed['semantic_sources']
result=dict(kind='independent-final-cli-parser-secret-handling-and-source-reuse-review',
    observed_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    tests_executed_by_this_check=0,distinct_new_cli_methods_with_passing_composed_evidence=19,
    sources={n:sha((R/n).read_bytes()) for n in ('frontend_api/history_recovery.py','scripts/history-recovery.py','tests_python/test_history_recovery_cli.py')},
    producer_sources=producer_sources(),semantic_sources=sources(),
    new_parser_class_ast_sha256=sha(ast.dump(next(n for n in ast.parse(current).body if isinstance(n,ast.ClassDef)),include_attributes=False).encode()),
    unchanged_old18_case_and_helper_ast_sha256=before_nodes,new_case_ast_sha256=final_nodes[new_method],
    old_cli_source_sha256=old_pin,
    old_cli_reconstruction='Exact inverse of explicit SafeArgumentParser patch, accepted only after matching prior source-stage hash.',
    change_scope='New SafeArgumentParser.error and main constructor class/fixed prog only; normalized whole module AST otherwise identical. No dispatch/config/error catch/budget/operation API change.',
    baseline='Four parser errors echo deliberately fake credentialed URL/token. Full dummy failure evidence retained.',
    final='New19th case passes all parser-redaction subcases plus validbackup control, same test AST. Existing18 methods not rerun.',
    core_source_scope='Core31 recorded source2 app module remains byte-identical. CLI producer pin changes dynamically with parser source; old whole-file/manifest pins remain historical, never relabelled.',
    review_conclusion='Parser main and inherited subparsers emit fixed usage/prog/error text without rejected values; no additional concrete issue found.',
    production_approved=False)
with (E/'HISTORY_CLI_FINAL_REVIEW.json').open('x',encoding='utf-8',newline='\n') as out:json.dump(result,out,sort_keys=True,indent=2);out.write('\n')
with (E/'test_history_recovery_cli-final19.py').open('xb') as out:out.write(test)
print(json.dumps(dict(new_cli_methods=19,old18_not_rerun=True,core_module_source2_unchanged=True,tests_executed=0)))
