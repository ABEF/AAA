from pathlib import Path
import ast, hashlib, json

R=Path(r'C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
E=Path(__file__).resolve().parent
name='tests_python/test_history_recovery_cli.py'
old=(E/'test_history_recovery_cli-stage1.py').read_bytes();new=(R/name).read_bytes()
def sha(raw):return hashlib.sha256(raw).hexdigest()
def nodes(raw):
    tree=ast.parse(raw)
    return {n.name:sha(ast.dump(n,include_attributes=False).encode())
            for c in tree.body if isinstance(c,ast.ClassDef) for n in c.body if isinstance(n,ast.FunctionDef)}
a,b=nodes(old),nodes(new)
changed=[n for n in a.keys()|b.keys() if a.get(n)!=b.get(n)]
assert changed==['test_known_failures_are_sanitized_and_never_retried'],changed
rep=json.loads((E/'history-cli-representative-01.json').read_bytes())
remaining=json.loads((E/'history-cli-remaining-01.json').read_bytes())
repaired=json.loads((E/'history-cli-harness-repair-01.json').read_bytes())
assert rep['successful'] and repaired['successful'] and remaining['tests_run']==17
methods=rep['executed_methods']+remaining['executed_methods']
assert len(methods)==len(set(methods))==18
bad='tests_python.test_history_recovery_cli.HistoryRecoveryCliTests.'+changed[0]
assert all(x[0].startswith(bad) for x in remaining['failures']) and not remaining['errors']
assert repaired['executed_methods']==[bad]
unchanged=set(a)-set(changed)
assert all(a[n]==b[n] for n in unchanged)
for key in ('frontend_api/history_recovery.py','scripts/history-recovery.py'):
    assert len({stage['source_sha256_before'][key] for stage in (rep,remaining,repaired)})==1
    assert all(stage['source_sha256_before']==stage['source_sha256_after'] for stage in (rep,remaining,repaired))
    assert all(stage['semantic_sources_unchanged'] for stage in (rep,remaining,repaired))
result=dict(scope='Source/case provenance only, no new test execution.',distinct_new_cli_methods_passed=18,
    test_source_initial_sha256=sha(old),test_source_final_sha256=sha(new),
    successful_method_ast_sha256={n:b[n] for n in b if n.startswith('test_')},
    unchanged_class_helper_and_other_test_nodes={n:b[n] for n in unchanged},
    changed_method=changed[0],failure='Only the one method expected literal not approved while CLI correctly said unapproved. Fixed new harness assertion; app/CLI did not change.',
    preserved_failure_subcases=len(remaining['failures']),
    final_case_source='tests_python/test_history_recovery_cli.py',
    application_source_at_stages={k:rep['source_sha256_before'][k] for k in ('frontend_api/history_recovery.py','scripts/history-recovery.py')},
    production_approved=False)
with (E/'history-cli-case-pins.json').open('x',encoding='utf-8',newline='\n') as out:json.dump(result,out,sort_keys=True,indent=2);out.write('\n')
with (E/'test_history_recovery_cli-final.py').open('xb') as out:out.write(new)
print(json.dumps(dict(new_cli_methods=18,unchanged_successes_not_rerun=True,production_approved=False)))
