from pathlib import Path
import ast,datetime,hashlib,json
R=Path(r'C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
E=Path(__file__).resolve().parent
def sha(raw):return hashlib.sha256(raw).hexdigest()
paths=('frontend_api/history_recovery.py','scripts/history-recovery.py','frontend_api/earnings_checkpoint_import.py',
       'tests_python/test_history_recovery_cli.py')
pins={name:sha((R/name).read_bytes().replace(b'\r\n',b'\n')) for name in paths}
initial=json.loads((E/'history-cli-representative-01.json').read_bytes())
assert sha((R/'scripts/history-recovery.py').read_bytes())==initial['source_sha256_before']['scripts/history-recovery.py']
from_nodes={}
for name in paths[:3]:
    tree=ast.parse((R/name).read_bytes())
    from_nodes[name]={n.name:sha(ast.dump(n,include_attributes=False).encode()) for n in tree.body
                      if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
review=dict(kind='independent-source-review-new-history-recovery-cli-and-filesystem-boundaries',
    observed_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_lf_sha256=pins,
    ast_nodes=from_nodes,tests_executed=0,unchanged_cli_source_across_all18_new_methods=True,
    new_cli_tests_passed_by_composed_stages=18,
    resolved_findings=[
      'Import review subset provenance validation now delegates to unchanged source-pinned importer _bind_review for exact shape, graph/counts, all anchors, full86400 earliest timestamp and handoff proof consistency. Original externally reviewed producer hash strings are preserved as provenance only, not code adoption.',
      'New recovery producer map pins the imported sidecar validator dependency as well as its own module/CLI.',
      'Cursor configuration JSON uses tagged encode equality so true/1.0 cannot impersonate integer1.',
      'Artifact bytes reserve the budget before creating/writing output databases; cumulative DB/artifact, manifest and restore-receipt limits checked before their writes.',
      'Source database inode recheck catches replacement across SQLite snapshot; output parent/database directories are synced on supported systems.'
    ],
    checked_boundaries=[
      'Strict source API profile construction uses injected NoNetwork; no signing/service interfaces. Public deployment configs and original sources are not edited.',
      'Portable profile remaps every known database/checkpoint path and replaces the sole accepted root RPC URLs with offline.invalid; original RPC/config content is not printed.',
      'Read-only SQLite connection uses query_only and trusted_schema OFF, ordinary WAL-aware transactions and progress budget. Source journal_mode, checkpoint or deletion is never requested.',
      'Exclusive new directories/files, exact payload inventory/digests, source/object identities, all retained rows and unapproved receipt/profile scope are preserved; failures retain partial outputs.',
      'CLI validates modes/required args/pairs/digests/limits before operations, uses active outer scope, delegates safe operations once and emits fixed sanitized errors without private details.'
    ],
    confirmed_remaining_defects=[],limitations=[
      'Internal source review, not independent release audit or a new execution of core/CLI tests.',
      'Trusted owner-controlled directories required; path lstat checks are not a capability-safe race-proof filesystem sandbox.',
      'Independent SQLite epoch snapshots do not make an atomic cross-database chain snapshot. Local ancestry/overlap consistency does not prove canonical history completeness.',
      'No actual off-host backup/restore, maximum-state or native SQLite hostile-file sandbox qualification from these checks.'
    ],production_approved=False)
with (E/'HISTORY_CLI_REVIEW.json').open('x',encoding='utf-8',newline='\n') as out:json.dump(review,out,sort_keys=True,indent=2);out.write('\n')
print(json.dumps(dict(tests_executed=0,cli18_source_unchanged=True,additional_confirmed_defects=0)))
