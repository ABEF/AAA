from pathlib import Path
import datetime,hashlib,json,sys,tomllib
R=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2');sys.path.insert(0,str(R))
from zzz_ops.abi import keccak256
V=Path('C:/Users/Ali/.codex/visualizations/2026/10/14/01a13899-2be7-76f2-a5d0-72e4804c67b9');T=V/'test-impact-followup-20261117';S=T/'lp-entry-01';Owned=V/'test-seal-deep-review-20261117/execution-fixtures/seadrop';D=R/'reports/test-impact-followup-20261117'
sha=lambda b:hashlib.sha256(b).hexdigest();raw=(S/'RESULT.json').read_bytes();res=json.loads(raw);start=json.loads((S/'START.json').read_bytes());assert res['execution_success'] and res['selected_exact'] and len(res['results'])==2
artifact=Owned/'out/LPOnlyEntryBoundary.t.sol/LPOnlyEntryBoundaryTest.json';ab=artifact.read_bytes();a=json.loads(ab);m=a['metadata'];assert m['settings']['compilationTarget']=={'test/LPOnlyEntryBoundary.t.sol':'LPOnlyEntryBoundaryTest'}
normal=json.loads((V/'test-seal-deep-review-20261117/normal-final-2/normal-size-evidence.json').read_bytes());remaps=[tuple(s.split('=',1)) for s in tomllib.loads((R/'foundry.toml').read_text(encoding='utf-8'))['profile']['default']['remappings']]
closure=[]
for name,item in sorted(m['sources'].items()):
 p=R/name
 if not p.is_file():
  paths=[R/(dst+name[len(prefix):]) for prefix,dst in sorted(remaps,key=lambda x:len(x[0]),reverse=True) if name.startswith(prefix)]
  p=next((p for p in paths if p.is_file()),p)
 assert p.is_file(),name
 rel=p.resolve().relative_to(R).as_posix();content=p.read_bytes();digest=sha(content);k='0x'+keccak256(content).hex();lf='0x'+keccak256(content.replace(b'\r\n',b'\n')).hex();assert item['keccak256'] in (k,lf),(name,'compiler-source mismatch')
 bracket=None
 if rel in start['source_before']:
  bracket=start['source_before'][rel]==res['source_after'][rel]==digest
  assert bracket,(rel,'selected compiler source changed')
 if rel.startswith('src/'):
  assert normal['source_sha256'][rel]==digest,(rel,'production normal source drift')
 closure.append({'compiler_source':name,'physical_path':rel,'raw_sha256':digest,'compiler_keccak256':item['keccak256'],'normalization':'raw' if k==item['keccak256'] else 'LF-only','recorded_before_after_equal':bracket})
assert any(x['physical_path']=='test/LPOnlyEntryBoundary.t.sol' and x['recorded_before_after_equal'] for x in closure)
code=a['deployedBytecode']['object'].removeprefix('0x');base=json.loads((D/'BASELINE.json').read_bytes())
protected={n:sha((R/n).read_bytes()) for n in ['reports/source-checks.json','scripts/run-fork-checks.py','tests_python/test_fork_runner.py','tests_python/test_frontend_history.py']}
assert protected==base['protected']
assert all(sha((R/n).read_bytes())==digest for n,digest in base['production_solidity_sha256'].items())
record={'schema':1,'recorded_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Two changed native-backing fixture methods only; not a full LP-entry or venue suite','selected_method_count':2,'results':res['results'],'execution_success':True,'raw_result_sha256':sha(raw),'raw_stdout_sha256':sha((S/'forge.json').read_bytes()),'artifact_sha256':sha(ab),'runtime_object_sha256':sha(bytes.fromhex(code)),'raw_metadata_sha256':sha(a['rawMetadata'].encode()),'compiler_target':m['settings']['compilationTarget'],'compiler_version':m['compiler']['version'],'compiler_metadata_source_count':len(closure),'selected_src_test_bracket_count':sum(x['recorded_before_after_equal'] is True for x in closure),'other_compiler_bound_dependency_count':sum(x['recorded_before_after_equal'] is None for x in closure),'all_selected_source_closure_unchanged':True,'raw_global_tree_source_changes':res['source_changes'],'global_source_unchanged':res['source_unchanged'],'normal_production_source_pins_preserved':True,'protected_current_sha256':protected,'source_closure':closure,'limits':'Mock liquidity and callback-capable runtime substitution, real Vault/oracle/Rewards/membership state. Not actual token/venue qualification. Total test gas is not a production transaction or 20M/24M profile measurement. Dependencies not before-snapshotted are tied to compiler metadata/current bytes only.','new_signing_rpc_or_deployment':False,'production_approved':False}
with(S/'SOURCE_CLOSURE.json').open('x',encoding='utf-8') as f:json.dump(record,f,indent=2);f.write('\n')
for src,name in [(S/'START.json','LP_ENTRY_START.json'),(S/'RESULT.json','LP_ENTRY_RESULT.json'),(S/'forge.json','LP_ENTRY_FORGE.json'),(S/'forge.stderr.log','LP_ENTRY_STDERR.log'),(S/'SOURCE_CLOSURE.json','LP_ENTRY_SOURCE_CLOSURE.json')]:
 with(D/name).open('xb') as f:f.write(src.read_bytes())
print(json.dumps({k:record[k] for k in ['execution_success','selected_method_count','results','compiler_metadata_source_count','selected_src_test_bracket_count','other_compiler_bound_dependency_count','artifact_sha256','raw_global_tree_source_changes','global_source_unchanged']}))
