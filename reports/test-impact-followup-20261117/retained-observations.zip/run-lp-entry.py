from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
R=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2');V=Path('C:/Users/Ali/.codex/visualizations/2026/10/14/01a13899-2be7-76f2-a5d0-72e4804c67b9');T=V/'test-impact-followup-20261117';D=T/'lp-entry-01';D.mkdir(exist_ok=False);Owned=V/'test-seal-deep-review-20261117/execution-fixtures/seadrop';assert(Owned/'out').is_dir()
forge=V/'foundry-v1.4.4/forge.exe';solc=V/'toolchain-0.8.26/solc.exe';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();normal=json.loads((V/'test-seal-deep-review-20261117/normal-final-2/normal-size-evidence.json').read_bytes());pin=json.loads((V/'test-seal-deep-review-20261117/static-final/static-ea32b2a5d0/START.json').read_bytes());assert sha(forge)==pin['forge_sha256']and sha(solc)==normal['solc_executable_sha256']
methods=['testTokenPullDonationAndCallbackCannotCreateCrossBucketRevenue','testLPPlacementDonationAndCallbackCannotCreateCrossBucketRevenue'];paths=sorted([p for root in('src','test')for p in(R/root).rglob('*')if p.is_file()]+[R/'foundry.toml',R/'package-lock.json'])
snapshot=lambda:{p.relative_to(R).as_posix():sha(p)for p in paths};before=snapshot()
keep=('SystemRoot','WINDIR','SystemDrive','COMSPEC','PATHEXT','TEMP','TMP','USERPROFILE','LOCALAPPDATA','APPDATA','PROGRAMDATA','HOMEDRIVE','HOMEPATH');env={k:os.environ[k]for k in keep if k in os.environ};env.update(PATH=str(forge.parent)+os.pathsep+str(solc.parent)+os.pathsep+str(Path(os.environ.get('SystemRoot','C:/Windows'))/'System32'),FOUNDRY_OFFLINE='true',FOUNDRY_PROFILE='default')
command=[str(forge),'test','--offline','--root',str(R),'--match-path','test/LPOnlyEntryBoundary.t.sol','--match-contract','LPOnlyEntryBoundaryTest','--match-test','|'.join(methods),'--out',str(Owned/'out'),'--cache-path',str(Owned/'cache'),'--use',str(solc),'--json'];record={'schema':1,'baseline':'fdb7562bf56b11d8bade612fdaf7f9a54daf118a','started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':command,'methods':methods,'source_before':before,'forge_sha256':sha(forge),'solc_sha256':sha(solc),'credentials_inherited':False,'owned_warm_cache_only':True,'default_limits_unchanged':True,'public_rpc_signing_or_old_state':False};(D/'START.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8');began=time.monotonic()
with(D/'forge.json').open('xb')as out,(D/'forge.stderr.log').open('xb')as err:
 p=subprocess.Popen(command,cwd=R,env=env,stdout=out,stderr=err)
 try:code=p.wait(timeout=1200)
 except subprocess.TimeoutExpired:p.kill();p.wait();(D/'TIMEOUT.json').write_text(json.dumps({'not_a_pass':True,'owned_pid':p.pid}));raise
results=[];parse_error=None
try:
 output=json.loads((D/'forge.json').read_bytes())
 for host,data in output.items():
  for method,r in data.get('test_results',{}).items():results.append({'host':host,'method':method,'status':r['status'],'reason':r.get('reason'),'kind':r.get('kind')})
except Exception as exc:parse_error=type(exc).__name__
after=snapshot();record.update(finished_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),seconds=round(time.monotonic()-began,3),exit_code=code,results=results,parse_error=parse_error,source_after=after,source_changes=[n for n in before if before[n]!=after.get(n)],source_unchanged=before==after,stdout_sha256=sha(D/'forge.json'),stderr_sha256=sha(D/'forge.stderr.log'),selected_exact=len(results)==2 and{r['method'].removesuffix('()')for r in results}==set(methods))
record['execution_success']=code==0 and record['selected_exact']and not parse_error and all(r['status']=='Success'for r in results)
(D/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8');print(json.dumps({k:record[k]for k in ['exit_code','seconds','selected_exact','results','source_changes','execution_success']}),flush=True)
sys.exit(not record['execution_success'])
