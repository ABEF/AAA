import hashlib,json,subprocess,time
from pathlib import Path
ROOT=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
V=Path('C:/Users/Ali/.codex/visualizations/2026/10/14/01a13899-2be7-76f2-a5d0-72e4804c67b9')
DEST=V/'test-impact-followup-20261117/physical';DEST.mkdir(parents=True,exist_ok=True)
def pins():
    return {p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
            for directory in ('src','test') for p in (ROOT/directory).rglob('*.sol')}
before=pins()
command=[str(V/'foundry-v1.4.4/forge.exe'),'test','--offline','--use',str(V/'toolchain-0.8.26/solc.exe'),
    '--match-path','test/OptionalPortfolioCore.t.sol','--match-contract','OptionalPortfolioCoreTest',
    '--match-test','testSecondMintFailureRollsBackOldPrincipalFeesAndCustody|testAuxiliaryBurnFailureRollsBackWholeMerge|testBothLegsHarvestWithoutReplacingEitherPosition',
    '--out',str(DEST/'out'),'--cache-path',str(DEST/'cache'),'--code-size-limit','1000000','--json']
(DEST/'START.json').write_text(json.dumps({'command':command,'source_before':before},indent=2)+'\n')
start=time.monotonic()
with (DEST/'RESULT.json').open('wb') as out,(DEST/'stderr.log').open('wb') as err:
    result=subprocess.run(command,cwd=ROOT,stdout=out,stderr=err,timeout=600)
after=pins();record={'command':command,'exit_code':result.returncode,'seconds':time.monotonic()-start,
    'source_before':before,'source_after':after,'global_test_source_unchanged':before==after,
    'external_rpc_or_existing_chain_or_signing':False,'harness_size_limit_not_production_admission':True}
try:
    raw=json.loads((DEST/'RESULT.json').read_bytes())
    record['methods']=[{'id':c+'.'+name,'status':value['status'],'reason':value.get('reason')}
        for c,suite in raw.items() for name,value in suite['test_results'].items()]
except Exception as error:record['result_parse_error']=str(error)
(DEST/'EXECUTION.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ('exit_code','seconds','global_test_source_unchanged','methods') if k in record}))
