import hashlib,json,subprocess,time
from pathlib import Path
R=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
V=Path('C:/Users/Ali/.codex/visualizations/2026/10/14/01a13899-2be7-76f2-a5d0-72e4804c67b9')
D=V/'test-impact-followup-20261117/rights-refactored';D.mkdir(parents=True,exist_ok=True)
def pins():return {p.relative_to(R).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for d in ('src','test') for p in (R/d).rglob('*.sol')}
before=pins()
c=[str(V/'foundry-v1.4.4/forge.exe'),'test','--offline','--use',str(V/'toolchain-0.8.26/solc.exe'),'--match-path','test/RightsImpactFollowup20261117.t.sol','--match-contract','RightsImpactFollowup20261117Test','--match-test','testImpactTinyHarvestCheckpointsExitTransfersAndFutureRoyaltiesDrainEveryUnit|testImpactLastRoyaltyCurrencyFailureRollsBackCrossNFTCrossLedgerClaimsThenDrains','--out',str(D/'out'),'--cache-path',str(D/'cache'),'--code-size-limit','1000000','--json']
(D/'START.json').write_text(json.dumps({'command':c,'source_before':before},indent=2)+'\n')
t=time.monotonic()
with (D/'RESULT.json').open('wb') as o,(D/'stderr.log').open('wb') as e:r=subprocess.run(c,cwd=R,stdout=o,stderr=e,timeout=600)
record={'command':c,'exit_code':r.returncode,'seconds':time.monotonic()-t,'source_before':before,'source_after':pins(),'harness_size_limit_not_production_admission':True}
try:
 raw=json.loads((D/'RESULT.json').read_bytes());record['methods']=[{'id':k+'.'+n,'status':x['status'],'reason':x.get('reason'),'gas':x.get('kind',{}).get('gas')} for k,s in raw.items() for n,x in s['test_results'].items()]
except Exception as e:record['parse_error']=str(e)
(D/'EXECUTION.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ('exit_code','seconds','methods','parse_error') if k in record}))
