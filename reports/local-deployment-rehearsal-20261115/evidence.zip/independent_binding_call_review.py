"""Additional read-only check of the exact nineteen submitted admin payloads."""
import hashlib, json, pathlib, sys
E=pathlib.Path(__file__).resolve().parent
R=pathlib.Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
sys.path.insert(0,str(R))
from zzz_ops.abi import keccak256
def load(path):return json.loads(path.read_text())
def addr(value):return int(value,16).to_bytes(32,'big')
def selector(signature):return keccak256(signature.encode())[:4]
instances={x['role']:x for x in load(E/'attempt1/instances.json')}
addresses={r:x['address'] for r,x in instances.items()}
modules=('oracle','liquidity','pools','strategy','vault','rewards','fees','membership','migration','compounder','buyback','nft','nft_canonical','vault_canonical','fees_canonical','canonical')
expected={}
for role in modules:
    expected['bind:'+role]=(addresses['access'],'0x'+(selector('bind(bytes32,address)')+keccak256(instances[role]['contract'].encode())+addr(addresses[role])).hex())
expected['bind:protocol_policy']=(addresses['access'],'0x'+(selector('bindProtocolPolicy(address)')+addr(addresses['protocol_policy'])).hex())
expected['bind:lp_converter']=(addresses['rewards'],'0x'+(selector('bindConverter(address)')+addr(addresses['lp_converter'])).hex())
expected['bind:seadrop_mint']=(addresses['nft'],'0x'+(selector('setSeaDropMint(address)')+addr(addresses['seadrop_mint'])).hex())
actual={}
for path in sorted((E/'attempt1').glob('[0-9][0-9]-bind-*.json')):
    row=load(path);tx=row['transaction'];label=row['label']
    assert label not in actual and int(row['receipt']['status'],16)==1
    actual[label]=(tx['to'].lower(),tx['input'].lower())
assert actual==expected and len(actual)==19
report={'status':'passed','mode':'read_only_original_attempt1_receipts','governance_payloads_independently_reencoded':19,'required_module_bindings':16,'other_bindings':['protocol_policy','lp_converter','seadrop_mint'],'transactions_repeated':0,'arbitrary_or_seal_payloads_submitted':0,'actual':{k:{'target':v[0],'data':v[1]}for k,v in actual.items()}}
raw=(json.dumps(report,sort_keys=True,indent=2)+'\n').encode()
with (E/'INDEPENDENT_BINDING_CALL_REVIEW.json').open('xb')as stream:stream.write(raw)
print(json.dumps({'status':'passed','bindings':19,'sha256':hashlib.sha256(raw).hexdigest()}))
