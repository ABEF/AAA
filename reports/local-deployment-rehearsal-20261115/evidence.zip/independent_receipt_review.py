"""Read-only independent reconciliation of the one already-recorded local run."""
import gzip, hashlib, json, pathlib, sys

E = pathlib.Path(__file__).resolve().parent
R = pathlib.Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
A = E / 'attempt1'
B = R / 'reports/manual-reference-swap-fix-20261115/build'
sys.path.insert(0, str(R))
from zzz_ops.abi import keccak256

def load(path):
    if str(path).endswith('.gz'):
        with gzip.open(path, 'rt', encoding='utf8') as stream: return json.load(stream)
    return json.loads(path.read_text(encoding='utf8'))

def sha(raw): return hashlib.sha256(raw).hexdigest()
def check(ok, message):
    if not ok: raise AssertionError(message)
def word(value): return int(value).to_bytes(32, 'big')
def encode(types, values):
    head, tail = [], b''
    for kind, value in zip(types, values, strict=True):
        if kind in ('bytes', 'string'):
            raw = value.encode('utf8') if kind == 'string' else bytes.fromhex(value[2:])
            head.append(word(32 * len(types) + len(tail)))
            tail += word(len(raw)) + raw + bytes((-len(raw)) % 32)
        elif kind == 'address': head.append(word(int(value, 16)))
        elif kind == 'bytes32': head.append(bytes.fromhex(value[2:]))
        elif kind == 'uint256': head.append(word(value))
        else: raise AssertionError('Unexpected constructor type ' + kind)
    return b''.join(head) + tail

def calldata(signature, types=(), values=()):
    return '0x' + (keccak256(signature.encode())[:4] + encode(types, values)).hex()

def main():
    stage = load(A / 'source-stage.json')
    for name, digest in stage['accepted_build_files_sha256'].items():
        check(sha((B / name).read_bytes()) == digest, 'Accepted build file drift: ' + name)
    for name, digest in stage['tool_sources_sha256'].items():
        check(sha((R / name).read_bytes()) == digest, 'Tool source drift: ' + name)
    check(load(A / 'SOURCE_UNCHANGED.json') == stage['tool_sources_sha256'], 'After-run tool pin disagreement')
    for name, digest in stage['source_sha256'].items():
        check(sha((R / name).read_bytes()) == digest, 'Current normal source drift: ' + name)
    compiler = load(B / 'compiler-output.json.gz')
    inp = load(B / 'compiler-input.json.gz')
    check(len(inp['sources']) == 100, 'Expected accepted 100-source closure')
    check(inp['settings']['viaIR'] is True and inp['settings']['evmVersion'] == 'cancun', 'Normal settings changed')
    check(inp['settings']['optimizer']['runs'] == 1, 'Optimizer changed')
    contracts = {name: (source, obj) for source, objs in compiler['contracts'].items() for name, obj in objs.items()}
    process, cleanup = load(A / 'node/process.json'), load(A / 'node/cleanup.json')
    genesis = load(A / 'node/genesis.json')
    check(process['chain_id'] == genesis['config']['chainId'] == 4663, 'Synthetic chain identity')
    check(int(genesis['gasLimit'], 16) == 32_000_000 and not process['size_limit_override'], 'Normal local EIP limits')
    command = process['command']
    check(command[command.index('--host') + 1] == '127.0.0.1', 'Loopback host')
    check(command[command.index('--accounts') + 1] == '0' and '--silent' in command, 'No generated keys/banner')
    check(process['port'] not in (8902, 57306), 'Protected port')
    check(process['minimal_environment'] and not process['public_rpc'], 'Environment scope')
    check(sha(pathlib.Path(command[0]).read_bytes()) == process['binary_sha256'], 'Exact owned binary')
    check(cleanup['pid'] == process['pid'] and cleanup['owned_node_stopped'] and cleanup['pending_submission'] is None and cleanup['failure_type'] is None, 'Clean own-process stop')
    rows = [load(p) for p in sorted(A.glob('[0-9][0-9]-*.json'))]
    check(len(rows) == 44, 'Exactly 44 receipt records')
    check(sum(x['label'].startswith('create:') for x in rows) == 25, 'Exactly 25 top-level deployments')
    check(sum(x['label'].startswith('bind:') for x in rows) == 19, 'Exactly 19 bindings')
    check(len({x['transaction']['hash'] for x in rows}) == 44, 'No duplicate receipts')
    wire = load(A / 'node/rpc-records.json.gz')
    check(len(wire) == 3567, 'Expected exact preserved wire capture')
    check([x['request']['id'] for x in wire] == list(range(1, len(wire)+1)), 'Complete ordered wire identifiers')
    for x in wire:
        check(x['request']['id'] == x['response']['id'] and 'result' in x['response'] and 'error' not in x['response'], 'Successful exact RPC response')
    mutations = [(i, x) for i, x in enumerate(wire) if x['request']['method'] in ('anvil_impersonateAccount', 'eth_sendTransaction')]
    check(len(mutations) == 45 and mutations[0][1]['request']['method'] == 'anvil_impersonateAccount', 'One impersonation and 44 submissions only')
    allowed_methods = {'eth_chainId','eth_getBlockByNumber','eth_getCode','eth_call','eth_estimateGas','eth_getTransactionCount','eth_gasPrice','eth_getTransactionReceipt','eth_getTransactionByHash','debug_traceTransaction','anvil_impersonateAccount','eth_sendTransaction'}
    check({x['request']['method'] for x in wire} <= allowed_methods, 'No reset/seal/state/admin-RPC method')
    sender = '0x000000000000000000000000000000000000a0a0'
    check(mutations[0][1]['request']['params'] == [sender], 'Fixed legitimate disposable bootstrap')
    owns = load(A / 'node/socket-ownership.json')
    check(len(owns) == 90, 'All actual guard observations recorded')
    known = {a.lower(): row['code'].lower() for a,row in genesis['alloc'].items() if row.get('code') not in (None, '0x')}
    creates = {}
    traces = {}
    for row in rows:
        if not row['label'].startswith('create:'): continue
        filename = row['label'].replace(':','-')
        candidates = list(A.glob('[0-9][0-9]-' + filename + '-trace.json.gz'))
        check(len(candidates) == 1, 'One exact CREATE trace')
        trace = load(candidates[0]); traces[row['transaction']['hash']] = trace
        def walk(frame):
            check(not frame.get('error'), 'No reverted CREATE call tree')
            if frame['type'] in ('CREATE','CREATE2'):
                check(frame['type'] == 'CREATE', 'No predicted CREATE2 deployment')
                target = frame['to'].lower(); check(target not in creates, 'Unique created address')
                creates[target] = {'frame': frame, 'trace': candidates[0].name, 'transaction_hash': row['transaction']['hash']}
            for child in frame.get('calls', []): walk(child)
        walk(trace)
    check(len(creates) == 39, '39 executed normal contract creations')
    owner_index = {o['before_rpc_index']: o for o in owns}
    seen_debug, guard_ends = set(), set()
    for i, x in enumerate(wire):
        if i in owner_index:
            o = owner_index[i]
            check(o['observed_listener_pids'] == [process['pid']] and o['expected_pid'] == process['pid'] and o['port'] == process['port'], 'Exact child socket ownership')
            chain, block = wire[i], wire[i+1]
            check(chain['request']['method'] == 'eth_chainId' and int(chain['response']['result'],16) == 4663, 'Guard chain read')
            check(block['request']['params'] == ['0x0',False] and block['response']['result']['hash'] == process['genesis_hash'] and int(block['response']['result']['gasLimit'],16) == 32_000_000, 'Guard genesis identity')
            observed_pins = {}
            for y in wire[i+2:i+2+len(known)]:
                check(y['request']['method'] == 'eth_getCode' and y['request']['params'][1] == 'latest', 'Guard reads only exact current code')
                target = y['request']['params'][0].lower()
                check(target not in observed_pins, 'No duplicate runtime pin read')
                observed_pins[target] = y['response']['result'].lower()
            check(observed_pins == known, 'Every seeded/created runtime pinned before mutation')
            guard_ends.add(i + 2 + len(known))
        if x['request']['method'] == 'debug_traceTransaction':
            txhash = x['request']['params'][0]
            check(txhash not in seen_debug and x['response']['result'] == traces[txhash], 'Exact unmodified actual CREATE trace response')
            seen_debug.add(txhash)
            for target, c in creates.items():
                if c['transaction_hash'] == txhash: known[target] = c['frame']['output'].lower()
        if x['request']['method'] in ('anvil_impersonateAccount','eth_sendTransaction'):
            check(i in guard_ends, 'Mutation immediately follows full successful exact-PID/genesis/runtime guard')
    sends = [x for _, x in mutations[1:]]
    gas = []
    for n, (row, sent) in enumerate(zip(rows, sends, strict=True)):
        tx, receipt = row['transaction'], row['receipt']
        request = sent['request']['params'][0]
        check(sent['response']['result'] == tx['hash'] == receipt['transactionHash'], 'Wire/record/receipt hash agreement')
        check(int(tx['nonce'],16) == n and int(request['nonce'],16) == n, 'Strict EOA nonce sequence without resends')
        check(tx['from'].lower() == receipt['from'].lower() == request['from'] == sender, 'Only fixed disposable EOA submissions')
        check(int(tx['value'],16) == int(request['value'],16) == 0, 'No native payment')
        check(int(tx['chainId'],16) == 4663 and int(receipt['status'],16) == 1, 'Included successful local transaction')
        check(tx['blockHash'] == receipt['blockHash'] and int(tx['blockNumber'],16) == int(receipt['blockNumber'],16) == n+1, 'One included receipt per successive local block')
        check(tx['input'].lower() == request['data'].lower(), 'Actual input exactly submitted')
        estimate, padded, used = row['estimated_gas'], row['padded_gas'], int(receipt['gasUsed'],16)
        check(padded == (estimate*12500+9999)//10000 == int(tx['gas'],16) == int(request['gas'],16), 'Complete 25% padded exact gas')
        check(used <= padded <= 32_000_000 and row['padding_bps'] == 12500, 'Original block cap')
        matching = [w for w in wire if w['request']['method'] == 'eth_call' and w['request']['params'][0].get('data','').lower() == tx['input'].lower() and w['request']['params'][0].get('from') == sender]
        # Original attempt stores mutable transaction objects. These earlier
        # requests were overwritten in memory with later gas/nonce/fee fields.
        # Preserve this genuine evidence limit instead of inventing exact wire
        # fields from the source. Only the second call's gas was already padded.
        check(len(matching) == 2 and [int(w['request']['params'][0]['gas'],16) for w in matching] == [padded,padded], 'Known original request-alias recording defect')
        check(all(w['response']['result'] == row['simulation_return'] for w in matching), 'Exact simulated constructor/bind output preserved')
        ests = [w for w in wire if w['request']['method'] == 'eth_estimateGas' and w['request']['params'][0].get('data','').lower() == tx['input'].lower()]
        check(len(ests) == 1 and int(ests[0]['response']['result'],16) == estimate, 'One actual estimate per payload')
        receipts = [w for w in wire if w['request']['method'] == 'eth_getTransactionReceipt' and w['request']['params'] == [tx['hash']] and w['response']['result'] is not None]
        check(len(receipts) == 1 and receipts[0]['response']['result'] == receipt, 'Captured included receipt unmodified')
        gas.append({'label':row['label'],'estimated_gas':estimate,'padded_gas':padded,'receipt_gas_used':used,'transaction_hash':tx['hash']})
    plan, instances = load(A/'offline-plan.json'), load(A/'instances.json')
    check(len(instances) == 39 and not plan['production_approved'] and not plan['ready_for_submission'], 'Offline plan is not release approval')
    by_role = {x['role']:x for x in instances}; addresses = {r:x['address'] for r,x in by_role.items()}
    parents = {'royalty_factory':'access','activation_assets_factory':'access','lp_balance_math':'balancing_router','lp_position_executor':'liquidity','contribution_pricing':'oracle','activation_assets':'activation_assets_factory','activation_entry':'pools','royalty_rewards':'royalty_factory','claim_router':'nft','rewards_canonical':'rewards','custody_validation':'migration','lp_v4_executor':'lp_converter','royalty_data_part0':'royalty_factory','royalty_data_part1':'royalty_factory'}
    getters = {'royalty_factory':('access','royaltyFactory()'),'activation_assets_factory':('access','activationAssetsFactory()'),'lp_balance_math':('balancing_router','balanceMath()'),'lp_position_executor':('liquidity','positionOperator()'),'contribution_pricing':('oracle','contributionPricing()'),'activation_assets':('pools','activationAssets()'),'activation_entry':('pools','activationEntry()'),'royalty_rewards':('nft','royaltyRewards()'),'claim_router':('nft','claimRouter()'),'rewards_canonical':('rewards','canonicalModule()'),'custody_validation':('migration','validation()'),'lp_v4_executor':('lp_converter','v4Executor()'),'royalty_data_part0':('royalty_factory','part0()'),'royalty_data_part1':('royalty_factory','part1()')}
    resolved = {'activation_entry':addresses['activation_assets'],'claim_router':addresses['royalty_rewards']}
    graph = []
    for p in plan['instances']:
        r, name = p['role'], p['contract']; actual = by_role[r]; proof = creates[actual['address']]; frame = proof['frame']
        source, obj = contracts[name]
        abi_types = [x['type'] for a in obj['abi'] if a['type']=='constructor' for x in a['inputs']]
        check(abi_types == p['constructor_types'], 'Actual compiler constructor ABI')
        values = [a['value'] for a in p['arguments']]
        values = [resolved[r] if x is None else x for x in values]
        creation = bytes.fromhex(obj['evm']['bytecode']['object'])
        expected = creation + encode(abi_types, values)
        check(frame['input'].lower() == actual['full_initcode_hex'].lower() == '0x'+expected.hex(), 'Independently ABI-encoded exact normal creation input')
        check(frame['from'].lower() == (addresses[parents[r]] if r in parents else sender), 'Actual source parent graph')
        runtime = bytes.fromhex(frame['output'][2:])
        if name=='ZZZRoyaltyCodeData': check(runtime == b'\x5f\x5f\xfd'+bytes.fromhex(values[0][2:]), 'Exact inert returned carrier runtime')
        else: check(len(runtime) == len(bytes.fromhex(obj['evm']['deployedBytecode']['object'])), 'Actual immutable-patched runtime length')
        check(len(expected)<=49152 and len(runtime)<=24576, 'Unrelaxed EIP3860/EIP170 bounds')
        check(sha(runtime)==actual['runtime_sha256'] and '0x'+keccak256(runtime).hex()==actual['runtime_keccak256'], 'Actual runtime hash')
        code_reads = [w for w in wire if w['request']['method']=='eth_getCode' and w['request']['params']==[actual['address'],'latest']]
        check(code_reads and all(w['response']['result'].lower()=='0x'+runtime.hex() for w in code_reads), 'All actual getCode matches CREATE returned runtime')
        if r in getters:
            parent, signature = getters[r]
            got = [w for w in wire if w['request']['method']=='eth_call' and w['request']['params'][0]=={'to':addresses[parent],'data':calldata(signature)}]
            check(got and all('0x'+w['response']['result'][-40:]==actual['address'] for w in got), 'Internal child discovered by real source getter')
        graph.append({'role':r,'contract':name,'address':actual['address'],'creator':frame['from'].lower(),'initcode_bytes':len(expected),'runtime_bytes':len(runtime),'runtime_sha256':sha(runtime),'trace_file':proof['trace']})
    bindings=load(A/'bindings.json')
    check(len(bindings)==112, '112 explicit post-deployment read checks')
    for b in bindings:
        sig=b['signature']; types=[x for x in sig[sig.index('(')+1:-1].split(',') if x]
        payload=calldata(sig,types,b.get('arguments',[]))
        matching=[w for w in wire if w['request']['method']=='eth_call' and w['request']['params'][0]=={'to':addresses[b['role']],'data':payload}]
        check(matching and all(w['response']['result']==b['actual'] for w in matching), 'Poststate binding comes from exact real wire read')
        if 'expected' in b: check(b['actual']==b['expected'], 'Expected binding state')
    final={(b['role'],b['signature']):b for b in bindings}
    check(int(final['access','isSealed()']['actual'],16)==0 and int(final['access','bootstrap()']['actual'],16)==int(sender,16), 'Never sealed and bootstrap retained')
    check(int(final['access','governance()']['actual'],16)==int(sender,16), 'Legitimate governed bootstrap')
    check(int(final['vault','bucketCount()']['actual'],16)==0 and int(final['nft','mintedCount()']['actual'],16)==0, 'No market or mint operation')
    check(not any(x['transaction']['input'].startswith(calldata('seal()')) for x in rows), 'No seal selector submitted')
    result=load(A/'RESULT.json')
    check(result['total_actual_gas']==sum(g['receipt_gas_used'] for g in gas) and result['worst_padded_gas']==max(g['padded_gas'] for g in gas), 'Independent gas sums')
    report={'status':'receipt_and_runtime_reconciliation_passed_with_recording_limitation','mode':'read_only_existing_evidence_only','actual_chain_executions_performed_by_reviewer':0,'source_stage':stage['tool_sources_sha256'],'accepted_normal_source_count':len(inp['sources']),'wire_records':len(wire),'socket_ownership_observations':len(owns),'mutations':45,'impersonations':1,'submitted_transactions':44,'top_level_create_receipts':25,'internal_creates':14,'binding_receipts':19,'actual_contract_instances':39,'poststate_getter_checks':112,'total_receipt_gas':sum(g['receipt_gas_used'] for g in gas),'worst_padded_gas':max(g['padded_gas'] for g in gas),'gas_by_transaction':gas,'independent_graph':graph,'cleanup':cleanup,'original_request_alias_recording_defect':{'affected_transaction_groups':44,'affected_request_types':['first full-cap eth_call','eth_estimateGas','padded eth_call late nonce/gasPrice fields'],'full_cap_gas_wire_independently_authenticated':False,'source_derived_original_first_call_gas':32000000,'second_call_padded_gas_field_preserved':True,'actual_submitted_transactions_receipts_and_CREATE_outputs_authenticated':True},'limitations':['Original Node.wire retained mutable request objects: earlier simulation/estimate gas, nonce and gasPrice fields were overwritten by later transaction mutation. The first full-cap call input is source-derived, not an exact archived transport proof; original bytes are preserved.','Synthetic owned Anvil4663, not a Robinhood deployment or provider/fee qualification.','Native external dependencies are constructor-only revert/selector doubles, not admitted production runtimes.','Exact archived SeaDrop runtime is seeded with controlled storage; mint/market/VRF use is unqualified.','No seal, operating configuration, public transaction, unchanged suite or compiler was executed.','Normal compiler templates have no immutableReferences; actual runtime identity is proven through exact executed initcode, actual CREATE outputs and every recorded getCode, not an unpatched-template comparison.']}
    target=E/'INDEPENDENT_RECEIPT_REVIEW.json'
    raw=(json.dumps(report,indent=2,sort_keys=True)+'\n').encode()
    with target.open('xb') as stream:stream.write(raw)
    print(json.dumps({'status':report['status'],'output':str(target),'sha256':sha(raw),'receipt_count':44,'instances':39,'raw_gas':report['total_receipt_gas'],'worst_padded_gas':report['worst_padded_gas']}))

if __name__=='__main__':main()
