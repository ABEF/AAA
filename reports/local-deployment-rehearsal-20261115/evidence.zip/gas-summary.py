import hashlib,json,pathlib
E=pathlib.Path(__file__).resolve().parent;A=E/'attempt1'
rows=[]
for p in sorted(A.glob('[0-9][0-9]-*.json')):
 v=json.loads(p.read_text());tx=v['transaction'];receipt=v['receipt'];actual=int(receipt['gasUsed'],16)
 assert int(tx['value'],16)==0 and int(receipt['status'],16)==1
 assert v['padded_gas']==(v['estimated_gas']*12500+9999)//10000
 assert actual<=v['padded_gas']<=32000000
 rows.append({'sequence':int(p.name[:2]),'label':v['label'],'nonce':int(tx['nonce'],16),'hash':receipt['transactionHash'],'estimated_gas':v['estimated_gas'],'padded_gas':v['padded_gas'],'actual_gas':actual,'receipt_file':p.name,'receipt_sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
assert len(rows)==44 and [r['nonce'] for r in rows]==list(range(44))
result={'scope':'Existing first local receipt data only; no new chain calls or test reruns','receipts':rows,'total_actual_gas':sum(r['actual_gas'] for r in rows),'creation_actual_gas':sum(r['actual_gas'] for r in rows if r['label'].startswith('create:')),'binding_actual_gas':sum(r['actual_gas'] for r in rows if r['label'].startswith('bind:')),'worst_padded':max(rows,key=lambda r:r['padded_gas']),'local_block_gas_limit':32000000,'padding_bps':12500,'fees_qualified':False}
(E/'GAS_SUMMARY.json').write_text(json.dumps(result,indent=2)+'\n')
table='| Creation | Estimated gas | Padded limit (25%) | Receipt gas |\n| --- | ---: | ---: | ---: |\n'
for r in rows:
 if r['label'].startswith('create:'):table+='| '+r['label'][7:]+' | '+f"{r['estimated_gas']:,} | {r['padded_gas']:,} | {r['actual_gas']:,} |\n"
(E/'GAS_TABLE.md').write_text(table)
print(json.dumps({'receipts':44,'total_raw':result['total_actual_gas'],'creation_raw':result['creation_actual_gas'],'binding_raw':result['binding_actual_gas'],'worst':result['worst_padded']}))
