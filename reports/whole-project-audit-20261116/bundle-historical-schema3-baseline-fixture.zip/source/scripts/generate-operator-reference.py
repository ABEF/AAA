# explicit operator reference consumer
