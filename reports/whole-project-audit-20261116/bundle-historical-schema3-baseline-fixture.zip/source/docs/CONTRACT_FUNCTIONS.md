# frozen operator fixture
