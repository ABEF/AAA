"""Offline fee/impact/spot analysis of retained actual-core call traces."""
import argparse,json,pathlib,sys
HERE=pathlib.Path(__file__).resolve().parent
sys.path.insert(0,str(HERE));import run_market as m
from zzz_ops.abi import keccak256,decode_words

def typ(v):
    return ('('+','.join(typ(c)for c in v['components'])+')'+v['type'][5:])if v['type'].startswith('tuple')else v['type']
def run(attempt):
    objects=m.deployer.load_production_objects();abi=objects['contracts']['src/ZZZLPBalancer.sol']['ZZZLPBalancer']['abi']
    selectors={}
    for f in abi:
        if f['type']=='function':
            sig=f['name']+'('+','.join(typ(v)for v in f['inputs'])+')'
            selectors['0x'+keccak256(sig.encode()).hex()[:8]]=f['name']
    def walk(n,p='0'):
        yield p,n
        for i,c in enumerate(n.get('calls',[])):yield from walk(c,p+'.'+str(i))
    summary=[]
    for casefile in sorted(attempt.glob('*-activation100.json')):
        case=json.loads(casefile.read_text());trace=case.get('trace')
        if not isinstance(trace,dict):continue
        routes=[];quotes=[];failures=[]
        for path,node in walk(trace):
            data=node.get('input','0x');name=selectors.get(data[:10])
            if name=='routePlan':
                words=decode_words('0x'+data[10:])
                if len(words)==21:
                    x=[int(v,16)for v in words]
                    routes.append({'path':path,'price':x[1],'lower_sqrt':x[2],'upper_sqrt':x[3],
                        'amount0':x[4],'amount1':x[5],'lower0':x[6],'upper0':x[7],'lower1':x[8],'upper1':x[9],
                        'scale1':x[10],'reference_sqrt':x[11],'additional_loss_bps':x[12],'main_floor_bps':x[13],
                        'venue':'0x'+words[18],'direction':bool(x[19]),'require_active':bool(x[20]),'error':node.get('error')})
            elif name=='quoteCandidate':
                words=decode_words('0x'+data[10:]);x=[int(v,16)for v in words]
                if len(x)!=7:continue
                quote={'path':path,'lp_fee_pips':x[2],'native_input':bool(x[5]),'amount_in':x[6],'error':node.get('error'),'gas_used':node.get('gasUsed')}
                out=node.get('output','0x')
                if len(out)==194:
                    y=[int(v,16)for v in decode_words(out)];quote.update(amount_out=y[0],post_sqrt=y[1],post_tick=y[2]-(1<<256)if y[2]>=1<<255 else y[2])
                    if routes:
                        r=routes[-1];protocol=1000;fee=protocol+x[2]-protocol*x[2]//1_000_000
                        def quoted(a):
                            value=a*(r['upper0']if x[5]else r['upper1'])//(10**18 if x[5]else r['scale1'])
                            return value*(r['scale1']if x[5]else 10**18)//(r['lower1']if x[5]else r['lower0'])
                        oracle=quoted(x[6]);gross=oracle*9800//10000
                        after_fee=x[6]*(1_000_000-fee)//1_000_000
                        extra=(quoted(after_fee)*(10000-r['additional_loss_bps'])+9999)//10000
                        root=y[1]*10**18//r['reference_sqrt'];ratio=root*root//10**18
                        deviation=abs(ratio-10**18)
                        quote.update(oracle_output=oracle,effective_directional_fee_pips=fee,gross2percent_minimum=gross,
                            fee_net_additional1percent_minimum=extra,captured_minimum=max(gross,extra),
                            output_floor_pass=y[0]>=max(gross,extra),spot_deviation_scaled18=deviation,
                            configured_spot_max_bps=100,spot_guard_pass=deviation<=100*10**14)
                quotes.append(quote)
            if node.get('error')and data[:10]not in selectors:
                failures.append({'path':path,'to':node.get('to'),'selector':data[:10],'output':node.get('output'),'error':node.get('error'),'gas_used':node.get('gasUsed')})
        result={'case':case['case'],'recorded_status':case['status'],'routes':routes,'quotes':quotes,'other_reverted_calls':failures,
            'method':'Integer arithmetic matches retained source _quoted/_minimum/_validSpot; protocol1000 each direction per same-anchor selectedslot0; no RPC',
            'depth_failure_not_inferred_from_guard_rejection':True,'source_sha256':m.digest(m.ROOT/'src/ZZZLPBalancer.sol')}
        m.save(attempt/(case['case']+'-quote-diagnosis.json'),result)
        summary.append({'case':case['case'],'quotes':len(quotes),'output_pass':sum(q.get('output_floor_pass',False)for q in quotes),
            'spot_pass':sum(q.get('spot_guard_pass',False)for q in quotes),'routes':len(routes)})
    print(json.dumps(summary))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--attempt',required=True);a=p.parse_args();run(HERE/a.attempt)
