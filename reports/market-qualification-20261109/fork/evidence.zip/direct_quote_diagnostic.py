"""Read-only traces against ONLY the new owned diagnostic fork's Balancer.

eth_call sender=self exercises its exact self-only quote logic in simulation;
this grants no real authority and performs no transaction/state write. Core swap
delta in the trace distinguishes partial fill from a generic quote failure.
"""
import argparse,json,pathlib,sys,time,urllib.request
HERE=pathlib.Path(__file__).resolve().parent
sys.path[:0]=[str(HERE),str(pathlib.Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2'))]
import run_market as m
from zzz_ops.abi import keccak256,decode_words

def run(attempt):
    meta=json.loads((attempt/'owned-fork.json').read_text());url=meta['url']
    if not url.startswith('http://127.0.0.1:') or ':8902'in url:raise ValueError('New owned diagnostic fork required')
    sequence=0
    def rpc(method,params):
        nonlocal sequence
        if method not in('eth_chainId','web3_clientVersion','eth_getBlockByNumber','eth_getCode','eth_call','debug_traceCall'):raise ValueError('Read only')
        sequence+=1
        req=urllib.request.Request(url,json.dumps({'jsonrpc':'2.0','id':sequence,'method':method,'params':params}).encode(),{'Content-Type':'application/json'})
        with urllib.request.urlopen(req,timeout=120)as f:raw=f.read(32*1024*1024+1)
        if len(raw)>32*1024*1024:raise ValueError('Bounded response')
        result=json.loads(raw)
        if 'error'in result:raise m.LocalRPCError(method,result['error'])
        return result['result']
    if int(rpc('eth_chainId',[]),16)!=4663 or'anvil'not in rpc('web3_clientVersion',[]).lower():raise ValueError('Wrong fork')
    if rpc('eth_getBlockByNumber',[meta['anchor']['number'],False])['hash']!=meta['anchor']['hash']:raise ValueError('Wrong anchor')
    rows=[json.loads(x)for x in(attempt/'deployment/deployment-transactions.ndjson').read_text().splitlines()]
    confirmed=[x for x in rows if x.get('label')=='deploy:lp_balancer'and x['event']=='confirmed']
    if len(confirmed)!=1:raise ValueError('Exactly one confirmed new balancer required')
    balancer=confirmed[0]['receipt']['contractAddress']
    lab=m.deployer.RehearsalDeployment.__new__(m.deployer.RehearsalDeployment);lab.cast=m.V/'foundry-v1.4.4/cast.exe'
    slot_sig='getSlot0(bytes32)';swap_selector='0x'+keccak256(b'swap((address,address,uint24,int24,address),(bool,int256,uint160),bytes)').hex()[:8]
    def walk(node,path='0'):
        yield path,node
        for i,child in enumerate(node.get('calls',[])):yield from walk(child,path+'.'+str(i))
    results=[]
    for amount in(1,10**18):
        data=lab.calldata('quoteCandidate((address,address,uint24,int24,address),bool,uint256)',
            '('+','.join((m.ZERO,m.DEPS['zzz'],'10020','200',m.ZERO))+')',False,amount)
        tx={'from':balancer,'to':balancer,'data':data,'gas':hex(1_000_000)}
        head=rpc('eth_getBlockByNumber',['latest',False])
        trace=rpc('debug_traceCall',[tx,'latest',{'tracer':'callTracer','timeout':'60s','tracerConfig':{'withLog':True}}])
        deltas=[]
        for path,node in walk(trace):
            if node.get('to','').lower()==m.DEPS['pool_manager']and node.get('input','').startswith(swap_selector):
                output=node.get('output','0x')
                decoded=None
                if len(output)==66:
                    value=int(output,16);a0=value>>128;a1=value&((1<<128)-1)
                    if a0>=1<<127:a0-=1<<128
                    if a1>=1<<127:a1-=1<<128
                    decoded={'native_delta':str(a0),'zzz_delta':str(a1),'requested_zzz':str(amount),'consumed_zzz':str(-a1),'complete_input':-a1==amount}
                deltas.append({'path':path,'decoded':decoded,'core_error':node.get('error'),'logs':node.get('logs',[])})
        record={'source':'actual current normal90 LPBalancer self-only quote via readonly eth_call context',
            'new_owned_fork_pid':meta['pid'],'balancer':balancer,'amount_zzz':str(amount),'head_number':head['number'],
            'head_hash':head['hash'],'top_error':trace.get('error'),'top_output':trace.get('output'),'core_swaps':deltas,'trace':trace,
            'synthetic_depth':False,'public_transaction':False,'state_mutation':False}
        m.save(attempt/('direct-reverse-'+str(amount)+'.json'),record);results.append({k:record[k]for k in('amount_zzz','top_error','core_swaps')})
    print(json.dumps(results))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--attempt',required=True);a=p.parse_args()
    if a.attempt not in('attempt3','attempt4','attempt5'):raise ValueError('Explicit owned attempt required')
    run(HERE/a.attempt)
