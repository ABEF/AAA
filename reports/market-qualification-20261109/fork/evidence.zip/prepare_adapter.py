"""Create an isolated source-bound diagnostic adapter; no RPC or existing edits."""
import hashlib
import json
from pathlib import Path

ROOT = Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
DEST = Path(__file__).resolve().parent
original = (ROOT / 'scripts/source9_rehearsal_deploy.py').read_text(encoding='utf8')
updated = original

def replace_once(old, new):
    global updated
    if updated.count(old) != 1:
        raise ValueError('Adapter context changed: ' + old[:80])
    updated = updated.replace(old, new, 1)

replace_once("ROOT = Path(__file__).resolve().parents[1]", 'ROOT = Path(' + repr(str(ROOT)) + ')')
replace_once("reports/fee-flow-audit-20261107/contract/normal-final-4de5dcc67c", "reports/opensea-integration-20261109/contract/normal-final-05f7ac32db")
replace_once('def deploy(rpc, artifact_objects, fixture_objects, cast_path, output_dir):',
             'def deploy(rpc, artifact_objects, fixture_objects, cast_path, output_dir, market_plan):')
replace_once("review = '0x' + keccak256(b'SOURCE9 OWNED DISPOSABLE FORK ONLY; NOT PRODUCTION QUALIFICATION').hex()",
             "review = '0x' + keccak256(b'CURRENT NORMAL90 LP-ONLY MARKET DIAGNOSTIC; UNBOUND DIRECT MINT; CORRELATED PRICE FIXTURES').hex()")
replace_once("        lab.deploy('nft', 'ZZZNFT', 'constructor(address,string)', (ac, 'ipfs://SOURCE9-DISPOSABLE-REHEARSAL/')); lab.bind('nft')",
             "        metadata = lab.deploy('metadata_predeployed', 'ZZZNFTMetadata', 'constructor(address)', (ac,))\n"
             "        lab.deploy('nft', 'ZZZNFT', 'constructor(address,string,address)', (ac, 'ipfs://MARKET-DIAGNOSTIC-ONLY/', metadata)); lab.bind('nft')")
replace_once("        eth_price = 2000*UNIT\n        ratio_q96 = spot*spot//(1 << 96)\n        zzz_price = eth_price*(1 << 96)//ratio_q96",
             "        eth_price = market_plan['eth_price_usd18']\n        zzz_price = market_plan['zzz_price_usd18']\n"
             "        if any(type(x) is not int or not 0 < x < 2**127 for x in (eth_price, zzz_price)):\n"
             "            raise ValueError('Explicit positive integer diagnostic prices are required')")
replace_once("        lab.call('lp_balancer', 'configureExecutionPools(bytes32[],bytes32)', '[' + POOL + ']', review)",
             "        execution_pools = market_plan['execution_pools']\n"
             "        if not isinstance(execution_pools,list) or not 1 <= len(execution_pools) <= 4:\n"
             "            raise ValueError('One to four explicitly reviewed compatible execution pool keys are required')\n"
             "        venue_ids = []\n"
             "        for venue in execution_pools:\n"
             "            fee, spacing = venue['fee'], venue['tick_spacing']\n"
             "            if type(fee) is not int or not 0 <= fee < 20000 or type(spacing) is not int or not 0 < spacing <= 32767:\n"
             "                raise ValueError('Venue fee/spacing is incompatible with retained operating limits')\n"
             "            expected_id = '0x' + keccak256(bytes.fromhex(lab.encode('f(address,address,uint24,int24,address)',ZERO,DEPS['zzz'],fee,spacing,ZERO)[2:])).hex()\n"
             "            if venue['pool_id'].lower() != expected_id or expected_id in venue_ids:\n"
             "                raise ValueError('Venue key/hash mismatch or duplicate')\n"
             "            if expected_id != POOL:\n"
             "                alternate = '((' + ','.join((ZERO, DEPS['zzz'], str(fee), str(spacing), ZERO)) + '),false,true,5000,500,100,200,43200,' + str(5*UNIT) + ',' + str(1_000_000*UNIT) + ')'\n"
             "                admitted = lab.call('pools', 'configureNative(((address,address,uint24,int24,address),bool,bool,uint16,uint16,uint16,uint16,uint32,uint256,uint256))', alternate)\n"
             "            venue_ids.append(expected_id)\n"
             "        lab.call('lp_balancer', 'configureExecutionPools(bytes32[],bytes32)', '[' + ','.join(venue_ids) + ']', review)")
replace_once("mode='SOURCE9 OWNED DISPOSABLE FORK REHEARSAL'", "mode='CURRENT NORMAL90 LP-ONLY UNMODIFIED-MARKET DIAGNOSTIC; UNBOUND DIRECT MINT'")
replace_once("feeds=feeds, fixture_prices={'eth_usd_18': str(eth_price), 'zzz_usd_18': str(zzz_price)},",
             "feeds=feeds, fixture_prices={'eth_usd_18': str(eth_price), 'zzz_usd_18': str(zzz_price)},\n"
             "            market_plan=market_plan, independent_prices_qualified=False, primary_mint2_qualified=False, synthetic_venue_depth=False,")
replace_once("qualification_exclusions=['independent feeds', 'VRF proofs', 'wallet signing', 'hosting', 'production gas/latency']",
             "qualification_exclusions=['independent USD feeds (controlled correlated observations only)', 'production mint2 (helper deliberately unbound)', 'VRF proofs', 'wallet signing', 'hosting', 'production gas/latency']")
replace_once('Return a complete sealed source7 inventory on the owned exact fork.',
             'Return a sealed normal90 LP-only diagnostic on the newly owned fork.')

output = DEST / 'market_deploy_adapter.py'
with output.open('x', encoding='utf8', newline='\n') as stream:
    stream.write(updated)
record = {
    'kind': 'isolated copied diagnostic adapter; original repository script unchanged',
    'original': 'scripts/source9_rehearsal_deploy.py',
    'original_sha256': hashlib.sha256((ROOT/'scripts/source9_rehearsal_deploy.py').read_bytes()).hexdigest(),
    'adapter_sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
    'normal_build': 'reports/opensea-integration-20261109/contract/normal-final-05f7ac32db',
    'changes': ['exact current90-source normal build', 'predeployed renderer / NFT3args', 'explicit captured conditional price vector', 'explicit compatible hookless execution venue list', 'LP-only unbound direct-mint exclusion'],
    'no_network': True, 'production_sources_edited': False,
}
with (DEST/'adapter-provenance.json').open('x', encoding='utf8') as stream:
    json.dump(record,stream,indent=2);stream.write('\n')
print(json.dumps(record))
