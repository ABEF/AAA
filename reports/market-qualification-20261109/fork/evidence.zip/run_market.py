"""Current normal90 contracts on a NEW owned fork, with original venue depth.

Diagnostic only: no public transaction, key, signer, service or existing chain.
The input prices are explicitly controlled, correlated observations, never
independently qualified USD feeds. The SeaDrop helper is deliberately unbound;
direct fixture minting does not establish production mint2/OpenSea readiness.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import socket
import subprocess
import sys
import time
import traceback
import urllib.request

ROOT=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
HERE=Path(__file__).resolve().parent
V=HERE.parents[1]
sys.path[:0]=[str(ROOT),str(HERE)]
from scripts.source9_rehearsal_fork import cached_fork_provider, PUBLIC_ENDPOINT
from zzz_ops.abi import calldata, decode_words
from market_deploy_adapter import DEPS, POOL, ZERO, UNIT, _tool_env
import market_deploy_adapter as deployer

BASELINE='99a01e97887156be0d31b61d453df4e29eb8a055'
LIMIT=12_000_000
FIXTURE=V/'fresh-entry3-rehearsal-fixture-compile-subagent1'
PROTECTED=('reports/source-checks.json','scripts/run-fork-checks.py',
           'tests_python/test_fork_runner.py','tests_python/test_frontend_history.py')

def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def save(path,value):
    with Path(path).open('x',encoding='utf8',newline='\n') as f:
        json.dump(value,f,indent=2,sort_keys=True);f.write('\n');f.flush();os.fsync(f.fileno())

class LocalRPCError(RuntimeError):
    def __init__(self,method,error):
        self.method,self.error=method,error
        super().__init__(method+': '+json.dumps(error,sort_keys=True)[:300])

class Owned:
    """Transport bound to the child process object created by this invocation."""
    def __init__(self,process,url,plan,directory):
        if not re.fullmatch(r'http://127\.0\.0\.1:[0-9]+',url):raise ValueError('Loopback required')
        self.process,self.url,self.output=process,url,directory
        self.fork_block_number=plan['block'];self.fork_block_hash=plan['hash']
        self.rehearsal_owned=True;self.sequence=0;self.pending=None
        self.events=(directory/'owned-rpc.jsonl').open('x',encoding='utf8')
    def __call__(self,method,params):
        if self.process.poll() is not None:raise RuntimeError('This invocation owned fork has stopped')
        self.sequence+=1
        if self.sequence>30000:raise RuntimeError('Bounded diagnostic RPC allowance exhausted')
        req=urllib.request.Request(self.url,json.dumps({'jsonrpc':'2.0','id':self.sequence,'method':method,'params':params}).encode(),{'Content-Type':'application/json'})
        with urllib.request.urlopen(req,timeout=120) as response:
            raw=response.read(32*1024*1024+1)
        if len(raw)>32*1024*1024:raise RuntimeError('Bounded local RPC response exceeded')
        result=json.loads(raw)
        self.events.write(json.dumps({'time_utc':datetime.now(timezone.utc).isoformat(),'method':method,
            'error':result.get('error'),'response_bytes':len(raw)},sort_keys=True)+'\n');self.events.flush()
        if 'error'in result:raise LocalRPCError(method,result['error'])
        return result['result']
    call=__call__
    def submit(self,transaction,label):
        if self.pending is not None:raise RuntimeError('Unresolved saved transaction forbids new submission')
        if set(transaction)-{'from','to','data','value','gas','gasPrice','nonce'}:raise ValueError('Unexpected transaction field')
        transaction=dict(transaction)
        transaction['nonce']=self('eth_getTransactionCount',[transaction['from'],'pending'])
        record={'label':label,'transaction':transaction,'automatic_retry':False}
        self.pending=record
        stem=label+'-'+str(time.time_ns())
        save(self.output/(stem+'-intent.json'),record)
        h=self('eth_sendTransaction',[transaction]);record['hash']=h
        if not isinstance(h,str) or not re.fullmatch(r'0x[0-9a-fA-F]{64}',h):raise RuntimeError('No valid submitted hash')
        save(self.output/(stem+'-submitted.json'),record)
        until=time.monotonic()+120
        while time.monotonic()<until:
            receipt=self('eth_getTransactionReceipt',[h])
            if receipt is not None:break
            time.sleep(.1)
        else:raise RuntimeError('Saved local transaction unresolved; never resubmit')
        if receipt.get('transactionHash','').lower()!=h.lower() or receipt.get('status')not in('0x0','0x1'):raise RuntimeError('Unusable saved receipt')
        record['receipt']=receipt;save(self.output/(stem+'-receipt.json'),record)
        self.pending=None
        return receipt

def validate_plan(plan):
    required={'block','hash','eth_price_usd18','zzz_price_usd18','price_evidence','execution_pools'}
    if not required<=set(plan):raise ValueError('Explicit anchor, conditional prices/evidence and venue keys required')
    if type(plan['block'])is not int or plan['block']<=109612376 or not re.fullmatch(r'0x[0-9a-f]{64}',plan['hash']):raise ValueError('A fresh exact anchor required')
    for field in('eth_price_usd18','zzz_price_usd18'):
        if type(plan[field])is not int or not 0<plan[field]<2**127:raise ValueError('Exact integer conditional price required')
    if not isinstance(plan['price_evidence'],str) or not plan['price_evidence'].strip():raise ValueError('Price qualification limitations must be explicit')

def fixture_objects():
    status=json.loads((FIXTURE/'fixture-compiler-status.json').read_text())
    if status['errors'] or status['exit_code'] or status['fixture_source_sha256']!=digest(ROOT/deployer.FIXTURE_SOURCE):raise ValueError('Original isolated fixture build does not match current unchanged fixture')
    if status['solc_sha256']!='537fd8d8d4a0433a971bf456fc06f7b021cdcee27b252f74da49e0d8559aeb67':raise ValueError('Unexpected fixture compiler')
    objects=json.loads((FIXTURE/'fixture-compiler-stdout.json').read_text());objects['fixture_source_sha256']=status['fixture_source_sha256']
    return objects

def start_anvil(cached,plan,out):
    with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
    args=[str(V/'foundry-v1.4.4/anvil.exe'),'--host','127.0.0.1','--port',str(port),'--chain-id','4663','--fork-chain-id','4663',
        '--fork-url',cached.url,'--fork-block-number',str(plan['block']),'--gas-limit','64000000','--accounts','6',
        '--mnemonic-random','--balance','1000000','--no-storage-caching','--quiet']
    proc=subprocess.Popen(args,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,env=_tool_env(),creationflags=subprocess.CREATE_NO_WINDOW)
    rpc=Owned(proc,'http://127.0.0.1:'+str(port),plan,out)
    try:
        for _ in range(120):
            if proc.poll()is not None:raise RuntimeError('Owned fork failed during start')
            try:
                client=rpc('web3_clientVersion',[])
                if 'anvil'not in client.lower() or int(rpc('eth_chainId',[]),16)!=4663:raise RuntimeError('Owned fork identity mismatch')
                break
            except OSError:time.sleep(.25)
        else:raise RuntimeError('Owned fork readiness timeout')
        anchor=rpc('eth_getBlockByNumber',[hex(plan['block']),False])
        if anchor['hash']!=plan['hash']:raise RuntimeError('Owned fork anchor hash mismatch')
        rpc('anvil_setBlockTimestampInterval',[0])
        now=int(time.time())
        if now>int(anchor['timestamp'],16):rpc('evm_setNextBlockTimestamp',[now])
        rpc('anvil_mine',['0x1','0x0'])
        save(out/'owned-fork.json',{'pid':proc.pid,'url':rpc.url,'anchor':anchor,'client':client,'public_transactions':False,'owned_by_current_process':True})
        return proc,rpc
    except BaseException:
        proc.terminate();proc.wait(timeout=10);rpc.events.close();raise

def run(plan,out):
    validate_plan(plan)
    out.mkdir(parents=True,exist_ok=False)
    watched={name:digest(ROOT/name)for name in PROTECTED}
    head=subprocess.run(['git','-c','safe.directory='+str(ROOT),'rev-parse','HEAD'],cwd=ROOT,capture_output=True,text=True,check=True,env=_tool_env()).stdout.strip()
    if head!=BASELINE:raise ValueError('Current Git baseline changed; review before running')
    objects=deployer.load_production_objects();fixtures=fixture_objects()
    save(out/'start.json',{'head':head,'plan':plan,'protected_hashes':watched,'source_validation':objects['source_validation'],
        'adapter_sha256':digest(HERE/'market_deploy_adapter.py'),'runner_sha256':digest(__file__),
        'qualification':False,'synthetic_venue_depth':False,'primary_mint2_qualified':False,'independent_USD_sources':False,
        'fixture_reused':str(FIXTURE),'fixture_compiler_sha256':digest(FIXTURE/'fixture-compiler-stdout.json')})
    proc=rpc=None
    outcomes=[]
    try:
      with cached_fork_provider(PUBLIC_ENDPOINT,plan['block'],plan['hash'],out/'public-read-cache',requests_per_second=3)as cached:
       try:
        proc,rpc=start_anvil(cached,plan,out)
        print(json.dumps({'phase':'new_owned_fork_ready','pid':proc.pid,'anchor':plan['block']}),flush=True)
        inventory=deployer.deploy(rpc,objects,fixtures,V/'foundry-v1.4.4/cast.exe',out/'deployment',plan)
        save(out/'inventory.json',inventory)
        print(json.dumps({'phase':'current_contracts_deployed','transactions':len(inventory['receipts'])}),flush=True)
        lab=deployer.RehearsalDeployment.__new__(deployer.RehearsalDeployment)
        lab.rpc=rpc;lab.cast=V/'foundry-v1.4.4/cast.exe';lab.contracts=inventory['contracts'];lab.owner=inventory['governance']
        c=lab.contracts;accounts=inventory['accounts']
        def read(target,sig,*args):return lab.read(target,sig,*args)
        def uint(target,sig,*args):return int(read(target,sig,*args)[0],16)
        def transaction(target,sig,*args,owner=None,value=0):return {'from':owner or accounts[0],'to':c.get(target,target),'data':lab.calldata(sig,*args),'value':hex(value)}
        def send(target,sig,*args,owner=None,value=0,label='configuration'):
            tx=transaction(target,sig,*args,owner=owner,value=value)
            estimate=int(rpc('eth_estimateGas',[tx]),16);gas=(estimate*120+99)//100
            if gas>LIMIT:raise RuntimeError('Existing12M budget with20%headroom exceeded')
            tx['gas']=hex(gas);receipt=rpc.submit(tx,label)
            if receipt['status']!='0x1':raise RuntimeError('Local setup transaction reverted')
            return receipt
        nfts=[]
        for index,owner in enumerate(accounts[1:3]):
            fp='0x'+read('vault','mintPolicyFingerprint()')[0]
            price=int(read('policy','salePolicy()')[0],16)
            send('vault','mintDormant(bytes32)',fp,owner=owner,value=price,label='fixture-direct-mint-'+str(index))
            ordinal=uint('nft','mintedCount()');identifier=uint('nft','tokenAtOrdinal(uint256)',ordinal)
            send('vrf','fulfill(uint256,uint256,uint256)',uint('nft','requestOf(uint256)',identifier),0,0,label='fixture-vrf-'+str(index))
            send('nft','finalizeTraits(uint256)',identifier,label='fixture-traits-'+str(index))
            nfts.append({'id':identifier,'owner':owner})
        deployer.fund_zzz(rpc,accounts[2],10**25,out/'owned-zzz-funding')
        save(out/'nfts.json',nfts)
        def witness(nft):
            bucket=uint('vault','nftBucket(uint256)',nft['id']);group=read('vault','group(uint256)',bucket);main=int(group[1],16)
            physical=read('liquidity','portfolioAmounts(uint256)',main)if main else ['0'*64]*2
            return {'nft':nft,'owner':lab.addr('nft','ownerOf(uint256)',nft['id']),'bucket':bucket,'group':group,'main':main,
                'shares':uint('vault','sharesOf(uint256)',nft['id']),'total_shares':uint('vault','bucketTotalShares(uint256)',bucket),
                'wallet_zzz':uint(DEPS['zzz'],'balanceOf(address)',nft['owner']),'wallet_eth':int(rpc('eth_getBalance',[nft['owner'],'latest']),16),
                'entry_allowance':uint(DEPS['zzz'],'allowance(address,address)',nft['owner'],c['entry']),
                'entry_eth':int(rpc('eth_getBalance',[c['entry'],'latest']),16),'entry_zzz':uint(DEPS['zzz'],'balanceOf(address)',c['entry']),
                'physical':physical,'deployed_usd18':sum(int(x,16)*p//UNIT for x,p in zip(physical,[plan['eth_price_usd18'],plan['zzz_price_usd18']])),
                'idle_usd18':int(group[2],16)*plan['eth_price_usd18']//UNIT+int(group[3],16)*plan['zzz_price_usd18']//UNIT,
                'liquidity':uint(DEPS['position_manager'],'getPositionLiquidity(uint256)',main)if main else 0,
                'ticks':read('liquidity','ticks(uint256)',main)if main else [],'secondary':uint('liquidity','secondaryId(uint256)',main)if main else 0,
                'slot0':read(DEPS['state_view'],'getSlot0(bytes32)',POOL)}
        for index,(source,nft)in enumerate(zip([ZERO,DEPS['zzz']],nfts)):
          for increase,usd in((False,100),(True,5)):
            name=('eth'if source==ZERO else'zzz')+('-growth5'if increase else'-activation100')
            if increase and uint('vault','sharesOf(uint256)',nft['id'])==0:
                result={'case':name,'status':'blocked_no_successful_actual_activation','synthetic_incumbent_not_created':True}
                outcomes.append(result);save(out/(name+'.json'),result);continue
            price=plan['eth_price_usd18'if source==ZERO else'zzz_price_usd18'];amount=(usd*UNIT*UNIT+price-1)//price
            approval=None
            if source!=ZERO:
                if uint(source,'allowance(address,address)',nft['owner'],c['entry'])!=0:raise RuntimeError('Fresh case expected zero previous allowance')
                approval=send(source,'approve(address,uint256)',c['entry'],amount,owner=nft['owner'],label=name+'-exact-approval')
            before=witness(nft);headblock=rpc('eth_getBlockByNumber',['latest',False]);deadline=int(headblock['timestamp'],16)+600
            request='('+','.join((str(nft['id']),POOL,source,str(amount),'1',str(deadline),'true'if increase else'false'))+')'
            fp='0x'+read('policy','entryFingerprint()')[0]
            tx=transaction('entry','executeReviewed((uint256,bytes32,address,uint256,uint128,uint256,bool),uint16,bytes32)',request,200,fp,owner=nft['owner'],value=amount if source==ZERO else 0)
            tx['gas']=hex(LIMIT)
            result={'case':name,'usd_requested':usd,'source_amount':str(amount),'source_usd18':str(amount*price//UNIT),
                'before':before,'unsigned_transaction':tx,'approval_receipt':approval,'minimum_liquidity':1,'marginal_floor_still_protocol98percent':True}
            try:
                simulated=rpc('eth_call',[tx,'latest']);result['simulation']={'success':True,'result':simulated}
                estimate=int(rpc('eth_estimateGas',[tx]),16);gas=(estimate*120+99)//100
                result['estimate']=estimate;result['reviewed_gas_with20percent_headroom']=gas
                if gas>LIMIT:
                    result['status']='blocked_existing12Mbudget';outcomes.append(result);save(out/(name+'.json'),result);continue
                tx['gas']=hex(gas)
            except LocalRPCError as exc:
                result['simulation']={'success':False,'error':exc.error}
                # One bounded actual revert proves rollback; do not retry or
                # loosen guards. Trace is diagnostic only and bounded by12M.
                try:result['trace']=rpc('debug_traceCall',[tx,'latest',{'tracer':'callTracer','timeout':'60s'}])
                except Exception as trace_error:result['trace_unavailable']=str(trace_error)
            receipt=rpc.submit(tx,name);result['receipt']=receipt;after=witness(nft);result['after']=after
            success=receipt['status']=='0x1'
            if success!=result['simulation']['success']:raise RuntimeError('Simulation/execution mismatch')
            if success:
                delta=after['deployed_usd18']-before['deployed_usd18']
                if delta*10000<int(result['source_usd18'])*9800:raise RuntimeError('Actual marginal LP below98%')
                if after['entry_allowance']!=0 or after['entry_eth']!=before['entry_eth']or after['entry_zzz']!=before['entry_zzz']:raise RuntimeError('Entry residual balance/approval')
                if after['secondary']or(after['shares']<=before['shares']):raise RuntimeError('No positive shares or unexpected residual')
                if increase and (after['main']!=before['main']or after['ticks']!=before['ticks']or after['group'][5:7]!=before['group'][5:7]):raise RuntimeError('Growth recentered/reset current main')
                result['status']='actual_success_conditional_USD';result['actual_marginal_deployed_usd18']=str(delta)
            else:
                ignored={'wallet_eth'}
                if any(before[k]!=after[k]for k in before if k not in ignored):raise RuntimeError('Reverted transaction changed protected balances/LP state')
                gas_cost=int(receipt['gasUsed'],16)*int(receipt['effectiveGasPrice'],16)
                if before['wallet_eth']-after['wallet_eth']!=gas_cost:raise RuntimeError('Reverted transaction lost more than network gas')
                result['status']='atomic_revert_unchanged_market';result['rollback_verified']=True
            outcomes.append(result);save(out/(name+'.json'),result)
            print(json.dumps({'case':name,'status':result['status'],'gas_used':int(receipt['gasUsed'],16)}),flush=True)
        save(out/'summary.json',{'baseline':BASELINE,'anchor':plan['block'],'anchor_hash':plan['hash'],
            'outcomes':[{k:x[k]for k in('case','status')}for x in outcomes],
            'synthetic_venue_depth':False,'independent_USD_qualified':False,'production_mint2_qualified':False,
            'public_transactions':False,'conversion_qualification':'separate reviewed cheaper route required; not established by contribution success'})
       finally:
        if proc is not None and proc.poll()is None:
            proc.terminate()
            try:proc.wait(timeout=10)
            except subprocess.TimeoutExpired:proc.kill();proc.wait(timeout=10)
        if rpc is not None:rpc.events.close()
        save(out/'owned-process-stopped.json',{'pid':proc.pid if proc else None,'exit_code':proc.poll()if proc else None,'only_invocation_owned_process_touched':True})
    except BaseException as exc:
        save(out/'failure.json',{'type':type(exc).__name__,'message':str(exc),'traceback':traceback.format_exc(),'completed_cases':len(outcomes),'automatic_retry':False})
        raise
    finally:
        final={name:digest(ROOT/name)for name in PROTECTED}
        save(out/'protected-final.json',{'initial':watched,'final':final,'unchanged':watched==final})
        if watched!=final:raise RuntimeError('Protected files changed during diagnostic')

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--plan',type=Path,required=True);parser.add_argument('--attempt',required=True)
    args=parser.parse_args()
    if not re.fullmatch(r'attempt[1-9][0-9]*',args.attempt):raise ValueError('Exclusive numbered attempt required')
    run(json.loads(args.plan.read_text()),HERE/args.attempt)
