contract Fixture {}
