"""Identify review work without accepting any new/changed detector context."""
from pathlib import Path
import collections,hashlib,importlib.util,json,re,sys

R=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
E=Path(__file__).resolve().parent;D=Path(sys.argv[1])
spec=importlib.util.spec_from_file_location('checker',R/'scripts/check-slither-review.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
oldpath=R/'reports/metadata-lifecycle-fixes-20261116/static-review.json'
old=json.loads(oldpath.read_bytes());assert len(old['findings'])==569
data=json.loads((D/'slither.json').read_bytes());execution=json.loads((D/'EXECUTION.json').read_bytes())
assert data['success'] is True and not data.get('error') and execution['source_unchanged'] is True
assert execution['compiler_invoked'] is False
oldby=collections.defaultdict(list)
for row in old['findings']:oldby[row['fingerprint']].append(row)
sources={p.relative_to(R).as_posix():m.source_hash(p) for p in (R/'src').rglob('*.sol')}
fresh=[];reuse=[]
for finding in data['results']['detectors']:
    fp=m.fingerprint(finding);desc=m.normalized_description(finding)
    paths=sorted(set(re.findall(r'src/[A-Za-z0-9_./-]+\.sol',desc)))
    row={k:finding[k] for k in ('check','impact','confidence')}
    row.update(fingerprint=fp,description=desc,referenced_paths=paths,
        referenced_source_sha256_lf={p:sources[p] for p in paths})
    if len(oldby[fp])==1 and paths and all(sources[p]==old['source_sha256_lf'].get(p) for p in paths):
        reuse.append(row)
    else:
        row['reason']='Changed referenced source or new/changed exact detector fingerprint; individual current review required.'
        fresh.append(row)
for name,value in [('CURRENT_CONTEXTS.json',{'current':fresh,'count':len(fresh),'dispositions_assigned':False}),
        ('EXACT_REUSE.json',{'reuse':reuse,'count':len(reuse),'reuse_scope':'Only exact old fingerprint and every referenced LF source unchanged.'})]:
    with (E/name).open('x',encoding='utf-8')as stream:json.dump(value,stream,indent=2);stream.write('\n')
summary={'total':len(data['results']['detectors']),'requiring_current_review':len(fresh),'exact_reuse_eligible':len(reuse),
    'by_detector':dict(collections.Counter(row['check'] for row in fresh)),
    'changed_production_sources':[n for n,h in sources.items() if old['source_sha256_lf'].get(n)!=h],
    'prior_review_sha256':hashlib.sha256(oldpath.read_bytes()).hexdigest(),
    'current_contexts_sha256':hashlib.sha256((E/'CURRENT_CONTEXTS.json').read_bytes()).hexdigest()}
with (E/'DIFF_SUMMARY.json').open('x',encoding='utf-8')as stream:json.dump(summary,stream,indent=2);stream.write('\n')
print(json.dumps(summary))
