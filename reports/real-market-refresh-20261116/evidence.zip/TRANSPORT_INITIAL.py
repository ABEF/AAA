"""Four NEW mocked collector checks; no provider, node, compiler or old tests."""
import importlib.util,json,tempfile,time,threading,unittest,urllib.error
from pathlib import Path
from unittest.mock import patch
HERE=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('fresh_market_capture',HERE/'capture.py');M=importlib.util.module_from_spec(spec);spec.loader.exec_module(M)
class Response:
    status=200;headers={}
    def __init__(self,raw):self.raw=raw
    def __enter__(self):return self
    def __exit__(self,*args):return False
    def read(self,maximum):return self.raw[:maximum]
class Tests(unittest.TestCase):
    def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.p=patch.object(M,'OUT',Path(self.tmp.name));self.p.start()
    def tearDown(self):self.p.stop();self.tmp.cleanup()
    def test_serialized_snapshot_is_immutable(self):
        class Opener:
            def open(self,req,timeout):
                sent=json.loads(req.data);return Response(json.dumps({'jsonrpc':'2.0','id':sent['id'],'result':{'field':'original'}}).encode())
        with patch.object(M.urllib.request,'build_opener',return_value=Opener()):
            c=M.Capture();tx={'data':'0x1234','gas':'0x7a120'};returned=c.rpc('eth_call',[tx,{'blockHash':'0xabc','requireCanonical':True}],'fake')
            tx['gas']='0x1';returned['field']='changed';self.assertEqual(c.rows[0]['request']['params'][0]['gas'],'0x7a120');self.assertEqual(c.rows[0]['response']['result'],{'field':'original'})
    def test_http429_stops_without_another_post(self):
        class Opener:
            posts=0
            def open(self,req,timeout):self.posts+=1;raise urllib.error.HTTPError(M.URL,429,'limited',{'Retry-After':'60'},None)
        opener=Opener()
        with patch.object(M.urllib.request,'build_opener',return_value=opener):
            c=M.Capture()
            with self.assertRaises(M.Stop):c.rpc('eth_chainId',[],'first')
            with self.assertRaisesRegex(ValueError,'already stopped'):c.rpc('eth_chainId',[],'no-retry')
            self.assertEqual(opener.posts,1);self.assertEqual(c.rows[0]['http_status'],429)
    def test_absolute_deadline_stops_slow_body(self):
        gate=threading.Event()
        class Slow(Response):
            def read(self,maximum):gate.wait(.5);return self.raw
        class Opener:
            def open(self,req,timeout):return Slow(b'{"jsonrpc":"2.0","id":1,"result":"0x1237"}')
        try:
            with patch.object(M,'TIMEOUT',.02),patch.object(M,'MAX_SECONDS',.1),patch.object(M.urllib.request,'build_opener',return_value=Opener()):
                c=M.Capture();start=time.monotonic()
                with self.assertRaisesRegex(M.Stop,'absolute_http_deadline'):c.rpc('eth_chainId',[],'slow')
                self.assertLess(time.monotonic()-start,.2);self.assertTrue(c.stopped);self.assertEqual(len(c.rows),1)
        finally:gate.set()
    def test_pacing_and_closure_reserve_charge_original_budget(self):
        class Opener:
            def open(self,req,timeout):
                sent=json.loads(req.data);return Response(json.dumps({'jsonrpc':'2.0','id':sent['id'],'result':'0x1237'}).encode())
        with patch.object(M,'TIMEOUT',.05),patch.object(M,'MAX_SECONDS',.3),patch.object(M,'INTERVAL',.01),patch.object(M.urllib.request,'build_opener',return_value=Opener()):
            c=M.Capture();c.rpc('eth_chainId',[],'first');c.rpc('eth_chainId',[],'second')
            self.assertGreaterEqual(c.rows[1]['started_elapsed_seconds']-c.rows[0]['started_elapsed_seconds'],.0099)
            c.start=time.monotonic()-.225;c.last=None;c.rpc('eth_chainId',[],'reserved')
            self.assertGreater(c.rows[-1]['timeout_seconds'],0);self.assertLess(c.rows[-1]['timeout_seconds'],.026)
            c.rpc('eth_getBlockByNumber',['0x1',False],'closure',closure=True);self.assertLessEqual(c.rows[-1]['timeout_seconds'],.05)
if __name__=='__main__':unittest.main()
