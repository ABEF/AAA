"""Exact offline replay/interpretation of fresh captured responses; no network."""
from pathlib import Path
from fractions import Fraction
from decimal import Decimal,localcontext
import datetime as dt,hashlib,json,gzip,sys
R=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2');sys.path.insert(0,str(R))
from zzz_ops.abi import keccak256
E=Path(__file__).resolve().parent;HERE=E/'capture'
def load(name):return json.loads((HERE/name).read_bytes())
def require(ok,message):
    if not ok:raise ValueError(message)
def save(name,value):(E/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n',encoding='utf8')
def sha(raw):return hashlib.sha256(raw).hexdigest()
def words(value):
    require(type(value)is str and value.startswith('0x')and (len(value)-2)%64==0,'Bad ABI words')
    return [int(value[i:i+64],16)for i in range(2,len(value),64)]
def ratio(value):
    with localcontext()as ctx:ctx.prec=90;decimal=format(Decimal(value.numerator)/Decimal(value.denominator),'.24f')
    return {'numerator':str(value.numerator),'denominator':str(value.denominator),'decimal':decimal}
def word(x):return (int(x,16)if type(x)is str else x%(1<<256)).to_bytes(32,'big')
def total_fee(pool,direction):
    packed=pool['slot0']['protocolFee'];protocol=packed&4095 if direction else packed>>12;lp=pool['slot0']['lpFee']
    require(protocol<=1000 and lp<1000000,'Unknown fee layout');return protocol+lp-protocol*lp//1000000
def error_decode(raw,pool_id):
    err=raw.get('rpc_error');require(type(err)is dict,'No explicit error');data=err.get('data');result={'rpc_error':err,'classification':'unavailable_unknown_cause'}
    if type(data)is not str or not data.startswith('0x'):return result
    try:b=bytes.fromhex(data[2:])
    except ValueError:return result
    if len(b)<68 or b[:4]!=keccak256(b'UnexpectedRevertBytes(bytes)')[:4]or int.from_bytes(b[4:36],'big')!=32:return result
    n=int.from_bytes(b[36:68],'big')
    if len(b)!=68+((n+31)//32)*32 or any(b[68+n:]):return result
    inner=b[68:68+n];result['canonical_wrapped_bytes']='0x'+inner.hex()
    if n==36 and inner[:4]==keccak256(b'NotEnoughLiquidity(bytes32)')[:4]and inner[4:]==bytes.fromhex(pool_id[2:]):result['classification']='exact_full_input_incomplete'
    elif n==0:result['classification']='empty_wrapped_revert_at_500k_unknown_cause'
    return result
def main():
    c=load('CAPTURE.json');log=load('RPC.json');by={x['label']:x for x in log['rows']};anchor=c['anchor'];block=anchor['selector'];require(c['canonical_final_recheck']is True and c['final_header']==anchor['header'],'Unclosed primary anchor')
    require(len(log['rows'])==33 and c['request_count']==33 and c['phase_elapsed_seconds']<=90,'Primary work limit')
    statuses={'rpc_results':0,'rpc_errors':0}
    for i,row in enumerate(log['rows'],1):
        raw=(HERE/row['raw_file']).read_bytes();require(len(raw)==row['raw_bytes']<=262144 and sha(raw)==row['raw_sha256']and json.loads(raw)==row['response'],'Raw response mismatch')
        request=row['request'];require(request['id']==i and request['method']in ('eth_chainId','eth_getBlockByNumber','eth_getCode','eth_getStorageAt','eth_call')and row['response']['id']==i and row['http_status']==200,'Envelope/method mismatch')
        if i>1:require(row['started_elapsed_seconds']-log['rows'][i-2]['started_elapsed_seconds']>=2,'Actual HTTP start pacing')
        require(0<row['timeout_seconds']<=12 and row['finished_elapsed_seconds']<=90,'Timeout/work bound')
        if request['method']in ('eth_getCode','eth_getStorageAt','eth_call'):require(request['params'][-1]==block,'Mixed state anchor')
        statuses['rpc_errors'if 'error'in row['response']else 'rpc_results']+=1
    require(by['chain']['response']['result']=='0x1237'and by['independent-genesis']['response']['result']['hash']=='0xaad15f3d702aaea00caf3e9bb56395efe9127bc3b31b24921abf1eee3409305c','Chain/genesis mismatch')
    require(load('SOURCE_PINS.json')=={p:sha((R/p).read_bytes())for p in load('SOURCE_PINS.json')},'Source changed')
    for label,pin in c['runtimes'].items():require('0x'+keccak256(bytes.fromhex(by[label+'.runtime']['response']['result'][2:])).hex()==pin['keccak256']==pin['expected_prior_keccak256'],'Runtime source-layout binding')
    prior=json.loads(gzip.decompress((R/'reports/predeployment-qualification-20261113/markets/CAPTURE_PARTIAL.json.gz').read_bytes()));old={p['poolId']:p for p in prior['known_pool_states']};pools=c['known_pool_states'];require(len(pools)==95 and len({p['poolId']for p in pools})==95,'Wrong known-key inventory')
    slots=[]
    for p in pools:
        require('0x'+keccak256(b''.join(word(v)for v in p['key'])).hex()==p['poolId'],'PoolKey identity');slot=int.from_bytes(keccak256(word(p['poolId'])+word(6)),'big');slots.extend((slot,slot+3))
    packed=[]
    for i,start in enumerate(range(0,len(slots),50)):
        chunk=slots[start:start+50];row=by[f'known95-bulk-{i}'];expected='0x'+(keccak256(b'extsload(bytes32[])')[:4]+word(32)+word(len(chunk))+b''.join(word(v)for v in chunk)).hex();require(row['request']['params'][0]['data']==expected,'Wrong bulk slots')
        v=words(row['response']['result']);require(v[:2]==[32,len(chunk)]and len(v)==len(chunk)+2,'Bulk layout');packed+=v[2:]
    selected=next(p for p in pools if p['poolId']==c['quote_selection']['selected']);selected_price=Fraction(selected['slot0']['sqrtPriceX96']**2,1<<192);active=[];all_bands=[];changed=[]
    cl=c['feeds']['chainlink_primary'];v=words(cl['latestRoundData']);dec=words(cl['decimals'])[0];eth=Fraction(v[1],10**dec);ts=anchor['timestamp'];require(cl['same_aggregator_as_secondary']and cl['structurally_valid_hard_day'],'CL interpretation changed')
    for i,p in enumerate(pools):
        n,L=packed[i*2:i*2+2];s=p['slot0'];tick=(n>>160)&0xffffff;tick-=1<<24 if tick&(1<<23)else 0
        require(s=={'sqrtPriceX96':n&((1<<160)-1),'tick':tick,'protocolFee':(n>>184)&0xffffff,'lpFee':(n>>208)&0xffffff}and n>>232==0 and L==int(p['active_liquidity'])and L<1<<128,'Packed-state mismatch')
        price=Fraction(s['sqrtPriceX96']**2,1<<192);relative=price/selected_price;row={**p,'zzz_per_eth':ratio(price),'eth_per_zzz':ratio(1/price),'conditional_zzz_usd_from_single_ETH_and_this_pool':ratio(eth/price),'price_ratio_to_selected':ratio(relative),'common_500bps_continuous_reference_possible':max(relative,1/relative)<=Fraction(105,95),'combined_fee_pips_ETH_to_ZZZ':total_fee(p,True),'combined_fee_pips_ZZZ_to_ETH':total_fee(p,False)};all_bands.append(row)
        if L:active.append(row)
        if s!=old[p['poolId']]['slot0']or L!=old[p['poolId']]['liquidity']:changed.append(p['poolId'])
    py=words(c['feeds']['pyth']['observation']);exponent=py[2]-(1<<256)if py[2]>>255 else py[2];require(len(py)==4 and 0<py[0]<1<<63 and py[1]<1<<64 and -(1<<31)<=exponent<1<<31 and -36<=exponent<=36,'Pyth ABI/precision');py_price=Fraction(py[0])*Fraction(10)**exponent;spread=abs(py_price-eth)/min(py_price,eth)*10000
    quotes=[]
    for q in c['quotes']:
        p=next(p for p in pools if p['poolId']==q['pool_id']);label='quote.'+q['venue_label']+'.'+('ETH-to-ZZZ'if q['zero_for_one']else 'ZZZ-to-ETH');wire=by[label];amount=int(q['input_raw']);expected='0x'+(keccak256(b'quoteExactInputSingle(((address,address,uint24,int24,address),bool,uint128,bytes))')[:4]+word(32)+b''.join(word(x)for x in q['key'])+word(int(q['zero_for_one']))+word(amount)+word(256)+word(0)).hex();require(wire['request']['params'][0]['data']==expected and int(wire['request']['params'][0]['gas'],16)==500000 and q['postspot']is None and q['qualified_usd']is False,'Quote encoding/scope')
        row={**q,'whole_operation_qualified':False,'analytical_floor_scope':'Owninitialspot only; not two-sourceUSD, configuredvenue/userfloor, LPdeployment or finalsourceagreement.'}
        if type(q['result'])is str:
            value=words(q['result']);require(len(value)==2,'Quoter ABI');price=Fraction(p['slot0']['sqrtPriceX96']**2,1<<192);ideal=amount*(price if q['zero_for_one']else 1/price);fee=total_fee(p,q['zero_for_one']);net=ideal*Fraction(1000000-fee,1000000);out=value[0]
            row.update(amount_out_raw=str(out),quoter_reported_gas=value[1],conditional_own_spot_gross_loss_bps=ratio((1-Fraction(out)/ideal)*10000),conditional_extra_loss_after_known_fee_bps=ratio((1-Fraction(out)/net)*10000),passes_analytic_3pct_swap_value_floor=Fraction(out)>=ideal*Fraction(97,100),passes_analytic_1pct_conversion_gross_floor=Fraction(out)>=ideal*Fraction(99,100),passes_analytic_1pct_additional_after_fee_floor=Fraction(out)>=net*Fraction(99,100))
        else:row['error_decode']=error_decode(q['result'],q['pool_id'])
        quotes.append(row)
    out={'production_approved':False,'deployable_configuration':False,'anchor':{k:v for k,v in anchor.items()if k!='header'},'anchor_utc':dt.datetime.fromtimestamp(ts,dt.timezone.utc).isoformat(),'canonical_final_recheck':True,'network':{'primary_requests':33,'primary_phase_seconds':c['phase_elapsed_seconds'],**statuses,'read_only':True,'retries':0},'feeds':{'chainlink':{'usd':ratio(eth),'updated_at':v[3]if False else words(cl['latestRoundData'])[3],'age_seconds':cl['age_seconds'],'decimals':dec,'two_proxies_same_aggregator':True,'qualified_independent_pair':False,'max_age_policy_unapproved':True},'pyth':{'stored_usd':ratio(py_price),'publish_time':py[3],'age_seconds':ts-py[3],'hard_86400_seconds_pass':0<py[3]<=ts and ts-py[3]<=86400,'confidence_usd':ratio(Fraction(py[1])*Fraction(10)**exponent),'confidence_bps':ratio(Fraction(py[1],py[0])*10000),'spread_vs_chainlink_bps':ratio(spread),'agreement_300bps_pass':spread<=300,'qualified':False},'api3':{'current_read':c['feeds']['api3']['observation'],'current_base_name_subscription_state':'not_refreshed; historical Nov13 zero values remain dated','round_compatible_adapter_qualified':False}},'markets':{'known_pool_count':95,'changed_since_Nov13':changed,'active_reference_fee_only_count':len(active),'active_strict_principal_fee_only_count':sum(p['strict_principal_fee_only_candidate']for p in active),'selected':next(p for p in all_bands if p['poolId']==selected['poolId']),'active_by_rawL_not_TVL':sorted(active,key=lambda p:int(p['active_liquidity']),reverse=True),'all_bands':all_bands,'global_highest_or_ownership_or_depth_qualified':False},'quotes':quotes,'sources_qualified':{'independent_ETH_pair':False,'independent_ZZZ_pair':False},'unchanged_safeguards':c['safeguards_unchanged'],'important_limits':['No PoPL deployment: no wholeactivation/growth/maintenance/claim operation simulated.','Nominal100/5USD ETH quotes are fullinput diagnostics, not assumed protocol swap fractions.','Positive quoter responses provide output/gas only, not postspot/fullstate.','ActiveL0 does not prove emptyticks; rawL ranking does not proveTVL/depth/sourceindependence.','API3 current base/subscription not read. No Pyth publication/update/funding performed.','Oracle sourceage/depth/reviewIDs/routes/operating fees remain unapproved.']}
    save('RESULTS.json',out)
    additional=['node_modules/@uniswap/v4-periphery/src/base/BaseV4Quoter.sol','node_modules/@uniswap/v4-periphery/src/libraries/QuoterRevert.sol','node_modules/@uniswap/v4-core/src/interfaces/IPoolManager.sol']
    save('ADDITIONAL_SOURCE_PINS.json',{p:sha((R/p).read_bytes())for p in additional})
    candidate={'production_approved':False,'deployable_configuration':False,'anchor':out['anchor'],'eth_primary_candidate':{'address':cl['address'],'runtime_keccak256':cl['runtime']['keccak256'],'aggregator':c['feeds']['chainlink_aggregator']['address'],'feed_decimals':dec,'maxAge':None,'independenceId':None,'reviewHash':None},'eth_secondary':None,'zzz_primary':None,'zzz_secondary':None,'reviewed_reference':None,'reviewed_swap_routes':[],'selected_pool_id':selected['poolId'],'current_selected_active_liquidity':selected['active_liquidity'],'explicit_blockers':['No twoqualifiedindependentETH/ZZZsources','SelectedactiveL0; largestknownreferencepricebandincompatiblewithselecteddestination','No testedcomplete1000ZZZreverse/default1%conversion','Route/source/depth/ages/operations mustbe reviewed; no generated values adopted']};save('CANDIDATE_CONFIG.json',candidate)
    save('OFFLINE_VERIFICATION.json',{'status':'PASS','primary_raw_responses':33,'known_states':95,'quote_encodings':6,'network_calls':0,'EVM_executions':0,'compiler_runs':0,'old_test_suites':0,'capture_source_sha256':sha((E/'capture.py').read_bytes()),'analyzer_sha256':sha(Path(__file__).read_bytes())})
    print(json.dumps({'ETH':out['feeds']['chainlink']['usd']['decimal'],'PythAge':ts-py[3],'selectedL':selected['active_liquidity'],'active_reference':len(active),'changed_pools':len(changed),'quotes':len(quotes),'positive_quotes':sum('amount_out_raw'in q for q in quotes)}))
if __name__=='__main__':main()
