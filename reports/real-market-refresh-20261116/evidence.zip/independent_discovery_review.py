"""Read only the three already-recorded, separately approved log reads."""
from pathlib import Path
import hashlib,json,sys
E=Path(__file__).resolve().parent;R=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2');sys.path.insert(0,str(R))
from zzz_ops.abi import keccak256
def load(path):return json.loads(path.read_bytes())
def sha(raw):return hashlib.sha256(raw).hexdigest()
c=load(E/'capture/CAPTURE.json');d=load(E/'discovery/RESULT.json');w=load(E/'discovery/RPC.json');rows=w['rows']
assert len(rows)==d['requests']==3 and d['elapsed_seconds']<=90 and w['retries']==0 and w['read_only']is True
assert d['production_approved']is False and d['global_inventory_complete']is False
assert d['canonical_closed']is True and d['raw_log_count']==0 and d['new_pool_keys']==[]
assert d['prior_capture_sha256']==sha((E/'capture/CAPTURE.json').read_bytes())
assert d['initialize_abi_source_sha256']==sha((R/'node_modules/@uniswap/v4-core/src/interfaces/IPoolManager.sol').read_bytes())
for i,row in enumerate(rows,1):
    assert row['raw_file']==f'rpc-{i:02d}.raw'
    raw=(E/'discovery'/row['raw_file']).read_bytes();response=json.loads(raw)
    assert len(raw)<=262144 and sha(raw)==row['raw_sha256']and response==row['response']and response['id']==row['request']['id']==i
    assert row['http_status']==200 and row['timeout_seconds']<=12 and row['finished_elapsed_seconds']<=90
    if i>1:assert row['started_elapsed_seconds']-rows[i-2]['started_elapsed_seconds']>=2
header=c['anchor']['header'];number=c['anchor']['number']
for row in (rows[0],rows[2]):assert row['request']['method']=='eth_getBlockByNumber'and row['request']['params']==[hex(number),False]and row['response']['result']==header
assert rows[1]['request']['method']=='eth_getLogs'and rows[1]['response']['result']==[]
query=rows[1]['request']['params'][0]
expected={'address':c['runtimes']['core']['address'],'fromBlock':hex(c['prior_anchor']['number']+1),'toBlock':hex(number),'topics':['0x'+keccak256(b'Initialize(bytes32,address,address,uint24,int24,address,uint160,int24)').hex(),None,'0x'+'0'*64,'0x'+'7dbf38976f6d3b9c529e7d9484a71898b409ee6a'.rjust(64,'0')]}
assert query==d['query']==expected
result={'status':'three_recorded_log_reads_verified','requests':3,'independent_rpc_calls':0,'source_range_start':c['prior_anchor']['number']+1,'range_end':number,'observed_log_count':0,'canonical_headers_match':True,'production_approved':False,'global_inventory_complete':False,'limits':['The separately observed interval starts after the13November anchor. It does not close any earlier gap after the original9November inventory.','An empty provider response is not independent proof of index completeness, historical state availability, highest TVL, market depth or source qualification.']}
raw=(json.dumps(result,indent=2,sort_keys=True)+'\n').encode()
with(E/'INDEPENDENT_DISCOVERY_REVIEW.json').open('xb')as stream:stream.write(raw)
print(json.dumps({'status':result['status'],'sha256':sha(raw),'requests':3,'logs':0}))
