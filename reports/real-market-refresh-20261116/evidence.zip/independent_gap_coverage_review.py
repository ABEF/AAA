"""Inspect the new gap capture and stitch referenced discovery ranges offline."""
from pathlib import Path
import hashlib,json,sys
E=Path(__file__).resolve().parent;R=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2');sys.path.insert(0,str(R))
from zzz_ops.abi import keccak256
def load(path):return json.loads(path.read_bytes())
def sha(raw):return hashlib.sha256(raw).hexdigest()
def word(value):return (int(value,16)if type(value)is str else value%(1<<256)).to_bytes(32,'big')
c=load(E/'capture/CAPTURE.json');g=load(E/'discovery-gap/RESULT.json');wire=load(E/'discovery-gap/RPC.json');rows=wire['rows'];post=load(E/'discovery/RESULT.json')
assert len(rows)==g['requests']==3 and 0<g['elapsed_seconds']<=90 and wire['retries']==0 and wire['read_only']is True
assert g['production_approved']is False and g['global_inventory_complete']is False and g['canonical_closed']is True and g['raw_log_count']==0 and g['new_pool_keys']==[]
assert g['prior_capture_sha256']==sha((E/'capture/CAPTURE.json').read_bytes())
assert g['initialize_abi_source_sha256']==sha((R/'node_modules/@uniswap/v4-core/src/interfaces/IPoolManager.sol').read_bytes())
for i,row in enumerate(rows,1):
    assert row['raw_file']==f'rpc-{i:02d}.raw'
    raw=(E/'discovery-gap'/row['raw_file']).read_bytes();response=json.loads(raw)
    assert len(raw)<=262144 and sha(raw)==row['raw_sha256']and response==row['response']and type(response['id'])is int and response['id']==row['request']['id']==i
    assert row['http_status']==200 and row['timeout_seconds']<=12 and row['finished_elapsed_seconds']<=90
    if i>1:assert row['started_elapsed_seconds']-rows[i-2]['started_elapsed_seconds']>=2
prior=c['prior_anchor'];core=c['runtimes']['core']['address'];topic='0x'+keccak256(b'Initialize(bytes32,address,address,uint24,int24,address,uint160,int24)').hex()
topics=[topic,None,'0x'+'0'*64,'0x'+'7dbf38976f6d3b9c529e7d9484a71898b409ee6a'.rjust(64,'0')]
for row in (rows[0],rows[2]):assert row['request']['method']=='eth_getBlockByNumber'and row['request']['params']==[hex(prior['number']),False]and row['response']['result']==prior['header']
assert rows[1]['request']['method']=='eth_getLogs'and rows[1]['response']['result']==[]
query=rows[1]['request']['params'][0];assert query==g['query']=={'address':core,'fromBlock':hex(110324512),'toBlock':hex(prior['number']),'topics':topics}
# Inspect only historical artifacts newly needed for the combined-coverage claim;
# do not execute any historical collector, verifier or test.
old=R/'reports/market-qualification-20261109/markets';follow=R/'reports/market-followup-20261109/routes'
original_request=load(old/'v4-initialize-bounded-02-request.json')['json'];original_raw=(old/'v4-initialize-bounded-02-response.raw').read_bytes();original_response=json.loads(original_raw)
original_metadata=load(old/'v4-initialize-bounded-02-result.json')
assert sha(original_raw)==original_metadata['sha256']and len(original_raw)==original_metadata['response_bytes']and len(original_request)==len(original_response)==11
responses={x['id']:x for x in original_response};expected_start=0;events=[];ranges=[]
for request in original_request:
    filt=request['params'][0];response=responses[request['id']]
    assert request['method']=='eth_getLogs'and filt['address']==core and filt['topics']==topics and 'result'in response and 'error'not in response
    start,end=int(filt['fromBlock'],16),int(filt['toBlock'],16);assert start==expected_start and end>=start and end-start<10000000
    ranges.append([start,end]);expected_start=end+1
    for event in response['result']:
        assert event['removed']is False and event['address'].lower()==core and len(event['topics'])==4 and event['topics'][0]==topic and event['topics'][2:]==topics[2:]
        assert start<=int(event['blockNumber'],16)<=end
        vals=[int(event['data'][i:i+64],16)for i in range(2,len(event['data']),64)];assert len(vals)==5
        fee,spacing,hook,_,_=vals;spacing-=1<<256 if spacing&(1<<255)else 0
        key=['0x'+'0'*40,'0x7dbf38976f6d3b9c529e7d9484a71898b409ee6a',fee,spacing,'0x'+f'{hook:040x}']
        poolid='0x'+keccak256(b''.join(word(v)for v in key)).hex();assert poolid==event['topics'][1]
        events.append({'poolId':poolid,'key':key})
assert expected_start==109785804 and len(events)==len({x['poolId']for x in events})==102
decoded=load(old/'v4-discovered-pools.json');assert {x['poolId']:x['key']for x in events}=={x['poolId']:x['key']for x in decoded}
delta_request=load(follow/'delta-discovery-request.json')['json'][0];delta_raw=(follow/'delta-discovery-response.raw').read_bytes();delta_response=json.loads(delta_raw)[0];delta_meta=load(follow/'delta-discovery-result.json')
assert sha(delta_raw)==delta_meta['response_sha256']and len(delta_raw)==delta_meta['response_bytes']
assert delta_request['method']=='eth_getLogs'and delta_request['params'][0]=={'address':core,'fromBlock':hex(expected_start),'toBlock':hex(110324511),'topics':topics}and delta_response['id']==delta_request['id']and delta_response['result']==[]
ranges.extend([[expected_start,110324511],[g['range_start'],g['range_end']],[post['range_start'],post['range_end']]])
assert all(a[1]+1==b[0]for a,b in zip(ranges,ranges[1:]))and ranges[-1][1]==c['anchor']['number']
filtered={x['poolId']:x['key']for x in events if x['key'][4]=='0x'+'0'*40 and x['key'][2]<1000000}
current={x['poolId']:x['key']for x in c['known_pool_states']};assert len(filtered)==95 and filtered==current
result={'status':'new_gap_capture_and_combined_recorded_ranges_verified','new_gap_actual_reads':3,'new_total_reads_three_phases':39,'independent_rpc_calls':0,'compiler_evm_or_old_test_runs':0,'gap_range':[g['range_start'],g['range_end']],'gap_observed_log_count':0,'gap_headers_match_retained_nov13_anchor':True,'all_recorded_single_core_exact_pair_ranges_contiguous':True,'recorded_ranges':ranges,'recorded_range_start':ranges[0][0],'recorded_range_end':ranges[-1][1],'original_initialization_events':102,'current_hookless_static_fee_lt_1m_subset':95,'production_approved':False,'global_inventory_complete':False,'historical_raw_sha256':{'v4-initialize-bounded-02-response.raw':sha(original_raw),'delta-discovery-response.raw':sha(delta_raw)},'wording':'Recorded provider-dependent Initialize queries on the specified core for exact native ETH/fixed ZZZ now cover contiguous block0..115708674. No additional initialization logs were returned after the original102 events; current95-key subset is the hookless static fee<1M subset. This is not a global market, highest-TVL, depth or oracle-independence qualification.','limits':['Old captures retain their original sources and endpoints; no old collector, verifier or tests were rerun.','Contiguous requested ranges plus empty provider responses do not independently attest index completeness or absence of provider omission.','No coverage is claimed for other cores/chains, WETH, different token contracts, multihop venues or other assets.','Current stored state/depth and live reference truth remain separate from initialization-log coverage.','Earlier independent discovery records accurately describe their narrower scopes before the later gap capture; they are not rewritten.']}
raw=(json.dumps(result,indent=2,sort_keys=True)+'\n').encode()
with(E/'INDEPENDENT_GAP_COVERAGE_REVIEW.json').open('xb')as stream:stream.write(raw)
print(json.dumps({'status':result['status'],'sha256':sha(raw),'gap_reads':3,'total_new_reads':39,'recorded_coverage':result['recorded_range_end'],'current_subset':95}))
