"""Four NEW adversarial evidence checks. No network/EVM/compiler or old suite."""
from pathlib import Path
from unittest.mock import patch
import contextlib,copy,hashlib,importlib.util,io,json,sys,unittest,zipfile
E=Path(__file__).resolve().parent;R=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
s=importlib.util.spec_from_file_location('market_verifier',E/'verify.py');M=importlib.util.module_from_spec(s);s.loader.exec_module(M)
with zipfile.ZipFile(E/'evidence.zip')as z:ORIGINAL={name:z.read(name)for name in z.namelist()}
class Tests(unittest.TestCase):
    def rejected(self,mutate):
        files=dict(ORIGINAL);capture=json.loads(files['capture/CAPTURE.json']);result=json.loads(files['RESULTS.json']);mutate(capture,result)
        for name,obj in (('capture/CAPTURE.json',capture),('RESULTS.json',result)):files[name]=json.dumps(obj,sort_keys=True,indent=2).encode()
        manifest=json.loads(files['manifest.json'])
        for row in manifest['files']:
            raw=files[row['path']];row['bytes']=len(raw);row['sha256']=hashlib.sha256(raw).hexdigest()
        files['manifest.json']=json.dumps(manifest).encode()
        class ConsistentReader:
            def __init__(self,path):pass
            def raw(self,name):return files[name]
            def obj(self,name):return json.loads(self.raw(name))
        with patch.object(M,'Reader',ConsistentReader),patch.object(sys,'argv',['verify.py','--evidence','unused-for-memory-test','--repo',str(R)]),contextlib.redirect_stdout(io.StringIO()):
            with self.assertRaises(ValueError):M.main()
    def test_truncated_quote_arrays_rejected(self):
        def mutate(c,r):c['quotes']=[];r['quotes']=[]
        self.rejected(mutate)
    def test_replaced_quote_result_rejected(self):
        def mutate(c,r):
            c['quotes'][1]['result']=copy.deepcopy(c['quotes'][5]['result']);r['quotes'][1]['result']=copy.deepcopy(c['quotes'][1]['result']);r['quotes'][1]['error_decode']=copy.deepcopy(r['quotes'][5]['error_decode'])
        self.rejected(mutate)
    def test_embedded_api_feed_without_wire_support_rejected(self):
        def mutate(c,r):
            fake='0x'+f'{123:064x}'+f'{456:064x}';c['feeds']['api3']['observation']=fake;r['feeds']['api3']['current_read']=fake
        self.rejected(mutate)
    def test_embedded_anchor_hash_without_wire_support_rejected(self):
        def mutate(c,r):c['anchor']['hash']='0x'+'ab'*32;r['anchor']['hash']=c['anchor']['hash']
        self.rejected(mutate)
if __name__=='__main__':unittest.main()
