"""Approved three-call discovery only; no range shrinking, retries or writes."""
from pathlib import Path
import datetime as dt,hashlib,json,sys,time,threading,urllib.request,urllib.error
R=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2');sys.path.insert(0,str(R))
from zzz_ops.abi import keccak256
E=Path(__file__).resolve().parent;OUT=E/'discovery';URL='https://robinhood.rpc.pinax.network'
C=json.loads((E/'capture/CAPTURE.json').read_bytes());OLD=C['prior_anchor'];ANCHOR=C['anchor'];CORE=C['runtimes']['core']['address'];ZZZ='0x7dbf38976f6d3b9c529e7d9484a71898b409ee6a'
ROWS=[];START=None;LAST=None;STOPPED=False
def require(ok,reason):
    if not ok:raise ValueError(reason)
def save(name,value):(OUT/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n',encoding='utf8')
class Stop(Exception):pass
class NoRedirects(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,headers,newurl):fp.close();raise Stop('redirect_refused')
def rpc(method,params,label):
    global LAST,STOPPED,START
    require(not STOPPED and method in ('eth_getBlockByNumber','eth_getLogs')and len(ROWS)<3,'Closed discovery budget/method')
    if START is None:START=time.perf_counter()
    wait=max(0,2-(time.perf_counter()-LAST))if LAST is not None else 0
    require(90-(time.perf_counter()-START)>wait+12,'Original discovery budget exhausted')
    if wait:time.sleep(wait)
    timeout=min(12,90-(time.perf_counter()-START));payload={'jsonrpc':'2.0','id':len(ROWS)+1,'method':method,'params':params};body=json.dumps(payload).encode();row={'label':label,'request':json.loads(body),'observed_at_utc':dt.datetime.now(dt.timezone.utc).isoformat(),'timeout_seconds':timeout};ROWS.append(row)
    event=threading.Event();outcome={}
    def post():
        global LAST
        LAST=time.perf_counter();row['started_elapsed_seconds']=LAST-START
        try:
            req=urllib.request.Request(URL,body,{'Content-Type':'application/json','User-Agent':'PoPL-readonly-native-pair-discovery/1'})
            with urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirects).open(req,timeout=timeout)as response:outcome['raw']=response.read(262145);outcome['status']=response.status
        except BaseException as exc:outcome['error']=exc
        finally:event.set()
    try:
        threading.Thread(target=post,daemon=True).start()
        if not event.wait(timeout):raise Stop('absolute_http_deadline')
        if 'error'in outcome:raise outcome['error']
        raw=outcome['raw'];require(len(raw)<=262144,'Response exceeds256KiB');row['http_status']=outcome['status'];row['raw_file']=f'rpc-{len(ROWS):02d}.raw';(OUT/row['raw_file']).write_bytes(raw);row['raw_sha256']=hashlib.sha256(raw).hexdigest();result=json.loads(raw)
        require(type(result)is dict and result.get('id')==payload['id']and result.get('jsonrpc')=='2.0'and ('result'in result)!=('error'in result),'Invalid RPC envelope');row['response']=json.loads(raw)
        if 'error'in result:raise Stop('provider_or_range_refusal_no_shrink_or_retry')
        return result['result']
    except Exception as exc:
        STOPPED=True;row['error_class']=type(exc).__name__
        if isinstance(exc,urllib.error.HTTPError):row['http_status']=exc.code;exc.close()
        raise
    finally:row['finished_elapsed_seconds']=time.perf_counter()-START;save('RPC.json',{'endpoint':URL,'read_only':True,'retries':0,'maximum_calls':3,'maximum_seconds':90,'interval_seconds':2,'maximum_response_bytes':262144,'rows':ROWS})
def main():
    OUT.mkdir(exist_ok=False);topic='0x'+keccak256(b'Initialize(bytes32,address,address,uint24,int24,address,uint160,int24)').hex();query={'address':CORE,'fromBlock':hex(OLD['number']+1),'toBlock':hex(ANCHOR['number']),'topics':[topic,None,'0x'+'0'*64,'0x'+ZZZ[2:].rjust(64,'0')]}
    result={'production_approved':False,'range_start':OLD['number']+1,'range_end':ANCHOR['number'],'exact_pair':{'currency0':'0x'+'0'*40,'currency1':ZZZ},'query':query,'canonical_closed':False,'new_pool_keys':[],'global_inventory_complete':False,'prior_capture_sha256':hashlib.sha256((E/'capture/CAPTURE.json').read_bytes()).hexdigest(),'initialize_abi_source_sha256':hashlib.sha256((R/'node_modules/@uniswap/v4-core/src/interfaces/IPoolManager.sol').read_bytes()).hexdigest()}
    try:
        require(rpc('eth_getBlockByNumber',[hex(ANCHOR['number']),False],'anchor-before')==ANCHOR['header'],'Anchor changed before logquery')
        logs=rpc('eth_getLogs',[query],'one-exact-pair-Initialize-range');require(type(logs)is list and len(logs)<=1024,'Unbounded log inventory');result['raw_log_count']=len(logs);known={p['poolId']for p in C['known_pool_states']};seen=set()
        for log in logs:
            require(log['removed']is False and log['address'].lower()==CORE and len(log['topics'])==4 and log['topics'][0]==topic and log['topics'][2:]==query['topics'][2:]and OLD['number']<int(log['blockNumber'],16)<=ANCHOR['number'],'Wrong/removed/out-of-range event')
            require(type(log['data'])is str and len(log['data'])==322,'Wrong Initialize data length');values=[int(log['data'][i:i+64],16)for i in range(2,len(log['data']),64)]
            signed=lambda value:value-(1<<256)if value>>255 else value
            f,spacing,hooks,price,tick=values;spacing=signed(spacing);tick=signed(tick)
            require(f<1<<24 and 0<spacing<=32767 and hooks<1<<160 and 0<price<1<<160 and -(1<<23)<=tick<1<<23,'Noncanonical Initialize fields')
            key=['0x'+'0'*40,ZZZ,f,spacing,'0x'+f'{hooks:040x}'];pool_id='0x'+keccak256(b''.join((int(x,16)if type(x)is str else x%(1<<256)).to_bytes(32,'big')for x in key)).hex();require(pool_id==log['topics'][1],'PoolKey hash mismatch')
            identity=(log['transactionHash'],log['logIndex']);require(identity not in seen,'Duplicate initialization log');seen.add(identity)
            if pool_id not in known:result['new_pool_keys'].append({'poolId':pool_id,'key':key,'block':int(log['blockNumber'],16),'transaction_hash':log['transactionHash'],'log_index':int(log['logIndex'],16),'initial_sqrtPriceX96':str(price),'initial_tick':tick,'current_state_unread':True})
        require(rpc('eth_getBlockByNumber',[hex(ANCHOR['number']),False],'anchor-after')==ANCHOR['header'],'Anchor changed after logquery');result['canonical_closed']=True
    except Exception as exc:result['stopped']={'exception_type':type(exc).__name__,'reason':str(exc)if type(exc)in (Stop,ValueError)else 'Transport failed; no retry','provider_stopped':STOPPED}
    finally:result['requests']=len(ROWS);result['elapsed_seconds']=None if START is None else time.perf_counter()-START;save('RESULT.json',result);print(json.dumps({'requests':len(ROWS),'new_keys':len(result['new_pool_keys']),'canonical_closed':result['canonical_closed'],'stopped':result.get('stopped')}))
if __name__=='__main__':main()
