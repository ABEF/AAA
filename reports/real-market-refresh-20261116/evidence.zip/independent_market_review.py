"""Reconcile this new 33-read market observation only; no network or tests."""
from pathlib import Path
from fractions import Fraction
from decimal import Decimal, localcontext
import gzip,hashlib,json,sys
E=Path(__file__).resolve().parent;A=E/'capture'
R=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
sys.path.insert(0,str(R))
from zzz_ops.abi import keccak256
def load(path):return json.loads(path.read_bytes())
def check(ok,label):
    if not ok:raise AssertionError(label)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def word(value):return (int(value,16)if isinstance(value,str)else value%(1<<256)).to_bytes(32,'big')
def words(raw,count=None):
    check(type(raw)is str and raw.startswith('0x')and (len(raw)-2)%64==0,'Canonical ABI words')
    v=[int(raw[i:i+64],16)for i in range(2,len(raw),64)]
    check(count is None or len(v)==count,'Exact ABI return length');return v
def decimal(frac):
    with localcontext()as c:c.prec=70;return str(Decimal(frac.numerator)/Decimal(frac.denominator))
def fraction(value):return {'numerator':str(value.numerator),'denominator':str(value.denominator),'decimal':decimal(value)}
def main():
    c=load(A/'CAPTURE.json');w=load(A/'RPC.json');anchor=c['anchor'];selector=anchor['selector'];rows=w['rows'];bylabel={x['label']:x for x in rows}
    check(c['production_approved']is False and c['deployable_configuration']is False and c['public_transactions']==0 and c['source_or_settings_changes']is False,'No adoption or transaction')
    check(c['canonical_final_recheck']is True and c['final_header']==anchor['header'],'Actual numbered-header closure')
    check(anchor['chain_id']==4663 and selector=={'blockHash':anchor['hash'],'requireCanonical':True},'Exact same-chain anchor')
    check(len(rows)==c['request_count']==33 and 0<c['phase_elapsed_seconds']<=90 and w['retries']==0,'Original work budget')
    check(w['endpoint']=='https://robinhood.rpc.pinax.network'and w['read_only']is True and w['actual_start_interval_seconds']==2,'One public read-only endpoint')
    check([x['id']for x in rows]==list(range(1,34))and len(bylabel)==33,'No duplicate or missing observations')
    allowed={'eth_chainId','eth_getBlockByNumber','eth_getCode','eth_getStorageAt','eth_call'}
    previous=None;count_results=0;count_errors=0
    for i,row in enumerate(rows,1):
        check(row['request']['id']==row['id']==i and row['request']['method']in allowed,'Closed read-only RPC methods')
        check(row['raw_file']==f'rpc-{i:02d}.raw','Exact fixed raw filename')
        raw=(A/row['raw_file']).read_bytes();response=json.loads(raw)
        check(len(raw)==row['raw_bytes']<=262144 and sha(raw)==row['raw_sha256']and response==row['response'],'Exact preserved response body')
        check(type(response['id'])is int and response['id']==i and response['jsonrpc']=='2.0'and ('result'in response)!=('error'in response),'Actual exact response envelope')
        count_results+='result'in response;count_errors+='error'in response
        check(row['http_status']==200 and row['timeout_seconds']<=12 and row['finished_elapsed_seconds']<=90,'Bounded real HTTP capture')
        check(row['finished_elapsed_seconds']>=row['started_elapsed_seconds'],'Correct monotonic order')
        if previous is not None:check(row['started_elapsed_seconds']-previous>=2,'Actual observed minimum two-second start spacing')
        previous=row['started_elapsed_seconds']
        method=row['request']['method'];params=row['request']['params']
        if method in ('eth_call','eth_getStorageAt','eth_getCode'):check(params[-1]==selector,'Every state read at same canonical hash')
        if method=='eth_call':check(int(params[0]['gas'],16)==500000,'Original bounded call gas')
    check(bylabel['chain']['response']['result']=='0x1237','Observed chain ID')
    check(bylabel['independent-genesis']['response']['result']['hash']=='0xaad15f3d702aaea00caf3e9bb56395efe9127bc3b31b24921abf1eee3409305c','Independent genesis pin')
    check(bylabel['fresh-anchor']['response']['result']==anchor['header'],'Fresh anchor response')
    check(bylabel['final-canonical-numbered-header']['request']['params']==[hex(anchor['number']),False]and bylabel['final-canonical-numbered-header']['response']['result']==anchor['header'],'Final canonical numbered header')
    pins=load(A/'SOURCE_PINS.json')
    for path,pin in pins.items():check(sha((R/path).read_bytes())==pin,'Captured source unchanged: '+path)
    for label,entry in c['runtimes'].items():
        raw=bytes.fromhex(bylabel[label+'.runtime']['response']['result'][2:])
        check(len(raw)==entry['bytes']and '0x'+keccak256(raw).hex()==entry['keccak256']==entry['expected_prior_keccak256'],'Runtime authenticated before layout: '+label)
    oldpath=R/'reports/market-followup-20261109/routes/v4-state.json';old=load(oldpath)
    check(len(old)==len(c['known_pool_states'])==95 and sha(oldpath.read_bytes())==c['prior_pool_inventory_sha256'],'Exact historical95-key inventory scope')
    slots=[]
    for pool in old:
        check('0x'+keccak256(b''.join(word(v)for v in pool['key'])).hex()==pool['poolId'],'Exact PoolKey/ID')
        slot=int.from_bytes(keccak256(word(pool['poolId'])+word(6)),'big');slots.extend((slot,slot+3))
    values=[]
    for i,start in enumerate(range(0,len(slots),50)):
        row=bylabel[f'known95-bulk-{i}'];chunk=slots[start:start+50]
        expected='0x'+(keccak256(b'extsload(bytes32[])')[:4]+word(32)+word(len(chunk))+b''.join(word(v)for v in chunk)).hex()
        check(row['request']['params'][0]['data']==expected,'Exact native-core storage slots')
        got=words(row['response']['result']);check(got[:2]==[32,len(chunk)]and len(got)==len(chunk)+2,'Canonical bulk return')
        values+=got[2:]
    states={}
    for i,(prior,pool)in enumerate(zip(old,c['known_pool_states'],strict=True)):
        packed,L=values[2*i:2*i+2];tick=(packed>>160)&0xffffff;tick-=1<<24 if tick&(1<<23)else 0
        state={'sqrtPriceX96':packed&((1<<160)-1),'tick':tick,'protocolFee':(packed>>184)&0xffffff,'lpFee':(packed>>208)&0xffffff}
        check(packed>>232==0 and 0<=L<1<<128 and pool['poolId']==prior['poolId']and pool['key']==prior['key'],'Exact fixed-key state packing')
        check(state==pool['slot0']and L==int(pool['active_liquidity'])and state['lpFee']==pool['key'][2],'Actual native state and static fee')
        check((state['protocolFee']&4095)<=1000 and (state['protocolFee']>>12)<=1000,'Directional protocol fee bounds')
        check(pool['reference_fee_only_candidate']==(state['lpFee']<1000000)and pool['strict_principal_fee_only_candidate']==(state['lpFee']<100000),'Separate reference/principal fee classifications')
        states[pool['poolId']]=pool
    selected=states[c['quote_selection']['selected']]
    largest=max((p for p in states.values()if p['poolId']!=selected['poolId']and p['reference_fee_only_candidate']),key=lambda p:int(p['active_liquidity']))
    check(largest['poolId']==c['quote_selection']['largest_known_active_L_reference'],'Exact known inventory active-L ranking, not global TVL')
    def fee(pool,direction):
        protocol=pool['slot0']['protocolFee']&4095 if direction else pool['slot0']['protocolFee']>>12
        lp=pool['slot0']['lpFee'];return protocol+lp-protocol*lp//1000000
    cheap=max((p for p in states.values()if p['poolId']not in (selected['poolId'],largest['poolId'])and p['strict_principal_fee_only_candidate']and fee(p,False)<10000),key=lambda p:(int(p['active_liquidity']),-fee(p,False)))
    check(cheap['poolId']==c['quote_selection']['cheap_fee_only_conversion_lead'],'Exact diagnostic cheap-fee ranking')
    timestamp=anchor['timestamp'];feed=c['feeds']
    prior=json.loads(gzip.decompress((R/'reports/predeployment-qualification-20261113/markets/CAPTURE_PARTIAL.json.gz').read_bytes()))
    check(feed['chainlink_primary']['latestRoundData']==bylabel['chainlink.primary.round']['response']['result']and feed['chainlink_primary']['decimals']==bylabel['chainlink.primary.decimals']['response']['result'],'Exact actual ETH round and precision responses')
    for name in ('chainlink_primary','chainlink_secondary'):
        check(feed[name]['aggregator']==bylabel[name+'.aggregator']['response']['result'],'Exact current upstream aggregator response')
    ag=feed['chainlink_aggregator'];agr=bytes.fromhex(bylabel['chainlink_aggregator.runtime']['response']['result'][2:])
    check('0x'+keccak256(agr).hex()==ag['keccak256']==prior['feeds']['chainlink_aggregator']['runtime']['keccak256']and ag['address']==prior['feeds']['chainlink_aggregator']['address'],'Actual prior-pinned ETH aggregator runtime')
    cl=words(feed['chainlink_primary']['latestRoundData'],5);precision=words(feed['chainlink_primary']['decimals'],1)[0]
    check(precision==8 and 0<cl[0]<(1<<80)and cl[0]<=cl[4]<(1<<80)and 0<cl[1]<(1<<255)and 0<cl[2]<=cl[3]<=timestamp and timestamp-cl[3]<=86400,'Contract-compatible conditional ETH round')
    eth=Fraction(cl[1],10**precision)
    check(Fraction(int(c['conditional_eth_usd']['numerator']),int(c['conditional_eth_usd']['denominator']))==eth,'Exact rational ETH value')
    check(feed['chainlink_primary']['aggregator']==feed['chainlink_secondary']['aggregator']and feed['chainlink_primary']['same_aggregator_as_secondary']is True,'One shared-aggregator service, not independent redundancy')
    for name in ('chainlink_primary','chainlink_secondary','pyth','api3'):
        entry=feed[name]['runtime'];raw=bytes.fromhex(bylabel[name+'.runtime']['response']['result'][2:]);check('0x'+keccak256(raw).hex()==entry['keccak256']==entry['expected_prior_keccak256']==prior['feeds'][name]['runtime']['keccak256'],'Authenticated source runtime')
    for name in ('pyth','api3'):
        slot=bylabel[name+'.implementation-slot']['response']['result'];check(slot==feed[name]['implementation_slot']==prior['feeds'][name]['implementation_slot'],'Exact current implementation slot')
        raw=bytes.fromhex(bylabel[name+'.implementation.runtime']['response']['result'][2:]);entry=feed[name]['implementation_runtime'];check('0x'+keccak256(raw).hex()==entry['keccak256']==entry['expected_prior_keccak256']==prior['feeds'][name]['implementation_runtime']['keccak256'],'Authenticated source implementation runtime')
        response=bylabel[name+'.observation']['response'];check(feed[name]['observation']==(response['result']if 'result'in response else {'rpc_error':response['error']}),'Exact stored-price or failure observation')
    py=words(feed['pyth']['observation'],4);exponent=py[2]-(1<<256)if py[2]&(1<<255)else py[2];pyth=Fraction(py[0])*Fraction(10)**exponent
    pyth_spread=abs(pyth-eth)/min(pyth,eth)*10000
    quote_review=[]
    for q in c['quotes']:
        pool=states[q['pool_id']];direction=q['zero_for_one'];amount=int(q['input_raw']);check(q['key']==pool['key']and 0<amount<1<<127,'Exact intended input and signed quoter range')
        name='quote.'+q['venue_label']+'.'+('ETH-to-ZZZ'if direction else 'ZZZ-to-ETH');row=bylabel[name]
        expected='0x'+(keccak256(b'quoteExactInputSingle(((address,address,uint24,int24,address),bool,uint128,bytes))')[:4]+word(32)+b''.join(word(v)for v in pool['key'])+word(int(direction))+word(amount)+word(256)+word(0)).hex()
        check(row['request']['params'][0]['data']==expected and row['request']['params'][0]['to']=='0x8dc178efb8111bb0973dd9d722ebeff267c98f94','Exact native official-quoter request')
        if direction:check(amount==int(Fraction(q['nominal_USD_from_single_ETH_round_only']*10**18)/eth),'Exact floor-rounded nominal input')
        else:check(amount==1000*10**18 and q['nominal_USD_from_single_ETH_round_only']is None,'Reverse input has no qualified USD claim')
        f=fee(pool,direction);check(f==q['known_directional_total_fee_pips'],'Exact current directional fee composition')
        review={'venue':q['venue_label'],'pool_id':pool['poolId'],'zero_for_one':direction,'input_raw':str(amount),'directional_fee_pips':f,'qualified_route':False,'postspot_known':False}
        if 'result'in row['response']:
            check(q['result']==row['response']['result'],'Captured successful quote')
            out,gas=words(q['result'],2);p=Fraction(pool['slot0']['sqrtPriceX96']**2,1<<192);ideal=Fraction(amount)*p if direction else Fraction(amount)/p
            net_ideal=ideal*Fraction(1000000-f,1000000)
            review.update(status='full_input_quote_returned',output_raw=str(out),quoter_reported_gas=gas,gross_loss_vs_own_stored_spot_bps=fraction((ideal-out)/ideal*10000),additional_loss_after_known_fee_vs_own_spot_bps=fraction((net_ideal-out)/net_ideal*10000))
        else:
            check(q['result']=={'rpc_error':row['response']['error']},'Captured application error, no fabricated fill')
            raw=bytes.fromhex(row['response']['error']['data'][2:]);check(raw[:4]==keccak256(b'UnexpectedRevertBytes(bytes)')[:4]and int.from_bytes(raw[4:36],'big')==32,'Canonical official wrapped quote failure')
            length=int.from_bytes(raw[36:68],'big');inner=raw[68:68+length];check(len(raw)==68+((length+31)//32)*32 and raw[68+length:]==bytes((-length)%32),'Canonical wrapper length/padding')
            if length==36 and inner[:4]==keccak256(b'NotEnoughLiquidity(bytes32)')[:4]:check('0x'+inner[4:].hex()==pool['poolId'],'Exact incomplete-input pool');review['status']='exact_input_incomplete_not_partial_success'
            elif length==0:review['status']='opaque_empty_revert_at_500k_no_precise_cause'
            else:raise AssertionError('Unexpected fresh quote error shape')
        quote_review.append(review)
    price_selected=Fraction(selected['slot0']['sqrtPriceX96']**2,1<<192);bands=[]
    for pool in states.values():
        ratio=Fraction(pool['slot0']['sqrtPriceX96']**2,selected['slot0']['sqrtPriceX96']**2)
        if int(pool['active_liquidity'])>0:
            bands.append({'pool_id':pool['poolId'],'active_liquidity':pool['active_liquidity'],'price_ratio_to_selected':fraction(ratio),'common_continuous_reference_at_max_500bps_possible':max(ratio,1/ratio)<=Fraction(105,95),'strict_principal_fee_only_candidate':pool['strict_principal_fee_only_candidate']})
    report={'status':'new_read_only_capture_integrity_and_math_verified','source_baseline':'0b31f33','requests':len(rows),'successful_result_responses':count_results,'application_error_responses':count_errors,'provider_refusals':0,'retries':0,'canonical_final_recheck':True,'anchor':{k:v for k,v in anchor.items()if k!='header'},'phase_elapsed_seconds':c['phase_elapsed_seconds'],'actual_minimum_start_spacing_seconds':min(b['started_elapsed_seconds']-a['started_elapsed_seconds']for a,b in zip(rows,rows[1:])),'independent_rpc_calls':0,'compiler_or_evm_runs':0,'old_tests_executed':0,'production_approved':False,'conditional_eth_usd':fraction(eth),'chainlink_age_seconds':timestamp-cl[3],'chainlink_sources_share_one_aggregator':True,'pyth_stored_eth_usd':fraction(pyth),'pyth_stored_age_seconds':timestamp-py[3],'pyth_spread_vs_chainlink_bps':fraction(pyth_spread),'api3_current_observation':'read reverted; this phase does not remeasure name/base/subscription zero values','selected_active_liquidity':selected['active_liquidity'],'largest_known_active_L_pool':largest['poolId'],'cheap_fee_only_lead':cheap['poolId'],'active_known_pool_band_checks':bands,'quote_reviews':quote_review,'limitations':['Known95-key inventory only; not a fresh global pool scan or highest-TVL/ownership proof.','ActiveL is not TVL, bidirectional usable depth or post-PoPL-withdrawal depth.','Current stored spot has no measured last-swap timestamp or independent truth proof.','ETH price is one conditional source, not an admitted dual source; no independent ZZZ pair is qualified.','Official quote output/gas does not expose post-state or prove complete LP3 activation/growth/maintenance/conversion or fees.','Quote loss figures use each venue own stored spot, not an approved conservative two-source USD vector.','No source, route, cap, destination, live provider or operating setting is adopted.']}
    raw=(json.dumps(report,indent=2,sort_keys=True)+'\n').encode()
    with (E/'INDEPENDENT_MARKET_REVIEW.json').open('xb')as stream:stream.write(raw)
    print(json.dumps({'status':report['status'],'sha256':sha(raw),'requests':33,'result_responses':count_results,'application_errors':count_errors,'selected_L':selected['active_liquidity'],'ETH_USD':decimal(eth),'pyth_age':report['pyth_stored_age_seconds'],'quote_statuses':[x['status']for x in quote_review]}))
if __name__=='__main__':main()
