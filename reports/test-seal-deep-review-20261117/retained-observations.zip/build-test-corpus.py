from pathlib import Path
import re,json,hashlib,collections
R=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
D=R/'reports/test-seal-deep-review-20261117'

groups={
'authority/bootstrap/one-time setup':'AccessController AdaptableTerms DirectGovernance FixedZZZBinding OperatorControls OperatorSealArtwork20261117 ProtocolPolicy RandomnessRequestSettings SealCriticalInputs20261117',
'contribution identity, exact input and marginal LP/share protection':'ActivationAssets AtomicActivationIntegration BucketCapacity ContributionBudgetIsolation ContributionEntryPriceSecurity ContributionMarkPacking ContributionPool ContributionPriceSecurity ContributionSourcePolicy ContributionThreePercent EntryExecutionBudget EntryReviewPolicy FixedZZZPool LPOnlyEntryBoundary NativeSourceIdentity PooledEntry ReservationCapacity',
'actual fee allocation, exact LP accounting and claims':'ClaimRouter CollectionScale CombinedCapacityGas DynamicAccounting ExactLPAllocation ExactLPRewards ExactLPVaultWire GlobalMembershipDust HarvestAudit20261106 IntegratedEconomicConservation LPRewardConversion LPRewardNativeFloor NativeFeeRewards PooledRewards RewardsAndFees RewardsCheckpointCaching',
'main/residual LP policy, pricing and physical execution':'BuybackExecution BuybackOperatingLimit CompoundInterval CustodyParking DynamicRange FeeAdjustedExecution GovernedExecutionLoss HybridActiveMain KeeperCompletion KeeperRangePolicy LiquidityEncoding LiquidityFactualChecks LPBalanceMath LPExecutionRouting MaintenanceCadence ManualRecoveryQualification ManualReferenceSwapQualification MigrationBudgetAdversarial MigrationExecutionBudget NativeAssetFoundation NativeCustody NativeLiquidity NativeVaultFlows NativeWrapperPolicy OptionalPortfolioCore OutsideOnlyUpkeep PoolSwitching PortfolioAccounting PortfolioPolicy PostExitReserveVenue PrincipalOperatingGuard RangePolicy RebalanceBudget RebalanceConfirmation ReferenceExecutionContext StrategyFeeSizing StrategyPriceSnapshot TypedV4Executor TypedV4Rewards V3VenueValidation',
'independent price-source/admission and external-read failures':'DualOracleSecurity OracleAndTransfers OracleReadCost PoolSpotPriceFeed PythPriceFeed SequencerPolicy',
'NFT traits, metadata, economic ownership and canonical lifecycle':'ArtworkLookup CanonicalHandoff CanonicalPreparation HolderCollectiveExit MetadataLifecycleNotifications MetadataLifecycleSnapshots MetadataRendererCompatibility NativeCanonicalIntegration NFTMetadata NFTOwnershipRights NFTRightsInvariants NFTRoyalties RoyaltyAudit20261105 RoyaltyFactoryCodeData RoyaltyLaunchWindow RoyaltyNoCustodian RoyaltyRecovery ZeroAssetCanonical',
'OpenSea helper, pinned runtime, quotas and same-chain mint history':'SeaDropArtworkBoundary20261117 SeaDropCanonical SeaDropFullHandoff SeaDropIntegration SeaDropPoPLIntegration SeaDropQuota',
'controlled gas/maximum-state and stateful accounting models':'GasProfileQualification ProductionGas ProductionInvariants',
'opt-in fork market/dependency observations':'CurrentNativePoolFork UniswapV4Fork',
'deliberate historical royalty-conversion model':'RoyaltyConversion RoyaltyRecoveryLegacy'
}
purpose={name:desc for desc,names in groups.items() for name in names.split()}
purpose.update({'ExactRoyaltyAllocation':'exact royalty-unit allocation versus explicit frozen reference model','PooledSecurity':'current pooled custody/contribution/callback failure models','VaultAccounting':'shared current native pooled fixture and real share/fee/reward accounting models'})

# These dispositions require source tracing, not a keyword inference.
seams={
'CanonicalHandoff':'Actual Migration instances supply validation; adapted foreign-home case is an explicit constructor rejection. Its compile-stage fixture difference is recorded separately.',
'CanonicalPreparation':'Actual Migration supplies validation; deterministic native venue explicitly supplies current execution context. No real venue/provider acceptance.',
'CombinedCapacityGas':'Migration=this fixture exposes a real controller-bound validation child; native execution adapter is explicit. Capacity/gas remain synthetic model bounds.',
'CurrentNativePoolFork':'First real-Vault branch binds Migration=this with real validation getter; native admission/actual selected contracts remain opt-in fork scope. Header still says current-accounting3 although sources are current accounting7: stale scope prose, not a runtime acceptance claim.',
'HarvestAudit20261106':'Actual Migration exists for actual-v4 section; ledger-only FinalIndex inherits RewardsAndFees setup, not a new custody graph.',
'HolderCollectiveExit':'Actual Migration handles economic fixture. Separate 1000-holder scale model is explicitly a model, not real 1000 actual-core LP creation.',
'IntegratedEconomicConservation':'Migration=this exposes real validation child; deterministic/native admission and current execution seams are explicit.',
'ManualRecoveryQualification':'Actual Migration and fixed native graph; positive readiness is controlled local operation, not actual target-chain/host approval.',
'ManualReferenceSwapQualification':'Actual Migration and current execution1/native graph; manual retained/bypass masks are explicit. No first-reservation getter omission found in setup.',
'NativeCanonicalIntegration':'Actual Migration and source/fixed-ZZZ bindings; same-chain funding model, not cross-chain transport.',
'NativeVaultFlows':'Migration=this has validation getter before first activation. The later EmergencyFingerprintManifest replacement occurs after existing-pool activation and exercises only emergency fingerprint context, not a fresh reservation.',
'OptionalPortfolioCore':'Actual Migration creates its fixed validation child; real local installed-v4 manager/positions with explicit native admission seam. 82 declarations are not 82 newly executed cases.',
'ProductionGas':'Migration=this supplies real validation; venue forwards AccountingExecutionFixture, not an arbitrary true/no-op identity. Measured deltas exclude setup/intrinsic/fake venue costs as declared.',
'ReferenceExecutionContext':'Actual Migration and explicit native installed-v4 reference/swap fixtures; current source profile is not live market qualification.',
'RoyaltyAudit20261105':'MintSaleEnd subgraph has real Vault but calls dormant mint only; no LP first-reservation path. A missing Migration getter here is not an exercised seam bug.',
'SeaDropCanonical':'Real Vault is for mint/canonical records, without LP first-reservation operation; absence of a Migration fixture is not itself a confirmed failure.',
'SeaDropFullHandoff':'Actual Migration plus native venue and exact NFT/royalty/canonical peers; real whole-graph controlled lifecycle, not real markets/VRF.',
'SeaDropPoPLIntegration':'Actual Vault dormant issuance with pinned SeaDrop runtime; no liquidity graph. Getter requirements for LP reservation do not apply to its mint-only setup.',
'SealCriticalInputs20261117':'Constructor-only Vault tests and actual NFT/root setup plus hash-pinned old-bytecode controls; no LP activation/reservation occurs.',
'VaultAccounting':'Base PooledVaultFixture exposes real validation and configures current native execution adapter/fixed ZZZ. Final mock exchange/fee funding is outside protocol operations; ordinary native sends preserve rollback. Descendants replacing Migration or venue need separate tracing.',
'ProductionInvariants':'Confirmed activePlan-only replacement regression was fixed with a real controller-bound validation child. New positive constructor/harvest smoke selected separately; no full invariant campaign is implied.',
'NFTRightsInvariants':'Confirmed activePlan-only replacement regression was fixed with a real controller-bound validation child. New positive constructor/royalty-claim smoke selected separately; no full invariant campaign is implied.',
'NativeFeeRewards':'Positive current-NFT constructor bare URI corrected to nonempty TEST-ONLY identifier. One selected real fee-split/backing case verifies changed setup; no full 22-method suite claim.',
'PooledRewards':'Positive current-NFT constructor bare URI corrected. Two codeful accounting tokens are isolated reward-ledger fixtures, not fresh two-token LP admission.',
'RewardsAndFees':'Positive current-NFT constructor bare URI corrected. Shared setup supplies exact fixed-ZZZ/current Rewards books; one affected fee-split case selected.',
'RewardsCheckpointCaching':'Inherits RewardsAndFees setup without overriding it; its two-currency checkpoints are current exact LP engine tests. No extra rerun solely for inherited URI string was requested.',
'UniswapV4Fork':'Bare positive root corrected statically only. Setup also lacks SyntheticPoolRegistry fixed-ZZZ binding, and wrapped-positive Manager paths conflict with current native-only Math admission. Six opt-in declarations are not current native qualification. Pinned Pons/market observations are deliberately historical; no public run performed.',
'BuybackExecution':'Confirmed native-versus-ERC20-only setup mismatch repaired with an isolated native Registry fixture. It checks actual reciprocal local Manager/core/State/PosM/Permit2 and retains native/fixed-ZZZ/hookless/fee/Oracle/Rewards checks; no shared synthetic helper or production guard is weakened. Three selected burn/rollback/authority methods have their own verification record, not a full 25-method claim.',
'PortfolioAccounting':'Typed Pricing/Budget/Vault stub composition does not invoke real Vault._reserve; matching Migration=this without validation is not automatically a failure.',
'NativeCustody':'Budget/canonical typed parent stubs exercise receipt/valuation helpers, not real first activation; no reservation seam claim.',
'RebalanceConfirmation':'Strategy/Budget with explicit stub Vault/venue/price observations; emergency context calls do not create first LP custody reservation.',
}


# Additional concrete execution-child candidates are being ported by the
# parallel contract-review agent; final helper evidence must retain its stage.
for _name in ('MigrationBudgetAdversarial','RebalanceBudget','GovernedExecutionLoss','ContributionThreePercent','KeeperCompletion'):
 seams[_name]='Initial source-traced gap: custom BudgetAdversarialVenue/subclasses lacked executionStrategy. Current test-only code now configures a real controller/policy math adapter, including replacement-venue call sites. Positive/negative current execution-seam verification is separate; this inventory does not declare all family methods passed.'
for _name in ('CanonicalHandoff','NativeCanonicalIntegration','SeaDropFullHandoff'):
 seams[_name]+=' LP-seeding originally used a CanonicalNativeVenue lacking executionStrategy. Its current constructor now supplies a real controller-bound math adapter/context; earlier constructor/mint-only success is not relabelled as an LP pass. Parallel activation/handoff verification has its own scope.'
seams['HolderCollectiveExit']+=' HolderExitVenue originally lacked executionStrategy; current code supplies a real controller-bound adapter. Earlier metadata descendant injection did not repair the base suite; parallel current base exit verification remains separately scoped.'
seams['PortfolioAccounting']+=' Its positive utilization/checkpoint methods originally lacked execution math; current Liquidity stub now forwards to the actual child. Nav-only behavior remains distinct; selected current execution verification is recorded separately.'
seams['MigrationExecutionBudget']='Initial ScaleHarness lacked current execution math and used a retired two-ERC20 model. Current port uses native ETH/fixed six-decimal ZZZ, actual Oracle and real math; exact aggregate-floor/base-unit and round-invalidation cases have separate staged verification, not actual LP placement.'
seams['EntryExecutionBudget']='Explicitly sets the narrower governed 1% policy in setUp; its 99%-deployed assertions are not a stale claim that the default remains1%. Shares the repaired pooled fixture.'

def mask(t):
 # Preserve character positions/lines while removing comments/string contents.
 return re.sub(r'//[^\r\n]*|/\*[\s\S]*?\*/|"(?:\\.|[^"\\])*"|\'(?:\\.|[^\'\\])*\'',lambda m:''.join('\n' if c=='\n' else ' ' for c in m.group()),t)
def end_brace(s,start):
 n=0
 for i in range(start,len(s)):
  if s[i]=='{':n+=1
  elif s[i]=='}':
   n-=1
   if n==0:return i+1
 raise ValueError('unbalanced source block')
def line(t,p):return t[:p].count('\n')+1
files=[]
for p in sorted((R/'test').rglob('*.sol')):
 rel=p.relative_to(R).as_posix();raw=p.read_bytes();t=raw.decode();s=mask(t);contracts=[]
 for m in re.finditer(r'\b(?:(abstract)\s+)?(contract|library|interface)\s+(\w+)\b([^{};]*)\{',s):
  b=s.find('{',m.start());e=end_brace(s,b);header=t[m.start():b].strip();base=re.search(r'\bis\s+(.+)',header,re.S)
  contracts.append({'name':m[3],'kind':('abstract ' if m[1] else '')+m[2],'line':line(t,m.start()),'header':header,'bases_raw':base[1].strip() if base else '', 'start':m.start(),'end':e})
 methods=[]
 for m in re.finditer(r'\bfunction\s+(\w+)\s*\(',s):
  q=s.find('(',m.start());n=1;i=q+1
  while n:
   if s[i]=='(':n+=1
   elif s[i]==')':n-=1
   i+=1
  b=s.find('{',i);semi=s.find(';',i);body_end=end_brace(s,b) if b>=0 and (semi<0 or b<semi) else semi+1
  header_end=b if b>=0 and (semi<0 or b<semi) else semi
  owners=[x for x in contracts if x['start']<=m.start()<x['end']];owner=min(owners,key=lambda x:x['end']-x['start'])['name'] if owners else None
  methods.append({'contract':owner,'name':m[1],'line':line(t,m.start()),'inputs_raw':t[q+1:i-1].strip(),'qualifiers_raw':t[i:header_end].strip(),'signature_raw':t[m.start():header_end].strip(),'body_source_sha256':hashlib.sha256(t[m.start():body_end].encode()).hexdigest(),'is_test_or_invariant_declaration':m[1].startswith('test') or m[1].startswith('invariant_')})
 imports=re.findall(r'import[\s\S]*?["\']([^"\']+)["\']\s*;',t)
 comments=[l.strip().removeprefix('///').strip() for l in t.splitlines() if l.strip().startswith(('/// @notice','/// @dev','/// Profile:','/// Real ','/// Current','/// Historical','/// TEST'))]
 stem=p.name.removesuffix('.t.sol').removesuffix('.sol')
 if '/historical/' in rel:profile='deliberate historical source/compatibility fixture'
 elif stem=='RoyaltyConversion':profile='deliberate historical royalty conversion, explicitly imports archived receiver/converter'
 elif stem=='MetadataRendererCompatibility':profile='current renderer versus authenticated historical baseline differential'
 elif stem=='SealCriticalInputs20261117':profile='current setup guards with explicit historical EVM counterexamples'
 elif stem=='UniswapV4Fork':profile='opt-in historical-market/wrapped mixed-current-source suite; adaptation required'
 elif stem=='CurrentNativePoolFork':profile='opt-in selected native market with current code and declared synthetic prices/VRF'
 elif '/local/' in rel:profile='disposable environment/recorded source9 or local fixture; not production adoption'
 elif stem in ('HistoricalMetadata20261115','ExactLPAllocationBaseline'):profile='frozen explicit differential reference, not current implementation'
 elif '/fixtures/' in rel:profile='pinned exact external runtime fixture; no provider/onboarding acceptance'
 elif '/helpers/' in rel or '/mocks/' in rel:profile='test helper/model; preserves explicitly scoped mocked/historical boundaries'
 else:profile='current-source unit/composition/model declaration; runtime compatibility not established by inventory'
 assessment=seams.get(stem)
 if assessment is None:
  if 'PooledVaultFixture' in t or 'DirectEntryFixture' in t:assessment='Shares the current repaired pooled/direct-entry fixture; imported base is recorded. No separate source-proved contradictory setup found in the bounded inventory; this is not a dynamic pass.'
  elif stem=='RoyaltyConversion' or '/historical/' in rel:assessment='Intentionally imports/fixes the superseded royalty-conversion model; do not count as fresh original-currency royalty evidence or remove merely because feature retired.'
  elif '/local/' in rel:assessment='Environment helper, no declared unit/invariant test methods. Existing runtime/profile/configuration must not be silently relabelled.'
  else:assessment='Declared purpose, imports, inheritance and test methods inventoried; no full body or runtime compatibility proof is claimed for this file.'
 files.append({'file':rel,'raw_source_sha256':hashlib.sha256(raw).hexdigest(),'is_test_file':p.name.endswith('.t.sol'),'declared_profile_scope':profile,'purpose':purpose.get(stem,'supporting fixture/interface/transport or baseline utility'),'inspection_level':('manually traced named setup/guard seam; not every body audited' if stem in seams else 'declarations/imports/header/inherited-profile inventory only; not a manual full-body audit'),'source_assessment':assessment,'declared_scope_comments':comments,'imports':imports,'production_imports':[x for x in imports if '/src/' in x],'test_dependencies':[x for x in imports if x.startswith('.') and '/src/' not in x],'contracts':[{k:v for k,v in x.items() if k not in ('start','end')} for x in contracts],'method_declarations':methods,'test_invariant_declarations':[x for x in methods if x['is_test_or_invariant_declaration']],'setup_declarations':[x for x in methods if x['name'] in ('setUp','_fixture','_setup','_deploySystem')]})
missing=[x['file'] for x in files if x['is_test_file'] and x['purpose'].startswith('supporting')]
assert not missing,missing
counts={'solidity_files':len(files),'test_files':sum(x['is_test_file'] for x in files),'helper_non_test_files':sum(not x['is_test_file'] for x in files),'declared_test_invariant_methods':sum(len(x['test_invariant_declarations']) for x in files),'all_declared_methods':sum(len(x['method_declarations']) for x in files)}
data={'schema':1,'scope':'all .sol files under test; retired .sol.txt archive is inventoried separately','evidence_type':'read-only declaration/import/fixture-context inventory with specific source-traced findings; NOT Forge discovery, compilation, coverage, passing count or every-body audit','counts':counts,'files':files,'noncompiled_archives':[p.relative_to(R).as_posix() for p in sorted((R/'test/legacy').rglob('*')) if p.is_file()]}
(D/'TEST_CORPUS_SOLIDITY.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf8')
doc=['# Solidity test-corpus context\n\n',f"Inventoried **{counts['solidity_files']} Solidity files**, including **{counts['test_files']} `.t.sol` files**, and **{counts['declared_test_invariant_methods']} declared test/invariant methods**. These are declarations, not Forge discovery or passes; inheritance can produce additional runnable copies and opt-in gates can exclude execution. No whole suite, invariant campaign or public fork was run for this inventory. The JSON records every declared method with contract, inputs, qualifiers, location and source-body digest.\n\n",'The assessment distinguishes current production-source models from deliberate historical implementations, differential baselines, helper-only files and archived noncompiled `.sol.txt` material. A date, filename, missing stub selector or keyword alone does not establish obsolescence. In particular, mint-only/component fixtures do not need the LP first-reservation seam.\n\n','## Source-traced findings\n\n',
'- **Invariant handler first-reservation reachability:** both handlers replaced the repaired base Migration binding with deployed `activePlan`-only objects. The actual path is first activation → Vault._reserve → Budget.validateReservation → Migration.validation. The two new fixtures supply real controller-bound validation children; focused positive seed/harvest and seed/royalty-claim methods are recorded separately. No fail-open boolean stub or invariant campaign is substituted.\n',
'- **Positive artwork setup:** NativeFeeRewards, PooledRewards, RewardsAndFees and opt-in UniswapV4Fork used bare `ipfs://` with the current NFT/renderer. Those inputs were corrected to explicit nonempty TEST-ONLY roots. Intentional negative/baseline controls are preserved. Three meaningful affected accounting cases are selected separately; the public fork is not executed.\n',
'- **BuybackExecution native-versus-synthetic admission:** setup used native input=address(0) with an ERC20-only helper that rejected zero. It now uses an isolated test-only native Registry validating the real local reciprocal Manager/core/State/PosM/Permit2 graph, while retaining native/fixed-ZZZ/hookless/fee/Oracle/Rewards and lifecycle checks. Three selected burn/rollback/authority cases have separate verification; no whole-25-method or real-market claim.\n',
'- **Old optional wrapped fork:** after the URI correction, setup still lacks the synthetic helper\'s fixed ZZZ identity, while positive WETH/ZZZ Manager paths disagree with current Math.nativeConfig requiring native currency0/isNativePool. It needs deliberate archival/native adaptation; pinned old market facts remain historical. No external RPC was used to pretend this is qualified.\n',
'- **Delegated execution math:** custom adversarial, holder-exit, bare canonical, portfolio-accounting and scale fixtures lacked the current executionStrategy/math interface. Positive setup can fail before its intended scenario; broad expected-revert tests can also hide a wrong failure cause. These source-traced families were assigned to a parallel fixture-only adaptation with actual math, not permissive placeholder returns; its exact verification is separate.\n',
'- **Shared-base sensitivity:** the repaired PooledVaultFixture, execution adapter and fixed-ZZZ getter propagate to descendants. Inherited baseline reuse retains exact source stages; an automatically generated inventory never converts unchanged historical evidence into current runtime acceptance.\n\n',
'## Per-file declared scope and assessment\n\n| File | Declared tests/invariants | Scope | Source-backed context / limit |\n| --- | ---: | --- | --- |\n']
for x in files:
 doc.append('| ['+x['file']+'](../../'+x['file']+') | '+str(len(x['test_invariant_declarations']))+' | '+x['declared_profile_scope']+' | '+x['source_assessment'].replace('|','\\|')+' |\n')
doc.append('\n## Retained limitations\n\nThis bounded pass does not establish that all listed methods compile, run, use realistic markets, or have complete assertions. Exact selected smoke/changed-fixture executions and any retained failures belong to their own verification record. Permissionless/malicious token behavior, maximum-state gas, current target markets/providers, OpenSea/VRF/content/host acceptance and independent audit remain separate. No production/configuration or protected-file changes are authorized by this inventory.\n')
(D/'TEST_CORPUS_SOLIDITY.md').write_text(''.join(doc),encoding='utf8')
print(json.dumps(counts,indent=2))
