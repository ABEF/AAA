"""Only the ten changed prior-30 methods, not their unchanged suites."""
from pathlib import Path
import datetime,hashlib,io,json,sys,time,unittest

R=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
E=Path(__file__).resolve().parent;sys.path.insert(0,str(R))
selected={
 'tests_python.test_manual_lp_review.ManualLPReviewTests':[
  'test_changed_final_nonce_controls_and_physical_backing_refuse_without_rewriting',
  'test_healthy_trading_and_new_price_rounds_keep_original_manifest_and_revalidate_twice',
  'test_latest_retained_guard_failure_refuses_without_fallback_or_third_probe',
  'test_contract_or_delegated_governance_requires_unsupported_outer_envelope_before_funding'],
 'tests_python.test_parked_manual_lp_review.ParkedManualLPReviewTests':[
  'test_explicit_execution1_lp3_profile_and_late_source_controls',
  'test_every_parked_control_is_rechecked_at_later_canonical_tip'],
 'tests_python.test_manual_lp_diagnostics.ManualLPDiagnosticsTests':[
  'test_final_controls_failure_is_distinct_from_final_simulation'],
 'tests_python.test_manual_lp_frozen_gas.ManualFrozenGasTests':[
  'test_strict_reference_wrapper_accepts_only_the_exact_updated_base_source'],
 'tests_python.test_operator_input_annotations.OperatorInputAnnotationTests':[
  'test_legacy_string_notes_keep_identical_parameter_records',
  'test_shared_struct_keeps_operation_specific_examples_and_meanings']}
names=[cls+'.'+name for cls,methods in selected.items()for name in methods]
assert len(names)==len(set(names))==10
paths=set(cls.rsplit('.',1)[0].replace('.','/')+'.py'for cls in selected)
paths.update(('zzz_ops/manual_lp_review.py','zzz_ops/management_review.py',
 'zzz_ops/operator_review.py','zzz_ops/function_reference.py','zzz_ops/operator_reference.py',
 'scripts/rehearse-manual-recovery.py','scripts/rehearse-manual-reference.py',
 'docs/function-reference.json','docs/operator-call-examples.json'))
def pins():return {n:hashlib.sha256((R/n).read_bytes()).hexdigest()for n in sorted(paths)}
before=pins();start=time.monotonic()
class Result(unittest.TextTestResult):
 def __init__(self,*args,**kwargs):super().__init__(*args,**kwargs);self.methods=[]
 def startTest(self,test):super().startTest(test);self.methods.append(test.id())
stage='earlier-changed-01'
with (E/(stage+'.log')).open('x',encoding='utf-8')as stream:
 result=unittest.TextTestRunner(stream=stream,verbosity=2,resultclass=Result).run(
  unittest.TestSuite(unittest.defaultTestLoader.loadTestsFromName(name)for name in names))
after=pins()
record={'schema':1,'baseline_commit':'003c8d8dc88b60cbfbcc8caf61fa864c6487b40f',
 'recorded_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'source_before':before,'source_after':after,'source_unchanged':before==after,
 'selected':names,'executed':result.methods,'tests_run':result.testsRun,
 'failures':[test.id()for test,_ in result.failures],'errors':[test.id()for test,_ in result.errors],
 'skips':result.skipped,'seconds':round(time.monotonic()-start,3),
 'unchanged_methods_executed':0,'existing_chain_or_signing':False}
with (E/(stage+'.json')).open('x',encoding='utf-8')as stream:json.dump(record,stream,indent=2);stream.write('\n')
print(json.dumps({k:record[k]for k in ('tests_run','failures','errors','source_unchanged','seconds')}))
assert result.methods==names,'Requested/executed identity mismatch'
raise SystemExit(0 if result.wasSuccessful()and before==after else 1)
