// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;
import {ProtocolPolicyFixture} from "./helpers/ProtocolPolicyFixture.sol";
import {NoHybridPolicyFixture, SinglePositionFixture} from "./helpers/PortfolioFixture.sol";
import {DualOracleFixture} from "./helpers/DualOracleFixture.sol";
import {ZZZOracle as FixtureOracleType} from "../src/ZZZOracle.sol";
using DualOracleFixture for FixtureOracleType;


import {Test} from "forge-std/Test.sol";
import {PooledVaultFixture} from "./VaultAccounting.t.sol";
import {ZZZMigration} from "../src/ZZZMigration.sol";
import {ZZZMigrationBudget} from "../src/ZZZMigrationBudget.sol";
import {ZZZOracle} from "../src/ZZZOracle.sol";
import {MockAccess, MockToken, MockPools, MockFeed} from "./mocks/Mocks.sol";
import {Ids, PoolConfig, Position, PositionStatus} from "../src/libraries/ZZZTypes.sol";
import {AccountingExecutionFixture} from "./helpers/AccountingExecutionFixture.sol";

contract MigrationExecutionBudgetTest is PooledVaultFixture {
    event MigrationValueChecked(uint256 indexed bucketId, uint256 beforeUSD, uint256 deployedUSD, uint256 idleUSD);

    function _target() private returns (bytes32 target) {
        PoolConfig memory c = pools.get(poolId);
        c.key.fee = 500;
        target = keccak256(abi.encode(c.key));
        pools.set(target, c);
    }
    function _migration() private returns (ZZZMigration migration) {
        migration = new ZZZMigration(address(ac));
        ac.bind(Ids.MIGRATION, address(migration));
    }
    function testReceiptIncludesOldAndNewDesignatedCompoundWithoutCountingRewardsBuybackOrDonations() public {
        uint256 id = activatedPosition();
        uint256 bucket = _bucket();
        venue.setFees(200, 400);
        vault.collectFees(bucket, block.timestamp + 100);
        assertEq(fees.compoundBalance(bucket, address(t0)), 10);
        assertEq(fees.compoundBalance(bucket, address(t1)), 20);
        _giftNative(address(vault), 777);
        t1.mint(address(vault), 888);
        venue.setFees(100, 200);
        bytes32 target = _target();
        ZZZMigration migration = _migration();
        vm.expectEmit(true, false, false, true, address(vault.migrationBudget()));
        emit MigrationValueChecked(bucket, 2045e18, 2045e18, 0);
        migration.moveFunds(bucket, target, 1, block.timestamp + 100);
        Position memory p = vault.group(bucket);
        assertEq(venue.a0(p.lpTokenId), 1015);
        assertEq(venue.a1(p.lpTokenId), 1030);
        assertEq(rewards.claimable(id, address(t0)), 270);
        assertEq(rewards.claimable(id, address(t1)), 540);
        assertEq(fees.buybackBalance(address(t0)), 15);
        assertEq(fees.buybackBalance(address(t1)), 30);
        assertEq(address(address(vault)).balance, 777);
        assertEq(t1.balanceOf(address(vault)), 888);
        assertEq(vault.sharesOf(id), 2000e18);
    }
    function testRepeatedMovesStartFreshSnapshotsIncludingAttributedIdle() public {
        activatedPosition();
        uint256 bucket = _bucket();
        bytes32 target = _target();
        ZZZMigration migration = _migration();
        venue.setSpendBps(9500);
        vm.expectEmit(true, false, false, true, address(vault.migrationBudget()));
        emit MigrationValueChecked(bucket, 2000e18, 1900e18, 100e18);
        migration.moveFunds(bucket, target, 1, block.timestamp + 100);
        assertEq(vault.group(bucket).idle0, 50);
        assertEq(vault.group(bucket).idle1, 50);
        venue.setSpendBps(10000);
        vm.expectEmit(true, false, false, true, address(vault.migrationBudget()));
        emit MigrationValueChecked(bucket, 2000e18, 2000e18, 0);
        migration.moveFunds(bucket, poolId, 1, block.timestamp + 100);
        assertEq(vault.group(bucket).idle0, 0);
        assertEq(vault.group(bucket).idle1, 0);
    }
    function testStaleBaselineFeedRejectsBeforeHarvestAndPreservesCustody() public {
        uint256 id = activatedPosition();
        uint256 bucket = _bucket();
        Position memory beforePosition = vault.group(bucket);
        venue.setFees(100, 200);
        bytes32 target = _target();
        ZZZMigration migration = _migration();
        vm.warp(block.timestamp + 3601);
        vm.expectRevert();
        migration.moveFunds(bucket, target, 1, block.timestamp + 100);
        assertEq(venue.fee0(), 100);
        assertEq(venue.fee1(), 200);
        assertEq(vault.group(bucket).lpTokenId, beforePosition.lpTokenId);
        assertEq(venue.ownerOf(beforePosition.lpTokenId), address(vault));
        assertEq(rewards.claimable(id, address(t0)), 0);
        assertEq(vault.poolBucket(target), 0);
    }
}

/// @dev Only the helper valuation math is isolated here. Integration tests above
/// and the adversarial suite use the actual Vault, fees, ownership and shares.
contract MigrationBudgetScaleHarness is SinglePositionFixture, NoHybridPolicyFixture {
    ZZZMigrationBudget public immutable budget;
    address public immutable executionStrategy;
    bytes32 private immutable pool;
    Position private position;
    uint256 private amount0;
    uint256 private amount1;
    constructor(address access,bytes32 poolId) {
        pool=poolId;budget = new ZZZMigrationBudget(access);
        executionStrategy=address(new AccountingExecutionFixture(access,address(this)));
    }
    function target(bytes32) external pure returns(int24,int24,uint160){return(-600,600,uint160(1<<96));}
    function validatePrice(bytes32) external pure returns(uint160){return uint160(1<<96);}
    function validateExitPrice(bytes32) external pure returns(uint160){return uint160(1<<96);}
    function migrationBudget() external view returns(ZZZMigrationBudget) { return budget; }
    // TEST ONLY: isolate cached-price/loss rounding, not confirmation timing.
    // The real helper/keeper buffer is exercised by its dedicated test suite.
    function rebalanceConfirmation() external view returns(address){return address(this);}
    function controlFingerprint(bytes32) external pure returns(bytes32){return keccak256("budget-scale fixture controls");}
    function observationFingerprint(uint256,bytes32) external pure returns(bytes32){
        return keccak256(abi.encode(keccak256("budget-scale fixture controls"),bytes32(0),uint64(0),uint64(0),uint8(0)));
    }
    function observations(uint256) external pure returns(bytes32,uint64,uint64,uint8){return(bytes32(0),0,0,0);}
    function setAmounts(uint256 a0, uint256 a1) external {
        position.poolId = pool;
        position.lpTokenId = 1;position.status=PositionStatus.Active;
        amount0 = a0;
        amount1 = a1;
    }
    function group(uint256) external view returns (Position memory) { return position; }
    function amounts(uint256) external view returns (uint256, uint256) { return (amount0, amount1); }
    function begin() external { budget.checkpoint(1, 0); budget.checkpoint(1, 1); }
    function finish() external { budget.checkpoint(1, 2); }
}

contract MigrationBudgetScaleTest is Test {
    MigrationBudgetScaleHarness private harness;
    MockFeed private stableFeed;
    MockFeed private nativeFeed;
    function setUp() public {
        vm.warp(1_000_000);
        MockAccess ac = new MockAccess(); ProtocolPolicyFixture.bind(address(ac));
        MockPools pools = new MockPools();
        MockToken stable = new MockToken(6);
        stableFeed = new MockFeed(8, 1e8);
        nativeFeed = new MockFeed(8, 2000e8);
        ZZZOracle oracle = new ZZZOracle(address(ac), address(0));
        oracle.setTestFeed(address(stable), address(stableFeed), 3600);
        oracle.setTestFeed(address(0), address(nativeFeed), 3600);
        PoolConfig memory c;
        c.key.currency0 = address(0);
        c.key.currency1 = address(stable);c.key.fee=3000;c.key.tickSpacing=60;c.operationsEnabled=true;
        bytes32 pool=keccak256(abi.encode(c.key));pools.set(pool,c);pools.setFixedZZZ(address(stable));
        harness = new MigrationBudgetScaleHarness(address(ac),pool);
        ac.bind(Ids.ORACLE, address(oracle));
        ac.bind(Ids.POOLS, address(pools));
        // The shared immutable Pricing helper authenticates the real Budget
        // through its Vault parent. This harness is that parent in this test.
        ac.bind(Ids.VAULT, address(harness));
        ac.bind(Ids.LIQUIDITY, address(harness));
        ac.bind(Ids.STRATEGY, address(harness));ac.seal();
    }
    function testMixedDecimalsAndUnequalPricesAcceptExactlyThreePercentAggregateLoss() public {
        harness.setAmounts(1 ether,1000e6); // Native ETH $2,000 + fixed six-decimal ZZZ $1,000.
        harness.begin();
        harness.setAmounts(1 ether,910e6); // $2,910, exactly 97%.
        harness.finish();
    }
    function testMixedNativeDecimalsRejectOneZZZBaseUnitPastFloor() public {
        harness.setAmounts(1 ether,1000e6);harness.begin();
        harness.setAmounts(1 ether,910e6-1);
        vm.expectRevert(ZZZMigrationBudget.Slippage.selector);harness.finish();
    }
    function testNativePriceRoundChangeCannotRepriceCapturedMaintenance() public {
        harness.setAmounts(1 ether,1000e6);harness.begin();
        nativeFeed.set(4000e8,block.timestamp,block.timestamp);
        harness.setAmounts(1 ether,910e6);
        vm.expectRevert(abi.encodeWithSelector(ZZZOracle.InvalidPrice.selector,address(0)));harness.finish();
        assertEq(harness.budget().maintenanceBucket(),1);
    }
}
