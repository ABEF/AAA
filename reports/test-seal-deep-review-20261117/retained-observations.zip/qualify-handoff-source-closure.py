from pathlib import Path
import datetime,hashlib,json,sys,tomllib
R=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2');sys.path.insert(0,str(R))
from zzz_ops.abi import keccak256
V=Path('C:/Users/Ali/.codex/visualizations/2026/10/14/01a13899-2be7-76f2-a5d0-72e4804c67b9');T=V/'test-seal-deep-review-20261117';D=R/'reports/test-seal-deep-review-20261117'
allowed={'test/GovernedExecutionLoss.t.sol','test/KeeperCompletion.t.sol','test/MigrationBudgetAdversarial.t.sol','test/MigrationExecutionBudget.t.sol'}
remaps=[tuple(s.split('=',1))for s in tomllib.loads((R/'foundry.toml').read_text(encoding='utf-8'))['profile']['default']['remappings']]
normal=json.loads((T/'normal-final-2/normal-size-evidence.json').read_bytes())
sha=lambda b:hashlib.sha256(b).hexdigest()
reports=[]
for label,file,contract in [('seadrop','SeaDropFullHandoff.t.sol','SeaDropFullHandoffTest'),('canonical-v10','CanonicalHandoff.t.sol','CanonicalHandoffTest')]:
 Owned=T/'execution-fixtures'/label;stage=Owned/'attempt2';raw=(stage/'RESULT.json').read_bytes();result=json.loads(raw);start=json.loads((stage/'START.json').read_bytes())
 assert result['selected_methods_exact']and result['exit_code']==0 and len(result['results'])==2 and all(x['status']=='Success'for x in result['results'])
 assert set(result['source_changes'])==allowed
 artifact=Owned/'out'/file/(contract+'.json');artifactraw=artifact.read_bytes();a=json.loads(artifactraw);m=a['metadata'];assert m['settings']['compilationTarget']=={'test/'+file:contract}
 assert m['compiler']['version'].startswith('0.8.26+')
 sources=[];tracked=[];outside=[];all_declared_unchanged=True
 for name,item in sorted(m['sources'].items()):
  path=R/name
  if not path.is_file():
   found=[R/(dst+name[len(prefix):])for prefix,dst in sorted(remaps,key=lambda x:len(x[0]),reverse=True)if name.startswith(prefix)]
   path=next((p for p in found if p.is_file()),path)
  assert path.is_file(),name
  relative=path.resolve().relative_to(R).as_posix();content=path.read_bytes();digest=sha(content);wanted=item['keccak256'];actual='0x'+keccak256(content).hex();lf='0x'+keccak256(content.replace(b'\r\n',b'\n')).hex()
  assert wanted in {actual,lf},(name,'compiler-source mismatch')
  assert relative not in allowed,(label,relative)
  in_snapshot=relative in start['source_before'];bracket=None
  if in_snapshot:
   bracket=start['source_before'][relative]==result['source_after'][relative]==digest
   assert bracket,(label,relative,'selected-closure changed')
   tracked.append(relative)
  else:outside.append(relative)
  if relative.startswith('src/'):
   assert normal['source_sha256'][relative]==digest,relative
  sources.append({'compiler_source':name,'physical_path':relative,'raw_sha256':digest,'compiler_keccak256':wanted,'matches_raw_or_LF_only_normalized_source':True,'normalization':'raw'if actual==wanted else'LF-only','recorded_before_after_equal':bracket,'scope':'src/test source bracket'if in_snapshot else'compiler metadata binds dependency bytes; no additional before snapshot claimed'})
 assert 'test/'+file in tracked
 assert 'test/helpers/CanonicalNativeVenue.sol'in tracked or label=='canonical-v10'
 bytecode=a['deployedBytecode']['object'];bytecode=bytecode[2:]if bytecode.startswith('0x')else bytecode
 code_sha=sha(bytes.fromhex(bytecode))
 record={'schema':1,'label':label,'recorded_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'raw_attempt_result_sha256':sha(raw),'raw_attempt_success_field':result['success'],'raw_attempt_global_tree_source_changes':result['source_changes'],'global_source_unchanged':False,'scoped_selected_execution_pass':True,'selected_method_count':2,'results':result['results'],'compiler_target':m['settings']['compilationTarget'],'compiler_version':m['compiler']['version'],'compiler_metadata_source_count':len(sources),'selected_src_test_bracket_count':len(tracked),'other_compiler_bound_dependencies':len(outside),'all_selected_src_test_before_after_equal':True,'all4_unrelated_changed_test_files_excluded_from_metadata_closure':True,'artifact_path':artifact.relative_to(Owned).as_posix(),'artifact_sha256':sha(artifactraw),'runtime_object_sha256':code_sha,'raw_metadata_sha256':sha(a['rawMetadata'].encode('utf-8')),'source_closure':sources,'normal_production_source_pins_preserved':True,'pinned_tools_match_accepted_evidence':True,'new_rpc_signing_or_deployment':False,'no_test_rerun_for_unrelated_drift':True,'limit':'Solc-target metadata and exact src/test bracket narrow the claim. Dependencies not in original bracket are tied to actual compiled metadata/current bytes, not claimed before-snapshotted. Whole test gas includes setup/many transactions and is not a production transaction or gas-profile qualification.','production_approved':False}
 with(stage/'SOURCE_CLOSURE_ASSESSMENT.json').open('x',encoding='utf-8')as f:json.dump(record,f,indent=2);f.write('\n')
 prefix='HANDOFF_'+label.upper().replace('-','_')
 for source,target in [(stage/'RESULT.json',prefix+'_ATTEMPT2.json'),(stage/'forge.json',prefix+'_FORGE.json'),(stage/'forge.stderr.log',prefix+'_STDERR.log'),(stage/'SOURCE_CLOSURE_ASSESSMENT.json',prefix+'_SOURCE_CLOSURE.json'),(Owned/'RESULT.json',prefix+'_INITIAL_EMPTY_SELECTION.json'),(Owned/'forge.stderr.log',prefix+'_INITIAL_STDERR.log')]:
  with(D/target).open('xb')as f:f.write(source.read_bytes())
 reports.append({k:record[k]for k in ['label','scoped_selected_execution_pass','selected_method_count','compiler_metadata_source_count','selected_src_test_bracket_count','other_compiler_bound_dependencies','artifact_sha256','runtime_object_sha256','global_source_unchanged']})
summary={'schema':1,'scope':'Four explicitly selected changed-fixture handoff methods, exact compiled-target source closure stable; global unrelated changes preserved separately.','distinct_selected_methods_passed':4,'initial_attempts_selected_zero':2,'initial_attempts_not_passes':True,'unchanged_full_suites_rerun':False,'source_or_code_edits_by_this_driver':False,'runs':reports,'production_approved':False}
with(D/'HANDOFF_EXECUTION_RESULT.json').open('x',encoding='utf-8')as f:json.dump(summary,f,indent=2);f.write('\n')
print(json.dumps(summary))
