from pathlib import Path
import subprocess,json,hashlib
R=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
V=Path('C:/Users/Ali/.codex/visualizations/2026/10/14/01a13899-2be7-76f2-a5d0-72e4804c67b9')
D=V/'test-seal-deep-review-20261117'
cases=[
 ('rights','NFTRightsInvariants','NFTRightsInvariantTest','testConstructorActivationAndRoyaltyClaimReachable20261117',1),
 ('native-fees','NativeFeeRewards','NativeFeeRewardsTest','testNativeFeeSplitIsIndexedAndSeparatelyBacked',1),
 ('pooled-rewards','PooledRewards','PooledRewardsTest','testOwnerFeesFollowSharesAndCollectiveIsEqualAcrossBuckets',1),
 ('fee-split','RewardsAndFees','RewardsAndFeesTest','testFeeSplitIsExactAndBacked',1),
 ('buyback','BuybackExecution','BuybackExecutionTest','testApprovedDirectSwapBurnPreservesRewardAndCompoundBalances|testSwapFailureRollsBackThenClaimsAndRetryRemainAvailable|testUnauthorizedCallerAndDirectReserveReleaseRejected',3)
]
records=[]
def snapshot():
 return {p.relative_to(R).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for root in ('src','test') for p in (R/root).rglob('*.sol')}
for label,file,contract,method,count in cases:
 command=[str(V/'foundry-v1.4.4/forge.exe'),'test','--match-path','test/'+file+'.t.sol','--match-contract',contract,'--match-test',method,'--out',str(D/'corpus-smokes/out'),'--cache-path',str(D/'corpus-smokes/cache'),'--use',str(V/'toolchain-0.8.26/solc.exe'),'--json']
 before=snapshot();result=subprocess.run(command,cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 stem='corpus-'+label+'-results';(D/(stem+'.json')).write_bytes(result.stdout);(D/(stem+'.stderr.log')).write_bytes(result.stderr)
 status=[]
 try:
  output=json.loads(result.stdout)
  for c,details in output.items():
   for name,row in details.get('test_results',{}).items():status.append({'contract':c,'method':name,'status':row['status'],'reason':row['reason']})
 except Exception as e:status=[{'parse_error':str(e)}]
 after=snapshot();record={'label':label,'command':command,'exit_code':result.returncode,'expected_selected_count':count,'actual_results':status,'source_sha256_before':before,'source_changes_during_command':[p for p,h in before.items() if after.get(p)!=h],'foundry_sha256':hashlib.sha256((R/'foundry.toml').read_bytes()).hexdigest(),'stdout_sha256':hashlib.sha256(result.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(result.stderr).hexdigest()}
 records.append(record);(D/'corpus-selected-manifest.json').write_text(json.dumps(records,indent=2)+'\n')
 print(json.dumps({'label':label,'exit':result.returncode,'selected':status,'sources_changed':record['source_changes_during_command']}),flush=True)
print('Finished only explicitly selected changed-fixture checks; no full suite/invariant/fork run.',flush=True)
