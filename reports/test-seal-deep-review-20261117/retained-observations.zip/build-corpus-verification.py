from pathlib import Path
import json,hashlib,sys,re
R=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2');sys.path.insert(0,str(R))
from zzz_ops.abi import keccak256
V=Path('C:/Users/Ali/.codex/visualizations/2026/10/14/01a13899-2be7-76f2-a5d0-72e4804c67b9/test-seal-deep-review-20261117');D=R/'reports/test-seal-deep-review-20261117';O=V/'corpus-smokes/out'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
warnings={}
def load(p):
 b=p.read_bytes();text=b.decode('utf16') if b.startswith(b'\xff\xfe') else b.decode('utf8')
 if not text.lstrip().startswith('{') and not text.lstrip().startswith('['):
  prefix,separator,payload=text.partition('\n')
  if not separator or not re.fullmatch(r'\d{4}-\d{2}-\d{2}T[^\s]+\s+WARN evm::traces: failed to read cache file .*signatures.*',prefix):
   raise ValueError('unrecognized non-JSON process output: '+str(p))
  warnings[p.name]=prefix;text=payload
 return json.loads(text)
def compact(path,success_only=False):
 j=load(path);items=[]
 for c,v in j.items():
  for name,x in v.get('test_results',{}).items():
   if success_only and x['status']!='Success':continue
   items.append({'contract':c,'method':name,'status':x['status'],'reason':x['reason'],'kind':x['kind'],'trace_groups':len(x.get('traces',[]))})
 assert items,'no tests is no verification'
 return items
stages={
 'production_seed':('corpus-production-smoke-results.json',O/'ProductionInvariants.t.sol/ProductionAccountingInvariantTest.json'),
 'rights_seed':('corpus-rights-results.json',O/'NFTRightsInvariants.t.sol/NFTRightsInvariantTest.json'),
 'native_fee_split':('corpus-native-fees-results.json',O/'NativeFeeRewards.t.sol/NativeFeeRewardsTest.json'),
 'pooled_rewards':('corpus-pooled-rewards-results.json',O/'PooledRewards.t.sol/PooledRewardsTest.json'),
 'fee_split':('corpus-fee-split-results.json',O/'RewardsAndFees.t.sol/RewardsAndFeesTest.json'),
 'buyback_authority_prior_quote_adapter':('corpus-buyback-results.json',V/'buyback-fixture-first-native/BuybackExecutionTest.json'),
 'buyback_final_quote':('corpus-buyback-final-results.json',O/'BuybackExecution.t.sol/BuybackExecutionTest.json')
}
cachepath=V/'corpus-source-keccak-cache.json';cache=load(cachepath) if cachepath.exists() else {}
def keccak_text(b):
 b=b.decode().replace('\r\n','\n').encode();h=hashlib.sha256(b).hexdigest()
 if h not in cache:cache[h]='0x'+keccak256(b).hex();cachepath.write_text(json.dumps(cache)+'\n')
 return cache[h]
records={};unique=set()
for label,(name,artifact) in stages.items():
 results=compact(V/name,success_only=True);assert all(x['status']=='Success' for x in results)
 if label=='buyback_authority_prior_quote_adapter':assert len(results)==1
 for x in results:unique.add((x['contract'],x['method']))
 a=load(artifact);sourceinfo=[]
 for p,details in a['metadata']['sources'].items():
  local=R/p;row={'file':p,'compiler_source_keccak256':details['keccak256']}
  if local.is_file():
   b=local.read_bytes();row.update(current_raw_sha256=hashlib.sha256(b).hexdigest(),matches_current_compiler_text=keccak_text(b)==details['keccak256'])
  sourceinfo.append(row)
 records[label]={'results':results,'raw_stdout_sha256':sha(V/name),'known_stdout_prefix_warning':warnings.get(name),'artifact_sha256':sha(artifact),'compiler_sources':sourceinfo,'compiler':a['metadata']['compiler'],'settings':a['metadata']['settings']}
assert len(unique)==8,(len(unique),unique)
manifest=load(V/'corpus-selected-manifest.json')
for record in manifest:
 if record['label']!='buyback':assert record['exit_code']==0
 assert not record['source_changes_during_command'],record['source_changes_during_command']
out={'reused_fixture_stage_assessment':'Production/rights seed observations retain their earlier fixture program. The later optional zero-policy branch is not used by their fixed nonzero policy; the subsequent shared native-funding/rollback model correction is separately verified by the execution-fixture owner. These eight observations are not relabelled as final whole-program passes.', 'schema':1,'type':'selected changed-fixture EVM checks, not a full test-corpus/invariant/market campaign','unique_methods_passed':8,'production_sources_changed':False,'public_rpc_or_existing_anvil_used':False,'unchanged_suites_rerun':False,'stages':records,'source_stage_limits':'The already-passing authority method retains its first native-admission stage before deterministic getLiquidity was added. Only its two failed swap cases were rerun after that quote-model correction. Later independent execution-fixture ports may differ from current transitive test files; exact compiler-source hashes above are retained, never relabelled.','failed_stage':{'raw_stdout_sha256':sha(V/'corpus-buyback-results.json'),'results':compact(V/'corpus-buyback-results.json'),'classification':'Two quote-dependent failures identified missing State.getLiquidity and old pre-quote error expectation; authority was already successful. Final negative requires actual core.swap observation before accepting wrapped InvalidState and retains full rollback, holder claims and successful retry.'},'raw_trace_retention':'Original complete stdout (including controlled deployment/execution traces) remains external under the task evidence directory and is hashed per stage; compact tracked results avoid embedding megabytes of duplicated code.','profile_sha256':sha(R/'foundry.toml'),'selected_runner_manifest_sha256':sha(V/'corpus-selected-manifest.json'),'static_fork_limit':'UniswapV4Fork only received a source/static-inspected nonempty URI fixture. It was not executed; missing source identity/wrapped-current-native incompatibility remains explicit.'}
(D/'TEST_CORPUS_VERIFICATION.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf8')
lines=['# Selected test-corpus fixture verification\n\n','Eight distinct changed-fixture methods pass. This is not a full-corpus/full-invariant or public-fork pass.\n\n','| Stage | Method | Result |\n| --- | --- | --- |\n']
for label,row in records.items():
 for x in row['results']:lines.append('| '+label+' | `'+x['method']+'` | '+x['status']+' |\n')
lines.append('\nThe two new handler smokes prove real positive activation shares/membership, exact funded LP allocations and a positive post-opening royalty claim. Three changed positive-URI ledger setups prove their intended owner/equal-collective/split backing again. The native buyback fixture now validates the actual local reciprocal venue graph, observes deterministic quote liquidity and proves swap/burn preservation, failed-swap rollback with successful retry, and unchanged authority. Its negative case explicitly expects an actual core swap call before accepting the quoter\'s wrapped error.\n\n')
lines.append('The already-passing buyback authority method retains its prior stage; only failed quote-dependent methods were rerun. Original failed raw output/source/artifact hashes are retained. The current-context table is a declaration inventory, not claimed runtime coverage. Exact compiler inputs, stage differences and original raw trace hashes are in [TEST_CORPUS_VERIFICATION.json](TEST_CORPUS_VERIFICATION.json). Independent later fixture ports retain their separate scope; no production source, default, signer, network, existing chain or service changed.\n')
(D/'TEST_CORPUS_VERIFICATION.md').write_text(''.join(lines),encoding='utf8')
print(json.dumps({'passed_unique':8,'stages':{k:len(x['results']) for k,x in records.items()},'source_stage_differences':{k:[y['file'] for y in x['compiler_sources'] if not y.get('matches_current_compiler_text',True)] for k,x in records.items()}},indent=2))
