from pathlib import Path
import hashlib,json,subprocess
R=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
E=Path(__file__).resolve().parent
current_raw=(E/'CURRENT_CONTEXTS.json').read_bytes();contexts=json.loads(current_raw)['current']
oldpath=R/'reports/operator-behavior-followup-20261117/static-review.json';old=json.loads(oldpath.read_bytes());oldby={x['fingerprint']:x for x in old['findings']}
# This is the complete, explicitly enumerated current-review list, not a rule
# accepting all detector records, changed sources, or familiar detector names.
notes=[
('0daf5644faf7','Full close brackets fixed-ZZZ before1; the alleged stale token0 is the authenticated native currency identity. Current constructor only restricts the home-chain identity, not this lock or exact native receipt proof.'),
('b8eae13f5c4e','Post-entry-swap harvest intentionally retains pre-entry supply until entrant net shares are issued. activate/increase are mutex-protected; incumbent NAV is reread after harvest. Reviewed this exact reordered nested-leaf report directly, without broadening checker normalization.'),
('25f16c9f6501','Collect brackets fixed-ZZZ before1; token0 remains the configured native identity and delta receipt is checked before actual fees are allocated under the outer lock.'),
('5a559d5a5234','Collect path brackets native before0; the old token0 identity is required for comparing actual ETH to authenticated nativeReceived, rather than a stale price or configurable amount.'),
('872f75573e30','Residual-close path native before0 intentionally predates closeSecondary; equality with nativeReceived prevents prefunded/forced ETH from masquerading as residual proceeds.'),
('042dbb967bb3','Full-close native before0 is an intentional difference baseline around Manager.close; token identity is authenticated and no other economic Vault writer can enter under the mutex.'),
('399c6a8823aa','Residual-close fixed-ZZZ before1 is the intended exact receipt baseline around closeSecondary; any recipient/token callback cannot modify bucket shares through locked economic entry points.'),
('105710468200','Supply used after post-entry-swap compound release remains the pre-entry supply by design. Released compound belongs to incumbents; new shares follow revaluation and marginal deployment.'),
('e809b9efa29f','before1 across the zero-native-value Manager.balance alternative is the intentional fixed-ZZZ delta baseline. Exact returned token equality and postcall context checks run under the outer mutex; constructor restriction introduces no callback.'),
('708f59e1d05a','before1 across Manager.balance is the required fixed-ZZZ baseline. Full live context equality plus exact opposite asset deltas are checked before attributing the returned balance.'),
('44e17fa236a4','before0 across native-funded Manager.balance is the intentional ETH delta baseline. Exact returned token equality and control-context checks prevent prefunds from covering shortfalls while outer economic callers hold the lock.'),
('d49f86625117','Supply remains pre-entry across contributionNav reread after the entrant swap. Incumbent LP repricing is included in their NAV before issuing shares; the value read cannot authorize a callback-created entrant.'),
('13c8daf70201','before0 across Manager.balance must predate execution. Exact native outflow/inflow equality and immutable control context reject false returned amounts or changed routing controls.'),
('1846f761a6ad','Pre-entry supply remains unchanged across post-entry-swap dust flush. Dust is allocated before membership/shares change and cannot be captured by the entrant through a callback.'),
('e494619f1f44','Incoming amounts enter idle only after exact reception; subsequent swap/deploy proves entrant marginal value. Reentrancy cannot rewrite positions/totalIdle through the locked public economic entries.'),
('b5ae20c7453e','Terminal exit releases only the bucket compound reserve into attributed idle before final close. Migration-only outer call is nonReentrant and terminal validation precedes the financial writes.'),
('e63ad24b6003','Unwind harvests and releases designated compound before close. The idle writes occur inside a nonReentrant maintenance/exit caller; earned claim reserves stay in their ledgers.'),
('7f03d3f54d8a','Pool move rewrites main ID/centre/clock only after actual guarded deployment, with both assets kept in the same attributed bucket. Outer Migration-only move/resume calls hold the Vault mutex.'),
('abf964a30b56','Phase3 releaseCompound writes attributed idle under the outer nonReentrant compound path; phase4 consolidation does not release that reserve. Current constructor condition changes neither phase branch.'),
('175c52d0b416','Residual-only close executes operation2 and cannot take operation1 main-ID zeroing branch. It harvests first, attributes actual residual proceeds, and checks paused again; reported cross-branch lpTokenId write is not an extra reachable residual deletion.'),
('77b2dc844d19','Redeploy updates idle after exact Manager spent amounts; when creating, approvals/physical ownership and budget proofs precede successful attribution. Caller holds the mutex across the full sequence.'),
('b5dda96d6f1d','Join put writes main identity/centre only for create=true; existing contributions call increase into unchanged geometry. All writes occur before authenticated new-share issuance and rollback with a failed proof.'),
('5b42e46ce1ad','Late compound after putting entrant funds is attributed to incumbent NAV, not entrant input. Exact source-authorized release and outer lock prevent duplicate share value from a callback.'),
('0d5285f28ac1','Initial incumbent compound release before entrant reception intentionally moves reserves to idle. Exact balance/ledger assertions and later net-NAV share calculation prevent entrant subsidy.'),
('e5ca60758689','Whole rebalance replaces the main only after close and guarded mint; clock/centre and totalIdle are reconciled in the single locked operation with captured budget phases.'),
('25c229427693','Reinvestment calls redeploy under the compound/manual outer mutex. It redeploys attributed idle with exact delta checks; release of earned holder funds is not authorized by this helper.'),
('e4f4e47e10ee','Park calls harvest and actual close before status Parked. The lock spans venue calls and status assignment; only fixed Migration can invoke it with paused custody controls.'),
('ceffe91c8c9f','Redeploy harvest after balancing attributes any actual balancing-swap fees before deployment. The generic harvest helper contains branches for close but operation0 does not zero main ID.'),
('c20776c628df','PoolId assignment is deliberately between complete old-pool unwind and new deployment; ordered pair validation and bucket-level attribution persist, and the mutex forbids nested economic reads becoming writes.'),
('92a6db69d7c9','Fresh compound harvested from the entrant swap is reread separately and belongs to incumbents; later share computation subtracts that incumbent value. Fixed Fees authorization and mutex protect the idle write.'),
('27bb3765c72a','After Manager.mint/increase, assertPut checks actual spending against pre-call balances; only then is spent inventory removed from attributed idle. External token/venue qualification remains an assumption.'),
('2dfd7b4344e1','Join balance uses only the explicit entrant token amounts, not all idle. Full-context and exact receipt proof precede idle update under nonReentrant activate/increase.'),
('3f1bcbdc8c35','Individually reviewed newly emitted terminal-exit write bundle: _close clears main LP ID and attributes actual close proceeds before payout. Migration-only plus Vault mutex, terminal validator, minimum outputs and exact asset pushes prevent callback repetition; canonicalWrite separately requires inert authenticated import state.'),
('a2946a552099','bucketTotalShares is issued after contributionResult and exact deployment, before postwrite syncShares. Its old value stays protected by the outer activation/increase mutex across external calls.'),
('44381d2b95c6','Resume writes Active only after guarded movePool finishes on an initially Parked bucket. Migration-only caller and nonReentrant scope prevent a callback taking the resumed status early.'),
('7e60eaa34c24','Centre and lastRebalance are written only on new main mint, never ordinary increase. Exact minted/approved position identity and postput checks run within the locked operation.'),
('19b2bc3b774d','Individually reviewed second new terminal-exit bundle: idle becomes zero and status Exited before ETH/ZZZ transfers. Amounts are captured from attributed principal only; external push failure reverts all state, and the Vault mutex disallows repeat exit. Preserved holder rewards are held outside this principal ledger.'),
('c9dd99d90e1c','Phase4 closes only an existing residual before redeploy; operation2 leaves main ID unchanged. The report merges operation1 lpTokenId writes from the shared helper, but that branch is not selected for residual-only close.'),
('9fd5fffb00e9','Emergency parked recovery writes Active only after _pullCompound, redeploy and postbudget phase succeed. Public keeper calls cannot select parked emergency, and Migration controls retained check masks.'),
('674b5ad80e90','The postbalance join harvest is collect=0; the shared close helper alternatives are not selected. Actual swap-generated fees are funded to incumbent rights before entrant shares, with mutex held.'),
('5a3f5d9148a8','Balance idle writes use p.idle minus explicit budget plus exact returned amounts. Matching context and before/after token equality protect attribution against nested venue callbacks.'),
('73f2efb487b3','depositUSD increments after marginal deployed LP/net-NAV proof and share issuance. Economic writers are locked; notifier/read callbacks cannot fabricate a second deposit.'),
('68b64d2229b8','Unwind actual close updates main ID and idle only after harvest/release/checkpoint; outer rebalance/move mutex and downstream budget validation prevent a half-closed successful operation.'),
('76c08e7662ec','_receiveVenue operation1 clears main ID, operation2 leaves it and operation0 allocates fees. Those typed branches execute under locked economic routes with exact net receipts, not arbitrary public operation selection.'),
('66190b110e6c','Parked emergency rebalance pulls existing designated compound before redeploy. Migration-only paused emergency and outer mutex prevent a nested write from crossing canonical or ordinary paths.'),
('e86ae7aafa35','_pullCompound releases native and fixed-ZZZ separately from fixed Fees, then updates attributed idle. Exact source authorization and the lock on all economic callers prevent double release/reentry.'),
('03e67bdba38d','First activation writes pool/status after reservation and before zero-share checkpoint intentionally. Outer activate has owner/Entry, live/operating/principal and mutex checks; callback cannot activate again.'),
('bc857e9af626','Move of Parked funds releases compound into the same bucket before new mint. Attributed reserves and pair validation stay intact under Migration-only nonReentrant resume/move.'),
('4815109ee75a','_visualAttributes.number is a value-type uint256 with Solidity zero initialization. Increment occurs before bounded color-label rendering; the tightened baseURI parser does not modify that number or loop.'),
('4e2c5c10767d','freshCompound is a value-type uint256 with defined zero when supply=0; nonzero-supply branch assigns it from actual reserve release before incumbent NAV. Constructor current-chain validation does not change this branch.'),
('3d8fdc44dedf','currentValue intentionally calls validateExitPrice for its revert-based price validation; its returned centre is not needed to value actual portfolio token amounts. URI validation tightening is independent of valuation.'),
('ce881e72ccc4','_ownedCollection calls ownerOf solely to ensure existence via standard revert; the returned owner is not serialized or used as authority by this read-only renderer. Tightened URI validation grants no writes.'),
('a86d4f9b65cb','Direct mint payee originates in fixed canonical/policy validation, which rejects zero recipients. SeaDrop-bound issuance skips the ETH call entirely; current-chain constructor constraint neither alters payee nor relaxes source validation.'),
('b299d2cfab85','_balanceUsing postcall totalIdle updates follow exact token net-delta and control equality; no parallel Vault economic writer can enter under the outer lock.'),
('923903bcc24a','Join contributionUSD and postwrite membership updates occur only after contributionResult and share update. Callback reads may observe transient state, but authorized writes remain locked/authenticated; no new callback is introduced.'),
('eba10e3329e6','Join sharesOf is updated after actual marginal deployment proof and before authenticated syncShares. No incoming owner/token callback can recursively issue another share through the locked entry.'),
('2960a1ee6f0c','Activation sets nftBucket before zero-share checkpoint intentionally, preserving fee-index domain; reservation and current-owner validation hold under the outer lock before join.'),
('a78635ae2d97','_receiveVenue operation1 main-ID clearing and idle attribution occur after exact portfolio receipt proof; operation0 fees do not mutate principal. Same locked outer callers remain.'),
('1fde0ae2e727','New main mint ID write happens after Manager return, followed by LP approvals and exact spending/deployment assertions before completion. Any failed callback/proof reverts the whole contribution or maintenance.'),
('450ddabc5ceb','Compound release updates totalIdle only after fixed Fees returns exact designated reserve; actual economic caller retains Vault mutex. This is not a permissionless arbitrary reserve writer.'),
('2e37b68d4bae','_reserve emits PoolReserved after fixed canonical registerAlias. That is a typed authenticated bounded alias registration, not an arbitrary callback. Current constructor restricts chain identity and adds no notification path.'),
('0a039fdbceca','Low-level ETH mint forwarding is an intentional exact-value transfer; paid boolean and captured mint policy fingerprint are checked, with nonReentrant mint. SeaDrop-bound path performs no Vault ETH forwarding.'),
('cb0225d846c9','Vault structurally matches IActivationVault activation/increase signatures with typed fixed Entry and owner checks. Nominal inheritance would not add authorization, and new constructor only fixes canonical home to current chain.'),
('5b868ce30ce7','PositionExecutor structurally supplies closeSecondary to the fixed native portfolio pipeline; explicit callers/ownership and trusted module bindings constrain it. The referencing Vault constructor change does not modify this ABI.'),
('53d92a240b6c','LiquidityManager structurally supplies closeSecondary; Vault selects it through the immutable bound module and the residual close path has typed caller checks. Nominal interface inheritance is not a runtime guard.'),
]
assert len(notes)==len(contexts)==65
# Reconstruct the only changed whole-file bytes against the reviewed prior
# revision. This is scope evidence, not an automatic disposition rule.
proof=[]
for path,replacements in [('src/ZZZVault.sol',[(b'nftHomeChain == 0 || nftHomeChain != block.chainid ||',b'nftHomeChain == 0 ||')]),('src/ZZZNFTMetadata.sol',[(b'value.length>7',b'value.length>=7'),(b'value.length>5',b'value.length>=5')])]:
 raw=(R/path).read_bytes();prior=subprocess.check_output(['git','show','003c8d8:'+path],cwd=R);restored=raw
 for new,oldvalue in replacements:
  assert restored.count(new)==1,(path,new)
  restored=restored.replace(new,oldvalue,1)
 assert restored==prior,path
 assert hashlib.sha256(prior.replace(b'\r\n',b'\n')).hexdigest()==old['source_sha256_lf'][path]
 proof.append({'path':path,'current_raw_sha256':hashlib.sha256(raw).hexdigest(),'prior_raw_sha256':hashlib.sha256(prior).hexdigest(),'reconstructed_prior_exactly':True,'changed_sites':[n.decode()for n,_ in replacements]})
result={'schema':1,'input_sha256':hashlib.sha256(current_raw).hexdigest(),'findings':[],'independent_audit':False,'scope_proof':proof,'new_text_fingerprints':[]}
for item,(prefix,note)in zip(contexts,notes):
 assert item['fingerprint'].startswith(prefix)
 earlier=oldby.get(item['fingerprint'])
 if earlier:
  disposition=earlier['disposition'];prior=earlier['rationale']
 else:
  assert prefix in {'b8eae13f5c4e','3f1bcbdc8c35','19b2bc3b774d'}
  disposition='false_positive';prior=''
  result['new_text_fingerprints'].append(item['fingerprint'])
 rationale='Current individual review: '+note
 if prior:rationale+=' Prior detailed context retained, after rereading current code: '+prior
 rationale+=' The only whole-file changes are the checked Vault constructor current-chain equality and the Metadata bare-scheme rejection. No lock, custody/token binding, amount proof, claim right or post-call validation is removed. External dependency qualification and independent audit remain required.'
 row={**item,'disposition':disposition,'rationale':rationale,'current_review_note':note,'prior_same_fingerprint':item['fingerprint']if earlier else None,'review_scope':'Individually current source/context review. No claim of new full-transitive or dynamic acceptance; not counted as exact-source reuse.'}
 result['findings'].append(row)
with (E/'ASSESSMENTS.json').open('w',encoding='utf-8')as f:json.dump(result,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps({'individually_reviewed':len(result['findings']),'new_text_fingerprints':result['new_text_fingerprints']}))
