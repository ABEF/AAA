from pathlib import Path
import json,hashlib,shutil,sys
sys.path.insert(0,str(Path.cwd()))
from zzz_ops.abi import keccak256
R=Path.cwd();V=Path('C:/Users/Ali/.codex/visualizations/2026/10/14/01a13899-2be7-76f2-a5d0-72e4804c67b9/test-seal-deep-review-20261117');D=R/'reports/test-seal-deep-review-20261117'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def readjson(p):
 raw=p.read_bytes();return json.loads(raw.decode('utf-16') if raw.startswith((b'\xff\xfe',b'\xfe\xff')) else raw.decode('utf8'))
def results(path):
 value=readjson(path);items=[]
 for contract,v in value.items():
  for name,row in v.get('test_results',{}).items():items.append({'contract':contract,'method':name,'status':row['status'],'reason':row['reason'],'gas':row.get('kind',{}).get('Unit',{}).get('gas')})
 assert items,'zero selected tests do not verify anything'
 return items
initial=results(V/'critical-inputs-results.json')
initial_pass=[x for x in initial if x['status']=='Success']
assert len(initial_pass)==3
final=results(V/'critical-inputs-final-results.json');assert len(final)==2 and all(x['status']=='Success' for x in final)
canonical=results(V/'critical-canonical-final-results.json');assert len(canonical)==1 and canonical[0]['status']=='Success'
artifacts={
 'initial_current_guards':V/'critical-inputs/initial-stage/SealCriticalInputs20261117Test.json',
 'final_portable_historical_controls':V/'critical-inputs/out/SealCriticalInputs20261117.t.sol/SealCriticalInputs20261117Test.json',
 'final_canonical_constructor_case':V/'critical-canonical/out/CanonicalHandoff.t.sol/CanonicalHandoffTest.json'
}
source_bindings={}
for name,p in artifacts.items():
 a=readjson(p); sources=a['metadata']['sources']; current=[];stage_different=[]
 for path,val in sources.items():
  local=R/path
  if not local.is_file():continue
  raw=local.read_bytes();k='0x'+keccak256(raw.decode('utf8').replace('\r\n','\n').encode()).hex()
  info={'file':path,'compiler_source_keccak256':val['keccak256']}
  if k==val['keccak256']:info['current_raw_sha256']=hashlib.sha256(raw).hexdigest();current.append(info)
  else:info['current_compiler_source_keccak256']=k;stage_different.append(info)
 if name=='final_portable_historical_controls':assert not stage_different,(name,stage_different)
 if name=='final_canonical_constructor_case':
  assert [x['file'] for x in stage_different]==['test/VaultAccounting.t.sol'],stage_different
  prior=V/'critical-canonical/passing-stage/VaultAccounting.t.sol'
  expected=sources['test/VaultAccounting.t.sol']['keccak256']
  assert '0x'+keccak256(prior.read_text().encode()).hex()==expected
 source_bindings[name]={'artifact_sha256':digest(p),'compiler_source_count':len(sources),'current_matching_sources':current,'different_from_current_sources':stage_different,'compiler_sources':sources}
fixture=[]
for name in ('ZZZVault','ZZZNFTMetadata'):
 p=R/'test/fixtures/seal-critical-003c8d8'/f'{name}.json';a=readjson(p);b=bytes.fromhex(a['bytecode']['object'].removeprefix('0x'));assert hashlib.sha256(b).hexdigest()==a['provenance']['creation_sha256'];fixture.append({'file':p.relative_to(R).as_posix(),'file_sha256':digest(p),'creation_sha256':hashlib.sha256(b).hexdigest(),'creation_bytes':len(b),'provenance':a['provenance']})
for file,out in [('critical-inputs-final-results.json','SEAL_GUARD_FINAL_RAW.json'),('critical-canonical-final-results.json','SEAL_CANONICAL_FINAL_RAW.json')]:
 raw=(V/file).read_bytes();t=raw.decode('utf-16') if raw.startswith((b'\xff\xfe',b'\xfe\xff')) else raw.decode('utf8');(D/out).write_bytes(t.encode('utf8'))
data={'schema':1,'baseline_git':'003c8d8dc88b60cbfbcc8caf61fa864c6487b40f','unique_methods_passed':6,'no_unchanged_suite_rerun':True,'coverage_limits':'Controlled constructor/root inputs and one adapted real canonical graph case only; no market/provider/OpenSea/VRF/content/deployment qualification, no claim every operator branch is dynamically verified. Three initial methods retain their original two-fix stage rather than being relabelled as final reservation source. Canonical constructor success has current production code but the explicitly identified prior VaultAccounting fixture source.','stages':{'initial_current_guards':{'passed_methods':initial_pass,'excluded_failures':[x for x in initial if x['status']!='Success'],'raw':'SEAL_INITIAL_RAW.json','scope':'Current two guard fixes before unrelated reservation change; no historical deployment occurred in the two file-permission failures.'},'final_portable_historical_controls':{'passed_methods':final,'raw':'SEAL_GUARD_FINAL_RAW.json','scope':'Final source snapshot; actual pinned historical bytecode acceptance followed by exact current rejection. This does not dynamically test the reservation helper.'},'final_canonical_constructor_case':{'passed_methods':canonical,'raw':'SEAL_CANONICAL_FINAL_RAW.json','scope':'All production hashes current; preserves source operating and destination importer states after foreign-chain constructor rejection. The transitive test/VaultAccounting.t.sol import is its authenticated earlier stage: VaultPolicyMock used by PreparationPolicy is unchanged; later added execution fixtures are not instantiated in this case. Not relabelled as wholly current test input.'}},'source_bindings':source_bindings,'historical_fixtures':fixture,'profile_delta':'SEAL_TEST_CONFIG_DELTA.json','superseded_and_failed_attempts':'SEAL_TEST_ATTEMPTS.json','final_foundry_sha256':digest(R/'foundry.toml')}
for stage,file in [('initial_current_guards','critical-inputs-results.json'),('final_portable_historical_controls','critical-inputs-final-results.json'),('final_canonical_constructor_case','critical-canonical-final-results.json')]:
 data['stages'][stage]['original_stdout_sha256']=digest(V/file)
 data['stages'][stage]['raw_payload_format']='original JSON text in UTF-8; original process stdout bytes/encoding retained externally and hashed here'
(D/'SEAL_GUARD_VERIFICATION.json').write_text(json.dumps(data,indent=2)+'\n',encoding='utf8')
print(json.dumps({'unique_methods':6,'initial_pass':3,'final_portable_pass':2,'final_canonical_pass':1,'initial_stage_source_differences':[x['file'] for x in source_bindings['initial_current_guards']['different_from_current_sources']]},indent=2))
