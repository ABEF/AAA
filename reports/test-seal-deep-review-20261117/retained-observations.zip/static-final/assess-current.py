from pathlib import Path
import hashlib,json,subprocess
R=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2');E=Path(__file__).resolve().parent
raw=(E/'CURRENT_CONTEXTS.json').read_bytes();contexts=json.loads(raw)['current'];oldpath=R/'reports/test-seal-deep-review-20261117/static-review.json';old=json.loads(oldpath.read_bytes());oldby={f['fingerprint']:f for f in old['findings']}
# Every current context below is explicitly fingerprint-bound and reviewed;
# location-only similarity is a provenance aid, never a blanket acceptance rule.
notes=[
('639eb70ae268','false_positive','Individually reread the new combined terminal-exit write-bundle presentation. Vault.exitBucketToHolders is fixed-Migration-only/nonReentrant; it authenticates terminal holder exit, harvests/release-designated-compound/closes, checks raw caller floors, zeroes attributed idle and sets Exited before exact ETH/ZZZ push. No callback can repeat a custody write. canonicalWrite separately requires its authenticated inert import path. This report combines the previous close/zero/status bundles; no checker normalization was widened.',None),
('c21481acaa75','false_positive','_afterMove remains onlyVault through checkpoint under the Vault economic mutex. Full value/control proofs precede fixed Pricing.endMaintenance and snapshot cleanup; emergency context survives until explicit final cleanup. Only reservation validation changes in this file, not this function or its fixed Pricing behavior.','d24a9d307704'),
('b58b60286902','false_positive','_beforeMove rejects an existing snapshot, captures bucket/controls/limits, obtains fixed Pricing mark and requires nonzero value before assigning all required snapshot data. Its onlyVault outer maintenance lock and no-token-callback sequence are unchanged; the new reservation predicate is not called here.','2a422f8c7262'),
('53f0998624ca','false_positive','endEmergency remains fixed-Migration-only/nonReentrant, validates active paused same governance and empty snapshot, performs fixed Pricing/Oracle ending verification before deleting emergency flags. Retaining flags during final validation is intentional. The new reservation predicate adds no emergency caller.','c29e38f0311b'),
('f7880088e15c','false_positive','Snapshot memory s has defined zero defaults. Bucket/source/limits/confirmation and complete nonzero Pricing mark are populated before storage; portfolioRevision/replacement intentionally remain zero only for the emergency branch that does not consume ordinary portfolio fields. Reservation restriction does not change this initialization.','5858e3a98dd7'),
('86d2d69a3f79','false_positive','Pools.get is used as an admission/existence assertion via revert, not to consume a price/key. New onlyVault validation still rejects zero IDs, retains exact preexisting pool association, and for new pool associations demands the fixed Migration-created CustodyValidation identity predicate. The predicate admits only canonical-origin identity or a bounded registered alias; it does not attest full pool configuration, remaining capacity or future activation readiness.','c7afb853264e'),
('7a54a0532cff','false_positive','validateUnwind intentionally uses Strategy.validateExitPrice as success-or-revert financial validation; it needs no returned price value. Only explicit emergency omission of the matching check skips it; custody/floors/exact receipt checks remain separate. New reservation logic changes none of that.','733139407516'),
('c4a81a08f0d6','false_positive','Emergency fingerprint needs ETH source/policy identity, while original numerical bounds are consumed independently by retained price/value helpers. oracle.validateExecution precedes both fingerprint reads. New read-only identity predicate does not alter this guarded commitment.','f2e8d828b43f'),
('4747e0fde8a3','false_positive','ZZZ source identity is deliberately extracted after complete execution validation. Numerical bounds and output floors remain enforced in their own callers, so dropping unused numeric components here does not drop a financial guard. Reservation identity adds no execution-context scope.','a0c95f4f3d6f'),
('d0cf7570ee82','false_positive','Guarded same-main consolidation uses slot0 current tick to assert active geometry; immutable lower/upper, pool/owner/liquidity and control data are verified independently. It need not consume spot sqrt/fee outputs in this helper. Added identity-only view leaves consolidation flow unchanged.','61a32db0b69a'),
('1048a330f0a2','informational','beginEmergency arms only transaction-local context; successful outer Migration emits the reviewed request/hash/check mask. A revert erases intermediate state. No new persistent policy setter or event deficiency is introduced by reservation restriction.','a7036fdfeaff'),
('1ddeaf4f6fc3','informational','The newly reported bucketAt loop has a hard count>4 rejection before iteration. Each of at most four calls is a typed STATICCALL to the sealed fixed Vault raw indexed getter, with no token, market, signer or discretionary address. Predicate returns bool only and cannot register, transfer, approve, mutate custody or attest complete reservation readiness. Four extra getter calls have bounded cost; wrong/unavailable bound modules fail closed. This is a real bounded calls-in-loop tradeoff, not an unbounded loop or accepted arbitrary external callback.',None),
('59f272cdf93d','false_positive','checkpoint is onlyVault inside nonReentrant Vault maintenance; fixed Pricing/Oracle capture completes before lastCompound records successful eligibility. Later failure rolls clock and snapshot back atomically. Phase4 manual reinvestment remains distinct from ordinary rebalance and unaffected by identity predicate.','87e8f5341d57'),
('a00a7798fa88','false_positive','MigrationValueChecked is emitted after fixed Pricing.endMaintenance final validation, then only local cleanup/event under onlyVault and outer Vault mutex. Values come from captured mark and verified actual poststate, not an untrusted callback return. Reservation-only source change adds no event callback.','481170456720'),
('380cf1f6f7d4','informational','CustodyValidation implements exact validReservationIdentity(bytes32,uint256) external-view returns(bool) as used by the new Budget facade. Migration constructs it immutably, Budget resolves the bound Migration.validation typed getter, and actual reservation writes/roles remain in Vault/Budget. Nominal interface inheritance would add no authority or execution restriction.',None),
('6bb453a2dc3c','informational','PortfolioPolicy already implements the exact controlFingerprint(bytes32) view. The same local interface at its unchanged line grants no authority; new identity reader is separate and does not change portfolio controls.','6bb453a2dc3c'),
('a461ffb1e650','informational','Unchanged VaultCanonical implements the three exact downstream owner/holder-exit/contribution validation signatures with fixed caller and canonical rules. New Budget predicate is separate; nominal inheritance cannot strengthen the existing typed forwarding.','a461ffb1e650'),
('7bfac571a75c','informational','Budget maintenanceBucket/maintenancePrices remain the exact IPortfolioBudget views over authenticated active snapshot. New identity admission does not mutate or expose another snapshot source, and explicit inheritance does not change those guards.','203221d9b67a'),
('d40a98921f2c','informational','Unchanged VaultCanonical.bucketIdentity(bytes32) external view returns(uint256) exactly matches IReservationOrigin. The fixed preserved originChain/originVault hash supplies canonical identity through STATICCALL; there is no new identity setter or replacement trust. Nominal inheritance is unnecessary for this typed ABI call.',None),
('77e8411e5b3f','informational','RebalanceConfirmation already implements the exact controlFingerprint(bytes32) view, including reviewed observation controls. This interface coincidence requires no inheritance relation to PortfolioPolicy and changes no permissions.','77e8411e5b3f'),
('1f2002760385','informational','Migration still exposes the exact emergencyFingerprint/target views; the fingerprint authenticates actual Budget and current emergency, target is read-only. Newly read immutable validation getter already exists and is not an arbitrary executor or role grant.','1f2002760385'),
('7ae4d5db724b','informational','Budget still provides the three onlyVault IBudgetVaultValidation forwarders to fixed VaultCanonical. Its separate new reservation facade preserves onlyVault and exact association checks; structural inheritance introduces no absent runtime check.','5e87444fdf20'),
]
assert len(notes)==len(contexts)==22
proof=[]
for name in ['ZZZMigrationBudget','ZZZCustodyValidation']:
 p='src/'+name+'.sol';cur=(R/p).read_bytes().replace(b'\r\n',b'\n');previous=subprocess.check_output(['git','show','003c8d8:'+p],cwd=R).replace(b'\r\n',b'\n');restored=cur
 if name=='ZZZMigrationBudget':
  for declaration in [b'interface IBudgetReservationIdentity { function validReservationIdentity(bytes32,uint256) external view returns(bool); }\n',b'interface IBudgetMigrationValidation { function validation() external view returns(address); }\n']:
   assert restored.count(declaration)==1;restored=restored.replace(declaration,b'',1)
  start=b'    function validateReservation(';end=b'    function validateMove('
  a=restored.index(start);b=restored.index(end,a);pa=previous.index(start);pb=previous.index(end,pa)
  restored=restored[:a]+previous[pa:pb]+restored[b:]
 else:
  declaration=b'interface IReservationOrigin { function bucketIdentity(bytes32) external view returns(uint256); }\n'
  assert restored.count(declaration)==1;restored=restored.replace(declaration,b'',1)
  start=b'    /// @notice New custody uses';end=b'    /// @notice Bootstrap identity'
  a=restored.index(start);b=restored.index(end,a);restored=restored[:a]+restored[b:]
 assert restored==previous,p
 assert hashlib.sha256(previous).hexdigest()==old['source_sha256_lf'][p]
 proof.append({'path':p,'current_raw_sha256':hashlib.sha256((R/p).read_bytes()).hexdigest(),'current_lf_sha256':hashlib.sha256(cur).hexdigest(),'prior_lf_sha256':hashlib.sha256(previous).hexdigest(),'reconstructed_prior_exactly_lf':True,'scope':'Only explicitly reviewed reservation predicate/facades change. Every other byte is equal after LF normalization.'})
result={'schema':1,'input_sha256':hashlib.sha256(raw).hexdigest(),'independent_audit':False,'scope_proof':proof,'findings':[]}
for item,(prefix,disposition,note,priorprefix)in zip(contexts,notes):
 assert item['fingerprint'].startswith(prefix)
 prior=None
 if priorprefix:
  found=[f for f in old['findings']if f['fingerprint'].startswith(priorprefix)];assert len(found)==1;prior=found[0]
 rationale='Current individual review: '+note
 if prior:rationale+=' Prior detailed rationale retained after current source reread: '+prior['rationale']
 rationale+=' This is scoped internal static review, not new full-transitive/dynamic acceptance or independent exploit-absence assurance.'
 result['findings'].append({**item,'disposition':disposition,'rationale':rationale,'current_review_note':note,'prior_similar_fingerprint':prior['fingerprint']if prior else None,'review_scope':'Individually current context; similarity/location shift is provenance only, not counted as exact-source reuse.'})
with (E/'ASSESSMENTS.json').open('x',encoding='utf-8')as f:json.dump(result,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps({'individually_reviewed':22,'source_proof_count':len(proof)}))
