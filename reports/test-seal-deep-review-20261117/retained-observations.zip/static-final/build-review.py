"""Bind complete actual analyzer output to explicit current/referenced reviews."""
from pathlib import Path
import collections,copy,gzip,hashlib,importlib.util,io,json,re,sys

E=Path(__file__).resolve().parent;D=Path(sys.argv[1])
R=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
P=R/'reports/test-seal-deep-review-20261117'
def sha(raw):return hashlib.sha256(raw).hexdigest()
def encoded(value):return (json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
def save(path,value):
    with path.open('xb')as stream:stream.write(encoded(value))
spec=importlib.util.spec_from_file_location('checker',R/'scripts/check-slither-review.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
oldpath=R/'reports/test-seal-deep-review-20261117/static-review.json'
old=json.loads(oldpath.read_bytes());oldby={row['fingerprint']:row for row in old['findings']}
assert len(oldby)==len(old['findings'])==571
data=json.loads((D/'slither.json').read_bytes());execution=json.loads((D/'EXECUTION.json').read_bytes())
assert execution['analyzer_success'] is True and not execution['analyzer_error']
assert execution['source_unchanged'] is True and execution['compiler_invoked'] is False
assert execution['raw_report_sha256']==sha((D/'slither.json').read_bytes())
assert execution['detector_count']==len(data['results']['detectors'])==573
current_bytes=(E/'CURRENT_CONTEXTS.json').read_bytes();current=json.loads(current_bytes)
assessments=json.loads((E/'ASSESSMENTS.json').read_bytes())
assert assessments['input_sha256']==sha(current_bytes)
fresh={row['fingerprint']:row for row in assessments['findings']}
assert len(fresh)==len(assessments['findings'])==current['count']==22
assert set(fresh)=={row['fingerprint']for row in current['current']}
source={p.relative_to(R).as_posix():m.source_hash(p) for p in sorted((R/'src').rglob('*.sol'))}
source.update({n:m.source_hash(R/n)for n in ('foundry.toml','package-lock.json','slither.config.json')})
assert len(source)==64
assert all(execution['source_before'][n]==execution['source_after'][n]==sha((R/n).read_bytes())for n in source)
reuse_allowed={row['fingerprint']:row for row in json.loads((E/'EXACT_REUSE.json').read_bytes())['reuse']}
assert len(reuse_allowed)==551
rows=[];reuse=[]
for finding in data['results']['detectors']:
 fp=m.fingerprint(finding);desc=m.normalized_description(finding)
 paths=sorted(set(re.findall(r'src/[A-Za-z0-9_./-]+\.sol',desc)))
 if fp in fresh:
  row=copy.deepcopy(fresh[fp])
  assert row['description']==desc and row['referenced_paths']==paths
  assert all(row[k]==finding[k]for k in ('check','impact','confidence'))
  assert row['referenced_source_sha256_lf']=={p:source[p]for p in paths}
 else:
  assert fp in oldby and fp in reuse_allowed and paths
  assert all(source[p]==old['source_sha256_lf'][p]for p in paths)
  row=copy.deepcopy(oldby[fp])
  row.update(prior_review='reports/test-seal-deep-review-20261117/static-review.json',prior_fingerprint=fp,
   review_scope='Unique exact old fingerprint with every description-referenced LF source unchanged. Prior rationale/authority/transitive limits retained; not a new full-transitive audit.')
  reuse.append({'fingerprint':fp,'referenced_paths':paths,'referenced_source_sha256_lf':{p:source[p]for p in paths}})
 assert row['disposition'] in ('false_positive','informational','accepted_risk') and row['rationale'].strip()
 rows.append(row)
assert len(rows)==len({r['fingerprint']for r in rows})==573 and len(reuse)==551
projection={'success':data['success'],'error':data.get('error'),'results':{'detectors':[
 {k:f[k]for k in ('check','impact','confidence','description')}for f in data['results']['detectors']]},
 'projection':{'kind':'Complete strict-review input projection; every actual detector retained',
 'retained_fields_per_detector':['check','impact','confidence','description'],
 'omitted_metadata':['supporting AST/element metadata','compilation objects'],
 'raw_analyzer_report_sha256':execution['raw_report_sha256'],'compiler_input_sha256':execution['compiler_input_sha256'],
 'compiler_output_sha256':execution['compiler_output_sha256'],'detector_count':573,
 'additional_analyzer_run':False,'additional_compiler_run':False}}
assert [m.fingerprint(f)for f in projection['results']['detectors']]==[m.fingerprint(f)for f in data['results']['detectors']]
projected=encoded(projection);buffer=io.BytesIO()
with gzip.GzipFile(fileobj=buffer,mode='wb',filename='',mtime=0)as stream:stream.write(projected)
compressed=buffer.getvalue()
review={'analyzer':'Slither0.11.6/crytic-compile0.4.2','date':'2026-11-17','independent_audit':False,
 'reviewer':'Internal scoped seal-input boundary review: 22 individually current contexts and551 exact referenced-source reuses. Not independent audit or exploit-absence proof.',
 'source_sha256_lf':dict(sorted(source.items())),'findings':rows,
 'scope':{'baseline':'003c8d8dc88b60cbfbcc8caf61fa864c6487b40f','solidity_sources':61,
 'changed_production_sources':['src/ZZZVault.sol','src/ZZZNFTMetadata.sol','src/ZZZMigrationBudget.sol','src/ZZZCustodyValidation.sol'],'changed_since_prior_review':['src/ZZZMigrationBudget.sol','src/ZZZCustodyValidation.sol'],'compiler_input_sources':execution['exact_compiler_source_count'],
 'actual_analyzer':True,'compiler_invoked_by_analyzer':False,
 'compiler_input_sha256':execution['compiler_input_sha256'],'compiler_output_sha256':execution['compiler_output_sha256'],
 'build_info_sha256':execution['build_info_sha256'],'source_bracket_unchanged':True,
 'individually_current_records':22,'unique_exact_reused':551,'total':573,
 'current_source_delta_proof':assessments['scope_proof'],'current_assessment_input_sha256':sha(current_bytes),'current_assessment_sha256':sha((E/'ASSESSMENTS.json').read_bytes()),
 'prior_review':'reports/test-seal-deep-review-20261117/static-review.json','prior_review_sha256_raw':sha(oldpath.read_bytes()),
 'analyzer_exit_code':execution['analyzer_exit_code'],
 'analyzer_exit_note':'Windows detector-present exit4294967295 retained. JSON success/no analyzer error and full strict coverage checked separately; not exit0.',
 'raw_analyzer_report_sha256':execution['raw_report_sha256'],'raw_analyzer_log_sha256':execution['raw_log_sha256'],
 'strict_input_projection':{'path':'reports/test-seal-deep-review-20261117/static-final-input.json.gz',
 'gzip_sha256':sha(compressed),'decompressed_sha256':sha(projected),'gzip_bytes':len(compressed),'decompressed_bytes':len(projected),
 'retains_all_detector_records':True,'retains_exact_detector_text_and_classification':True,
 'fingerprints_equal_raw_analyzer_in_order':True},
 'new_identity_predicate_only':True,'separate_checks_remain':['pool admission','roles','remaining custody capacity','activation/maintenance eligibility','all financial guards'],'reuse_limit':'Only unique exact fingerprints with all description-referenced LF sources unchanged; prior transitive/context limits retained.',
 'not_qualified':['Independent audit or exploit absence','actual markets/routes/providers/complete fees','maximum state, host, wallet and recovery acceptance','public deployment/sealing/signing/services/sites','remote artwork availability/OpenSea ingestion']}}
assert not m.check(data,review),m.check(data,review)
assert not m.check(projection,review),m.check(projection,review)
save(E/'STRICT_INPUT.json',projection);save(E/'REUSE_PROOF.json',{'count':551,'reuse':reuse})
save(P/'static-final-review.json',review)
with (P/'static-final-input.json.gz').open('xb')as stream:stream.write(compressed)
save(P/'FINAL_STATIC_REASSESSMENTS.json',assessments)
save(P/'FINAL_STATIC_REUSE_PROOF.json',{'count':551,'reuse':reuse})
result={'schema':1,'review_coverage_pass':True,'independent_audit':False,'raw_actual_analyzer_check':'pass',
 'complete_projected_input_check':'pass','individual_current':22,'unique_exact_reuse':551,'total':573,
 'current_dispositions':dict(collections.Counter(row['disposition']for row in fresh.values())),
 'all_dispositions':dict(collections.Counter(row['disposition']for row in rows)),
 'review_sha256':sha((P/'static-final-review.json').read_bytes()),'projection_gzip_sha256':sha(compressed),
 'projection_decompressed_sha256':sha(projected),'analyzer_exit_code':execution['analyzer_exit_code'],
 'analyzer_success':execution['analyzer_success'],'analyzer_error':execution['analyzer_error'],
 'source_unchanged_during_analyzer':True,'analyzer_compilation':False,'compiler_reinvoked':False,
 'test_methods_executed':0,'raw_report_sha256':execution['raw_report_sha256'],'raw_log_sha256':execution['raw_log_sha256']}
save(E/'RESULT.json',result);save(P/'FINAL_STATIC_RESULT.json',result)
print(json.dumps(result))
