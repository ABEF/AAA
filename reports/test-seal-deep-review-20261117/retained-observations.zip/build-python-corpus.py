from pathlib import Path
import ast,collections,datetime,hashlib,json
R=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2');D=R/'reports/test-seal-deep-review-20261117'
paths=sorted((R/'tests_python').glob('*.py'));modules={}
errors=[]
for p in paths:
 raw=p.read_bytes()
 try:t=ast.parse(raw.decode('utf-8-sig'),filename=str(p))
 except(SyntaxError,UnicodeError)as e:errors.append({'path':p.relative_to(R).as_posix(),'type':type(e).__name__,'line':getattr(e,'lineno',None)});continue
 name='tests_python.'+p.stem
 classes={n.name:n for n in t.body if isinstance(n,ast.ClassDef)}
 imports={}
 for n in t.body:
  if isinstance(n,ast.Import):
   for a in n.names:imports[a.asname or a.name.split('.')[0]]=(a.name if a.asname else a.name.split('.')[0],None)
  elif isinstance(n,ast.ImportFrom):
   mod=(('tests_python.' if n.level==1 else '')+(n.module or ''))
   for a in n.names:imports[a.asname or a.name]=(mod,a.name)
 modules[name]={'p':p,'tree':t,'classes':classes,'imports':imports,'raw':raw}
cache={};resolving=set()
def lineage(mod,cls):
 key=(mod,cls)
 if key in cache:return cache[key]
 if key in resolving:return(False,{},['cyclic/unresolved base'])
 resolving.add(key);data=modules.get(mod);node=data['classes'].get(cls)if data else None
 if node is None:resolving.remove(key);return(False,{},['unknown class '+mod+'.'+cls])
 unit=False;methods={};unknown=[]
 for b in node.bases:
  m=None;c=None
  if isinstance(b,ast.Name):
   if b.id in data['classes']:m=mod;c=b.id
   elif b.id in data['imports']:m,c=data['imports'][b.id]
   elif b.id!='object':unknown.append(ast.unparse(b))
  elif isinstance(b,ast.Attribute)and isinstance(b.value,ast.Name):
   imp=data['imports'].get(b.value.id)
   if imp and imp[1]is None:m=imp[0];c=b.attr
   elif b.value.id=='unittest':m='unittest';c=b.attr
  if m=='unittest'and c in ('TestCase','IsolatedAsyncioTestCase'):unit=True
  elif m and c:
   if m in modules and c in modules[m]['classes']:
    v,n,u=lineage(m,c);unit|=v;methods.update(n);unknown.extend(u)
   elif not(m=='unittest'and c=='TestCase'):unknown.append((m or'')+'.'+(c or''))
  elif not isinstance(b,ast.Name)or b.id!='object':unknown.append(ast.unparse(b))
 for n in node.body:
  if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))and n.name.startswith('test'):
   methods[n.name]={'defined_in':mod+'.'+cls,'line':n.lineno}
 resolving.remove(key);cache[key]=(unit,methods,sorted(set(unknown)));return cache[key]
kpath=R/'scripts/run-keeper-tests.py';kt=ast.parse(kpath.read_text(encoding='utf-8-sig'));keeper=ast.literal_eval(next(n.value for n in kt.body if isinstance(n,ast.Assign)and any(isinstance(a,ast.Name)and a.id=='MODULES'for a in n.targets)))
rows=[];missing=[];dupes=[];skipdecorators=[]
for name,d in modules.items():
 p=d['p'];t=d['tree'];local=[]
 for cls,n in d['classes'].items():
  isunit,methods,unknown=lineage(name,cls)
  if isunit:local.append({'class':cls,'local_test_methods':sum(isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef))and x.name.startswith('test')for x in n.body),'static_selected_method_count':len(methods),'methods':methods,'unresolved_bases':unknown})
  counts=collections.Counter(x.name for x in n.body if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef)))
  for meth,num in counts.items():
   if num>1:dupes.append({'module':name,'class':cls,'name':meth,'definitions':num})
 for n in ast.walk(t):
  if isinstance(n,ast.ImportFrom)and n.module and n.module.split('.')[0]in {'tests_python','zzz_ops','keeper','frontend_api','indexer'}:
   mod=n.module;f=R/(mod.replace('.','/')+'.py');folder=R/mod.replace('.','/')/'__init__.py'
   if not f.exists()and not folder.exists():missing.append({'module':name,'line':n.lineno,'target':mod})
 doc=ast.get_docstring(t)or''
 top_methods=[n.name for n in t.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))and n.name.startswith('test')]
 selected=p.name.startswith('test')
 categories=[]
 for base,label in [('keeper','keeper operation/recovery'),('frontend','API/website data/preparation'),('history','history/accounting recovery'),('deployment','unsigned deployment preparation'),('preseal','unsigned pre-seal preparation'),('manual','manual LP preparation'),('royalty','royalty currency accounting'),('canonical','canonical lifecycle'),('metadata','NFT metadata'),('verification','verification tooling'),('slither','static review'),('rpc','RPC transport'),('operator','operator tooling')]:
  if base in p.stem:categories.append(label)
 if not categories:categories=['source docstring and named local cases']
 rows.append({'module':name,'path':p.relative_to(R).as_posix(),'sha256':hashlib.sha256(d['raw']).hexdigest(),'purpose_from_source_docstring':doc,'source_area_hints':categories,'full_runner_filename_admitted':selected,'keeper_runner_listed':p.stem in keeper,'local_unittest_classes':local,'local_unittest_class_count':len(local),'static_selected_method_count':sum(x['static_selected_method_count']for x in local),'top_level_test_functions_not_selected':top_methods,'custom_load_tests_defined':any(isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))and n.name=='load_tests'for n in t.body),'inventory_only':True})
selected=[r for r in rows if r['full_runner_filename_admitted']]
summary={'all_python_files_in_tests_python':len(paths),'test_filename_modules':len(selected),'helper_modules':len(rows)-len(selected),'parse_errors':errors,'local_unittest_classes':sum(r['local_unittest_class_count']for r in selected),'static_selected_methods_including_inheritance':sum(r['static_selected_method_count']for r in selected),'keeper_listed_modules':len(keeper),'keeper_list_unique':len(set(keeper))==len(keeper),'keeper_list_missing_files':[m for m in keeper if not(R/'tests_python'/(m+'.py')).is_file()],'test_filename_modules_without_statically_resolved_testcase':[r['module']for r in selected if r['local_unittest_class_count']==0],'custom_load_tests_modules':[r['module']for r in selected if r['custom_load_tests_defined']],'top_level_test_functions_not_selected':[{'module':r['module'],'methods':r['top_level_test_functions_not_selected']}for r in selected if r['top_level_test_functions_not_selected']],'duplicate_local_method_definitions':dupes,'missing_explicit_local_import_modules':missing,'unresolved_base_classes':[{'module':r['module'],'class':c['class'],'bases':c['unresolved_bases']}for r in selected for c in r['local_unittest_classes']if c['unresolved_bases']]}
record={'schema':1,'recorded_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Read-only AST inventory and bounded source-based compatibility review; no imports, collection, test bodies or subprocess tools executed.','execution_performed':False,'tests_run':0,'summary':summary,'runner_sources':{'scripts/run_python_tests.py':hashlib.sha256((R/'scripts/run_python_tests.py').read_bytes()).hexdigest(),'scripts/run-keeper-tests.py':hashlib.sha256(kpath.read_bytes()).hexdigest()},'modules':rows,'limitations':['AST counts approximate runtime unittest selection, not actual collection or pass evidence.','Imported fixture aliases are excluded; locally defined subclasses include statically resolvable inherited methods. Dynamic class creation/attribute mutation/import conditions may differ.','Purpose is taken from source docstrings and classes, not a behavioral audit of every method.','Historical profiles and wrapped-token codecs remain legitimate where explicitly versioned; keyword presence alone is not a stale-code finding.']}
(D/'TEST_CORPUS_PYTHON.json').write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False))
