from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
R=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2');V=Path('C:/Users/Ali/.codex/visualizations/2026/10/14/01a13899-2be7-76f2-a5d0-72e4804c67b9');T=V/'test-seal-deep-review-20261117';label=sys.argv[1]
cases={'seadrop':('test/SeaDropFullHandoff.t.sol','SeaDropFullHandoffTest',['testBoundSeaDropWholeV10CommitCarriesActualLPAndRoyaltyClaimsToCurrentOwner','testBoundSeaDropFundedV10AbortReturnsBackingAndPreservesOriginalMintBooks']),'canonical-v10':('test/CanonicalHandoff.t.sol','CanonicalHandoffTest',['testCompleteHandoffPreservesOwnersSharesTraitsAndBothRewardLedgers','testPartialFundingCannotActivateAndFundingCannotReplay'])}
file,contract,methods=cases[label];D=T/'execution-fixtures'/label;D.mkdir(parents=False,exist_ok=False)
forge=V/'foundry-v1.4.4/forge.exe';solc=V/'toolchain-0.8.26/solc.exe';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
prior=json.loads((T/'static-final/static-ea32b2a5d0/START.json').read_bytes());normal=json.loads((T/'normal-final-2/normal-size-evidence.json').read_bytes())
assert sha(forge)==prior['forge_sha256'];assert sha(solc)==normal['solc_executable_sha256']
paths=sorted([p for folder in ('src','test')for p in(R/folder).rglob('*')if p.is_file()]+[R/'foundry.toml',R/'package-lock.json',R/'lib/forge-std/src/Test.sol'])
def snapshot():return{p.relative_to(R).as_posix():sha(p)for p in paths}
before=snapshot()
keep=('SystemRoot','WINDIR','SystemDrive','COMSPEC','PATHEXT','TEMP','TMP','USERPROFILE','LOCALAPPDATA','APPDATA','PROGRAMDATA','HOMEDRIVE','HOMEPATH')
env={k:os.environ[k]for k in keep if k in os.environ};env.update(FOUNDRY_OFFLINE='true',FOUNDRY_PROFILE='default',PATH=str(forge.parent)+os.pathsep+str(solc.parent)+os.pathsep+str(Path(os.environ.get('SystemRoot','C:/Windows'))/'System32'))
command=[str(forge),'test','--offline','--root',str(R),'--match-path',file,'--match-contract','^'+contract+'$','--match-test','^('+'|'.join(methods)+')$','--out',str(D/'out'),'--cache-path',str(D/'cache'),'--use',str(solc),'--json']
start={'schema':1,'label':label,'started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'selected_methods':methods,'command':command,'forge_sha256':sha(forge),'solc_sha256':sha(solc),'source_before':before,'credentials_inherited':False,'offline':True,'new_exclusive_out_cache':True,'normal_size_or_gas_limits_changed':False,'fork_or_public_rpc':False,'production_approved':False}
(D/'START.json').write_text(json.dumps(start,indent=2)+'\n',encoding='utf-8');began=time.monotonic()
with(D/'forge.json').open('xb')as out,(D/'forge.stderr.log').open('xb')as err:
 proc=subprocess.Popen(command,cwd=R,env=env,stdout=out,stderr=err)
 try:code=proc.wait(timeout=1200)
 except subprocess.TimeoutExpired:proc.kill();proc.wait();(D/'TIMEOUT.json').write_text(json.dumps({'owned_pid':proc.pid,'not_a_pass':True}));raise
status=[];parse_error=None
try:
 output=json.loads((D/'forge.json').read_bytes())
 for host,data in output.items():
  for name,row in data.get('test_results',{}).items():status.append({'contract':host,'method':name,'status':row['status'],'reason':row.get('reason'),'kind':row.get('kind')})
except(Exception)as ex:parse_error=type(ex).__name__
after=snapshot();artifacts={p.relative_to(D).as_posix():sha(p)for p in(D/'out').rglob('*.json')}
actual={r['method'].removesuffix('()')for r in status};selected_exact=actual==set(methods)and len(status)==len(methods)
record={**start,'finished_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'seconds':round(time.monotonic()-began,3),'exit_code':code,'results':status,'expected_selected_count':len(methods),'selected_methods_exact':selected_exact,'parse_error':parse_error,'source_after':after,'source_changes':[n for n in before if before[n]!=after.get(n)],'artifact_sha256':artifacts,'stdout_sha256':sha(D/'forge.json'),'stderr_sha256':sha(D/'forge.stderr.log'),'success':code==0 and selected_exact and not parse_error and before==after and all(r['status']=='Success'for r in status)}
(D/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:record[k]for k in ['label','exit_code','seconds','selected_methods_exact','results','source_changes','success']}),flush=True)
raise SystemExit(0 if record['success'] else 1)
