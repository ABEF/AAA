import hashlib,json,subprocess,sys,time
from pathlib import Path
R=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
V=Path('C:/Users/Ali/.codex/visualizations/2026/10/14/01a13899-2be7-76f2-a5d0-72e4804c67b9/five-report-consolidation-20261117')
stage=sys.argv[1];methods=sys.argv[2:];files=['zzz_ops/focused_evidence.py','scripts/check-focused-evidence.py','tests_python/test_focused_evidence.py','config/focused-evidence-1c18379.json']
def pins():return {f:hashlib.sha256((R/f).read_bytes()).hexdigest() for f in files}
before=pins();cmd=[sys.executable,'-m','unittest','-v']+methods;t=time.monotonic()
with (V/(stage+'.log')).open('wb') as out:r=subprocess.run(cmd,cwd=R,stdout=out,stderr=subprocess.STDOUT,timeout=60)
record={'command':cmd,'exit_code':r.returncode,'elapsed_seconds':time.monotonic()-t,'source_before':before,'source_after':pins(),'log_sha256':hashlib.sha256((V/(stage+'.log')).read_bytes()).hexdigest(),'EVM_executions':0}
(V/(stage+'.json')).write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
