from pathlib import Path
import difflib,json,subprocess
R=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2');E=Path(__file__).parent
def edit(name,fn):
 p=R/name;raw=p.read_bytes();archive=E/'originals'/name
 if not archive.exists():
  head=subprocess.check_output(['git','show','HEAD:'+name],cwd=R);assert head.replace(b'\r\n',b'\n')==raw.replace(b'\r\n',b'\n');archive.parent.mkdir(parents=True,exist_ok=True);archive.write_bytes(raw)
 old=raw.decode();lines=old.splitlines(keepends=True);new=fn(old.replace('\r\n','\n')).splitlines();nl='\r\n' if b'\r\n'in raw else '\n';out=[]
 for tag,i,j,k,l in difflib.SequenceMatcher(a=[x.rstrip('\r\n')for x in lines],b=new,autojunk=False).get_opcodes():out.extend(lines[i:j]if tag=='equal'else[x+nl for x in new[k:l]])
 p.write_bytes(''.join(out).encode())
def ledger(t):
 d=json.loads(t);task=next(t for a in d['areas']for t in a['tasks']if t['id']=='callable-reference')
 task['text']=task['text'].replace('40contracts/956functions','40contracts/963functions').replace('1009short','1016short')
 task['acceptance'][0]=task['acceptance'][0].replace('40contracts/956functions/1009call','40contracts/963functions/1016call')
 task['acceptance'].insert(1,'[Metadata2 callable closure](reports/metadata-lifecycle-fixes-20261116/FUNCTION_REFERENCE_REVIEW.json) adds4public reads and preserves existing concrete functions/constructor ABIs. Current generated reference has40contracts/963functions/1016examples; earlier956/1009 and959/1012 counts retain their original source stages. The five-audit reconciliation corrects the stale current task wording without rerunning old tests.')
 return json.dumps(d,ensure_ascii=False,indent=2)+'\n'
edit('docs/project-todo.json',ledger)
def matrix(t):
 old='''  at `206892ab8b93d65cae3564e71feaf4435f90cdee`:
  [view](https://github.com/ABEF/AAA-website/blob/206892ab8b93d65cae3564e71feaf4435f90cdee/deployment-view.js),
  [principal reader](https://github.com/ABEF/AAA-website/blob/206892ab8b93d65cae3564e71feaf4435f90cdee/deployment-source9-data.js).'''
 new='''  at baseline `206892ab8b93d65cae3564e71feaf4435f90cdee`; current metadata corrections
  are accepted at `2a528696d5eaea5ebb42cfeb313836840fff5e97`:
  [current view](https://github.com/ABEF/AAA-website/blob/2a528696d5eaea5ebb42cfeb313836840fff5e97/deployment-view.js),
  [principal reader](https://github.com/ABEF/AAA-website/blob/2a528696d5eaea5ebb42cfeb313836840fff5e97/deployment-source9-data.js).'''
 assert old in t;return t.replace(old,new,1)
edit('docs/METADATA_LIFECYCLE.md',matrix)
def findings(t):
 old='''worst padded call is13,010,802/24M. It also reproduces an open emergency-only
coupling: retaining the live price fingerprint rejects a successful swap through
that reference even when original output/L floors are feasible. Healthy14 uses a
separately reviewed third venue; explicit0 remains a separate outage decision,
never an automatic workaround. Production sources/defaults remain unchanged.'''
 new='''worst padded call at that original source is13,010,802/24M. It reproduced the
then-open emergency-only fingerprint coupling; the later reference-swap fix above
resolves it in source. That earlier healthy14 used a separately reviewed third
venue; explicit0 remains an independent outage decision, never an automatic
workaround. Keep each receipt/gas/runtime scope historical: later metadata
callers changed even though the six manual-fix objects and Vault remain exact.'''
 assert old in t;return t.replace(old,new,1)
edit('docs/AUDIT_FINDINGS.md',findings)
print('Corrected current callable counts, metadata website source links and superseded manual-coupling wording; historical reports unchanged.')
