from pathlib import Path
import hashlib,json,os,subprocess,sys,time
R=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2');E=Path(__file__).parent;O=E/'cli';O.mkdir(exist_ok=False)
keep=('SystemRoot','WINDIR','SystemDrive','COMSPEC','PATHEXT','TEMP','TMP','USERPROFILE','LOCALAPPDATA','APPDATA','PROGRAMDATA')
env={n:os.environ[n]for n in keep if n in os.environ};rows=[]
cases=[('current-plan',['scripts/prepare-deployment.py','--input','config/deployment-preparation.example.json','--output',str(O/'current-plan.json')],2),('historical-replay',['scripts/check-local-deployment-evidence.py','--evidence','reports/local-deployment-rehearsal-20261115/evidence.zip','--output',str(O/'historical-replay.json')],0)]
before={n:hashlib.sha256((R/n).read_bytes()).hexdigest()for n in ('zzz_ops/deployment_plan.py','scripts/prepare-deployment.py','scripts/check-local-deployment-evidence.py')}
for label,args,expected in cases:
 t=time.monotonic();p=subprocess.run([sys.executable,'-I','-B','-X','utf8',*args],cwd=R,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=120)
 (O/(label+'.stdout')).write_bytes(p.stdout);(O/(label+'.stderr')).write_bytes(p.stderr);assert p.returncode==expected,(label,p.returncode)
 value=json.loads((O/(label+'.json')).read_bytes())
 if label=='current-plan':assert value['build_profile']=='metadata2-20261116' and value['accepted_build']['profile']=='metadata2-20261116' and value['production_approved']is False and value['ready_for_submission']is False
 else:assert value['receipts']==44 and value['binding_observations']==112 and value['node_started']is False
 rows.append({'label':label,'command':args,'exit':p.returncode,'seconds':time.monotonic()-t,'output_sha256':hashlib.sha256((O/(label+'.json')).read_bytes()).hexdigest()})
assert before=={n:hashlib.sha256((R/n).read_bytes()).hexdigest()for n in before}
result={'scope':'Actual changed CLI entry points; offline only. Blocked preview preserves missing release inputs; replay uses original archive, no node/transactions. Overlaps new unit workflows, not extra feature count.','checks':rows,'source_sha256':before,'network_calls':0,'compiler_runs':0,'existing_tests_executed':0}
(E/'CLI_REVIEW.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
