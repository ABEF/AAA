from pathlib import Path
from collections import Counter
import hashlib,json
E=Path(__file__).parent;R=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2');P=R/'reports/five-audit-reconciliation-20261116'
base=json.loads((E/'BASELINE.json').read_bytes());rows=[]
G={
'G1':('Independent ETH and ZZZ valuation','Creator/team, operator and engineering',['dual-price-qualification','creator-zzz-price']),
'G2':('Usable routes, external depth and destination compatibility','Creator/team and engineering',['activation-assets','lp-eth-settlement','creator-input-liquidity','lp-execution-routing']),
'G3':('Provider capacity and complete target fees/gas','Operator and engineering',['deployment-initcode','testnet-rehearsal']),
'G4':('Actual authorities, bootstrap and dependency controls','Operator and creator/team',['authorities-prices','creator-market-controls']),
'G5':('Metadata content, read gas and real marketplace outcome','Operator and engineering',['metadata-ops']),
'G6':('Supported, funded and operated randomness','Operator/provider and engineering',['authorities-prices','nft-lifecycle','audit-release']),
'G7':('Actual OpenSea/SeaDrop launch and payments','Operator/platform and engineering',['opensea-mint']),
'G8':('Current release constructors, runtime and bindings','Operator and engineering',['deployment-initcode']),
'G9':('Current services, wallets, maximum workloads and recovery','Operator and engineering',['host-services','keeper-recovery','testnet-rehearsal','wallet']),
'G10':('Independent audit, remediation and release sign-off','Independent auditor and operator',['audit-release','security-integration'])}
def add(namespace,row,status,gates,workstream,title,evidence,action,origin):
 rows.append({'id':namespace+'-'+row['id'],'original_id':row['id'],'origin':origin,'status':status,'workstream':workstream,'finding':title,'current_evidence':evidence,'next_action':action,'remaining_release_gates':gates,'original_assessment':row})
a=json.loads((E/'metadata-manual/FINDINGS.json').read_bytes())
for x in a['findings']:
 k=x['id'];status=('fixed_now'if k in ('D1','D2')else'superseded'if k=='MR6'else'open_external'if k in ('M8','MR3','MR4')else'accepted_limit'if k in ('M5','M7','MR2','MR5','MR7')else'resolved_before')
 gates={'M5':['G5','G9'],'M6':['G9'],'M8':['G5','G9'],'MW1':['G9'],'MR3':['G1','G2'],'MR4':['G2','G3','G9']}.get(k,[])
 add('META-MANUAL',x,status,gates,'current-docs'if k.startswith('D')else'manual-lp'if k.startswith('MR')else'metadata',x['finding'],x['current_evidence'],x['next_action'],x['origin'])
c=json.loads((E/'market/FINDINGS.json').read_bytes())
market_titles={1:'Derived market/feed/quote/candidate flags were underchecked',2:'Captured Chainlink proxies share one aggregator',3:'Pyth requires qualified publication, funding and freshness',4:'API3 activation and round-compatible adaptation remain unqualified',5:'No two independently qualified exact-ZZZ paths',6:'Selected pool has zero active liquidity at the recorded anchor',7:'Recorded selected/reference price bands do not intersect',8:'Tested1000ZZZ reverse conversion lacks complete qualified execution',9:'Diagnostic500k quotes are not operating-budget or full-operation evidence',10:'Stored spot provides no native last-trade timestamp',11:'Filtered discovery interval is stitched; global completeness unproved',12:'Bounded public reads do not approve provider capacity or SLA',13:'Candidate intentionally retains null policies and empty routes',14:'Implemented source guards do not replace upstream/common-mode review',15:'Historical checks retain original source scopes and overlaps'}
for x in c['rows']:
 n=int(x['id'].split('-')[1]);status='fixed_now'if n==1 else'resolved_before'if n==11 else'accepted_limit'if n in (10,13,15)else'open_external'
 gates={2:['G1'],3:['G1'],4:['G1'],5:['G1'],6:['G2'],7:['G2'],8:['G2'],9:['G2','G3'],10:['G1','G2'],12:['G3','G9'],14:['G1','G4']}.get(n,[])
 add('MARKET',x,status,gates,'market-evidence'if n==1 else'market-release',market_titles[n],x['evidence'],x['action'],x['origin'])
b=json.loads((E/'deployment/FINDINGS.json').read_bytes())
for x in b['findings']:
 n=int(x['id'].split('-')[1]);status='fixed_now'if n in (1,2,3,4,5,6,11)else'accepted_limit'if n in (9,12)else'open_verification'if n==19 else'open_external'if 13<=n<=23 else'resolved_before'
 gates={13:['G4'],14:['G5'],15:['G4'],16:['G1','G2'],17:['G6'],18:['G7'],19:['G8'],20:['G3'],21:['G8','G9','G10'],22:['G9'],23:['G10']}.get(n,[])
 work='deployment-build'if n in(1,2,10,11)else'local-evidence'if n in(3,4,5,7,9)else'output-preservation'if n in(6,8)else'deployment-release'
 add('DEPLOY',x,status,gates,work,x['title'],x['current_evidence'],x['next_action'],x['provenance'])
assert len(rows)==57 and len({x['id']for x in rows})==57
counts=Counter(x['status']for x in rows)
tasks={t['id']for area in json.loads((R/'docs/project-todo.json').read_bytes())['areas']for t in area['tasks']}
gates=[]
for k,(title,owner,ids)in G.items():
 assert set(ids)<=tasks
 related=[x['id']for x in rows if k in x['remaining_release_gates']]
 gates.append({'id':k,'title':title,'owner':owner,'task_ids':ids,'related_rows':related,'status':'open','scope':'Release obligations may share rows. Do not sum action groups as bugs.'})
result={'schema':1,'baseline':base['head'],'selection_basis':base['selection_basis'],'families_newest_first':base['families_newest_first'],'individually_reconciled_items':len(rows),'counts':dict(counts),'count_notice':'57source obligations/limits/defects, not57bugs.10fixed_now records include documentation and test maintenance; duplicated release needs map to10shared gates. Scope conditions remain in each original assessment.','findings':rows,'remaining_release_gates':gates,'preservation':'All114selected historical report files and61Solidity files retain exact baseline bytes. No new deployment/site/service/journal adoption.','supporting_review_files':{n:hashlib.sha256((E/n).read_bytes()).hexdigest()for n in ('metadata-manual/FINDINGS.json','metadata-manual/OBJECT_EQUIVALENCE.json','market/FINDINGS.json','deployment/FINDINGS.json','INDEPENDENT_IMPLEMENTATION_REVIEW.json')}}
(P/'FINDINGS.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
table=['# Five-audit finding index','','57 individually reconciled items; these include source fixes, decisions and release obligations.','Related open needs are consolidated into ten shared release gates. The sole Todo owns status.','','| ID | Disposition | Finding | Remaining gates |','| --- | --- | --- | --- |']
for x in rows:table.append('| '+x['id']+' | '+x['status']+' | '+x['finding'].replace('|','/')+' | '+', '.join(x['remaining_release_gates'])+' |')
table+=['','## Shared remaining actions','','| Gate | Action / owner | Existing Todo |','| --- | --- | --- |']
for x in gates:table.append('| '+x['id']+' | '+x['title']+' — '+x['owner']+' | '+', '.join('['+i+'](../../TODO.md#task-'+i+')'for i in x['task_ids'])+' |')
table+=['','Full provenance, current evidence, original assessments and exact next actions are in [FINDINGS.json](FINDINGS.json).','Closed source work does not imply deployed behavior or live qualification.']
(P/'INDEX.md').write_text('\n'.join(table)+'\n')
print(json.dumps({'rows':len(rows),'counts':dict(counts),'remaining_shared_release_gates':len(gates)}))
