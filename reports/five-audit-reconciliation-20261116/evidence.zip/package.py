from pathlib import Path
import hashlib,json,shutil,zipfile
E=Path(__file__).parent;R=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2');P=R/'reports/five-audit-reconciliation-20261116'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base=json.loads((E/'BASELINE.json').read_bytes())
assert all(sha(R/n)==h for n,h in base['production_sources'].items());assert all(sha(R/n)==h for n,h in base['report_pins'].items());assert all(sha(R/n)==h for n,h in base['protected'].items())
owned=['zzz_ops/deployment_plan.py','scripts/check-local-deployment-evidence.py','scripts/rehearse-local-deployment.py','zzz_ops/market_evidence.py','scripts/check-market-evidence.py','tests_python/test_deployment_plan.py','tests_python/deployment_legacy_fixture.py','tests_python/test_deployment_build_profiles.py','tests_python/test_market_evidence.py']
members={}
def add(name,raw):assert name not in members;members[name]=raw
for p in E.rglob('*'):
 if not p.is_file() or p.suffix not in ('.json','.py','.log','.txt','.stdout','.stderr'):continue
 if any(x in ('__pycache__',) for x in p.relative_to(E).parts):continue
 add(p.relative_to(E).as_posix(),p.read_bytes())
for n in owned:add('published-source/'+n,(R/n).read_bytes())
manifest={'schema':1,'baseline':base['head'],'files':{n:{'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)}for n,raw in sorted(members.items())},'limitations':'Offline internal evidence. Historical original archives are linked by baseline hashes and remain in their original report families. No public/runtime qualification.'}
raw=(json.dumps(manifest,indent=2)+'\n').encode();add('MANIFEST.json',raw)
with zipfile.ZipFile(P/'evidence.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for name,data in sorted(members.items()):
  item=zipfile.ZipInfo(name,(2026,11,16,0,0,0));item.compress_type=zipfile.ZIP_DEFLATED;z.writestr(item,data)
(P/'EVIDENCE_MANIFEST.json').write_bytes(raw)
for a,b in [('deployment/VERIFICATION.json','DEPLOYMENT_VERIFICATION.json'),('deployment/LEGACY_TEST_AST_DELTA.json','LEGACY_TEST_AST_DELTA.json'),('market/CLI.json','MARKET_CLI.json'),('CLI_REVIEW.json','CLI_REVIEW.json'),('metadata-manual/OBJECT_EQUIVALENCE.json','OBJECT_EQUIVALENCE.json'),('INDEPENDENT_IMPLEMENTATION_REVIEW.json','INTERNAL_IMPLEMENTATION_REVIEW.json')]:shutil.copyfile(E/a,P/b)
preservation={'baseline':base['head'],'production_sources_unchanged':base['production_sources'],'historical_report_files_unchanged':base['report_pins'],'unrelated_dirty_files_unchanged':base['protected'],'website_protected':base['website_protected'],'owned_code_sha256':{n:sha(R/n)for n in owned},'compiler_invocations':0,'new_nodes':0,'public_rpc_calls':0,'public_transactions':0,'services_sites_or_journals_changed':False}
(P/'PRESERVATION.json').write_text(json.dumps(preservation,indent=2)+'\n')
bundle={'schema':1,'evidence_zip_sha256':sha(P/'evidence.zip'),'evidence_zip_bytes':(P/'evidence.zip').stat().st_size,'manifest_sha256':hashlib.sha256(raw).hexdigest(),'members':len(members)}
(P/'BUNDLE.json').write_text(json.dumps(bundle,indent=2)+'\n')
with zipfile.ZipFile(P/'evidence.zip')as z:
 assert set(z.namelist())==set(members)
 for n,data in members.items():assert z.read(n)==data
print(json.dumps(bundle))
