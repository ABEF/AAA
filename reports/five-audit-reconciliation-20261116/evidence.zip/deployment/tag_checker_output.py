from pathlib import Path
p=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2/scripts/check-local-deployment-evidence.py')
raw=p.read_bytes();old=b"return {'status':'offline_reconciliation_passed','receipts':44"
assert raw.count(old)==1
p.write_bytes(raw.replace(old,b"return {'status':'offline_reconciliation_passed','build_profile':profile,'receipts':44"))
