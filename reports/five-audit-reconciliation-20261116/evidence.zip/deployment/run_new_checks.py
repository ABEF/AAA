"""Execute only named new deployment-profile methods; never discover old suites."""
from pathlib import Path
import hashlib,importlib.util,json,sys,unittest
R=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
E=Path(__file__).resolve().parent
sys.path.insert(0,str(R))
stage=sys.argv[1];names=sys.argv[2:];out=E/stage;out.mkdir(exist_ok=False)
module_path=R/'tests_python/test_deployment_build_profiles.py'
spec=importlib.util.spec_from_file_location('new_deployment_build_profiles',module_path)
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
suite=unittest.TestSuite(module.DeploymentBuildProfileTests(name)for name in names)
assert len(names)==len(set(names))and names
paths=['zzz_ops/deployment_plan.py','scripts/check-local-deployment-evidence.py','scripts/rehearse-local-deployment.py','scripts/prepare-deployment.py','tests_python/test_deployment_build_profiles.py','tests_python/deployment_legacy_fixture.py','tests_python/test_deployment_plan.py']
pins={name:hashlib.sha256((R/name).read_bytes()).hexdigest()for name in paths}
(out/'START.json').write_text(json.dumps({'selected_methods':names,'source_sha256':pins,'unchanged_methods_selected':0,'rpc_calls':0,'compiler_runs':0},indent=2)+'\n')
with(out/'test-output.log').open('w',encoding='utf8')as stream:result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
assert pins=={name:hashlib.sha256((R/name).read_bytes()).hexdigest()for name in paths}
record={'selected':len(names),'executed':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skips':len(result.skipped),'passed':result.testsRun-len(result.failures)-len(result.errors)-len(result.skipped),'source_unchanged':True,'unchanged_methods_executed':0}
(out/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record));sys.exit(not result.wasSuccessful())
