"""Offline source/evidence closure and individually reconciled obligations."""
from pathlib import Path
import ast,hashlib,json,shutil,subprocess
E=Path(__file__).resolve().parent;R=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
BASE='28431b3ac63d909c9c04246de1ee68cc16a3ed5e'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
paths=['zzz_ops/deployment_plan.py','scripts/check-local-deployment-evidence.py','scripts/rehearse-local-deployment.py','scripts/prepare-deployment.py',
       'tests_python/test_deployment_plan.py','tests_python/deployment_legacy_fixture.py','tests_python/test_deployment_build_profiles.py']
pins={name:sha((R/name).read_bytes())for name in paths}
for name in paths:
 target=E/'final-source'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/name,target)
old=subprocess.run(['git','show',BASE+':tests_python/test_deployment_plan.py'],cwd=R,capture_output=True,check=True).stdout
def methods(raw):
 tree=ast.parse(raw);return {node.name:ast.dump(node,include_attributes=False)for node in ast.walk(tree)if isinstance(node,ast.FunctionDef)and node.name.startswith('test_')}
before=methods(old);after=methods((R/'tests_python/test_deployment_plan.py').read_bytes());assert before==after and len(before)==22
delta={'baseline':BASE,'old_test_file_sha256':sha(old),'current_test_file_sha256':pins['tests_python/test_deployment_plan.py'],
       'old_method_bodies_unchanged':True,'preserved_old_methods':len(before),'old_methods_executed':0,
       'change':'Shared import only: explicit test-only legacy100-source temporary checkout and explicit legacy build selection. Individual assertions preserved.',
       'adapter_sha256':pins['tests_python/deployment_legacy_fixture.py']}
(E/'LEGACY_TEST_AST_DELTA.json').write_text(json.dumps(delta,indent=2)+'\n')
stages=['baseline-current-drift','baseline-duplicate-coverage','current-fix-focused','legacy-label-newcase',
        'baseline-output-preflight','output-preflight-fixed','baseline-wire-and-constructor','wire-and-constructor-fixed','wire-envelope-newcase',
        'baseline-send-and-impersonation','send-and-carrier-fixed','quantity-bound-newcase']
records=[];passed={}
for stage in stages:
 p=E/stage;start=json.loads((p/'START.json').read_bytes());result=json.loads((p/'RESULT.json').read_bytes())
 artifacts={str(path.relative_to(E)):sha(path.read_bytes())for path in p.iterdir()if path.is_file()}
 record={'stage':stage,'selection':start['selected_methods'],'result':result,'source_sha256':start['source_sha256'],'artifacts':artifacts};records.append(record)
 if result['passed']==result['selected']:
  for method in start['selected_methods']:passed[method]=stage
assert len(passed)==21
summary={'schema':1,'baseline':BASE,'unique_new_methods_passed':21,'unchanged_methods_executed':0,
 'passed_methods_with_latest_source_stage':passed,'stages':records,
 'scope':'Offline current100-source/39-instance/48-gate plan, exact trusted-family dispatch, historical112-binding/44-receipt replay and adversarial evidence admission. No constructor execution/current deployment gas qualification.',
 'failed_regressions':{'current_source_drift':1,'duplicated_binding_coverage':1,'output_path_consumed_before_build_validation':1,'unlisted_rpc_mutation':1,'self_committed_constructor_argument':1,'wire_sender_not_bound':1,'wrong_impersonation_target':1},
 'total_method_invocations':sum(record['result']['executed']for record in records),
 'passed_invocations':sum(record['result']['passed']for record in records),
 'overlap_notice':'The original-capture positive method executes at three substantive checker source stages; this is one unique method. The final quantity-only bound has its own new boundary/176actual-wire-values property; the full archive is not rerun for that bound.',
 'final_source_sha256':pins,'legacy_method_ast_delta':'LEGACY_TEST_AST_DELTA.json',
 'production_sources_changed':0,'compiler_runs':0,'static_runs':0,'nodes_started':0,'public_rpc_calls':0,'signing_or_deployment':False,
 'limitations':['Source-stage hashes and retained failed/success logs are authoritative; successful stages are separate and not presented as one final-source21-method run.',
                'The exact original archive remains historical, including mutable-preflight capture limitations; final strict checker replay is not a new deployment or current gas measurement.',
                'The closed input graph and size acceptance do not qualify real dependencies, authorities, content, fees, hosting or independent audit.']}
(E/'VERIFICATION.json').write_text(json.dumps(summary,indent=2)+'\n')
rows=[]
def add(number,title,origin,status,evidence,next_action,kind='obligation'):
 rows.append({'id':'DEP-'+str(number).zfill(2),'title':title,'provenance':origin,'current_status':status,'current_evidence':evidence,'next_action':next_action,'kind':kind})
planner='reports/deployment-preparation-20261115/REVIEW.md'
rehearsal='reports/local-deployment-rehearsal-20261115/REVIEW.md'
add(1,'Current planner blocked by obsolete accepted-build source pins',[planner,'reports/metadata-lifecycle-fixes-20261116/REVIEW.md'],'fixed',
    'Closed metadata2-20261116 build entry; exact5accepted artifact pins,100source closure and48normal gates; current default39instance payload plan passes.',
    'Use a new unsigned review with explicit accepted_build.profile; do not relabel old reviews.','new_defect')
add(2,'Changing current build must not invalidate old rehearsal replay',[planner,rehearsal],'fixed',
    'Legacy BUILD/BUILD_PINS remain exact; checker dispatches explicit trusted profile or exact legacy-only omitted identifier, before build reads. Original44receipt/112getter ZIP reconciles.',
    'Retain both artifact families and original immutable evidence.','compatibility_obligation')
add(3,'Binding observation count accepted duplicate/missing coverage',[rehearsal,'scripts/check-local-deployment-evidence.py'],'fixed',
    'Baseline accepted112copies of one row. Checker now derives exact112unique role/signature/argument keys and values from graph/constructors, rejects deletion/duplication/expected omission/self-consistent false values.',
    'Keep closed expected inventory synchronized if constructor graph changes.','new_defect')
add(4,'Build/chain labels and self-committed plan did not fully bind construction intent',[rehearsal],'fixed',
    'Strict build labels, result/process/input chain4663 and normalized input/plan hash equality. All39 constructor names/source/types/ref arguments and parent creators independently derived; manipulated unused sequencer regression now fails. Inert returned code must equal0x5f5ffd plus the trusted ledger slice, not self-provided runtime bytes.',
    'Require explicit new trusted entry for any future build family; self-reported plan commitments are not authority.','new_defect')
add(5,'Other local mutating RPC methods escaped45-mutation counting',[rehearsal],'fixed',
    'Baseline rogue anvil_setCode, mismatched wire sender and wrong impersonation passed. Closed12read methods plus exactly two intended mutation kinds enforced; sequential exact-integer JSON-RPC envelopes, exact reviewed impersonation, closed canonical send sender/target/nonce/value/calldata/gas/gasPrice/type binding, and bounded uint256 quantities. Reset/storage/raw-send/mine variants rejected.',
    'Review any future added RPC method rather than expanding the allowlist generically.','new_defect')
add(6,'Unavailable build consumed otherwise new rehearsal output path',[rehearsal],'fixed',
    'Baseline consumed the directory before source_changed. Build/dependency preflight now precedes output creation; new failure regression preserves absent path without starting a node.',
    'Preserve output/receipts after any actual run; never resume unknown state automatically.','new_defect')
add(7,'Immutable-patched runtime cannot equal unpatched compiler template',[rehearsal],'historically_corrected_still_applicable',
    'Actual original CREATE inputs/return bytes/getCode reconcile; checker retains this method and full runtime/initcode bounds. Current offline plan labels templates explicitly.',
    'For a future actual release reconcile new immutable-specific runtimes from receipts/returns.','historical_finding')
add(8,'Existing/dangling output paths and publication uncertainty',[planner,rehearsal],'historically_corrected_still_applicable',
    'Exclusive link publication and output preservation are retained; new preflight ordering fix is separate. No old output/report overwritten.',
    'Use new owned directories; inspect uncertain publication before retry.','historical_finding')
add(9,'Original mutable request alias cannot attest exact preflight fields',[rehearsal],'accepted_historical_evidence_limit',
    'Recorder already freezes serialized requests/responses; original archive remains untouched and strict replay still reports legacy capture true/preflight verified false.',
    'Use corrected recording on a separately authorized future changed-runtime rehearsal; never repair the old label.','historical_finding')
add(10,'Evidence cannot choose its own trusted build files',[rehearsal],'historically_corrected_and_extended',
    'Closed two-entry registry checks identifiers and exact filename/hash inventories before reading compiler artifacts; forged traversal/hash/profile cases fail.',
    'Add reviewed source-pinned entries only; never accept arbitrary evidence-provided artifact roots/pins.','historical_finding')
add(11,'Original planner tests encoded historical constructor sizes',[planner],'fixed_test_maintenance',
    'All22old method AST bodies/assertions preserved; explicit legacy temp source/build adapter and CLI selection. New current-profile properties cover fresh metadata objects.',
    'Ordinary CI may run both declared families; this task did not rerun the22old methods.','new_defect')
add(12,'Symlink regression unavailable on original Windows account',[planner],'platform_coverage_limit_retained',
    'Original one skip stays explicit; normal exclusive-output/publication properties retain original evidence. No unsupported platform pass inferred.',
    'Exercise symlink-specific case on an authorized supporting host if required for release.','historical_finding')
add(13,'Actual governance/bootstrap/keeper/guardian/payee choices',[planner,rehearsal],'open_operator_release_inputs',
    'Offline addresses remain unverified assignments; no signer or CREATE prediction added.',
    'Select actual public roles/recovery/custody arrangements, reconcile actual bootstrap and constructor receipts.')
add(14,'Metadata URI/content/persistence and marketplace acceptance',[planner,rehearsal],'open_external_qualification',
    'Metadata2source/normal size is accepted and URI ABI sizing is source checked. No content retention/OpenSea queued reads/media/cache outcome is qualified.',
    'Choose final root, review all source artwork/content retention and supported-chain OpenSea behavior.')
add(15,'Actual native periphery/token/runtime controls',[planner,rehearsal],'open_external_qualification',
    'Source native identities remain fixed; historical constructor-only doubles do not pass real registry runtime admission.',
    'Review live code/getters/control/proxy behavior and release constructor arguments without treating seeded doubles as real dependencies.')
add(16,'Independent ETH/ZZZ pricing and usable routes',[planner,rehearsal],'open_external_qualification',
    'No source/route admitted by this work; latest real-market report remains separate. No safeguards relaxed.',
    'Resolve genuine independent sources, liveness and bidirectional execution capacity at required sizes.')
add(17,'Supported randomness configuration/subscription/funding',[planner,rehearsal],'open_external_qualification',
    'Construction succeeds unconfigured; no VRF provider/subscription/consumer/funding selected or adopted.',
    'Qualify actual provider, exact callback/configuration, authority and funded operation.')
add(18,'SeaDrop/OpenSea onboarding/settings/stages/fees/payers',[planner,rehearsal],'open_external_qualification',
    'Exact archived SeaDrop runtime was seeded only locally; helper remains unconfigured. Direct NFT constructor success is not marketplace acceptance.',
    'Complete supported-chain onboarding, terms/upstream synchronization, mintEnd and real gross/fee/net behavior.')
add(19,'Current actual constructors/runtime/bindings after metadata source changes',[rehearsal,'reports/metadata-lifecycle-fixes-20261116/VERIFICATION.md'],'open_changed_runtime_execution',
    'Current normal100-source build/39instance unsigned payload graph/48size checks pass; old44actual transactions retain older5-source runtime family.',
    'If authorized, rehearse changed accepted objects on a new owned chain and reconcile actual immutable-specific runtimes; do not relabel Nov15 receipts.')
add(20,'Target deployment gas and complete posting/execution fees',[planner,rehearsal],'open_target_qualification',
    '141382621total/14172289worst padded figures remain historical controlled local observations. No new constructor or fee work executed.',
    'Review final actual payload/gas/complete fees with approved provider and spending caps; do not sum internal children twice.')
add(21,'Configured operational graph and pre-seal release review',[planner,rehearsal],'open_operating_qualification',
    'Plans remain unsigned/not ready/production false; no seal/configuration/service adoption, no market/VRF/route setup inferred.',
    'Complete reviewed pools/routes/limits/confirmation/VRF/SeaDrop/inventory and reciprocal deployed bindings before any separate sealing authorization.')
add(22,'Hosting, restart, backups and operating recovery',[planner,rehearsal],'open_operating_qualification',
    'Isolated node shutdown and old capture integrity are not production host recovery or running service qualification.',
    'Rehearse matching approved host/provider/configuration/recovery and journal retention separately.')
add(23,'Independent audit and remediation',[planner,rehearsal],'open_independent_release_gate',
    'Internal scoped code/evidence checks provide no independent production approval.',
    'Commission independent review of exact final release artifacts, remediate and verify identified issues.')
add(24,'Permissionless factory interleaving and child addresses',[planner,rehearsal],'implemented_preserved',
    'Getter-discovered ActivationAssets and royalty ledger remain unresolved offline; checker resolves actual captured addresses rather than assuming factory nonces.',
    'Continue actual getter/receipt discovery; no CREATE prediction or invented zero address.')
document={'schema':1,'baseline':BASE,'families':[planner,rehearsal],'findings':rows,
          'scope':'Current source evaluation; historical evidence remains at its original accepted build. No all-future-state or production readiness guarantee.',
          'source_sha256':pins,'verification':'VERIFICATION.json'}
(E/'FINDINGS.json').write_text(json.dumps(document,indent=2)+'\n')
(E/'SOURCE_SHA256.json').write_text(json.dumps(pins,indent=2)+'\n')
print(json.dumps({'rows':len(rows),'unique_new_methods':21,'invocations':summary['total_method_invocations'],
                 'findings_sha256':sha((E/'FINDINGS.json').read_bytes()),'verification_sha256':sha((E/'VERIFICATION.json').read_bytes())}))
