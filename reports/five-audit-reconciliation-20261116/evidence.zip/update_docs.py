from pathlib import Path
import difflib,json,re
R=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2');E=Path(__file__).parent
def edit(name,fn):
 p=R/name;raw=p.read_bytes();old=raw.decode();lines=old.splitlines(keepends=True);new=fn(old.replace('\r\n','\n')).splitlines();nl='\r\n' if b'\r\n'in raw else '\n';out=[]
 for tag,i,j,k,l in difflib.SequenceMatcher(a=[x.rstrip('\r\n')for x in lines],b=new,autojunk=False).get_opcodes():out.extend(lines[i:j]if tag=='equal'else[x+nl for x in new[k:l]])
 p.write_bytes(''.join(out).encode())
def top(name,text):
 def fn(t):
  a,b=t.split('\n',1);return a+'\n\n'+text.strip()+'\n'+b
 edit(name,fn)
summary='''The [five-audit reconciliation](%s) separates resolved source work, accepted
limits and remaining release evidence. The unsigned deployment planner now
defaults to the exact trusted metadata2-20261116 build; explicit historical
manual-reference-20261115 remains separately authenticated. Old evidence is not
relabelled. The local checker requires the complete closed constructor/binding
graph and submission/RPC evidence; the new dated market checker recomputes all
summary/candidate flags while keeping approval false. Current callable counts
and metadata-source links are corrected. All61Solidity sources,114selected
historical report files, four unrelated dirty files, websites/signer/configs,
Anvil/journals and paused heartbeat remain unchanged. Only affected/new offline
checks run; actual current construction/gas, independent markets/services,
OpenSea/operations and independent audit remain open.'''
for name,link in [('AGENTS.md','reports/five-audit-reconciliation-20261116/REVIEW.md'),('PROJECT_CONTEXT.md','reports/five-audit-reconciliation-20261116/REVIEW.md'),('docs/WORK_HANDOFF.md','../reports/five-audit-reconciliation-20261116/REVIEW.md')]:
 top(name,summary%link)
 edit(name,lambda t:re.sub(r'(\[offline planner\]\([^)]*\)) remains byte-identical and unsigned;',r'\1 stayed unsigned and unchanged for that recorded rehearsal;',t))
top('README.md','''The [five-audit consolidation](reports/five-audit-reconciliation-20261116/REVIEW.md)
restores unsigned planning against the current metadata build and strengthens
deployment/market evidence checks. Historical artifacts keep their original
pins and gas scope. Financial contracts, safeguards and live environments are
unchanged; actual release qualification remains open.''')
top('docs/IMPLEMENTATION_STATUS.md','''[Five recent audit families](../reports/five-audit-reconciliation-20261116/REVIEW.md)
are reconciled against current source, with provenance and remaining actions in
one finding index. Current-build unsigned preparation, complete deployment
evidence and derived market-summary validation are corrected. No Solidity,
authority, policy, site or service changes; prior normal/static/EVM results keep
their exact source scope. Real release qualification is still separate.''')
top('docs/ROADMAP.md','''The [five-audit reconciliation](../reports/five-audit-reconciliation-20261116/REVIEW.md)
fixes current artifact-family planning and offline evidence-admission gaps.
Next qualify actual release authorities/dependencies/metadata and target fees,
then current-source constructors/operating workloads with those inputs. Reuse
unchanged source evidence; earlier44receipt construction gas stays historical.''')
top('docs/AUDIT_FINDINGS.md','''Use the [current five-audit finding index](../reports/five-audit-reconciliation-20261116/FINDINGS.json)
for the latest metadata, market, construction and manual-reference dispositions.
It records origin, duplicate action groups, source evidence, fixes and open
qualification. New trusted build selection and stronger offline checkers close
tooling/evidence defects; they do not qualify live providers or contracts.
The sole [Todo](../TODO.md) continues to own project status.''')
top('docs/README.md','''For the latest audit follow-through, use the [five-audit reconciliation](../reports/five-audit-reconciliation-20261116/REVIEW.md)
and its single finding index. [Deployment preparation](DEPLOYMENT_PREPARATION.md)
explains current/historical artifact selection and offline evidence checks.''')
top('reports/README.md','''[Five-audit reconciliation16November](five-audit-reconciliation-20261116/REVIEW.md)
checks the latest five substantive report families by Git publication history.
Current artifact planning and deployment/market evidence checkers are improved;
original114report files and all61Solidity files remain unchanged. Individual
dispositions and exact new/reused verification scopes stay explicit.''')
def deployment(t):
 t=t.replace('The offline\nplanner above stays unchanged and unsigned; this runner performs **local test',
 'The offline\nplanner above stays unsigned and uses its explicitly selected trusted build;\nthis runner performs **local test')
 marker='## Inputs and outputs';assert marker in t
 section='''## Select the exact reviewed build

The default trusted build is **`metadata2-20261116`**, using the accepted metadata
normal compiler family. Input `profile` stays `schema17/mint2/V10/execution1/LP3`;
the distinct build ID authenticates exact bytes. Output `build_profile` and
`accepted_build.profile` record it. Unknown IDs, mixed artifacts or changed
source bytes fail; there is no fallback to an older build to bypass drift.

```powershell
python scripts/prepare-deployment.py --build-profile metadata2-20261116 --input path/to/reviewed-input.json --output path/to/new-plan.json
```

The closed registry also retains **`manual-reference-20261115`** with its original
pins. Historical planning requires that exact old source checkout; selecting it
in the current checkout correctly refuses source drift. Old local evidence can
still be checked offline against its authenticated historical artifacts without
relabeling it current. A build profile, content SHA or plan manifest is not an
on-chain `reviewHash`, permission, runtime attestation or release approval.

After a future contract change, review a new exact closed compiler/source family
and extend the trusted registry deliberately. Never rewrite existing family pins,
copy local addresses into production inventories or install evidence-supplied
hashes as the trust root. This Python-only fix reuses current48normal gates;
it does not rerun constructors or refresh historical deployment gas.

'''
 t=t.replace(marker,section+marker,1)
 t=t.replace('The rehearsal constructs the exact current normal PoPL objects, binds Policy,','The rehearsal constructs the exact selected trusted normal PoPL objects, binds Policy,')
 t=t.replace('python scripts/rehearse-local-deployment.py --anvil "C:/reviewed-tools/anvil.exe" --output "C:/local-reviews/new-construction-run"','python scripts/rehearse-local-deployment.py --build-profile metadata2-20261116 --anvil "C:/reviewed-tools/anvil.exe" --output "C:/local-reviews/new-construction-run"')
 t=t.replace('and the reviewed local Anvil binary. Use a new output directory for each run;','and the reviewed local Anvil binary. Unknown build/source refusal happens before\ncreating a new output directory or starting a node. Use a new directory for each run;')
 t=t.replace('constructors, runtimes and binding observations. It reports the original','constructors, runtimes, exact submitted transaction fields and all112distinct\nrequired binding/state observations. It independently derives constructor roles,\narguments/parents and getter expectations from the closed graph, permits only\nthe recorded read methods and intended sends/impersonation, and verifies exact\ninert carrier payloads. Deleting or duplicating observations cannot satisfy\ncoverage. Captures with an explicit build ID must match its trusted files and\nplan/result identity; missing IDs are accepted only for exact historical pins.\nIt reports the original')
 t=t.replace('not reusable production transaction limits or ETH cost estimates.','not reusable production transaction limits or ETH cost estimates. That run used\nthe historical manual-reference family. Five later metadata objects changed;\ncurrent-family constructor execution and actual target fees remain unqualified.\nDo not replay44transactions merely to refresh a report date; qualify changed\nconstructors and real release inputs through an authorized targeted campaign.')
 return t
edit('docs/DEPLOYMENT_PREPARATION.md',deployment)
def operator(t):
 needle='### Offline deployment preparation';assert needle in t
 text='''### Offline audit and evidence tools

These calls use local files; they cannot approve release, sign, submit or seal.
The rehearsal row is a separate **future authorized local-chain operation**, not
part of this reconciliation. Preserve existing chains, journals and websites.

| Tool | Inputs | Example | Purpose |
| --- | --- | --- | --- |
| `prepare-deployment.py` | Reviewed input JSON, new output file; trusted build ID | `python scripts/prepare-deployment.py --build-profile metadata2-20261116 --input path/to/reviewed.json --output path/to/new-plan.json` | Review unsigned constructor plan |
| `check-local-deployment-evidence.py` | Captured ZIP/directory; optional relocated trusted build directory | `python scripts/check-local-deployment-evidence.py --evidence reports/local-deployment-rehearsal-20261115/evidence.zip --output path/to/new-result.json` | Reconcile captured local construction |
| `check-market-evidence.py` | Exact dated16November market ZIP | `python scripts/check-market-evidence.py --evidence reports/real-market-refresh-20261116/evidence.zip` | Recompute dated market summaries |
| `rehearse-local-deployment.py` | Reviewed Anvil executable, new directory, trusted build ID | `python scripts/rehearse-local-deployment.py --build-profile metadata2-20261116 --anvil C:/reviewed-tools/anvil.exe --output C:/local-reviews/new-run` | Measure isolated constructor execution |

Current planning defaults to `metadata2-20261116`; legacy
`manual-reference-20261115` remains separately pinned. The checker selects only
the captured closed build identity, and admits an absent ID only with the original
legacy pins. Neither a label nor an operator-selected `--build` directory can
replace those trusted hashes. Historical planning also needs its old exact source
checkout; old evidence replay does not. New metadata bytecode needs its own actual
constructor/gas qualification before release. No compiler rerun is required merely
to inspect accepted artifacts. [Full procedure](DEPLOYMENT_PREPARATION.md).

The market checker accepts one dated capture schema and recomputes market rows,
fees, quotes, gas, source/pass flags and the deliberately null/empty candidate.
PASS means internal semantic evidence closure. It does not authenticate provider
truth, current prices, depth, source independence or a deployable route. All
`production_approved`, `deployable_configuration`, `template_ready` and
`live_market_qualification` outputs remain false. Original report files stay
unchanged; use the [reconciliation](../reports/five-audit-reconciliation-20261116/REVIEW.md)
for the stronger current checker. No keeper/server restart is needed to run an
offline check; no running service is changed by publishing these tools.

'''
 t=t.replace(needle,text+needle,1)
 t=t.replace('The offline planner remains unsigned and unchanged. Do not','The offline planner remains unsigned and uses the explicitly reviewed build. Do not')
 return t
edit('docs/OPERATOR_MANUAL.md',operator)
def ledger(t):
 d=json.loads(t);d['reviewed']='2026-11-16';tasks={t['id']:t for a in d['areas']for t in a['tasks']}
 tasks['deployment-initcode']['acceptance'] += [
 '[Five-audit follow-through](reports/five-audit-reconciliation-20261116/REVIEW.md) restores current source planning with closed trusted metadata2-20261116 artifacts; original manual-reference-20261115 remains separately authenticated. Exact100source/39instance/48size offline review stays unsigned and unapproved. Unknown profiles/artifact mixing fail before caller-controlled build reads; no source-drift fallback.',
 'The current local evidence checker requires the exact112distinct expected getter/state observations, closed39constructor graph/arguments/parents and complete intended RPC/send/impersonation evidence. Inert carrier output is derived from trusted ledger bytes. Original44receipt data replays offline with the documented legacy preflight alias limitation. Preflight build refusal consumes no new rehearsal directory. No new node/deployment/gas campaign or old suite runs.',
 'Five metadata objects changed after the original local construction receipt set; its gas/runtime observations remain historical. Qualify current changed constructors, final actual arguments/dependencies and complete target fees before public deployment. Do not mark this broad task complete from an offline plan or archived receipt replay.'
 ]
 tasks['dual-price-qualification']['acceptance'].append('[Stronger dated evidence closure](reports/five-audit-reconciliation-20261116/REVIEW.md): new scripts/check-market-evidence.py rebuilds all market/feed/quote/pass/gas and null/empty candidate summaries from the recorded39responses. It rejects forged qualification fields but keeps every live approval false. Historical capture/checker/files remain unchanged; no source, route, provider, feed or operating policy is admitted.')
 tasks['metadata-ops']['acceptance'].append('[Five-audit reconciliation](reports/five-audit-reconciliation-20261116/REVIEW.md) confirms M1–M4/M6 implementation and retained M7 rights using exact unchanged source/accepted evidence; M5 freshness/adoption and M8 real OpenSea/content/host acceptance remain explicit. Current source links point to the accepted website2a52869; both hosted environments remain unchanged.')
 return json.dumps(d,ensure_ascii=False,indent=2)+'\n'
edit('docs/project-todo.json',ledger)
print('Updated current build/evidence procedures, scope links, Todo acceptance, feature/roadmap and memory. Historical reports untouched.')
