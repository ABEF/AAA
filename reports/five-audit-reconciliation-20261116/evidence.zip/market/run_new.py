"""Record only the newly authored market checker methods and exact source stage."""
from pathlib import Path
import hashlib,json,sys,time,unittest
R=Path(r'C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
E=Path(__file__).resolve().parent
sys.path.insert(0,str(R))
stage=sys.argv[1]
destination=E/stage;destination.mkdir(exist_ok=False)
pins={}
for name in ('zzz_ops/market_evidence.py','scripts/check-market-evidence.py','tests_python/test_market_evidence.py'):
    raw=(R/name).read_bytes();pins[name]=hashlib.sha256(raw).hexdigest()
    target=destination/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
selectors=sys.argv[2:] or ['tests_python.test_market_evidence']
suite=unittest.defaultTestLoader.loadTestsFromNames(selectors)
start=time.perf_counter()
with (destination/'tests.log').open('w',encoding='utf8')as log:
    result=unittest.TextTestRunner(stream=log,verbosity=2).run(suite)
report={'status':'PASS'if result.wasSuccessful()else'FAIL','methods':result.testsRun,
    'failures':len(result.failures),'errors':len(result.errors),'skips':len(result.skipped),
    'failed_ids':[case.id()for case,_ in result.failures+result.errors],
    'selectors':selectors,'source_sha256':pins,'duration_seconds':time.perf_counter()-start,
    'network_calls':0,'old_suites_rerun':0}
(destination/'RESULT.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
print(json.dumps(report))
raise SystemExit(not result.wasSuccessful())
