"""One NEW offline adversarial check against the exact historical checker."""
from pathlib import Path
import hashlib,json,subprocess,sys,tempfile,zipfile

R=Path(r'C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
E=Path(__file__).resolve().parent
source=R/'reports/real-market-refresh-20261116/verify.py'
assert hashlib.sha256(source.read_bytes()).hexdigest()=='c4d3ae7aba1a0bed3f250b9f87b6366d6cbfa8cd75fffb7f4555691630477233'
with zipfile.ZipFile(source.with_name('evidence.zip'))as z:
    members={name:z.read(name)for name in z.namelist()}
result=json.loads(members['RESULTS.json'])
result['sources_qualified']['independent_ZZZ_pair']=True
result['feeds']['pyth']['qualified']=True
members['RESULTS.json']=json.dumps(result,indent=2,sort_keys=True).encode()
manifest=json.loads(members['manifest.json'])
for row in manifest['files']:
    raw=members[row['path']];row['bytes']=len(raw);row['sha256']=hashlib.sha256(raw).hexdigest()
members['manifest.json']=json.dumps(manifest).encode()
with tempfile.TemporaryDirectory(dir=E)as tmp:
    evidence=Path(tmp)/'mutated.zip'
    with zipfile.ZipFile(evidence,'w',zipfile.ZIP_DEFLATED)as z:
        for name,raw in members.items():z.writestr(name,raw)
    run=subprocess.run([sys.executable,'-I','-B',str(source),'--evidence',str(evidence),'--repo',str(R)],capture_output=True,text=True,timeout=30)
    assert run.returncode==0,(run.stdout,run.stderr)
    report={'status':'CONFIRMED_SEMANTIC_GAP','new_adversarial_methods':1,
        'historical_checker_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
        'mutations':['sources_qualified.independent_ZZZ_pair:true','feeds.pyth.qualified:true'],
        'actual_wire_observations_changed':False,'manifest_hashes_consistent':True,
        'historical_checker_exit_code':run.returncode,'historical_output':json.loads(run.stdout),
        'network_calls':0,'old_suites_rerun':0}
    (E/'BASELINE.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
    print(json.dumps(report))
