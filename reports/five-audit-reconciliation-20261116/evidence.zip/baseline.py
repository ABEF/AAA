from pathlib import Path
import hashlib,json,subprocess
R=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2');E=Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=R,text=True).strip()
assert git('branch','--show-current')=='main';head=git('rev-parse','HEAD');assert head=='28431b3ac63d909c9c04246de1ee68cc16a3ed5e'
protected={'reports/source-checks.json':'049dca6943d06ba63de682dc8cdec2cf3935af1dc2e5479e9f3cf14e1af793c4','scripts/run-fork-checks.py':'875d27fb56963d92e6e7ec25b9f296b5559b830e007ad411afb856f0f0226f1b','tests_python/test_fork_runner.py':'6d50a612ec490ec0f3754d930ac6610173d96d0a684bbc5e4894eaedf4d9abc9','tests_python/test_frontend_history.py':'361f6a56153a4b3041b5b6f7eaaf399fea063bae9f46299da71397a08540c7eb'}
assert set(git('diff','--name-only').splitlines())==set(protected);assert not git('diff','--cached','--name-only')
for n,h in protected.items():assert sha(R/n)==h
families=['metadata-lifecycle-fixes-20261116','real-market-refresh-20261116','local-deployment-rehearsal-20261115','deployment-preparation-20261115','manual-reference-swap-fix-20261115']
report_pins={p.relative_to(R).as_posix():sha(p) for f in families for p in (R/'reports'/f).rglob('*') if p.is_file()}
tracked=git('ls-files','src','zzz_ops','scripts','keeper','frontend_api','indexer').splitlines();source_pins={n:sha(R/n) for n in tracked}
docs=['AGENTS.md','PROJECT_CONTEXT.md','README.md','TODO.md','docs/AUDIT_FINDINGS.md','docs/WORK_HANDOFF.md','docs/OPERATOR_MANUAL.md','docs/DEPLOYMENT_PREPARATION.md','docs/IMPLEMENTATION_STATUS.md','docs/ROADMAP.md','docs/RELEASE_CHECKLIST.md','docs/DEPLOYMENT_ADDRESSES.md','docs/PRODUCTION_PREFLIGHT.md','docs/DEVELOPMENT.md','docs/README.md','reports/README.md','docs/project-todo.json']
for n in docs+['zzz_ops/deployment_plan.py','scripts/prepare-deployment.py','scripts/check-local-deployment-evidence.py','scripts/rehearse-local-deployment.py']:
 p=E/'originals'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((R/n).read_bytes())
W=R.parent.parent/'aaa-website';website={n:sha(W/n) for n in ('browser-wallet.js','deployment-config.js','integration-config.js','deployment-view.js')}
record={'head':head,'branch':'main','source_pins':source_pins,'production_sources':{n:h for n,h in source_pins.items() if n.startswith('src/') and n.endswith('.sol')},'protected':protected,'families_newest_first':families,'report_pins':report_pins,'docs':docs,'website_protected':website,'status':git('status','--short'),'selection_basis':'Latest5substantive REVIEW.md report families by Git publication history; metadata80case matrix is supporting context, not a separate duplicate report.'}
(E/'BASELINE.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'head':head,'production_sources':len(record['production_sources']),'frozen_report_files':len(report_pins),'archived_docs':len(docs),'families':families}))
