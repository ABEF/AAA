from pathlib import Path
import gzip, hashlib, json

R = Path(r'C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
W = Path(r'C:/Users/Ali/Desktop/2.x holas/Oto/aaa-website')
E = Path(__file__).resolve().parent
E.mkdir(exist_ok=True)
HEAD = '28431b3ac63d909c9c04246de1ee68cc16a3ed5e'
def sha(raw): return hashlib.sha256(raw).hexdigest()
def pin(path):
    raw=path.read_bytes()
    return {'sha256_raw':sha(raw),'sha256_lf':sha(raw.replace(b'\r\n',b'\n'))}
def save(name,value): (E/name).write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def body(value):
    length=int(value[-4:],16)+2
    return value[:-2*length] if len(value)>=2*length else value

old_path=R/'reports/manual-reference-swap-fix-20261115/build/compiler-output.json.gz'
new_path=R/'reports/metadata-lifecycle-fixes-20261116/build/compiler-output.json.gz'
old_raw=gzip.decompress(old_path.read_bytes());new_raw=gzip.decompress(new_path.read_bytes())
a=json.loads(old_raw);b=json.loads(new_raw)
names=('ZZZMigrationBudget','ZZZContributionPricing','ZZZCustodyValidation','ZZZLiquidityManager',
       'ZZZLPBalanceMath','ZZZLPBalancer','ZZZVault','ZZZMigration','ZZZAccessController',
       'ZZZNFT','ZZZNFTMetadata','ZZZNFTCanonical')
objects=[]
for name in names:
    path='src/'+name+'.sol';x=a['contracts'][path][name];y=b['contracts'][path][name]
    xr=x['evm']['deployedBytecode']['object'];yr=y['evm']['deployedBytecode']['object']
    xc=x['evm']['bytecode']['object'];yc=y['evm']['bytecode']['object']
    objects.append({'contract':name,'source':path,'current_source':pin(R/path),
        'creation_template_equal':xc==yc,'runtime_template_equal':xr==yr,
        'runtime_body_excluding_CBOR_equal':body(xr)==body(yr),'ABI_equal':x['abi']==y['abi'],
        'runtime_bytes_before':len(xr)//2,'runtime_bytes_current':len(yr)//2,
        'old_runtime_template_sha256':sha(bytes.fromhex(xr)),
        'current_runtime_template_sha256':sha(bytes.fromhex(yr)),
        'old_creation_template_sha256':sha(bytes.fromhex(xc)),
        'current_creation_template_sha256':sha(bytes.fromhex(yc))})
assert all(row['creation_template_equal'] and row['runtime_template_equal'] and row['ABI_equal'] for row in objects[:7])
assert all(not row['runtime_template_equal'] for row in objects[7:])
equivalence={'head':HEAD,'kind':'Read-only comparison of existing accepted normal compiler objects; no compiler or tests',
    'prior_family':'manual-reference-swap-fix-20261115 accepted normal4',
    'current_family':'metadata-lifecycle-fixes-20261116 accepted normal6',
    'input_artifacts':{str(old_path.relative_to(R)):{'compressed':pin(old_path),'decompressed_sha256':sha(old_raw)},
                       str(new_path.relative_to(R)):{'compressed':pin(new_path),'decompressed_sha256':sha(new_raw)}},
    'objects':objects,
    'scope':'All six manual-fix objects and Vault have exact equal full creation/runtime templates and ABI. The surrounding Access/Migration/NFT/renderer/lens objects differ. This supports unchanged-object evidence reuse, not relabeling prior deployed immutable runtime hashes, C/D receipts, whole-graph gas or marketplace/host acceptance as current.',
    'executed':{'compiler':0,'analyzer':0,'test_methods':0,'RPC':0,'deployment':0,'transactions':0}}
save('OBJECT_EQUIVALENCE.json',equivalence)

rows=[]
def add(identifier,origin,status,finding,evidence,next_action,category='scope_reconciliation'):
    rows.append({'id':identifier,'origin':origin,'status':status,'category':category,'finding':finding,
                 'current_evidence':evidence,'next_action':next_action})
meta='reports/metadata-lifecycle-fixes-20261116/REVIEW.md'
matrix='docs/METADATA_LIFECYCLE.md'
manual='reports/manual-reference-swap-fix-20261115/REVIEW.md'
add('M1',meta+'; '+matrix+' material finding M1','closed_source',
    'Exit start, each bucket close and final Ready notify without waiting for holder payout.',
    ['src/ZZZAccessController.sol:110-116 and242-244: committed exit state followed by fixed event-only NFT hook',
     'src/ZZZMigration.sol:217-241,247-281: close/readiness notifications after coherent state writes',
     'src/ZZZNFT.sol:112-117: fixed controller/Policy/Migration callers emit O(1) whole-collection event',
     'Accepted metadata verification:10 new notification methods, including actual exit/payment composition; no rerun'],
    'Reuse accepted bounded notification evidence. Actual OpenSea ingestion and latency remain M8; do not add a per-NFT unbounded close loop.')
add('M2',meta+'; '+matrix+' material finding M2','closed_source',
    'Unassigned, assigned-not-ready, payable, paid and exact-zero principal are separate metadata states.',
    ['src/ZZZNFTCanonical.sol:67-95 validates exit phase/allocation/paid consistency;123-131 classifies status',
     'src/ZZZNFTMetadata.sol:174-198 uses terminal-specific descriptions without duplicating raw principal balances',
     'src/ZZZMigration.sol:316-331 marks/debits before transfer; successful notification is inside isolated atomic payment',
     'Accepted18 snapshot and10 notification methods retain exact controlled fixture scope'],
    'Keep Migration/API actual remaining values authoritative. No accounting change or old test rerun is justified.')
add('M3',meta+'; '+matrix+' material finding M3','closed_source',
    'A never-activated NFT remains Dormant after terminal exit and separately reports activation closure.',
    ['src/ZZZNFTMetadata.sol:199-210 weight0 stays Dormant; descriptions distinguish never-activated terminal NFTs',
     'src/ZZZNFTCanonical.sol:110 activation_closed is terminal/canonical context, not a royalty activation',
     'No share/royalty writes were added by metadata implementation'],
    'Preserve Dormant identity and zero ledger eligibility. Do not relabel it LP exited or award another NFT principal.')
add('M4',meta+'; '+matrix+' material finding M4','closed_source',
    'Preparing, frozen, importing, retired predecessor and cancelled import have explicit context and notifications.',
    ['src/ZZZNFTCanonical.sol:71-95 validates canonical bounds and required successor identities;132-145 labels lifecycle',
     'src/ZZZAccessController.sol:120-167 notifies after canonical/preparation changes',
     'src/ZZZNFTMetadata.sol:174-183 distinguishes temporary preparation from permanent activation closure',
     'All126 old canonical declarations/90 bodies remain exact per accepted MECHANICAL_REVIEW.json'],
    'Adopt new exact source/runtime pins only by explicit review. Existing listings/checkpoints never move automatically to a successor.')
add('M5',meta+'; '+matrix+' material finding M5','defined_source_external_operation_open',
    'Numeric NAV, visual tier, lifecycle change fingerprint and marketplace cache freshness are different facts.',
    ['src/ZZZNFTCanonical.sol:102-104 exposes metadata read block/time, not feed publication',
     'src/ZZZNFTMetadata.sol:134-148 fingerprints five price-free words and excludes NAV/read clock/owner',
     'keeper/monitor.py:2233-2250 still samples evolution/availability plus optional lifecycle fingerprint; it is not an all-price-change stream',
     'docs/OPERATIONS.md:469-527 documents bounded scans and shared transaction delays'],
    'Measure matching-host scan/backlog and marketplace latency later; do not promise per-block metadata, continuous price evidence or immediate OpenSea refresh.')
add('M6',meta+'; '+matrix+' material finding M6','closed_source_rollout_open',
    'Unavailable activated valuation uses labelled Activated fallback; pending LP targets wait for confirmed execution.',
    ['src/ZZZNFTMetadata.sol:199-210 catches marked valuation failure;223-231 chooses Activated fallback art',
     'Website commit2a528696d5eaea5ebb42cfeb313836840fff5e97 deployment-view.js:11-38 and283 holds target pending snapshot/no confirmed art marker',
     'Website deployment-view.js raw SHA89c348cd3895ffd997d677f441fa10aa57a941e6e172763bd094b0a028af29fe matches accepted verification',
     'Accepted13 new browser checks are reused, not rerun or counted as hosted/real wallet acceptance'],
    'Keep public configurations null and rollout separately reviewed. Fix stale matrix source links in D2; source publication is not site deployment.')
add('M7',meta+'; '+matrix+' material finding M7','decision_preserved',
    'LP exited is distinct from Dormant, with Activated artwork and retained old/future royalty rights.',
    ['src/ZZZNFTMetadata.sol:206 stage4;317-321 _stageFile(4) maps activated',
     'src/ZZZNFTCanonical.sol:141 LP exited lifecycle label; no ledger mutation',
     'Accepted actual tokenURI exit→transfer→payout composition retains royalty activation'],
    'No fifth image or economic deactivation. Any future different terminal art needs an explicit compatible content/renderer decision, not a silent cleanup.')
add('M8',meta+'; '+matrix+' material finding M8','open_external_qualification',
    'OpenSea supported-chain collection intake, on-chain read gas, content retention, cache/media outcome and matching-host operation remain unqualified.',
    ['reports/metadata-lifecycle-fixes-20261116/REVIEW.md What remains open',
     'docs/METADATA_LIFECYCLE.md H01-H07,I01-I08,J05-J08',
     'No marketplace acceptance or hosted worker was performed in accepted source checks'],
    'Once actual deployment/marketplace/host access is authorized, qualify exact collection/runtime/root/media, bounded tokenURI gas, watcher budgets/backlog, outages/restarts/reorgs and observed refresh latency. Independent audit remains separate.')
add('MW1',meta+' optional watcher lifecycle2','closed_source_adoption_open',
    'New lifecycle2 watcher admission is explicit; omission/0 historical behavior is not a defect.',
    ['keeper/monitor.py:2045-2138 strict exact0/2 profile, accounting7, nonzero renderer runtime, exact durable identity and disabled-pending recovery',
     'keeper/monitor.py:2199-2229 checks sealed deployment/NFT/Vault/controller/renderer/version/runtime at confirmed scan/receipt block',
     'keeper/monitor.py:2300-2330 rereads execution records and checks anchors before candidate checkpoint',
     'Deployment schema17 existing graph separately pins NFTCanonical/metadata_renderer roles; no unsupported automatic capability inference was added'],
    'Prepare reviewed new lifecycle2 config/identity only for a matching fresh graph; preserve old journals and pending recovery. No further source fix demonstrated.')
add('MR1',manual+' implementation and safeguards','closed_source_scoped_reuse',
    'Priced paused manual C/D use a whole-operation captured vector and exact selected actual-core output/full-state proof.',
    ['src/ZZZMigrationBudget.sol:105-125 arms/validates and opens retained2/4 scope before manual movement; cleans after final verification',
     'src/ZZZContributionPricing.sol:152-167 fixed-Budget scope ownership and begin/end; no mutable source replacement',
     'src/ZZZCustodyValidation.sol:147-160 validates live scope but commits starting source fingerprints',
     'src/ZZZLiquidityManager.sol:237-256,307-334,336-384 proves exact output/full expected core state before settlement and revalidates callbacks',
     'OBJECT_EQUIVALENCE.json: six implementing objects plus Vault exact full creation/runtime templates and ABI equal accepted manual normal4→metadata normal6'],
    'Reuse25new/3adapted methods and nine completed adverse callback records at their exact original scope; do not rerun unchanged methods merely for a new date.')
add('MR2',manual+' mask matrix','decision_preserved',
    'Unpriced masks0/8, retained price2/value4, operations8 and timing/sample bits1/16 keep distinct deliberate meanings.',
    ['src/ZZZMigrationBudget.sol:105-125 only bits2/4 open price scope',
     'src/ZZZLiquidityManager.sol:106-136 force-mask choice stays in Manager; zero/8 does not acquire an Oracle dependency',
     'reports/manual-reference-swap-fix-20261115/UNIT_METHODS.json and CALLBACK_TRACE_REVIEW.json preserve both directions/no-swap/sequential and actual callbacks',
     'Parked schema2 bit1/16 unsupported eligibility remains explicitly rejected, not silently bypassed'],
    'Preserve explicit mask review and caller raw floors. Disabled financial checks may lose nearly all principal; never automate force fallback or imply ordinary caps are unconditional governance limits.')
add('MR3',manual+' independent-reference boundary','open_market_qualification',
    'An external reference may be the swap venue, but same-core PoPL principal as its own independent reference remains excluded.',
    ['Manual own-transition proof authenticates our own trade; it does not establish external source independence, market depth or MEV immunity',
     'Accepted report explicitly retains fresh agreement, price bands, fees, actual depth, caller floors, loss and idle limits',
     'Later real-market-refresh family still supplies no qualified independent source pair or complete route'],
    'Qualify actual independent sources and directional execution at post-withdrawal depth without changing caps/duplicating feeds. Legitimate economic rejection is not a reason to remove a guard.')
add('MR4',manual+' gas and operating evidence','open_target_and_host_qualification',
    'Original C14/ActiveD14/ParkedD14 receipts and25% padded16,315,867/24M maximum are local source-scoped execution evidence.',
    ['Original GAS_AND_TRANSACTIONS.json preserves three manual and one park receipts, original inputs/expiry, once-only submission and32M owned local blocks',
     'Current surrounding Migration/Access/NFT runtime templates differ in OBJECT_EQUIVALENCE.json despite unchanged manual implementation objects',
     'No Robinhood full-operation/complete-fee/max-state/contract-wallet/host acceptance follows from these local receipts'],
    'Retain original receipt scope and qualify final exact graph/immutable runtimes, target provider full-call fees, maximum workload and real operator/contract wallet only when authorized; do not raise defaults or relabel local20M/24M as production approval.')
add('MR5',manual+' paused operation/recovery','defined_operational_boundary',
    'C retains exact main/ticks/rebalance clock and turns mode OFF; D replaces one main; successful manual flows remain paused.',
    ['src/ZZZMigration.sol:102-141 invokes typed manual wrappers, exact consolidation validation and explicit completion without unpause',
     'Guarded C may legitimately fail if current geometry/price/depth/floors no longer permit the reviewed operation; forced C/D is separately selected',
     'Original stale custody/share/policy review detection and expiry are replay protection, not a broken mutable-market workflow'],
    'Prepare fresh unsigned reviews for changed identity/state and explicitly review force mask if emergency. Unpause is a separate governance action; do not add automatic bypass/resend.')
add('MR6',manual+' static/current runtime provenance','superseded_current_inventory_historical_evidence_retained',
    'Manual565=113current+452reuse is historical; current metadata review569=57current+512reuse is source-bound current static inventory.',
    ['Current strict default reports/metadata-lifecycle-fixes-20261116/static-review.json; both full and projected original analyzer inputs passed at accepted source',
     'All48current normal size gates retained; Oracle3/Vault32/Manager101 margins remain, renderer455/NFTCanonical1446/NFT342 are new current margins',
     'Historical565 findings do not become new current individual review or all-resolved release obligations'],
    'Use current normal/static pins for new release reviews. Keep old source/runtimes/archives/journals unchanged and explain exact-source reuse; no new analyzer/compiler rerun warranted.')
add('MR7',manual+' preservation and evidence inspection','preserved_limitation',
    'Old Anvil live endpoint was unavailable; original report correctly does not claim preserved live state-root equality.',
    ['reports/manual-reference-swap-fix-20261115/REVIEW.md adoption/evidence explicitly records unavailable historical RPC',
     'Existing site/signer/configuration and protected4dirty files remain unrelated; current inspection contacted no chain/service'],
    'Do not probe/reset the old chain merely to retrofit equality evidence. Restore/adopt only through explicit future environment procedure.')
add('D1','docs/project-todo.json:380,383 → TODO.md:451,456','documentation_correction_required',
    'The sole current callable-reference task still says956 functions/1009 examples although the current generated reference has963/1016.',
    ['Current metadata VERIFICATION.md mechanical closure gives40contracts/963functions/40constructors/13receivers/1016examples',
     'Ledger text calls old counts current; it is not a labelled historical scope',
     'Manual report959/1012 counts remain historical and must not be rewritten'],
    'Root updates these two current ledger strings and regenerates Todo; preserve old report numbers.',category='stale_current_documentation')
add('D2','docs/METADATA_LIFECYCLE.md:232-234','documentation_correction_required',
    'Matrix source map links pre-fix website206892 while its current M6 behavior depends on accepted source2a52869.',
    ['Current sibling website HEAD2a528696d5eaea5ebb42cfeb313836840fff5e97',
     'Current deployment-view.js raw SHA89c348cd3895ffd997d677f441fa10aa57a941e6e172763bd094b0a028af29fe matches accepted metadata browser record',
     'Old source206892 may remain relevant as original inventory baseline, not evidence that current fallback code existed there'],
    'Root distinguishes original inspected source from accepted fix source and links current view with exact immutable commit. Do not imply hosted rollout.',category='stale_current_documentation')

pins=['src/ZZZAccessController.sol','src/ZZZMigration.sol','src/ZZZNFT.sol','src/ZZZNFTMetadata.sol','src/ZZZNFTCanonical.sol',
      'src/ZZZMigrationBudget.sol','src/ZZZContributionPricing.sol','src/ZZZCustodyValidation.sol','src/ZZZLiquidityManager.sol',
      'src/ZZZLPBalanceMath.sol','src/ZZZLPBalancer.sol','keeper/monitor.py','zzz_ops/deployment_plan.py','zzz_ops/production_v15.py',
      'zzz_ops/production_observer_v15.py','docs/METADATA_LIFECYCLE.md','docs/project-todo.json','TODO.md',
      'reports/metadata-lifecycle-fixes-20261116/REVIEW.md','reports/metadata-lifecycle-fixes-20261116/VERIFICATION.md',
      'reports/manual-reference-swap-fix-20261115/REVIEW.md','reports/manual-reference-swap-fix-20261115/VERIFICATION.md']
save('FINDINGS.json',{'head':HEAD,'scope':'Read-only current applicability and actionable gap review of metadata lifecycle and guarded manual-reference families; all eight material metadata findings and remaining manual boundaries are individually reconciled.',
    'source_pins':{name:pin(R/name) for name in pins},
    'website_source':{'commit':'2a528696d5eaea5ebb42cfeb313836840fff5e97','deployment-view.js':pin(W/'deployment-view.js')},
    'findings':rows,'new_demonstrated_contract_or_watcher_defects':0,
    'source_changes_justified_by_this_pass':False,
    'open_qualification_is_not_source_defect':True,
    'executed':{'compiler':0,'analyzer':0,'test_methods':0,'RPC':0,'deployment':0,'transactions':0},
    'preservation':'No source/docs edits or environment/state/service/site/public-signing changes; four unrelated dirty files untouched. Root owns current-doc corrections. Exact unchanged evidence is reused without relabeling historical fixtures/runtime/source/gas.'})
print(json.dumps({'rows':len(rows),'metadata_material_rows':8,'new_demonstrated_code_defects':0,
    'documentation_corrections':['D1','D2'],'objects_compared':len(objects),'full_equal_templates':7,'path':str(E)}))
