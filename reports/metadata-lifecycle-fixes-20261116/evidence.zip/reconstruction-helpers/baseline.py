from pathlib import Path
import hashlib,json,subprocess
R=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2');E=Path(__file__).resolve().parent
def git(*a):return subprocess.check_output(['git',*a],cwd=R)
head=git('rev-parse','HEAD').decode().strip();assert head=='dd242634b7dc4d3ead6d66f8a42c857da587cf15'
record={'head':head,'branch':git('branch','--show-current').decode().strip(),'status_at_capture':git('status','--short').decode(),'protected':{},'head_sources':{},'docs':{}}
paths=[p.relative_to(R).as_posix() for p in (R/'src').rglob('*.sol')]
docs=['AGENTS.md','PROJECT_CONTEXT.md','README.md','TODO.md','docs/WORK_HANDOFF.md','docs/OPERATOR_MANUAL.md','docs/METADATA_LIFECYCLE.md','docs/NFT_METADATA.md','docs/OPERATIONS.md','docs/ARTWORK_PUBLICATION.md','docs/IMPLEMENTATION_STATUS.md','docs/ROADMAP.md','docs/README.md','reports/README.md','docs/project-todo.json','docs/CONTRACT_FUNCTIONS.md','docs/function-reference.json','docs/function-reference-notes.json','docs/operator-call-examples.json','docs/OPERATOR_FUNCTIONS.md']
for name in paths:
    raw=git('show',head+':'+name);p=E/'baseline-head'/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw);record['head_sources'][name]=hashlib.sha256(raw).hexdigest()
for name in docs:
    p=R/name
    if not p.exists():continue
    raw=p.read_bytes();out=E/'originals'/name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(raw);record['docs'][name]=hashlib.sha256(raw).hexdigest()
for name in ('reports/source-checks.json','scripts/run-fork-checks.py','tests_python/test_fork_runner.py','tests_python/test_frontend_history.py'):record['protected'][name]=hashlib.sha256((R/name).read_bytes()).hexdigest()
record['note']='Source originals come from exact HEAD; notification agent may already be editing its approved files. Original dirty documents were archived before root consolidation.'
(E/'BASELINE.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'baseline':head,'source_originals':len(paths),'docs_archived':len(record['docs']),'protected':len(record['protected'])}))
