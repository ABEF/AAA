from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time
E=Path(__file__).resolve().parent;W=Path('C:/Users/Ali/Desktop/2.x holas/Oto/aaa-website');O=E/sys.argv[1];O.mkdir(exist_ok=False)
files=[*W.glob('*.js'),W/'tests/metadata-fallback.test.mjs'];pins={p.relative_to(W).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
cmd=['C:/Program Files/nodejs/node.exe','--test','--test-reporter=tap','tests/metadata-fallback.test.mjs']
env={n:os.environ[n] for n in ('SystemRoot','WINDIR','SystemDrive','COMSPEC','PATHEXT','TEMP','TMP','USERPROFILE','LOCALAPPDATA','APPDATA','PROGRAMDATA') if n in os.environ};env['PATH']='C:/Program Files/nodejs'+os.pathsep+'C:/Windows/System32'
(O/'START.json').write_text(json.dumps({'command':cmd,'source_sha256':pins,'old_tests_selected':0,'server_or_signer_started':False,'credentials_inherited':False},indent=2)+'\n');t=time.monotonic()
with (O/'stdout.tap').open('xb') as out,(O/'stderr.log').open('xb') as err:p=subprocess.run(cmd,cwd=W,env=env,stdout=out,stderr=err,timeout=90)
assert pins=={name:hashlib.sha256((W/name).read_bytes()).hexdigest() for name in pins}
text=(O/'stdout.tap').read_text(encoding='utf-8');counts={k:int(re.search(r'^# '+k+r' (\d+)\s*$',text,re.M)[1]) for k in ('tests','pass','fail','skipped')}
record={'exit_code':p.returncode,'seconds':time.monotonic()-t,'source_unchanged':True,'new_methods':counts,'old_tests_executed':0,'production_or_wallet_acceptance':False}
(O/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record));raise SystemExit(0 if p.returncode==0 and counts=={'tests':13,'pass':13,'fail':0,'skipped':0} else 1)
