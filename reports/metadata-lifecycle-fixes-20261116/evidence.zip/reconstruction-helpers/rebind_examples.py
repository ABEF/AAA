from pathlib import Path
import hashlib,json,sys
R=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2');E=Path(__file__).parent;sys.path.insert(0,str(R))
from zzz_ops.function_reference import canonical_json
a=json.loads((E/'originals/docs/function-reference.json').read_bytes());b=json.loads((R/'docs/function-reference.json').read_bytes())
def key(x):return x['type']+':'+x.get('name','')+':'+','.join(p['type'] for p in x.get('inputs',[]))
added={}
for c,info in a['abi_snapshot'].items():
    aa={key(x):x for x in info['abi']};bb={key(x):x for x in b['abi_snapshot'][c]['abi']}
    assert set(aa)<=set(bb) and all(aa[k]==bb[k] for k in aa),c
    if set(bb)-set(aa):added[c]=[bb[k] for k in sorted(set(bb)-set(aa))]
assert {c:len(v) for c,v in added.items()}=={'ZZZNFTCanonical':3,'ZZZNFTMetadata':2}
assert sum(x['type']=='function' for rows in added.values() for x in rows)==4
assert [x['name'] for rows in added.values() for x in rows if x['type']=='error']==['StringsInsufficientHexLength']
p=R/'docs/operator-call-examples.json';raw=p.read_bytes();j=json.loads(raw);old=json.loads((E/'originals/docs/operator-call-examples.json').read_bytes())
assert all(j['rows'][k]==v for k,v in old['rows'].items());assert len(j['rows'])==len(old['rows'])+4
j['reference_sha256']=hashlib.sha256(canonical_json(b).encode()).hexdigest()
p.write_text(json.dumps(j,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\r\n' if b'\r\n' in raw else '\n')
(E/'FUNCTION_REFERENCE_REVIEW.json').write_text(json.dumps({'existing_abis_unchanged':True,'added':added,'original_examples_unchanged':len(old['rows']),'new_reads':4,'reference_sha256':j['reference_sha256']},indent=2)+'\n')
print(json.dumps({'existing_abis_unchanged':True,'new_read_functions':4,'examples':len(j['rows'])}))
