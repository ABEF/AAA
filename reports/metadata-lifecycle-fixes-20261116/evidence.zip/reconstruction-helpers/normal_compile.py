from pathlib import Path
import gzip,hashlib,json,os,subprocess,sys,time
R=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2');E=Path(__file__).resolve().parent;V=E.parent
O=E/sys.argv[1];O.mkdir(exist_ok=False)
base=R/'reports/manual-reference-swap-fix-20261115/build'
raw=gzip.decompress((base/'compiler-input.json.gz').read_bytes());j=json.loads(raw);pins={};changed=[]
for name,row in j['sources'].items():
    current=(R/name).read_bytes();pins[name]=hashlib.sha256(current).hexdigest()
    if row['content']!=current.decode('utf-8'):changed.append(name);row['content']=current.decode('utf-8')
expected={'src/ZZZAccessController.sol','src/ZZZNFT.sol','src/ZZZMigration.sol','src/ZZZNFTMetadata.sol','src/ZZZNFTCanonical.sol'}
assert set(changed)==expected,(changed,expected)
assert len(j['sources'])==100
payload=json.dumps(j,separators=(',',':'),ensure_ascii=True).encode();(O/'compiler-input.json').write_bytes(payload)
keep=('SystemRoot','WINDIR','SystemDrive','COMSPEC','PATHEXT','TEMP','TMP','USERPROFILE','LOCALAPPDATA','APPDATA','PROGRAMDATA')
env={n:os.environ[n] for n in keep if n in os.environ};env['PATH']=str(V/'toolchain-0.8.26')+os.pathsep+str(Path(env.get('SystemRoot','C:/Windows'))/'System32')
cmd=[str(V/'toolchain-0.8.26/solc.exe'),'--standard-json']
start={'command':cmd,'compiler_sha256':hashlib.sha256(Path(cmd[0]).read_bytes()).hexdigest(),'baseline_compiler_input_sha256':hashlib.sha256(raw).hexdigest(),'input_sha256':hashlib.sha256(payload).hexdigest(),'source_sha256':pins,'changed_sources':changed,'settings':j['settings'],'codegen_settings_unchanged':True,'old_test_methods_executed':0}
(O/'START.json').write_text(json.dumps(start,indent=2)+'\n');t=time.monotonic()
with (O/'compiler-input.json').open('rb') as stream,(O/'compiler-output.json').open('xb') as out,(O/'stderr.txt').open('xb') as err:
    p=subprocess.Popen(cmd,stdin=stream,stdout=out,stderr=err,cwd=O,env=env,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    (O/'PID.json').write_text(json.dumps({'owned_pid':p.pid}))
    try:code=p.wait(timeout=900)
    except subprocess.TimeoutExpired:p.kill();p.wait(timeout=10);raise
assert pins=={n:hashlib.sha256((R/n).read_bytes()).hexdigest() for n in pins},'Source changed during compile'
assert hashlib.sha256(Path(cmd[0]).read_bytes()).hexdigest()==start['compiler_sha256'],'Compiler changed during build'
compiled=json.loads((O/'compiler-output.json').read_bytes());errors=[x for x in compiled.get('errors',[]) if x['severity']=='error'];gates=[]
if not errors:
    for g in json.loads((base/'production-size-gates.json').read_bytes())['gates']:
        c=compiled['contracts'][g['path']][g['name']];runtime=len(c['evm']['deployedBytecode']['object'])//2;creation=len(c['evm']['bytecode']['object'])//2
        gates.append({**g,'runtime':runtime,'creation':creation,'runtime_margin':24576-runtime,'maximum_total_argument_bytes':49152-creation,'runtime_ok':runtime<=24576,'creation_ok':creation+g['minimum_args']<=49152})
result={'exit_code':code,'seconds':time.monotonic()-t,'errors':errors,'gates':gates,'gates_pass':len(gates)==48 and all(g['runtime_ok'] and g['creation_ok'] for g in gates),'source_unchanged':True,'compiled_source_count':len(compiled.get('sources',{})),'settings_unchanged':True,'compiler_output_sha256':hashlib.sha256((O/'compiler-output.json').read_bytes()).hexdigest()}
(O/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n')
bound={**result,'all_pass':result['gates_pass'] and code==0 and not errors,'settings':j['settings'],'source_sha256':{n:h for n,h in pins.items() if n.startswith('src/')},'dependency_source_sha256':{n:h for n,h in pins.items() if not n.startswith('src/')},'compiler_input_sha256':hashlib.sha256(payload).hexdigest(),'compiler_output_sha256':result['compiler_output_sha256'],'compiler_content_sha256':{n:hashlib.sha256(r['content'].encode()).hexdigest() for n,r in j['sources'].items()},'build_input_sha256':json.loads((base/'production-size-gates.json').read_bytes())['build_input_sha256'],'solc_exit_code':code,'solc_executable_sha256':start['compiler_sha256'],'solc_executable_unchanged':True,'source_count':100,'compiled_source_count':len(compiled.get('sources',{})),'closed_input_inventory':True,'unchanged_before_build':True,'unchanged_during_build':True,'unexpected_implicit_sources':[],'missing_compiled_sources':[],'normal_limits':{'runtime_bytes':24576,'initcode_with_original_minimum_arguments_bytes':49152}}
(O/'normal-size-evidence.json').write_text(json.dumps(bound,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='gates'}));print(json.dumps({'changed_object_gates':[g for g in gates if g['path'] in expected or g['name'] in ('ZZZOracle','ZZZVault','ZZZCanonicalHandoff')]}))
raise SystemExit(0 if bound['all_pass'] else 1)
