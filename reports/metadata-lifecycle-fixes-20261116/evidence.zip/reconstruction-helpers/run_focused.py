from pathlib import Path
import hashlib,json,os,re,subprocess,sys,time
E=Path(__file__).resolve().parent;V=E.parent;P=E/sys.argv[1];O=E/sys.argv[2];O.mkdir(exist_ok=False)
record=json.loads((P/'PREPARED.json').read_bytes());before={n:hashlib.sha256((P/n).read_bytes()).hexdigest() for n in record['source_sha256']};assert before==record['source_sha256']
names=[r['method'] for r in record['new_methods']]+[record['adapted_method']['method']]
assert len(names)==31 and len(set(names))==31
contracts=['MetadataLifecycleSnapshotsTest','MetadataLifecycleControllerNotificationsTest','MetadataLifecycleExitNotificationsTest','MetadataRendererCompatibilityTest','NFTMetadataTest']
cmd=[str(V/'foundry-v1.4.4/forge.exe'),'test','--root',str(P),'--use',str(V/'toolchain-0.8.26/solc.exe'),'--match-contract','^('+'|'.join(contracts)+')$','--match-test','^('+'|'.join(map(re.escape,names))+r')(?:\(\))?$','--json','-vvv']
env={n:os.environ[n] for n in ('SystemRoot','WINDIR','SystemDrive','COMSPEC','PATHEXT','TEMP','TMP','USERPROFILE','LOCALAPPDATA','APPDATA','PROGRAMDATA') if n in os.environ}
env.update(RAYON_NUM_THREADS='2',FOUNDRY_OFFLINE='true',PATH=str(V/'foundry-v1.4.4')+os.pathsep+str(V/'toolchain-0.8.26')+os.pathsep+'C:/Windows/System32')
(O/'START.json').write_text(json.dumps({'command':cmd,'new_selected':30,'adapted_selected':1,'unchanged_methods_selected':0,'source_sha256':before,'credentials_inherited':False,'existing_node_contacted':False},indent=2)+'\n');t=time.monotonic()
with (O/'forge.json').open('xb') as out,(O/'stderr.log').open('xb') as err:
    p=subprocess.Popen(cmd,cwd=P,env=env,stdout=out,stderr=err,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0));(O/'PID.json').write_text(json.dumps({'owned_pid':p.pid}))
    try:code=p.wait(timeout=900)
    except subprocess.TimeoutExpired:p.kill();p.wait(timeout=10);raise
assert before=={n:hashlib.sha256((P/n).read_bytes()).hexdigest() for n in before}
raw=(O/'forge.json').read_bytes()
try:data=json.loads(raw)
except json.JSONDecodeError:data={}
rows=[{'suite':suite,'method':name,'status':v['status'],'reason':v.get('reason'),'gas':v.get('gas')} for suite,obj in data.items() if isinstance(obj,dict) for name,v in obj.get('test_results',{}).items()]
assert all(r['method'].split('(')[0] in names for r in rows),'Unexpected test executed'
result={'exit_code':code,'seconds':time.monotonic()-t,'source_unchanged':True,'selected_count':len(names),'executed_methods':rows,'passes':sum(r['status']=='Success' for r in rows),'unchanged_methods_executed':0,'new_methods_selected':30,'adapted_methods_selected':1}
(O/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result));raise SystemExit(0 if code==0 and len(rows)==31 and result['passes']==31 else 1)
