from pathlib import Path
import gzip,hashlib,json,shutil,zipfile
E=Path(__file__).parent;V=E.parent;S=V/'metadata-lifecycle-20261116/services';R=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2');P=R/'reports/metadata-lifecycle-fixes-20261116';P.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def cp(a,b):
 b.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(a,b)
def gz(a,b):
 b.parent.mkdir(parents=True,exist_ok=True)
 with a.open('rb') as src,b.open('wb') as dst:
  with gzip.GzipFile(filename='',mode='wb',fileobj=dst,mtime=0) as z:shutil.copyfileobj(src,z)
for n in ('compiler-input.json','compiler-output.json'):gz(E/'normal-6'/n,P/'build'/(n+'.gz'))
for n in ('START.json','RESULT.json','normal-size-evidence.json'):cp(E/'normal-6'/n,P/'build'/n)
entries={}
def add(path,name):
 assert path.is_file();raw=path.read_bytes();assert name not in entries;entries[name]=raw
for i in range(1,7):
 q=E/f'normal-{i}'
 for n in ('START.json','RESULT.json','stderr.log'):
  if(q/n).is_file():add(q/n,f'normal-{i}/{n}')
 if(q/'compiler-input.json').is_file():add(q/'compiler-input.json',f'normal-{i}/compiler-input.json')
for name in ('BASELINE.json','FUNCTION_REFERENCE_REVIEW.json','NEW_FUNCTION_NOTES.json','WEBSITE_APPLIED.json','WEBSITE_DOCS.json','WEBSITE_PUBLICATION.json','MECHANICAL_REVIEW.json','EVM_SCOPE_SUMMARY.json','FINAL_TEST_SOURCES.json'):
 if(E/name).is_file():add(E/name,name)
for folder in [E/'browser-1',E/'evm-1',*sorted(E.glob('split-*-*'))]:
 for file in folder.glob('*'):
  if file.is_file() and file.suffix in ('.json','.log','.tap'):add(file,folder.name+'/'+file.name)
for file in S.iterdir():
 if file.is_file() and file.suffix in ('.py','.json','.log','.mjs','.js'):add(file,'keeper-browser-stages/'+file.name)
for name in ('ASSESSMENT1.json','ASSESSMENT2.json','ASSESSMENT3.json','DIFF_SUMMARY.json','MERGE_RESULT.json','CLI_CHECK_RESULT.json','build-review.py','compare.py'):
 q=E/'static'/name
 if q.is_file():add(q,'static/'+name)
for file in (E/'static/static-40704496e9').glob('*'):
 if file.is_file() and file.name in ('START.json','EXECUTION.json','slither.log'):add(file,'static/'+file.name)
# Closed source copies support independent reconstruction; no node/key/env state.
for root in (E/'baseline-head',E/'focused-3',*sorted(E.glob('split-*-*/snapshot'))):
 if root.is_dir():
  for file in root.rglob('*'):
   rel=file.relative_to(root)
   if file.is_file() and (file.suffix=='.sol' or rel.as_posix()=='test/helpers/HistoricalMetadata20261115.json') and 'out' not in rel.parts and 'cache' not in rel.parts:add(file,'source-stages/'+root.parent.name+'/'+root.name+'/'+rel.as_posix())
for name in ('baseline.py','normal_compile.py','prepare_focused.py','PREPARE_IMPORT_INITIAL.py','run_focused.py','run_browser.py','run_split_evm.py','prepare-historical-metadata-fixture.py','update_reference.py','rebind_examples.py','package_evidence.py'):
 if(E/name).is_file():add(E/name,'reconstruction-helpers/'+name)
manifest={'schema':1,'files':{k:{'sha256':hashlib.sha256(v).hexdigest(),'bytes':len(v)} for k,v in sorted(entries.items())},'external_raw_directory':str(E),'source_baseline':'dd242634b7dc4d3ead6d66f8a42c857da587cf15','runtime_or_external_acceptance':False}
raw=(json.dumps(manifest,indent=2)+'\n').encode();entries['MANIFEST.json']=raw
with zipfile.ZipFile(P/'evidence.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for name,data in sorted(entries.items()):
  info=zipfile.ZipInfo(name,(2026,11,16,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;z.writestr(info,data)
cp(E/'FUNCTION_REFERENCE_REVIEW.json',P/'FUNCTION_REFERENCE_REVIEW.json')
for name in ('MECHANICAL_REVIEW.json','EVM_SCOPE_SUMMARY.json','FINAL_TEST_SOURCES.json','WEBSITE_PUBLICATION.json'):
 if(E/name).is_file():cp(E/name,P/name)
(P/'EVIDENCE_MANIFEST.json').write_bytes(raw)
result={'schema':1,'evidence_zip_sha256':sha(P/'evidence.zip'),'evidence_zip_bytes':(P/'evidence.zip').stat().st_size,'manifest_sha256':hashlib.sha256(raw).hexdigest(),'members':len(entries),'normal_compiler_output_sha256':sha(E/'normal-6/compiler-output.json')}
(P/'BUNDLE.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
