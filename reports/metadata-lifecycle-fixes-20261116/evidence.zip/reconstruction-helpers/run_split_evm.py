"""Owned isolated new-test groups; exact source pins/compiler/profile, no RPC."""
from pathlib import Path,PurePosixPath
import hashlib,json,os,posixpath,re,shutil,subprocess,sys,time
R=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
E=Path(__file__).resolve().parent;V=E.parent
GROUPS={
 'snapshots':('test/MetadataLifecycleSnapshots.t.sol',['MetadataLifecycleSnapshotsTest'],'test'),
 'notifications':('test/MetadataLifecycleNotifications.t.sol',['MetadataLifecycleControllerNotificationsTest','MetadataLifecycleExitNotificationsTest'],'testMetadataLifecycle'),
 'notification-exit':('test/MetadataLifecycleNotifications.t.sol',['MetadataLifecycleExitNotificationsTest'],'testMetadataLifecycle'),
 'compatibility':('test/MetadataRendererCompatibility.t.sol',['MetadataRendererCompatibilityTest'],'testMetadataRenderCompatibility'),
 'adapted':('test/NFTMetadata.t.sol',['NFTMetadataTest'],'testStaleOracleDoesNotBreakURIOrRoyaltyClaimsOrFabricateDormantState'),
}
group=sys.argv[1];stage=sys.argv[2];root,contracts,prefix=GROUPS[group]
O=E/stage;O.mkdir(exist_ok=False);P=O/'snapshot';P.mkdir()
remaps={'@openzeppelin/contracts/':'node_modules/@openzeppelin/contracts/','@uniswap/v4-core/':'node_modules/@uniswap/v4-core/','@uniswap/v4-periphery/':'node_modules/@uniswap/v4-periphery/','v4-core/':'node_modules/@uniswap/v4-core/','permit2/':'node_modules/@uniswap/v4-periphery/lib/permit2/','solmate/':'node_modules/@uniswap/v4-core/lib/solmate/','forge-std/':'lib/forge-std/src/'}
def resolve(source,name):
 if name.startswith('.'):return posixpath.normpath(str(PurePosixPath(source).parent/name))
 for key,value in remaps.items():
  if name.startswith(key):return value+name[len(key):]
 return name
todo=[root];pins={}
while todo:
 name=todo.pop()
 if name in pins:continue
 p=(R/name).resolve();assert p.is_relative_to(R)and p.is_file(),name
 raw=p.read_bytes();pins[name]=hashlib.sha256(raw).hexdigest()
 pattern=r'(?m)^\s*import\s+(?:(?:\{[^}]*\}|\*\s+as\s+\w+|\w+)\s+from\s+)?["\']([^"\']+)["\']\s*;'
 for imp in re.findall(pattern,raw.decode('utf-8')):todo.append(resolve(name,imp))
for name,digest in pins.items():
 target=P/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/name,target)
 assert hashlib.sha256(target.read_bytes()).hexdigest()==digest
(P/'empty').mkdir()
config='[profile.default]\nsrc="empty"\ntest="test"\nout="out"\ncache_path="cache"\nevm_version="cancun"\noptimizer=true\noptimizer_runs=1\noptimizer_details={yul=false}\nvia_ir=true\nffi=false\nremappings=[\n'+''.join(json.dumps(k+'='+v)+',\n'for k,v in remaps.items())+']\n'
(P/'foundry.toml').write_text(config)
method_source=(R/root).read_text()
if group=='notification-exit':method_source=method_source.split('contract MetadataLifecycleExitNotificationsTest is HolderCollectiveExitTest {',1)[1]
methods=[n for n in re.findall(r'function\s+(test\w+)\s*\(', method_source)if n.startswith(prefix)]
assert methods and len(methods)==len(set(methods))
forge=V/'foundry-v1.4.4/forge.exe';solc=V/'toolchain-0.8.26/solc.exe'
cmd=[str(forge),'test','--root',str(P),'--use',str(solc),'--match-contract','^('+'|'.join(contracts)+')$','--match-test','^('+'|'.join(map(re.escape,methods))+r')(?:\(\))?$','--json','-vvv']
keep=('SystemRoot','WINDIR','SystemDrive','COMSPEC','PATHEXT','TEMP','TMP','USERPROFILE','LOCALAPPDATA','APPDATA','PROGRAMDATA')
env={n:os.environ[n]for n in keep if n in os.environ}
env.update(RAYON_NUM_THREADS='2',FOUNDRY_OFFLINE='true',PATH=str(forge.parent)+os.pathsep+str(solc.parent)+os.pathsep+'C:/Windows/System32')
start={'group':group,'command':cmd,'selected_methods':methods,'source_sha256':pins,'compiler_sha256':hashlib.sha256(solc.read_bytes()).hexdigest(),'normal_profile':config,'credentials_inherited':False,'network_calls':0,'existing_node_contacted':False,'inherited_old_methods_selected':0}
(O/'START.json').write_text(json.dumps(start,indent=2)+'\n');print(json.dumps({'started_group':group,'selected_count':len(methods),'closed_sources':len(pins)}),flush=True)
t=time.monotonic()
with (O/'forge.json').open('xb')as out,(O/'stderr.log').open('xb')as err:
 p=subprocess.Popen(cmd,cwd=P,env=env,stdout=out,stderr=err,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
 (O/'PID.json').write_text(json.dumps({'owned_pid':p.pid}))
 try:code=p.wait(timeout=900)
 except subprocess.TimeoutExpired:p.kill();p.wait(timeout=10);raise
assert pins=={n:hashlib.sha256((P/n).read_bytes()).hexdigest()for n in pins}
assert hashlib.sha256(solc.read_bytes()).hexdigest()==start['compiler_sha256']
try:data=json.loads((O/'forge.json').read_bytes())
except json.JSONDecodeError:data={}
reported=[{'suite':suite,'method':name,'status':value['status'],'reason':value.get('reason'),'gas':value.get('kind',{}).get('Unit',{}).get('gas')}for suite,obj in data.items()if isinstance(obj,dict)for name,value in obj.get('test_results',{}).items()]
rows=[row for row in reported if row['method'].split('(')[0]in methods]
diagnostics=[row for row in reported if row not in rows]
assert all(row['method']=='setUp()'or row['method'].startswith('Found ')for row in diagnostics),'Unexpected test method executed'
result={'group':group,'exit_code':code,'seconds':time.monotonic()-t,'selected_count':len(methods),'executed_methods':rows,'passes':sum(r['status']=='Success'for r in rows),'discovery_or_fixture_errors':diagnostics,'source_unchanged':True,'unchanged_methods_executed':0}
(O/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
raise SystemExit(0 if code==0 and len(rows)==len(methods)and result['passes']==len(methods)else 1)
