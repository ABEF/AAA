"""Extract accepted historical creation bytes for NEW differential tests only."""
from pathlib import Path
import gzip,hashlib,json
R=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
original=R/'reports/manual-reference-swap-fix-20261115/build/compiler-output.json.gz'
packed=original.read_bytes();raw=gzip.decompress(packed);output=json.loads(raw)
contract=output['contracts']['src/ZZZNFTMetadata.sol']['ZZZNFTMetadata']
creation=bytes.fromhex(contract['evm']['bytecode']['object'])
runtime=bytes.fromhex(contract['evm']['deployedBytecode']['object'])
sha=lambda v:hashlib.sha256(v).hexdigest()
record={'source':'reports/manual-reference-swap-fix-20261115/build/compiler-output.json.gz',
    'compressed_output_sha256':sha(packed),'original_output_sha256':sha(raw),
    'creation_sha256':sha(creation),'creation_bytes':len(creation),'runtime_bytes':len(runtime),
    'purpose':'Test-only accepted-baseline oracle for new pure-render differential cases; never a deployed profile.'}
record['bytecode']={'object':'0x'+creation.hex()}
text='''// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

/// @dev TEST ONLY accepted baseline renderer, extracted without rebuilding it.
/// Source: reports/manual-reference-swap-fix-20261115/build/compiler-output.json.gz
/// Original gzip SHA256: %s
/// Original decoded output SHA256: %s
/// Creation SHA256: %s
/// Existing19499-byte runtime is a differential oracle, never a fresh profile.
library HistoricalMetadata20261115 {
    bytes32 internal constant CREATION_SHA256=hex"%s";
    // Public test-only chunk libraries keep large constant code-generation
    // graphs bounded on the supported native compiler. No filesystem
    // cheatcode permission or manually staged build artifact is required.
    function deploy(address controller)public returns(address renderer){
        bytes memory creation=bytes.concat(HistoricalMetadataChunk0.code(),HistoricalMetadataChunk1.code(),
            HistoricalMetadataChunk2.code(),HistoricalMetadataChunk3.code());
        require(sha256(creation)==CREATION_SHA256,"historical creation pin changed");
        bytes memory init=abi.encodePacked(creation,abi.encode(controller));
        assembly("memory-safe"){renderer:=create(0,add(init,32),mload(init))}
        require(renderer.code.length==%d,"historical renderer deployment failed");
    }
}
'''%(sha(packed),sha(raw),sha(creation),sha(creation),len(runtime))
chunk_size=(len(creation)+3)//4
for i in range(4):
 chunk=creation[i*chunk_size:(i+1)*chunk_size]
 text+='\n/// @dev TEST ONLY immutable historical creation fragment; never a release module.\n'
 text+='library HistoricalMetadataChunk%d {function code()external pure returns(bytes memory){return hex"%s";}}\n'%(i,chunk.hex())
(R/'test/helpers/HistoricalMetadata20261115.sol').write_text(text,encoding='utf-8',newline='\n')
(Path(__file__).resolve().parent/'HISTORICAL_ORACLE_PROVENANCE.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8',newline='\n')
print(json.dumps({key:value for key,value in record.items()if key!='bytecode'}))
