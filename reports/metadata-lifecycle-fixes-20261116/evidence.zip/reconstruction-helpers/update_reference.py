from pathlib import Path
import json,hashlib,sys
R=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2');E=Path(__file__).parent
def write(p,j):
    raw=p.read_bytes();p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\r\n' if b'\r\n' in raw else '\n')
p=R/'docs/function-reference-notes.json';j=json.loads(p.read_bytes());c=j['contracts']
new={
'ZZZNFTMetadata':{
 'METADATA_LIFECYCLE_VERSION()':{'purpose':'Identify explicit metadata schema2 lifecycle context; this is not a new accounting or canonical transport profile.','access':'Anyone; read-only.','outputs':{'0':'Exactly 2 for this renderer.'}},
 'metadataLifecycleFingerprint(uint256)':{'purpose':'Read a price-free change fingerprint for lifecycle, principal allocation/payment and successor identity. Excludes numeric NAV, owner and snapshot time; does not authorize any operation.','access':'Anyone; requires an existing NFT and correctly bound fixed lifecycle companion.','inputs':{'0':'Exact minted uint256 NFT ID, not mint ordinal.'},'outputs':{'0':'Opaque keccak256 of schema2 packed flags, historically assigned ETH/ZZZ and successor addresses. Never use as reviewHash, consent or proof of payment to an address.'}}},
'ZZZNFTCanonical':{
 'metadataLifecycleState(uint256)':{'purpose':'Read existing lifecycle and principal books through the immutable NFT state companion without prices or state writes. Does not change canonical export/import records.','access':'Anyone; requires existing owner, current NFT/controller binding and coherent lifecycle books.','inputs':{'0':'Exact minted uint256 NFT ID.'},'outputs':{'0':'Flags: version bits0-7; canonical8-15; exit phase16-23; position24-31; preparation32; exit started33; shares34; allocated35; paid36. Reserved bits37+ zero.','1':'Historically assigned ETH wei, retained after payment; zero before allocation is not final entitlement.','2':'Historically assigned fixed-ZZZ raw units, retained after payment; not remaining principal.','3':'Verified replacement controller only for retired predecessor; otherwise zero.','4':'Verified replacement NFT only for retired predecessor; otherwise zero.'}},
 'metadataLifecycleContext(uint256)':{'purpose':'Read the same single lifecycle snapshot with schema2 JSON fields and a human label. No custody, entitlement or accounting mutation.','access':'Anyone; same fixed bindings and coherence checks as metadataLifecycleState.','inputs':{'0':'Exact minted uint256 NFT ID.'},'outputs':{'0':'Comma-prefixed JSON field fragment, not standalone JSON. Snapshot block/time identify this read, not price freshness.','1':'Lifecycle label; LP exited remains distinct from Dormant and does not erase royalty rights.','2':'Same schema2 packed flags as metadataLifecycleState.','3':'Historical assigned ETH wei; not unpaid balance.','4':'Historical assigned ZZZ units; not unpaid balance.'}}}}
for name,functions in new.items():
    assert not set(functions)&set(c[name]['functions']);c[name]['functions'].update(functions)
c['ZZZNFT']['functions']['policyMetadataChanged()']['purpose']='Emit one collection-wide ERC-4906 refresh after a committed cosmetic, exit or canonical lifecycle change; performs no NAV read or economic write.'
c['ZZZNFT']['functions']['policyMetadataChanged()']['access']='Only the bound ProtocolPolicy, Access controller or fixed Migration module. Not a governance EOA call; permissionless refreshMetadata/refreshMetadataRange remain separate.'
c['ZZZNFTMetadata']['functions']['tokenMetadata(uint256)']['purpose']='Render confirmed dynamic JSON and four-path artwork with explicit schema2 lifecycle, successor and principal allocation/payment status. LP exited uses Activated art and keeps royalty rights; unavailable NAV is labelled fallback, never fabricated zero. Snapshot time is not source freshness.'
write(p,j)
p=R/'docs/operator-call-examples.json';x=json.loads(p.read_bytes())
for name,fs in new.items():
    for sig in fs:
        k=name+'.'+sig;assert k not in x['rows']
        x['rows'][k]={'role':'R','short':{'METADATA_LIFECYCLE_VERSION()':'Read metadata capability','metadataLifecycleFingerprint(uint256)':'Read lifecycle change hash','metadataLifecycleState(uint256)':'Read lifecycle settlement flags','metadataLifecycleContext(uint256)':'Read lifecycle JSON fragment'}[sig],'arguments':[] if sig.endswith('()') else ['$ACTUAL_NFT_ID'],'value':None}
write(p,x)
(E/'NEW_FUNCTION_NOTES.json').write_text(json.dumps(new,indent=2)+'\n')
print(json.dumps({'new_read_notes':4,'new_read_examples':4,'existing_hook_authority_corrected':True}))
