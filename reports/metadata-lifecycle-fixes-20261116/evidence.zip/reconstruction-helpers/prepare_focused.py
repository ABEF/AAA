from pathlib import Path,PurePosixPath
import hashlib,json,posixpath,re,shutil,sys
R=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2');E=Path(__file__).resolve().parent;V=E.parent;P=E/sys.argv[1]
OLD=V/'manual-reference-swap-fix-20261115-da24f65/focused-fixed'
remaps={'@openzeppelin/contracts/':'node_modules/@openzeppelin/contracts/','@uniswap/v4-core/':'node_modules/@uniswap/v4-core/','@uniswap/v4-periphery/':'node_modules/@uniswap/v4-periphery/','v4-core/':'node_modules/@uniswap/v4-core/','permit2/':'node_modules/@uniswap/v4-periphery/lib/permit2/','solmate/':'node_modules/@uniswap/v4-core/lib/solmate/','forge-std/':'lib/forge-std/src/'}
def resolve(source,name):
    if name.startswith('.'):return posixpath.normpath(str(PurePosixPath(source).parent/name))
    for prefix,target in remaps.items():
        if name.startswith(prefix):return target+name[len(prefix):]
    return name
roots=['test/MetadataLifecycleSnapshots.t.sol','test/MetadataLifecycleNotifications.t.sol','test/MetadataRendererCompatibility.t.sol'];todo=roots+['test/NFTMetadata.t.sol'];pins={}
while todo:
    name=todo.pop()
    if name in pins:continue
    p=(R/name).resolve();assert p.is_relative_to(R) and p.is_file(),name
    raw=p.read_bytes();pins[name]=hashlib.sha256(raw).hexdigest()
    # Match an actual import declaration, not the word "import" in metadata text.
    pattern=r'(?m)^\s*import\s+(?:(?:\{[^}]*\}|\*\s+as\s+\w+|\w+)\s+from\s+)?["\']([^"\']+)["\']\s*;'
    for imp in re.findall(pattern,raw.decode('utf-8')):todo.append(resolve(name,imp))
P.mkdir(exist_ok=False)
for name,h in pins.items():
    p=P/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/name,p)
    assert hashlib.sha256(p.read_bytes()).hexdigest()==h
for name in ('out','cache'):
    if (OLD/name).is_dir():shutil.copytree(OLD/name,P/name)
(P/'empty').mkdir()
config='[profile.default]\nsrc="empty"\ntest="test"\nout="out"\ncache_path="cache"\nevm_version="cancun"\noptimizer=true\noptimizer_runs=1\noptimizer_details={yul=false}\nvia_ir=true\nffi=false\nremappings=[\n'+''.join(json.dumps(k+'='+v)+',\n' for k,v in remaps.items())+']\n'
(P/'foundry.toml').write_text(config)
methods=[]
for name in roots:
    for method in re.findall(r'function\s+(test\w+)\s*\(', (R/name).read_text()):methods.append({'path':name,'method':method})
assert len(methods)==30 and len({m['method'] for m in methods})==30
adapted={'path':'test/NFTMetadata.t.sol','contract':'NFTMetadataTest','method':'testStaleOracleDoesNotBreakURIOrRoyaltyClaimsOrFabricateDormantState'}
assert 'function '+adapted['method'] in (R/adapted['path']).read_text()
record={'roots':roots,'source_sha256':pins,'new_methods':methods,'adapted_method':adapted,'inherited_old_methods_must_be_excluded':True,'selection':'Exact whitelisted method-name regex; one explicitly adapted fixture method separate.','compiler':str(V/'toolchain-0.8.26/solc.exe'),'normal_settings_preserved':True,'old_node_calls':0}
(P/'PREPARED.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'closed_sources':len(pins),'new_methods':len(methods),'snapshot':str(P),'inherited_old_methods_selected':0}))
