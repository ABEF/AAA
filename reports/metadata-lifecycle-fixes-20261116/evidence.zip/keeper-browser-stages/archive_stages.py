from pathlib import Path
import hashlib,json
R=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2');E=Path(__file__).resolve().parent
sha=lambda data:hashlib.sha256(data).hexdigest()
final=(R/'keeper/monitor.py').read_bytes()
lines=final.splitlines(keepends=True)
i=next(i for i,line in enumerate(lines)if line.strip()==b"if ('metadata_lifecycle_version' in stored_identity and")
assert lines[i+3].strip()==b"raise ValueError('Malformed persistent metadata lifecycle version')"
current=b''.join(lines[:i]+lines[i+4:])
assert sha(current)=='c67e15550d81de0eeb6645242cdf10f8883174ef6156791baead5e29c4bc05ba'
lines=current.splitlines(keepends=True)
i=next(i for i,line in enumerate(lines)if line.strip()==b'if not isinstance(stored_identity,dict):')
assert lines[i+1].strip()==b"raise ValueError('Malformed persistent metadata identity')"
corrected=b''.join(lines[:i]+lines[i+2:])
assert sha(corrected)=='7244363a63b1cfd25bb42778a44a20012e7cd14baff61857f477cff442db1011'
initial=corrected.replace(b'expected_identity',b'identity')
assert sha(initial)=='c8198a970629d49c5528a93b0f9217ac30acf17209fbf8f335463895e6a0c9fa'
(E/'monitor-initial.py').write_bytes(initial);(E/'monitor-corrected.py').write_bytes(corrected)
(E/'monitor-current.py').write_bytes(current);(E/'monitor-final.py').write_bytes(final)
tests=(R/'tests_python/test_keeper_metadata_lifecycle.py').read_bytes();lines=tests.splitlines(keepends=True)
i=next(i for i,line in enumerate(lines)if line.strip().startswith(b'def test_corrupt_disabled_identity_'))
j=next(i for i,line in enumerate(lines)if line.startswith(b"if __name__"))
prior=b''.join(lines[:i]+lines[j:])
# Preserve the original two separating blank lines after removing the added method.
for candidate in (prior,b''.join(lines[:i]+[b'\n']+lines[j:]),b''.join(lines[:i-1]+lines[j:])):
    if sha(candidate)=='f5f85dbe5262453a715952c055f124d48852b20ed1d0e65547fc828723325f29':
        prior=candidate;break
else:raise ValueError('Original test-source reconstruction did not match recorded hash')
(E/'tests-initial.py').write_bytes(prior);(E/'tests-current.py').write_bytes(tests)
i=next(i for i,line in enumerate(lines)if line.strip().startswith(b'def test_stored_lifecycle_version_'))
prior=b''.join(lines[:i]+lines[j:])
for candidate in (prior,b''.join(lines[:i]+[b'\n']+lines[j:]),b''.join(lines[:i-1]+lines[j:])):
    if sha(candidate)=='63d36978fb50158fd57d0561bc3c3b6f8e31e44162eeae4d06850bebd6f52646':
        prior=candidate;break
else:raise ValueError('Typed-identity test stage hash mismatch')
(E/'tests-typed-identity.py').write_bytes(prior)
files=['monitor-before.py','monitor-initial.py','monitor-corrected.py','monitor-current.py','monitor-final.py','tests-initial.py','tests-typed-identity.py','tests-current.py']
(E/'SOURCE_STAGES.json').write_text(json.dumps({name:sha((E/name).read_bytes())for name in files},indent=2)+'\n')
print(json.dumps({name:sha((E/name).read_bytes())for name in files}))
