from pathlib import Path
import difflib, hashlib, json
W=Path('C:/Users/Ali/Desktop/2.x holas/Oto/aaa-website')
E=Path(__file__).resolve().parent
p=W/'deployment-view.js';raw=p.read_bytes();text=raw.decode('utf-8');nl='\r\n'if'\r\n'in text else'\n'
old="export const positionArtwork=n=>n.traits_ready&&n.position.evolution_value_available?findArtwork(`${COLORWAYS[n.traits.palette]?.id}-${PATTERNS[n.traits.pattern]?.id}-${n.traits.rarity.toLowerCase()}-${n.position.evolution==='lp_exited'?'activated':n.position.evolution}`):null;"
new="""export const positionArtwork=n=>n.ui_artwork_pending_unconfirmed!==true&&n.traits_ready===true&&(n.position.evolution_value_available===true||n.position.activated===true)?findArtwork(`${COLORWAYS[n.traits.palette]?.id}-${PATTERNS[n.traits.pattern]?.id}-${n.traits.rarity.toLowerCase()}-${n.position.evolution_value_available!==true||n.position.evolution==='lp_exited'?'activated':n.position.evolution}`):null;
export function positionEvolutionLabel(n){
  if(n.ui_artwork_pending_unconfirmed===true)return 'Awaiting confirmed LP execution';
  const p=n.position;
  if(p.activated===false&&n.lifecycle?.lp_exit_started===true)return 'Dormant · activation closed';
  if(p.evolution_value_available!==true)return p.activated===true?'Valuation unavailable · Activated fallback':'Valuation unavailable';
  if(p.evolution!=='lp_exited')return p.evolution;
  const r=n.principal_return;
  if(r?.available!==true||!Number.isSafeInteger(r.phase_code)||r.phase!==['operating','closing','allocating','ready'][r.phase_code]||
    typeof r.allocated!=='boolean'||typeof r.paid!=='boolean')return 'LP exited';
  if([1,2].includes(r.phase_code)&&r.allocated===false&&r.paid===false)return 'LP exited · allocation pending';
  if(![2,3].includes(r.phase_code)||r.allocated!==true||!Array.isArray(r.assets)||r.assets.length!==2||
    !r.assets.every(a=>['allocated_raw','remaining_raw'].every(k=>typeof a?.[k]==='string'&&/^(0|[1-9][0-9]*)$/.test(a[k]))))return 'LP exited';
  if(r.phase_code===3&&r.paid===true&&r.assets.every(a=>a.remaining_raw==='0'))return r.assets.every(a=>a.allocated_raw==='0')?'LP exited · no principal to return':'LP exited · principal paid';
  if(r.paid===false&&r.assets.every(a=>a.remaining_raw===a.allocated_raw))return r.assets.every(a=>a.allocated_raw==='0')?'LP exited · no principal to return':r.phase_code===2?'LP exited · distribution not ready':'LP exited · payout pending';
  return 'LP exited';
}
// This marker is local presentation state. It is never an RPC/accounting field.
export function holdPendingArtwork(nfts,pending,previousNfts=[]){
  const target=pending?.context?.intent?.id;
  if(typeof target!=='string'||!target||!['activate','increase'].includes(pending.context.action))return nfts;
  const previous=previousNfts.find(n=>n.token_id===target);
  return nfts.map(n=>n.token_id!==target?n:previous||{...n,ui_artwork_pending_unconfirmed:true,
    position:{...n.position,current_lp_value:{...n.position.current_lp_value,available:false,raw:null},evolution_value_available:false}});
}""".replace('\n',nl)
assert text.count(old)==1
newtext=text.replace(old,new,1)
label="n.position.evolution_value_available?n.position.evolution:'Unavailable'"
assert newtext.count(label)==2
newtext=newtext.replace(label,'positionEvolutionLabel(n)')
alt="art.colorLabel+' '+art.rarityLabel+' '+art.evolutionLabel"
assert newtext.count(alt)==1
newtext=newtext.replace(alt,"art.colorLabel+' '+art.rarityLabel+' '+positionEvolutionLabel(n)")
for heading in ('<h2>PoPL #${n.mint_ordinal}</h2>', '<h2 id="nft-details-title">PoPL #${n.mint_ordinal}</h2>'):
    assert newtext.count(heading)==1
    newtext=newtext.replace(heading,heading+'<p class="small-note">${e(positionEvolutionLabel(n))}</p>',1)
old_pending="""      const waiting=pending(),target=waiting?.context?.intent?.id;
      if(data&&target&&['activate','increase'].includes(waiting.context.action)){
        const previous=snapshot?.nfts.find(n=>n.token_id===target);
        data.nfts=data.nfts.map(n=>n.token_id!==target?n:previous||{...n,position:{...n.position,current_lp_value:{...n.position.current_lp_value,available:false,raw:null},evolution_value_available:false}});
      }""".replace('\n',nl)
assert newtext.count(old_pending)==1
newtext=newtext.replace(old_pending,"      if(data)data.nfts=holdPendingArtwork(data.nfts,pending(),snapshot?.nfts||[]);",1)
(E/'deployment-view.proposed.js').write_bytes(newtext.encode('utf-8'))
(E/'website-fallback.patch').write_text(''.join(difflib.unified_diff(text.splitlines(True),newtext.splitlines(True),fromfile='a/deployment-view.js',tofile='b/deployment-view.js')),encoding='utf-8',newline='')
(E/'WEBSITE_PATCH.json').write_text(json.dumps({'path':'deployment-view.js','before_sha256':hashlib.sha256(raw).hexdigest(),'proposed_sha256':hashlib.sha256(newtext.encode()).hexdigest(),'test_path':'tests/metadata-fallback.test.mjs','test_sha256':hashlib.sha256((E/'metadata-fallback.test.mjs').read_bytes()).hexdigest(),'new_browser_methods':13,'browser_tests_executed':0,'website_unchanged':p.read_bytes()==raw,'pending_receipt_gate_preserved':True,'signer_or_configuration_changes':False},indent=2)+'\n')
