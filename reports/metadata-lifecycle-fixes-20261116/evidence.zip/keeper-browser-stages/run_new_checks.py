from pathlib import Path
import hashlib, importlib, io, json, sys, unittest
R=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
E=Path(__file__).resolve().parent
sys.path.insert(0,str(R))
module=importlib.import_module('tests_python.test_keeper_metadata_lifecycle')
mode=sys.argv[1]
names=['test_lifecycle_and_payment_changes_notify_without_tier_change',
       'test_unknown_or_boolean_lifecycle_versions_reject_before_work'] if mode=='baseline' else [name for name in dir(module.KeeperMetadataLifecycleTests) if name.startswith('test_')]
if len(sys.argv)>2:names=sys.argv[2:]
suite=unittest.TestSuite(module.KeeperMetadataLifecycleTests(name)for name in names)
stream=io.StringIO(); result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
(E/(mode+'.log')).write_text(stream.getvalue(),encoding='utf-8')
data={'methods':names,'run':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'skips':len(result.skipped),'successful':result.wasSuccessful(),'source_sha256':{name:hashlib.sha256((R/name).read_bytes()).hexdigest() for name in ('keeper/monitor.py','tests_python/test_keeper_metadata_lifecycle.py')}}
(E/(mode+'.json')).write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps(data)); print(stream.getvalue())
raise SystemExit(0 if result.wasSuccessful()else 1)
