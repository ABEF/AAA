// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

import {Math} from "@openzeppelin/contracts/utils/math/Math.sol";
import {TickMath} from "@uniswap/v4-core/src/libraries/TickMath.sol";
import {SqrtPriceMath} from "@uniswap/v4-core/src/libraries/SqrtPriceMath.sol";
import {ZZZLPBalanceMath} from "./ZZZLPBalanceMath.sol";
import {ZZZModule} from "./base/ZZZModule.sol";
import {Ids, PoolKey, PoolConfig} from "./libraries/ZZZTypes.sol";
import {IZZZPools, IZZZStrategy, IZZZLiquidity, IStateViewMinimal, IPoolManagerMinimal} from "./interfaces/IZZZ.sol";
import {IZZZExecutionStrategy, MarketState} from "./interfaces/IZZZExecutionOracle.sol";

interface IQuoteLiquidity { function getLiquidity(bytes32) external view returns(uint128); }

/// @notice Bounded, typed ETH/ZZZ balancing. Quotes revert all core changes and
/// compare useful target LP value at one independent price vector, not raw L.
/// This is a bounded search of reviewed venues, not a global optimum promise.
contract ZZZLPBalancer is ZZZModule {
    uint256 public constant LP_ROUTING_VERSION = 3;
    uint256 public constant EXECUTION_PRICE_VERSION = 1;
    uint256 public constant EXECUTION_QUALITY_VERSION = 1;
    uint256 public constant MAX_ADDITIONAL_LOSS_BPS = 1000;
    uint256 public constant MAX_EXECUTION_POOLS = 4;
    ZZZLPBalanceMath public immutable balanceMath;
    IPoolManagerMinimal public immutable poolManager;
    IStateViewMinimal public immutable stateView;
    bytes32[] private venues;
    uint64 public executionRevision;
    uint8 public searchIterations = 8;
    uint32 public quoteGasLimit = 200000;
    bytes32 private pendingQuoteHash;

    struct Plan { bytes32 poolId; bool zeroForOne; uint256 amountIn; uint256 amountOut; uint256 minimumOut; uint160 sqrtAfter; uint160 targetSqrtAfter; uint64 revision; bytes32 fingerprint; MarketState afterState; }
    error QuoteResult(uint256 output, uint160 sqrtAfter, int24 tickAfter,uint24 protocolFee,uint24 lpFee,uint128 liquidity);
    event ExecutionPoolsConfigured(uint64 indexed revision, bytes32[] pools, bytes32 indexed reviewHash);
    event SolverConfigured(uint64 indexed revision, uint8 iterations, uint32 gasLimit, bytes32 indexed reviewHash);
    /// @dev This is a selected quote, not income. The manager verifies exact
    /// actual output/price; any failed outer operation rolls this log back.
    event BalancePlanned(bytes32 indexed targetPool, bytes32 indexed executionPool, bool zeroForOne,
        uint256 amountIn, uint256 expectedOutput, uint64 revision);

    constructor(address controller, address core, address state) ZZZModule(controller) {
        balanceMath = new ZZZLPBalanceMath();
        poolManager = IPoolManagerMinimal(core);
        stateView = IStateViewMinimal(state);
    }
    /// @notice The sealed controller fixes the sole parent. Standalone creation
    /// avoids embedding this router in Manager initcode; no mutable parent setter.
    function liquidityManager() public view returns(address) { return access.module(Ids.LIQUIDITY); }
    function executionPoolCount() external view returns (uint256) { return venues.length; }
    function executionPoolAt(uint256 index) external view returns (bytes32) { return venues[index]; }
    /// @notice Shared exact v4 math avoids embedding a second copy in Manager.
    /// Pure calculation, no custody or authorization; Manager verifies raw spends.
    function deploymentAmounts(uint160 current,int24 lower,int24 upper,uint256 amount0,uint256 amount1)
        external view returns(uint128 liquidity,uint256 nativeDebt) {
        return balanceMath.deploymentAmounts(current,lower,upper,amount0,amount1);
    }
    function principalAmounts(uint256 id) external view returns(uint256 amount0,uint256 amount1) {
        return balanceMath.principalAmounts(IZZZLiquidity(liquidityManager()).positionManager(),address(stateView),id);
    }
    /// @notice Policy belongs to the fixed Strategy; never a keeper input.
    function additionalLossBps() public view returns(uint16) {
        return IZZZStrategy(access.module(Ids.STRATEGY)).additionalLossBps();
    }
    /// @notice Captures target/venue controls, monotonic registry changes and
    /// both independently validated source rounds. Recheck after token callbacks.
    function policyFingerprint(bytes32 target, bytes32 venue) public view returns (bytes32) {
        return balanceMath.policyFingerprint(target,venue);
    }

    /// @notice Empty removes all swap venues without consulting prices or core.
    /// Pool admission remains separate; this grants no token/recipient authority.
    function configureExecutionPools(bytes32[] calldata pools, bytes32 reviewHash)
        external onlyGovernance operating principalOperating {
        if (pools.length > MAX_EXECUTION_POOLS || reviewHash == bytes32(0)) revert InvalidConfiguration();
        for (uint256 i; i < pools.length; ++i) {
            PoolConfig memory c = _pool(pools[i]);
            IZZZStrategy(access.module(Ids.STRATEGY)).validatePrice(pools[i]);
            (,,,uint24 fee) = stateView.getSlot0(pools[i]);
            if (fee != c.key.fee) revert InvalidConfiguration();
            for (uint256 j; j < i; ++j) if (pools[j] == pools[i]) revert InvalidConfiguration();
        }
        venues = pools;
        ++executionRevision;
        emit ExecutionPoolsConfigured(executionRevision, pools, reviewHash);
    }
    /// @notice Work limits are explicit and governed; no unbounded quote loop.
    function configureSolver(uint8 iterations, uint32 gasLimit, bytes32 reviewHash)
        external onlyGovernance operating principalOperating {
        if (iterations < 4 || iterations > 12 || gasLimit < 100000 || gasLimit > 300000 || reviewHash == bytes32(0))
            revert InvalidConfiguration();
        searchIterations = iterations; quoteGasLimit = gasLimit; ++executionRevision;
        emit SolverConfigured(executionRevision, iterations, gasLimit, reviewHash);
    }
    function _fee(PoolConfig memory c, bool direction, uint24 protocol, uint24 fee) private pure returns (uint256) {
        if (fee != c.key.fee || (protocol & 0xfff) > 1000 || protocol >> 12 > 1000) revert InvalidState();
        uint256 selected = direction ? protocol & 0xfff : protocol >> 12;
        return selected + fee - Math.mulDiv(selected,fee,1_000_000);
    }
    function _pool(bytes32 id) private view returns (PoolConfig memory c) {
        return _pool(id,true);
    }
    function _pool(bytes32 id,bool requireOperations) private view returns (PoolConfig memory c) {
        c = IZZZPools(access.module(Ids.POOLS)).accounting(id);
        if ((requireOperations && !c.operationsEnabled) || c.key.currency0 != address(0) || c.key.currency1 == address(0) ||
            c.key.hooks != address(0) || c.key.fee > 100000 || c.maxSlippageBps > 1000 ||
            keccak256(abi.encode(c.key)) != id) revert InvalidConfiguration();
    }
    function _prices(address token) private view returns (ZZZLPBalanceMath.Prices memory p) {
        return balanceMath.executionPrices(token);
    }
    function _validSpot(uint160 price, uint160 referencePrice, uint16 deviation) private pure returns (bool) {
        if (price < TickMath.MIN_SQRT_PRICE || price >= TickMath.MAX_SQRT_PRICE) return false;
        uint256 root = Math.mulDiv(price,1e18,referencePrice);
        uint256 ratio = Math.mulDiv(root,root,1e18);
        return (ratio > 1e18 ? ratio-1e18 : 1e18-ratio) <= uint256(deviation)*1e14;
    }
    function _evaluate(ZZZLPBalanceMath.Context memory x,uint160 price,uint256 a0,uint256 a1)
        private view returns(ZZZLPBalanceMath.Evaluation memory) {
        return balanceMath.evaluate(x,price,a0,a1);
    }
    function _minimum(ZZZLPBalanceMath.Prices memory p, bool direction, uint256 amount, uint16 loss, uint256 fee) private view returns (uint256) {
        return balanceMath.minimumOutput(p,direction,amount,loss,fee);
    }
    /// @dev Fee-aware seed usually gives one quote for deep, small trades.
    function _seed(ZZZLPBalanceMath.Context memory x,bool direction,uint256 fee)
        private view returns(uint256 input,uint256 residual) {
        // routePlan passes a calldata copy. Seed a needed partial trade with
        // the same rounding headroom as its later qualification, without making
        // a naturally sufficient main require another swap.
        if(x.mainFloor<9999)++x.mainFloor;
        return balanceMath.seed(x,direction,fee);
    }
    function plan(bytes32 target,int24 lower,int24 upper,uint256 amount0,uint256 amount1)
        external returns(Plan memory) { uint256[4] memory marks; return _plan(target,lower,upper,amount0,amount1,10000,marks,false); }
    /// @notice Ordinary replacement requires an actually active main. Single
    /// mode uses10000; hybrid uses its captured minimum qualifying allocation.
    function planReplacement(bytes32 target,int24 lower,int24 upper,uint256 amount0,uint256 amount1,uint16 mainFloor,uint256[4] calldata marks)
        external returns(Plan memory) {
        if(mainFloor<6000 || mainFloor>10000)revert InvalidConfiguration();
        return _plan(target,lower,upper,amount0,amount1,mainFloor,marks,true);
    }
    function _activeTarget(ZZZLPBalanceMath.Context memory x) private view returns(bool) {
        (uint160 price,int24 tick,,)=stateView.getSlot0(x.target);
        return price==x.spot && _tickSide(x.lower,x.upper,tick)==0;
    }
    function _tickSide(uint160 lower,uint160 upper,int24 tick) private pure returns(int8) {
        uint160 atTick=TickMath.getSqrtPriceAtTick(tick);
        return atTick<lower?int8(-1):atTick>=upper?int8(1):int8(0);
    }
    function _plan(bytes32 target,int24 lower,int24 upper,uint256 amount0,uint256 amount1,uint16 mainFloor,uint256[4] memory marks,bool requireActive)
        private returns(Plan memory best) {
        if (msg.sender != liquidityManager() || access.module(Ids.LIQUIDITY) != msg.sender || !access.isSealed()) revert Unauthorized();
        if (amount0 > type(uint128).max || amount1 > type(uint128).max || lower >= upper) revert InvalidAmount();
        PoolConfig memory destination = _pool(target);
        ZZZLPBalanceMath.Context memory x = ZZZLPBalanceMath.Context(target,IZZZExecutionStrategy(address(balanceMath)).executionValidatePrice(target),
            TickMath.getSqrtPriceAtTick(lower),TickMath.getSqrtPriceAtTick(upper),amount0,amount1,_prices(destination.key.currency1),mainFloor,marks);
        ZZZLPBalanceMath.Evaluation memory baseline = _evaluate(x,x.spot,amount0,amount1);
        best.revision = executionRevision;
        best.targetSqrtAfter = x.spot;
        bytes32 original = policyFingerprint(target,bytes32(0));
        best.fingerprint = original;
        bool baselineActive=!requireActive || _activeTarget(x);
        uint256 bestValue = baselineActive?baseline.deployed:0;
        // A balanced budget needs no swap just to chase rounding dust.
        // A naturally sufficient main already satisfies the policy. The extra
        // 1bp sizing headroom is only for a needed trade, not a hidden reason
        // to swap an otherwise sufficient portfolio or require a live venue.
        if (baselineActive && (baseline.retained == 0 || baseline.deployed >= Math.mulDiv(baseline.retained,mainFloor==10000?9990:mainFloor,10000,Math.Rounding.Ceil))) {
            emit BalancePlanned(target,bytes32(0),false,0,0,best.revision);
            return best;
        }
        for (uint256 i; i < venues.length; ++i) {
            // An independently disabled venue must not freeze healthy candidates.
            try this.routePlan(x,venues[i],baseline.excess0,requireActive) returns (Plan memory candidate,uint256 deployed) {
                if (mainFloor==10000 ? deployed>bestValue : candidate.amountIn!=0 &&
                    (best.amountIn==0 || candidate.amountIn<best.amountIn ||
                        (candidate.amountIn==best.amountIn && candidate.amountOut>best.amountOut))) {
                    best=candidate;bestValue=deployed;
                }
            } catch {}
        }
        if (best.amountIn==0 && (mainFloor<10000 || !baselineActive)) revert Slippage();
        if (executionRevision != best.revision || policyFingerprint(target,bytes32(0)) != original) revert InvalidState();
        emit BalancePlanned(target,best.poolId,best.zeroForOne,best.amountIn,best.amountOut,best.revision);
    }
    function routePlan(ZZZLPBalanceMath.Context calldata x, bytes32 id, bool direction,bool requireActive) external returns (Plan memory best,uint256 bestValue) {
        if (msg.sender != address(this)) revert Unauthorized();
        PoolConfig memory c = _pool(id);
        PoolConfig memory target = _pool(x.target);
        if (c.key.currency1 != target.key.currency1) revert InvalidConfiguration();
        if(requireActive && id!=x.target && !_activeTarget(x))return(best,0);
        (uint160 beforePrice,,uint24 protocol,uint24 fee) = stateView.getSlot0(id);
        uint256 swapFee = _fee(c,direction,protocol,fee);
        if (!_validSpot(beforePrice,x.prices.referenceX96,c.maxSpotDeviationBps)) revert InvalidState();
        uint256 lo; uint256 hi = direction ? x.amount0 : x.amount1;
        if (hi > uint256(uint128(type(int128).max))) hi = uint256(uint128(type(int128).max));
        (uint256 input,uint256 initialResidual) = _seed(x,direction,swapFee);
        if (input == 0) return (best,0);
        if (input > hi) input = hi;
        best.revision = executionRevision;
        for (uint256 pass; pass < searchIterations && lo < hi; ++pass) {
            uint256 interpolated;
            bool quoted; uint256 output; MarketState memory state;
            try this.quoteCandidate{gas:quoteGasLimit}(c.key,direction,input) returns (uint256 out,MarketState memory result) {
                quoted = true; output = out; state=result;
            } catch {}
            if (!quoted) hi = input;
            else {
                uint160 afterPrice=state.sqrtPriceX96;
                int8 outside=requireActive && id==x.target?_tickSide(x.lower,x.upper,state.tick):int8(0);
                uint256 minimum = _minimum(x.prices,direction,input,
                    c.maxSlippageBps < target.maxSlippageBps ? c.maxSlippageBps : target.maxSlippageBps,swapFee);
                if (minimum == 0) lo = input+1;
                // Feasibility comes before the target-ratio bracket. Increasing
                // an already excessive trade cannot repair impact/spot limits.
                else if (output < minimum || !_validSpot(afterPrice,x.prices.referenceX96,c.maxSpotDeviationBps)) hi = input;
                else if(outside!=0) {
                    // Shrink an overshoot, but increase a trade which has not
                    // yet brought the destination into its required range.
                    if(direction ? outside<0 : outside>0)hi=input;
                    else lo=input+1;
                }
                else {
                    uint256 a0 = direction ? x.amount0-input : x.amount0+output;
                    uint256 a1 = direction ? x.amount1+output : x.amount1-input;
                    ZZZLPBalanceMath.Evaluation memory e = _evaluate(x,id == x.target ? afterPrice : x.spot,a0,a1);
                    // Keep one basis point of search headroom for rounded mint
                    // debts. A9999floor may be unavailable if full deployment
                    // cannot be represented; governance can choose a lower one.
                    bool meets=x.mainFloor<10000 && e.deployed>=Math.mulDiv(e.retained,x.mainFloor+1,10000,Math.Rounding.Ceil);
                    if(x.mainFloor<10000) {
                        if(meets) {
                            if(best.amountIn==0 || input<best.amountIn) {
                                bestValue=e.deployed;
                                best=Plan(id,direction,input,output,minimum,afterPrice,id==x.target?afterPrice:x.spot,
                                    executionRevision,policyFingerprint(x.target,id),state);
                            }
                            hi=input;
                        } else if(e.excess0==direction)lo=input+1;
                        else hi=input;
                    } else {
                        if(e.deployed>bestValue) {
                            bestValue=e.deployed;
                            best=Plan(id,direction,input,output,minimum,afterPrice,id==x.target?afterPrice:x.spot,
                                executionRevision,policyFingerprint(x.target,id),state);
                            if(e.deployed>=Math.mulDiv(e.retained,9990,10000))break;
                        }
                        if(e.excess0==direction)lo=input+1;
                        else hi=input;
                    }
                    // Safeguarded secant from the original zero-input residual:
                    // smooth v4 curves converge faster than midpoint-only
                    // search, without another real swap or an unbounded loop.
                    if (x.mainFloor==10000 && initialResidual != 0) {
                        if (e.excess0 == direction && e.imbalance < initialResidual) {
                            uint256 denominator = initialResidual-e.imbalance;
                            // Prove the quotient is bounded before mulDiv;
                            // a nearly flat residual must not overflow or jump
                            // outside the already established feasible bracket.
                            if (input < Math.mulDiv(hi,denominator,initialResidual))
                                interpolated = Math.mulDiv(input,initialResidual,denominator);
                        } else if (e.excess0 != direction && e.imbalance <= type(uint256).max-initialResidual) {
                            interpolated = Math.mulDiv(input,initialResidual,initialResidual+e.imbalance);
                        }
                    }
                }
            }
            if (lo >= hi) break;
            input = interpolated != 0 && interpolated >= lo && interpolated < hi ? interpolated : lo+(hi-lo)/2;
        }
    }
    /// @dev Only our bounded search may quote. No funds settle; the custom
    /// revert rolls back every tick, price, fee and transient core delta.
    function quoteCandidate(PoolKey calldata key, bool direction, uint256 amount) external returns (uint256 output,MarketState memory state) {
        if (msg.sender != address(this) || amount == 0 || amount > uint256(uint128(type(int128).max))) revert Unauthorized();
        bytes memory payload = abi.encode(key,direction,amount);
        pendingQuoteHash = keccak256(payload);
        try poolManager.unlock(payload) returns (bytes memory) { revert InvalidState(); }
        catch (bytes memory reason) {
            pendingQuoteHash = bytes32(0);
            bytes4 selector;
            if (reason.length == 196) assembly ("memory-safe") { selector := mload(add(reason,32)) }
            if (selector != QuoteResult.selector) revert InvalidState();
            bytes memory result=new bytes(192);
            assembly ("memory-safe") { mcopy(add(result,32),add(reason,36),192) }
            (output,state)=abi.decode(result,(uint256,MarketState));
            if (output == 0 || state.sqrtPriceX96<TickMath.MIN_SQRT_PRICE || state.sqrtPriceX96>=TickMath.MAX_SQRT_PRICE ||
                state.tick<TickMath.MIN_TICK || state.tick>=TickMath.MAX_TICK || state.lpFee!=key.fee ||
                (state.protocolFee & 0xfff)>1000 || state.protocolFee>>12>1000)revert InvalidState();
        }
    }
    /// @notice Fresh exact-input proof for a typed Manager swap. All structural
    /// admission stays; operations-enabled belongs to Manager's ordinary or
    /// explicit retained-bit8 path. Quoting settles nothing and reverts all core
    /// changes; it grants no permission to a keeper or arbitrary user.
    function quoteSwap(bytes32 poolId,bool direction,uint256 amount) external returns(uint256 output,MarketState memory state) {
        if(msg.sender!=liquidityManager() || !access.isSealed())revert Unauthorized();
        return this.quoteCandidate(_pool(poolId,false).key,direction,amount);
    }
    function unlockCallback(bytes calldata data) external returns (bytes memory) {
        if (msg.sender != address(poolManager) || pendingQuoteHash == bytes32(0) || keccak256(data) != pendingQuoteHash) revert Unauthorized();
        (PoolKey memory key,bool direction,uint256 amount) = abi.decode(data,(PoolKey,bool,uint256));
        int256 delta = poolManager.swap(key,IPoolManagerMinimal.SwapParams(direction,-int256(amount),
            direction ? TickMath.MIN_SQRT_PRICE+1 : TickMath.MAX_SQRT_PRICE-1),"");
        int128 d0 = int128(delta >> 128); int128 d1 = int128(uint128(uint256(delta)));
        int128 spent = direction ? d0 : d1; int128 received = direction ? d1 : d0;
        if (spent >= 0 || received <= 0 || uint256(-int256(spent)) != amount) revert Slippage();
        bytes32 poolId=keccak256(abi.encode(key));
        (uint160 afterPrice,int24 afterTick,uint24 protocol,uint24 fee) = stateView.getSlot0(poolId);
        revert QuoteResult(uint256(int256(received)),afterPrice,afterTick,protocol,fee,IQuoteLiquidity(address(stateView)).getLiquidity(poolId));
    }
}
