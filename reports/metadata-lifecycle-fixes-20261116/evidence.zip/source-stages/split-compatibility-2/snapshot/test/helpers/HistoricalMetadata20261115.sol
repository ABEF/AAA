// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;
import {Vm} from "forge-std/Vm.sol";

/// @dev TEST ONLY accepted baseline renderer, extracted without rebuilding it.
/// Source: reports/manual-reference-swap-fix-20261115/build/compiler-output.json.gz
/// Original gzip SHA256: d18a51c0f5d19c6abec3fbad7f50d9997c9e5b65c10ad80c7299c942234a19b4
/// Original decoded output SHA256: b659f79e113d05f0a4a110031e61711ce0dcb764023d8acc4774c49d2e1bf136
/// Creation SHA256: 592148d0f417749d4db02e0f741c27d501beb05bb1b68af3314f84ff242bc524
/// Existing19499-byte runtime is a differential oracle, never a fresh profile.
library HistoricalMetadata20261115 {
    bytes32 internal constant CREATION_SHA256=hex"592148d0f417749d4db02e0f741c27d501beb05bb1b68af3314f84ff242bc524";
    Vm private constant vm=Vm(address(uint160(uint256(keccak256("hevm cheat code")))));
    function deploy(address controller)internal returns(address renderer){
        bytes memory creation=vm.getCode("test/helpers/HistoricalMetadata20261115.json");
        require(sha256(creation)==CREATION_SHA256,"historical creation pin changed");
        bytes memory init=abi.encodePacked(creation,abi.encode(controller));
        assembly("memory-safe"){renderer:=create(0,add(init,32),mload(init))}
        require(renderer.code.length==19499,"historical renderer deployment failed");
    }
}
