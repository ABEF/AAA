// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;
import {ZZZContributionPricing} from "../src/ZZZContributionPricing.sol";
import {ZZZContributionPricingBaseline} from "../src/ZZZContributionPricingBaseline.sol";
import {PoolKey,PoolConfig,Position,PositionStatus,Ids} from "../src/libraries/ZZZTypes.sol";
import {IZZZProtocolPolicy} from "../src/interfaces/IZZZProtocolPolicy.sol";
interface Vm {struct Log {bytes32[] topics;bytes data;address emitter;}function getCode(string calldata)external returns(bytes memory);function recordLogs()external;function getRecordedLogs()external returns(Log[]memory);}
interface P {
 function beginEntryReviewed(uint256,bytes32,address,uint256,uint16,bytes32)external returns(uint256);
 function begin(uint256,uint256,uint256,uint256,uint32)external;
 function contributionNav(uint256)external returns(uint256,uint256);
 function finish(uint256,uint256,uint256,uint256,uint256,uint256,uint256,uint32)external returns(uint256,uint256);
 function endEntry()external;function active()external view returns(bool);function valueBucket(uint256,uint256,uint256)external view returns(uint256);function nav(uint256)external view returns(uint256,uint256);
}
contract Policy {
 function entryPolicy()external pure returns(IZZZProtocolPolicy.EntryPolicy memory){return IZZZProtocolPolicy.EntryPolicy(100e18,5e18,500,7);}
 function entryFingerprint()external view returns(bytes32){return keccak256(abi.encode(address(this),IZZZProtocolPolicy.EntryPolicy(100e18,5e18,500,7)));}
}
contract Access {address public protocolPolicy;mapping(bytes32=>address)public module;constructor(address p){protocolPolicy=p;}function bind(bytes32 id,address a)external{module[id]=a;}function isSealed()external pure returns(bool){return true;}function paused()external pure returns(bool){return false;}function preparationActive()external pure returns(bool){return false;}function canonicalState()external pure returns(uint8){return 0;}}
contract Pools {address public activationEntry;constructor(address e){activationEntry=e;}function accounting(bytes32)external pure returns(PoolConfig memory c){c.key=PoolKey(address(0),address(0x1234),3000,60,address(0));c.depositsEnabled=true;c.operationsEnabled=true;c.rangeBps=5000;c.maxSlippageBps=200;}}
contract Vault {address public migrationBudget;bytes32 constant POOL=keccak256("controlledpool");constructor(address b){migrationBudget=b;}function group(uint256)external pure returns(Position memory p){p.poolId=POOL;p.lpTokenId=1;p.status=PositionStatus.Active;}}
contract Strategy {function executionValidatePrice(bytes32)external pure returns(uint160){return uint160(1)<<96;}}
contract Liquidity {address public executionStrategy;uint256 public a0=500e18;uint256 public a1=500e18;constructor(address s){executionStrategy=s;}function portfolioAmounts(uint256)external view returns(uint256,uint256){return(a0,a1);}function set(uint256 x,uint256 y)external{a0=x;a1=y;}}
contract Oracle {
 uint256 public price=1e18;uint256 public revision=1;address public owner;address public entry;bool public failEnd;bool public checkCallbacks;uint256 public validations;
 function deploy(bytes memory code,address controller)external returns(address a){code=abi.encodePacked(code,abi.encode(controller,address(this)));assembly("memory-safe"){a:=create(0,add(code,32),mload(code))}require(a!=address(0));}
 function configure(address e,bool failed,bool callbacks,uint256 value)external{entry=e;failEnd=failed;checkCallbacks=callbacks;price=value;++revision;}
 function beginExecution(address)external{require(owner==address(0));owner=msg.sender;}
 function validateExecution()external view{require(owner!=address(0));_callback();}
 function endExecution()external{require(owner==msg.sender);_callback();require(!failEnd,"end-failure");owner=address(0);++validations;}
 function _callback()private view{if(checkCallbacks){(bool ok,bytes memory data)=entry.staticcall(abi.encodeWithSignature("reenter(address)",owner));require(!ok&&data.length==4&&bytes4(data)==bytes4(keccak256("InvalidState()")),"phase-callback");}}
 function executionBounds(address token)external view returns(uint256,uint256,bytes32){require(owner!=address(0));_callback();return(price,price,keccak256(abi.encode(token,revision)));}
 function tokenDecimals(address)external pure returns(uint8){return 18;}
 function value(address,uint256 amount)external view returns(uint256){return amount*price/1e18;}
}
contract Budget {
 Liquidity public liquidity;uint32 constant LIMITS=uint32(200)|(uint32(300)<<16);bytes32 constant POOL=keccak256("controlledpool");
 constructor(Liquidity l){liquidity=l;}function contributionLossBps()external pure returns(uint16){return 300;}
 function run(P p,uint256 nft,uint256 gross,address source,uint256 amount)external returns(uint256 issued,uint256 net){
  uint256 a0=source==address(0)?amount:0;uint256 a1=source==address(0)?0:amount;uint256 packed=a0|(a1<<128);
  (uint256 beforeD,uint256 beforeI)=p.nav(7);p.begin(nft,7,packed,gross,LIMITS);p.contributionNav(7);p.contributionNav(7);
  liquidity.set(liquidity.a0()+a0,liquidity.a1()+a1);(uint256 afterD,uint256 afterI)=p.contributionNav(7);
  return p.finish(7,gross,100e18,beforeD+beforeI,beforeD,afterD,afterI,LIMITS);
 }
 function zeroPhaseNav(P p)external{p.contributionNav(7);}
 function prematureFinish(P p)external{p.begin(1,7,100e18,100e18,LIMITS);p.contributionNav(7);p.finish(7,100e18,100e18,1000e18,1000e18,1100e18,0,LIMITS);}
 function direct(P p,uint256 nft,uint256 gross,address source,uint256 amount)external returns(uint256,uint256){return this.run(p,nft,gross,source,amount);}
}
contract Entry {
 Budget public budget;Policy public policy;bytes32 constant POOL=keccak256("controlledpool");bool public contextGood=true;
 constructor(Budget b,Policy pp){budget=b;policy=pp;}function setContext(bool x)external{contextGood=x;}
 function pricingContext(uint256,bytes32,uint256,uint256)external view returns(bool){return contextGood;}
 function endWithoutBegin(P p)external{p.endEntry();}
 function beginTwice(P p)external{p.beginEntryReviewed(1,POOL,address(0),100e18,300,policy.entryFingerprint());p.beginEntryReviewed(2,POOL,address(0x1234),100e18,300,policy.entryFingerprint());}
 function reenter(address target)external{P(target).beginEntryReviewed(1,POOL,address(0),100e18,300,policy.entryFingerprint());}
 function run(P p,uint256 nft,address source,uint256 amount)external returns(uint256 issued,uint256 net){
  uint256 gross=p.beginEntryReviewed(nft,POOL,source,amount,300,policy.entryFingerprint());(issued,net)=budget.run(p,nft,gross,source,amount);p.endEntry();
 }
}
contract PricingHostProbeTest {
 Vm constant vm=Vm(address(uint160(uint256(keccak256("hevm cheat code")))));Access access;Policy policy;Pools pools;Vault vault;Liquidity liq;Strategy strategy;Oracle oracle;Budget budget;Entry entry;P old;P fresh;
 event PricingGas(string label,uint256 gasUsed);
 constructor(){
  policy=new Policy();access=new Access(address(policy));strategy=new Strategy();liq=new Liquidity(address(strategy));budget=new Budget(liq);entry=new Entry(budget,policy);pools=new Pools(address(entry));vault=new Vault(address(budget));oracle=new Oracle();
  access.bind(Ids.VAULT,address(vault));access.bind(Ids.POOLS,address(pools));access.bind(Ids.LIQUIDITY,address(liq));
  old=P(oracle.deploy(vm.getCode("src/ZZZContributionPricingBaseline.sol:ZZZContributionPricingBaseline"),address(access)));
  fresh=P(oracle.deploy(vm.getCode("src/ZZZContributionPricing.sol:ZZZContributionPricing"),address(access)));
  oracle.configure(address(entry),false,false,1e18);
 }
 function _run(P p,uint256 id,address source,uint256 amount)private returns(uint256,uint256,bytes32){
  liq.set(500e18,500e18);vm.recordLogs();(uint256 issued,uint256 net)=entry.run(p,id,source,amount);Vm.Log[] memory ls=vm.getRecordedLogs();require(ls.length==1&&ls[0].topics.length==3);require(!p.active()&&oracle.owner()==address(0));return(issued,net,keccak256(abi.encode(ls[0].topics,ls[0].data)));
 }
 function testActualPricingEntryETHZZZExactBasisHashAndShares()external{
  for(uint256 i;i<6;++i){address source=i%2==0?address(0):address(0x1234);uint256 amount=(100+i)*1e18;
   (uint256 a,uint256 b,bytes32 h)=_run(old,i+1,source,amount);(uint256 c,uint256 d,bytes32 j)=_run(fresh,i+1,source,amount);require(a==c&&b==d&&h==j);require(b==amount&&a==amount/10);}
 }
 function testActualPricingDirectBudgetAlsoClears()external{
  for(uint256 i;i<2;++i){P p=i==0?old:fresh;liq.set(500e18,500e18);(uint256 issued,uint256 net)=budget.direct(p,11,100e18,address(0),100e18);require(issued==10e18&&net==100e18&&!p.active()&&oracle.owner()==address(0));}
 }
 function testActualPricingRepeatedSameTransactionClearsMarksAndChangedRevision()external{
  for(uint256 i;i<2;++i){P p=i==0?old:fresh;_run(p,12,address(0),100e18);oracle.configure(address(entry),false,false,2e18);(uint256 issued,uint256 net,)=_run(p,13,address(0x1234),100e18);require(issued==10e18&&net==200e18);oracle.configure(address(entry),false,false,1e18);}
 }
 function testActualPricingRevertRollsBackTransientAndPersistentState()external{
  for(uint256 i;i<2;++i){P p=i==0?old:fresh;liq.set(500e18,500e18);oracle.configure(address(entry),true,false,1e18);(bool ok,)=address(entry).call(abi.encodeCall(Entry.run,(p,14,address(0),100e18)));require(!ok&&!p.active()&&oracle.owner()==address(0));require(liq.a0()==500e18&&liq.a1()==500e18);oracle.configure(address(entry),false,false,2e18);(uint256 issued,uint256 net,)=_run(p,15,address(0x1234),100e18);require(issued==10e18&&net==200e18);oracle.configure(address(entry),false,false,1e18);}
 }
 function testActualPricingStaticCallbacksCannotReplaceActiveBasis()external{
  oracle.configure(address(entry),false,true,1e18);(uint256 a,uint256 b,bytes32 h)=_run(old,16,address(0),100e18);(uint256 c,uint256 d,bytes32 j)=_run(fresh,16,address(0),100e18);require(a==c&&b==d&&h==j);
 }
 function testActualPricingContextAndCallerGuardsPreserved()external{
  for(uint256 i;i<2;++i){P p=i==0?old:fresh;(bool ok,)=address(p).call(abi.encodeCall(P.beginEntryReviewed,(1,keccak256("controlledpool"),address(0),100e18,300,policy.entryFingerprint())));require(!ok&&!p.active());entry.setContext(false);liq.set(500e18,500e18);(ok,)=address(entry).call(abi.encodeCall(Entry.run,(p,1,address(0),100e18)));require(!ok&&!p.active()&&oracle.owner()==address(0));entry.setContext(true);}
 }
 function testActualPricingColdGasBaseline()external{liq.set(500e18,500e18);uint256 start=gasleft();(uint256 a,uint256 b)=entry.run(old,20,address(0x1234),100e18);uint256 used=start-gasleft();require(a==10e18&&b==100e18&&!old.active());emit PricingGas("baseline",used);}
 function testActualPricingColdGasCandidate()external{liq.set(500e18,500e18);uint256 start=gasleft();(uint256 a,uint256 b)=entry.run(fresh,20,address(0x1234),100e18);uint256 used=start-gasleft();require(a==10e18&&b==100e18&&!fresh.active());emit PricingGas("candidate",used);}
 function testActualPricingFullWidthNFTAndPackedMarkMax()external{
  oracle.configure(address(entry),false,false,type(uint128).max);
  (uint256 a,uint256 b,bytes32 h)=_run(old,type(uint256).max,address(0),100e18);(uint256 c,uint256 d,bytes32 j)=_run(fresh,type(uint256).max,address(0),100e18);
  require(a==c&&b==d&&h==j&&a==10e18&&b==uint256(type(uint128).max)*100);
 }
 function testActualPricingMalformedMarkBoundsRollback()external{
  uint256[2]memory values=[uint256(0),uint256(type(uint128).max)+1];
  for(uint256 i;i<2;++i)for(uint256 j;j<2;++j){P p=j==0?old:fresh;oracle.configure(address(entry),false,false,values[i]);
   (bool ok,bytes memory why)=address(entry).call(abi.encodeCall(Entry.run,(p,1,address(0),100e18)));require(!ok&&why.length==4&&bytes4(why)==bytes4(keccak256("InvalidState()"))&&!p.active()&&oracle.owner()==address(0));}
 }
 function testActualPricingWrongPhaseAndDoubleBeginRollback()external{
  for(uint256 i;i<2;++i){P p=i==0?old:fresh;
   (bool ok,bytes memory why)=address(budget).call(abi.encodeCall(Budget.zeroPhaseNav,(p)));require(!ok&&why.length==4&&bytes4(why)==bytes4(keccak256("InvalidState()")));
   (ok,why)=address(budget).call(abi.encodeCall(Budget.prematureFinish,(p)));require(!ok&&why.length==4&&bytes4(why)==bytes4(keccak256("InvalidState()"))&&!p.active()&&oracle.owner()==address(0));
   (ok,why)=address(entry).call(abi.encodeCall(Entry.endWithoutBegin,(p)));require(!ok&&why.length==4&&bytes4(why)==bytes4(keccak256("InvalidState()")));
   (ok,why)=address(entry).call(abi.encodeCall(Entry.beginTwice,(p)));require(!ok&&why.length==4&&bytes4(why)==bytes4(keccak256("InvalidState()"))&&!p.active()&&oracle.owner()==address(0));
   _run(p,2,address(0x1234),100e18);
  }
 }

}
