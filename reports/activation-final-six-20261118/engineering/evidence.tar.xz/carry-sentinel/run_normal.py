from pathlib import Path
import subprocess,time,json,hashlib,datetime
p=Path(__file__).resolve().parent
base=p.parents[1]/'activation-gas-20261118/build/final01'
root=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
sha=lambda b:hashlib.sha256(b).hexdigest()
ip=json.loads((base/'compiler-input.json').read_text(encoding='utf-8'))
old=ip['sources']['src/libraries/ExactLPAllocation.sol']['content']
actual=(root/'src/libraries/ExactLPAllocation.sol').read_bytes()
assert old==actual.decode('utf-8').replace('\r\n','\n')
new=(p/'src/ExactLPAllocationSentinel.sol').read_text(encoding='utf-8').replace('library ExactLPAllocationSentinel {','library ExactLPAllocation {')
ip['sources']['src/libraries/ExactLPAllocation.sol']['content']=new
np=p/'normal-host01';np.mkdir(exist_ok=True)
(np/'compiler-input.json').write_text(json.dumps(ip),encoding='utf-8')
solc=p.parents[1]/'toolchain-0.8.26/solc.exe'
assert sha(solc.read_bytes())=='537fd8d8d4a0433a971bf456fc06f7b021cdcee27b252f74da49e0d8559aeb67'
t=time.monotonic()
with(np/'compiler-input.json').open('rb')as fi,(np/'compiler-output.json').open('wb')as fo,(np/'compiler-stderr.log').open('wb')as fe:
 r=subprocess.run([str(solc),'--standard-json'],stdin=fi,stdout=fo,stderr=fe,cwd=np,timeout=900)
out=json.loads((np/'compiler-output.json').read_text(encoding='utf-8'))
bo=json.loads((base/'compiler-output.json').read_text(encoding='utf-8'))
evidence=json.loads((base/'normal-size-evidence.json').read_text(encoding='utf-8'))
gates=[]
for gate in evidence['gates']:
 c=out['contracts'][gate['path']][gate['name']]
 runtime=len(c['evm']['deployedBytecode']['object'])//2;creation=len(c['evm']['bytecode']['object'])//2
 gates.append(dict(name=gate['name'],path=gate['path'],runtime=runtime,creation=creation,minimum_args=gate['minimum_args'],runtime_margin=24576-runtime,init_margin_min_args=49152-creation-gate['minimum_args'],runtime_delta=runtime-gate['runtime'],creation_delta=creation-gate['creation'],pass_gate=runtime<=24576 and creation+gate['minimum_args']<=49152))
abi_changes=[];changed=[]
for path,cs in bo['contracts'].items():
 for name,c in cs.items():
  nc=out['contracts'][path][name]
  if c['abi']!=nc['abi']:abi_changes.append(path+':'+name)
  if c['evm']['bytecode']['object']!=nc['evm']['bytecode']['object']:changed.append({'path':path,'name':name,'oldruntime':len(c['evm']['deployedBytecode']['object'])//2,'newruntime':len(nc['evm']['deployedBytecode']['object'])//2,'oldcreation':len(c['evm']['bytecode']['object'])//2,'newcreation':len(nc['evm']['bytecode']['object'])//2})
result={'scope':'isolated normal exact100-source host compile, only candidate LP helper changed; no root writes','baseline_build':str(base),'seconds':time.monotonic()-t,'solc_exit':r.returncode,'errors':[e for e in out.get('errors',[]) if e['severity']=='error'],'input_sources':len(ip['sources']),'settings_unchanged':ip['settings']==json.loads((base/'compiler-input.json').read_text(encoding='utf-8'))['settings'],'original_current_library_raw_sha256':sha(actual),'current_library_preserved':(root/'src/libraries/ExactLPAllocation.sol').read_bytes()==actual,'candidate_library_compiler_content_sha256':sha(new.encode()),'candidate_library_content':new,'input_sha256':sha((np/'compiler-input.json').read_bytes()),'output_sha256':sha((np/'compiler-output.json').read_bytes()),'abi_changes':abi_changes,'changed_creations_including_metadata':changed,'gates':gates,'all_size_gates_pass':all(g['pass_gate'] for g in gates),'deployed_or_adopted':False}
(np/'RESULT.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in result.items()if k not in ['candidate_library_content','gates','changed_creations_including_metadata']},indent=2));print(json.dumps([g for g in gates if g['runtime_delta']or g['creation_delta']],indent=2))
