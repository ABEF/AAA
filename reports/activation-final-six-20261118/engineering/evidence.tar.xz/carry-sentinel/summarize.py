from pathlib import Path
import json
p=Path(__file__).resolve().parent
o=json.loads((p/'AFFECTED_STDOUT.json').read_text(encoding='utf-8'))
t=next(iter(o.values()))['test_results']
rows=[]
for method,r in t.items():
 assert r['status']=='Success',(method,r['reason'])
 for log in r['logs']:
  data=bytes.fromhex(log['data'][2:]);words=[int.from_bytes(data[i:i+32],'big')for i in range(0,len(data),32)]
  offset=words[0];size=int.from_bytes(data[offset:offset+32],'big');name=data[offset+32:offset+32+size].decode('utf-8')
  base,candidate=words[1:3]
  rows.append({'fixture':name,'baseline963_packed_gas':base,'sentinel_candidate_gas':candidate,'gas_saved':base-candidate,'scope':'cold engine component; not whole activation'})
r={'passed_methods':list(t),'distinct_affected_adapted_methods':7,'distinct_new_methods':1,'total':len(t),'component_gas':rows,'minimal_size':json.loads((p/'MINIMAL_RESULT.json').read_text(encoding='utf-8')),'root_edits':False,'new_private_representation_requires_fresh_source_runtime_pins':True,'not_complete_rewards_or_entry_qualification':True}
(p/'RESULT.json').write_text(json.dumps(r,indent=2),encoding='utf-8');print(json.dumps(r,indent=2))
