// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;
import {ExactLPAllocationBaseline} from "./ExactLPAllocationBaseline.sol";
import {ExactLPAllocationSentinel} from "./ExactLPAllocationSentinel.sol";
contract BaselineHost {
    using ExactLPAllocationBaseline for ExactLPAllocationBaseline.Tree;
    ExactLPAllocationBaseline.Tree internal tree;
    function setWeight(uint256 o,uint256 w)external returns(uint256){return tree.setWeight(o,w);}
    function credit(uint8 a,uint256 n)external{tree.credit(ExactLPAllocationBaseline.Asset(a),n);}
    function take(uint8 a,uint256 o)external returns(uint256){return tree.take(ExactLPAllocationBaseline.Asset(a),o);}
    function claimable(uint8 a,uint256 o)external view returns(uint256){return tree.claimable(ExactLPAllocationBaseline.Asset(a),o);}
    function outstanding(uint8 a)external view returns(uint256){return tree.outstanding(ExactLPAllocationBaseline.Asset(a));}
    function totalWeight()external view returns(uint256){return tree.totalWeight();}
    function weightOf(uint256 o)external view returns(uint256){return tree.weightOf(o);}
    function node(uint8 a,uint256 n)external view returns(uint256,uint256,uint128,uint256){ExactLPAllocationBaseline.Book storage b=tree.books[a];(uint128 h,uint256 l)=ExactLPAllocationBaseline.readCarry(b.carry[n]);return(tree.weights[n],b.pending[n],h,l);}
    function digest()external view returns(bytes32 v){v=keccak256(abi.encode(tree.books[0].outstanding,tree.books[1].outstanding));for(uint256 n=1;n<2048;++n){(uint128 h0,uint256 l0)=ExactLPAllocationBaseline.readCarry(tree.books[0].carry[n]);(uint128 h1,uint256 l1)=ExactLPAllocationBaseline.readCarry(tree.books[1].carry[n]);v=keccak256(abi.encode(v,tree.weights[n],tree.books[0].pending[n],h0,l0,tree.books[1].pending[n],h1,l1));}}
}
contract PackedHost {
    using ExactLPAllocationSentinel for ExactLPAllocationSentinel.Tree;
    ExactLPAllocationSentinel.Tree internal tree;
    function setWeight(uint256 o,uint256 w)external returns(uint256){return tree.setWeight(o,w);}
    function credit(uint8 a,uint256 n)external{tree.credit(ExactLPAllocationSentinel.Asset(a),n);}
    function take(uint8 a,uint256 o)external returns(uint256){return tree.take(ExactLPAllocationSentinel.Asset(a),o);}
    function claimable(uint8 a,uint256 o)external view returns(uint256){return tree.claimable(ExactLPAllocationSentinel.Asset(a),o);}
    function outstanding(uint8 a)external view returns(uint256){return tree.outstanding(ExactLPAllocationSentinel.Asset(a));}
    function totalWeight()external view returns(uint256){return tree.totalWeight();}
    function weightOf(uint256 o)external view returns(uint256){return tree.weightOf(o);}
    function node(uint8 a,uint256 n)external view returns(uint256,uint256,uint128,uint256){ExactLPAllocationSentinel.Book storage b=tree.books[a];(uint128 h,uint256 l)=ExactLPAllocationSentinel.readCarry(b.carry[n]);return(tree.weights[n],b.pending[n],h,l);}
    function digest()external view returns(bytes32 v){v=keccak256(abi.encode(tree.books[0].outstanding,tree.books[1].outstanding));for(uint256 n=1;n<2048;++n){(uint128 h0,uint256 l0)=ExactLPAllocationSentinel.readCarry(tree.books[0].carry[n]);(uint128 h1,uint256 l1)=ExactLPAllocationSentinel.readCarry(tree.books[1].carry[n]);v=keccak256(abi.encode(v,tree.weights[n],tree.books[0].pending[n],h0,l0,tree.books[1].pending[n],h1,l1));}}
}
