// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;
import {BaselineHost,PackedHost} from "../src/LPHeadlineHosts.sol";
import {ExactLPAllocationBaseline} from "../src/ExactLPAllocationBaseline.sol";
import {ExactLPAllocationSentinel} from "../src/ExactLPAllocationSentinel.sol";
contract TestBaselineHost is BaselineHost {
 function seedPhase(uint8 a,uint256 n,uint128 h,uint256 l)external{ExactLPAllocationBaseline.writeCarry(tree.books[a].carry[n],h,l);}
}
contract TestPackedHost is PackedHost {
 function seedPhase(uint8 a,uint256 n,uint128 h,uint256 l)external{ExactLPAllocationSentinel.writeCarry(tree.books[a].carry[n],h,l);}
 function physicalCarry(uint8 a,uint256 n)external view returns(uint256,uint256){ExactLPAllocationSentinel.Carry storage c=tree.books[a].carry[n];return(c.packed,c.wide);}
}
