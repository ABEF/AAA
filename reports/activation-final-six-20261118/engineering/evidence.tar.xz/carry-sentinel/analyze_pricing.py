from pathlib import Path
import sys,json,gzip,hashlib,collections
p=Path(__file__).resolve().parent
v=p.parents[1];root=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
sys.path.insert(0,str(root))
from zzz_ops.abi import keccak256
out=json.loads((v/'activation-gas-20261118/build/final01/compiler-output.json').read_text(encoding='utf-8'))
abi=out['contracts']['src/ZZZContributionPricing.sol']['ZZZContributionPricing']['abi']
signatures={}
for f in abi:
 if f['type']=='function':
  sig=f['name']+'('+','.join(a['type']for a in f['inputs'])+')';signatures['0x'+keccak256(sig.encode())[:4].hex()]=sig
cases=[]
for label in ('rounds-999-opening-zzz-allslow','rounds-999-opening-zzz','rounds-999-rotated-zzz','rounds-1000-grow-eth'):
 d=v/'activation-gas-20261118/full01/local-rpc'/label
 proof=json.loads((d/'VERIFICATION.json').read_text(encoding='utf-8'));address=proof['profile']['pins']['contribution_pricing']
 path=d/'rpc-records.json.gz';records=json.loads(gzip.decompress(path.read_bytes()))
 traces=[r for r in records if r['request']['method']=='debug_traceCall'];trace=traces[0]['response']['result'];rows=[]
 def gas(s):return int(s,16)if isinstance(s,str)else s
 def walk(t):
  if t.get('to','').lower()==address.lower():
   used=gas(t['gasUsed']);children=sum(gas(c['gasUsed'])for c in t.get('calls',[]));selector=t.get('input','0x')[:10]
   rows.append({'function':signatures.get(selector,selector),'type':t['type'],'inclusive_gas':used,'exclusive_gas':used-children,'child_count':len(t.get('calls',[]))})
  for c in t.get('calls',[]):walk(c)
 walk(trace)
 cases.append({'label':label,'trace_record_count':len(traces),'analysed_trace_index':0,'trace_source_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'contribution_pricing':address,'exclusive_total':sum(r['exclusive_gas']for r in rows),'frames':rows})
result={'kind':'read-only reuse existing authenticated current-source callTracer captures; no node or new execution','caveat':'exclusive gas = frame gasUsed minus direct child gasUsed, includes call opcode and marshalling; not isolated storage opcode attribution or promised optimization savings','cases':cases,'state_lifetime':{'basis':'begin Entry/budget through finish/endEntry; _clear deletes after complete Oracle.endExecution proof','marks_and_assets':'captured by _mark once per token, read throughout same call tree and callbacks, deleted only at _clear','maintenanceBucket':'separate maintenance scope; marks/assets unused there'},'transient_requirements':['EIP1153 actual target activation independently confirmed','TLOAD allowed during STATIC, no TSTORE in existing view entrypoints','retain explicit clear between multiple sequential operations in one transaction','preserve nested scope refusal, phase authorization, original source vector and fingerprints','reverted inner frame must roll back transient changes exactly','fresh code/source pins; no reinterpret old running state or journal','fixed namespace and contract-local slot ownership; no source/asset cap relaxation','do not replace monetary/accounting persistent state with transient'],'root_edits':False}
(p/'PRICING_READ_ONLY_ANALYSIS.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result,indent=2))
