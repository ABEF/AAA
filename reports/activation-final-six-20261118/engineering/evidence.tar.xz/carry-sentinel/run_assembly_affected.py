from pathlib import Path
import shutil,subprocess,time,json
p=Path(__file__).resolve().parent
q=p/'assembly-screen01/project';q.mkdir(parents=True,exist_ok=True)
for folder in ('src','test','fixtures','node_modules'):shutil.copytree(p/folder,q/folder,dirs_exist_ok=True)
shutil.copyfile(p/'foundry.toml',q/'foundry.toml')
shutil.copyfile(p/'assembly-screen01/ExactLPAllocationSentinel.sol',q/'src/ExactLPAllocationSentinel.sol')
forge=p.parents[1]/'foundry-v1.4.4/forge.exe';solc=p.parents[1]/'toolchain-0.8.26/solc.exe'
t=time.monotonic();args=[str(forge),'test','--root',str(q),'--use',str(solc),'--match-contract','LPPackedEngineeringTest','--json','-vv']
with(q/'AFFECTED_STDOUT.json').open('wb')as o,(q/'AFFECTED_STDERR.log').open('wb')as e:r=subprocess.run(args,stdout=o,stderr=e,cwd=q,timeout=600)
parsed=json.loads((q/'AFFECTED_STDOUT.json').read_text(encoding='utf-8'));tests=next(iter(parsed.values()))['test_results'];rows=[]
for method,result in tests.items():
 for log in result['logs']:
  data=bytes.fromhex(log['data'][2:]);words=[int.from_bytes(data[i:i+32],'big')for i in range(0,len(data),32)];offset=words[0];size=int.from_bytes(data[offset:offset+32],'big');name=data[offset+32:offset+32+size].decode('utf-8');old,new=words[1:3];rows.append({'fixture':name,'baseline963_packed_gas':old,'sentinel_assembly_gas':new,'gas_saved':old-new})
out={'command':args,'exit_code':r.returncode,'seconds':time.monotonic()-t,'test_statuses':{m:v['status']for m,v in tests.items()},'all_pass':all(v['status']=='Success'for v in tests.values()),'component_gas':rows,'scope':'same8affected methods at a second changed implementation; not8additional methods','root_edits':False}
(q/'RESULT.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out,indent=2))
