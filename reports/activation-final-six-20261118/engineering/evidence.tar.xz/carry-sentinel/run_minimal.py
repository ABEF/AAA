from pathlib import Path
import subprocess,time,json,hashlib
p=Path(__file__).resolve().parent
solc=Path('C:/Users/Ali/.codex/visualizations/2026/10/14/01a13899-2be7-76f2-a5d0-72e4804c67b9/toolchain-0.8.26/solc.exe')
assert hashlib.sha256(solc.read_bytes()).hexdigest()=='537fd8d8d4a0433a971bf456fc06f7b021cdcee27b252f74da49e0d8559aeb67'
t=time.monotonic()
with (p/'MINIMAL_INPUT.json').open('rb') as fi,(p/'MINIMAL_OUTPUT.json').open('wb') as fo,(p/'MINIMAL_STDERR.log').open('wb') as fe:
 r=subprocess.run([str(solc),'--standard-json'],stdin=fi,stdout=fo,stderr=fe,cwd=p,timeout=300)
o=json.loads((p/'MINIMAL_OUTPUT.json').read_text(encoding='utf-8'))
result={'exit_code':r.returncode,'seconds':time.monotonic()-t,'errors':[e for e in o.get('errors',[])if e['severity']=='error'],'runtime_sizes':{n:len(c['evm']['deployedBytecode']['object'])//2 for f,cs in o.get('contracts',{}).items() for n,c in cs.items() if n.endswith('Host')},'normal_settings':True,'engineering_only':True}
(p/'MINIMAL_RESULT.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result,indent=2))
