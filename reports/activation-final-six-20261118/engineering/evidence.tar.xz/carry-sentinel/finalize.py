from pathlib import Path
import json,difflib,hashlib
p=Path(__file__).resolve().parent
r=json.loads((p/'assembly-normal01/RESULT.json').read_text(encoding='utf-8'))
old=(p/'src/ExactLPAllocationBaseline.sol').read_text(encoding='utf-8').replace('library ExactLPAllocationBaseline {','library ExactLPAllocation {')
new=r['candidate_library_content']
q=p/'proposed';q.mkdir(exist_ok=True)
(q/'ExactLPAllocation.sol').write_text(new,encoding='utf-8')
(p/'PROPOSAL.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='baseline963/src/libraries/ExactLPAllocation.sol',tofile='candidate/src/libraries/ExactLPAllocation.sol')),encoding='utf-8')
scope='''# LP carry sentinel candidate

Candidate only, not adopted, deployed or whole-Entry qualified. No repository files changed.

The compact upper128 low value MAX128 is a marker. Logical low values below MAX128 use that upper half directly; values at least MAX128 store the exact uint256 low in the adjacent spill word. The lower128 always preserve the complete logical high. Reading a normal/zero carry requires only one SLOAD. Both helpers use memory-safe assembly; high is explicitly masked, and compact writes clear a preceding spill. No arithmetic, weight, pending, claim, outstanding or split rule changes.

Private encoding requires a fresh source/runtime review. An old live physical carry cannot be reinterpreted. Logical LP1/canonicalV10 rows are unchanged. The two-slot struct footprint stays unchanged.

Seven affected existing engineering assertions were adapted to compare current963 packed storage with the sentinel, plus one new all-width logical export/import/clear method. All eight distinct methods pass. They cover all2047logical nodes and both books, mutable weights, current/future claims, zero/noop/overflow, reachable spill to compact to spill, MAX128 boundaries, full MAX256 low preservation and a deterministic128-step sequence. The same eight ran at the later assembly helper source; this is not eight additional methods.

Matched cold extracted999-NFT engine components, current963 versus assembly sentinel:

|Component|Current963|Candidate|Saved gas|
|---|---:|---:|---:|
|Funded owner|1,062,531|967,836|94,695|
|Funded collective|975,650|884,428|91,222|
|Zero-fee owner|270,755|218,096|52,659|
|Zero-fee collective|270,562|217,920|52,642|

These are component measurements, not whole activation estimates. Funded total saves185,917; zero-fee total saves105,301. Earlier cross-campaign numbers retain their exact source/harness scopes.

The isolated exact100-source production compile, unchanged Solidity0.8.26/Cancun/viaIR/runs1/Yulfalse and unchanged output selection, passes all48normal size gates. Public ABIs are unchanged. Rewards is23,983runtime/593headroom and44,468creation;32static constructor bytes leave4,652initcode margin. Both are89bytes smaller than963. RewardsCanonical remains18,609runtime/19,361creation with changed metadata, so fresh exact pins are required. Royalty, data parts, Oracle, Vault and all other production outputs remain byte-identical. ExactLPAllocation library metadata also changes. No root state, service, signing, existing Anvil/journal, default or financial guard changes.

Remaining before adoption claims: actual immutable Rewards/Canonical scenarios and full affected1,000-NFT workload at the final combined build. The high-level sentinel probe is unadopted engineering evidence; the assembly candidate is the recommendation.

The separate read-only ContributionPricing trace analysis reuses existing current-source callTracer captures. Its617,747exclusive gas includes arithmetic and call overhead; it is not a savings promise. Marks/assets are transaction-scoped candidates, but explicit operation-end clear, phase authorization, callback visibility, STATIC read behavior, revert rollback and repeated same-transaction calls must remain. EIP1153 support on the target chain needs independent evidence; the general spec is https://eips.ethereum.org/EIPS/eip-1153 . No pricing code was changed.
'''
(p/'REVIEW.md').write_text(scope,encoding='utf-8')
print(json.dumps({'proposed_source_sha256':hashlib.sha256(new.encode()).hexdigest(),'proposal':str(q/'ExactLPAllocation.sol'),'review':str(p/'REVIEW.md'),'diff':str(p/'PROPOSAL.diff')},indent=2))
