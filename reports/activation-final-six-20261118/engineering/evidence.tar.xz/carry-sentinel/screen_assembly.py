from pathlib import Path
import json,subprocess,time,hashlib
p=Path(__file__).resolve().parent
q=p/'assembly-screen01';q.mkdir(exist_ok=True)
s=(p/'src/ExactLPAllocationSentinel.sol').read_text(encoding='utf-8')
start=s.index('    function readCarry(');end=s.index('    function _leaf(',start)
replacement='''    function readCarry(Carry storage c) internal view returns(uint128 high, uint256 low) {
        assembly ("memory-safe") {
            let marker := sub(shl(128, 1), 1)
            let packed := sload(c.slot)
            high := and(packed, marker)
            low := shr(128, packed)
            if eq(low, marker) { low := sload(add(c.slot, 1)) }
        }
    }
    function writeCarry(Carry storage c, uint128 high, uint256 low) internal {
        assembly ("memory-safe") {
            let marker := sub(shl(128, 1), 1)
            let packed := and(high, marker)
            switch lt(low, marker)
            case 1 {
                packed := or(packed, shl(128, low))
                if eq(shr(128, sload(c.slot)), marker) { sstore(add(c.slot, 1), 0) }
            }
            default {
                packed := or(packed, shl(128, marker))
                sstore(add(c.slot, 1), low)
            }
            sstore(c.slot, packed)
        }
    }

'''
s=s[:start]+replacement+s[end:]
(q/'ExactLPAllocationSentinel.sol').write_text(s,encoding='utf-8')
ip=json.loads((p/'MINIMAL_INPUT.json').read_text(encoding='utf-8'))
ip['sources']['src/ExactLPAllocationSentinel.sol']['content']=s
(q/'compiler-input.json').write_text(json.dumps(ip),encoding='utf-8')
solc=p.parents[1]/'toolchain-0.8.26/solc.exe'
t=time.monotonic()
with(q/'compiler-input.json').open('rb')as fi,(q/'compiler-output.json').open('wb')as fo,(q/'stderr.log').open('wb')as fe:r=subprocess.run([str(solc),'--standard-json'],stdin=fi,stdout=fo,stderr=fe,timeout=300,cwd=q)
o=json.loads((q/'compiler-output.json').read_text(encoding='utf-8'))
r={'seconds':time.monotonic()-t,'exit_code':r.returncode,'runtime_sizes':{n:len(c['evm']['deployedBytecode']['object'])//2 for f,cs in o.get('contracts',{}).items() for n,c in cs.items() if n.endswith('Host')},'errors':[e for e in o.get('errors',[])if e['severity']=='error'],'library_sha256':hashlib.sha256(s.encode()).hexdigest(),'only_minimal_size_no_gas_claim':True}
(q/'RESULT.json').write_text(json.dumps(r,indent=2),encoding='utf-8');print(json.dumps(r,indent=2))
