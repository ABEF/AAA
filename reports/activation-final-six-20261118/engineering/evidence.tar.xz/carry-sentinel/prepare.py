from pathlib import Path
import hashlib,json,shutil

ROOT=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
OLD=Path('C:/Users/Ali/.codex/visualizations/2026/10/14/01a13899-2be7-76f2-a5d0-72e4804c67b9/activation-gas-20261118/lp-packed')
OWN=Path(__file__).resolve().parent
def put(p,s):
    p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf-8')

raw=(ROOT/'src/libraries/ExactLPAllocation.sol').read_bytes()
base=raw.decode('utf-8').replace('library ExactLPAllocation {','library ExactLPAllocationBaseline {')
candidate=base.replace('library ExactLPAllocationBaseline {','library ExactLPAllocationSentinel {')
old='''        uint256 wide = c.wide;
        high = uint128(packed);
        low = wide == 0 ? packed >> 128 : wide;'''
new='''        high = uint128(packed);
        low = packed >> 128;
        if (low == type(uint128).max) low = c.wide;'''
assert candidate.count(old)==1
candidate=candidate.replace(old,new)
old='''        if (low <= type(uint128).max) {
            packed |= low << 128;
            if(c.wide != 0) delete c.wide;
        } else c.wide = low;'''
new='''        if (low < type(uint128).max) {
            packed |= low << 128;
            if (c.packed >> 128 == type(uint128).max) delete c.wide;
        } else {
            packed |= uint256(type(uint128).max) << 128;
            c.wide = low;
        }'''
assert candidate.count(old)==1
candidate=candidate.replace(old,new).replace('Nonzero wide is the >=2**128 spill.','MAX128 compact-low is the >=MAX128 spill marker.')
put(OWN/'src/ExactLPAllocationBaseline.sol',base)
put(OWN/'src/ExactLPAllocationSentinel.sol',candidate)
oldhosts=(OLD/'src/LPHeadlineHosts.sol').read_text(encoding='utf-8')
part=oldhosts[oldhosts.index('contract PackedHost {'):]
def host(name,lib):
    return part.replace('PackedHost',name).replace('ExactLPAllocationPacked',lib)
put(OWN/'src/LPHeadlineHosts.sol','// SPDX-License-Identifier: MIT\npragma solidity 0.8.26;\nimport {ExactLPAllocationBaseline} from "./ExactLPAllocationBaseline.sol";\nimport {ExactLPAllocationSentinel} from "./ExactLPAllocationSentinel.sol";\n'+host('BaselineHost','ExactLPAllocationBaseline')+host('PackedHost','ExactLPAllocationSentinel'))
put(OWN/'test/PackedTestHosts.sol','''// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;
import {BaselineHost,PackedHost} from "../src/LPHeadlineHosts.sol";
import {ExactLPAllocationBaseline} from "../src/ExactLPAllocationBaseline.sol";
import {ExactLPAllocationSentinel} from "../src/ExactLPAllocationSentinel.sol";
contract TestBaselineHost is BaselineHost {
 function seedPhase(uint8 a,uint256 n,uint128 h,uint256 l)external{ExactLPAllocationBaseline.writeCarry(tree.books[a].carry[n],h,l);}
}
contract TestPackedHost is PackedHost {
 function seedPhase(uint8 a,uint256 n,uint128 h,uint256 l)external{ExactLPAllocationSentinel.writeCarry(tree.books[a].carry[n],h,l);}
 function physicalCarry(uint8 a,uint256 n)external view returns(uint256,uint256){ExactLPAllocationSentinel.Carry storage c=tree.books[a].carry[n];return(c.packed,c.wide);}
}
''')
test=(OLD/'test/LPPackedEngineering.t.sol').read_text(encoding='utf-8')
test=test.replace('uint256 fused,uint256 saving','uint256 fused,int256 saving').replace('oldGas-newGas','int256(oldGas)-int256(newGas)')
test=test.replace('int256(int256(oldGas)-int256(newGas))','int256(oldGas)-int256(newGas)')
test=test.replace('"owner-baseline"','"owner-packed"').replace('"collective-baseline"','"collective-packed"')
test=test.replace('require(wide==0&&packed==type(uint256).max,"compact edge");','require(wide==type(uint128).max&&packed==type(uint256).max,"sentinel exact edge");')
test=test.replace('require(wide==(uint256(1)<<128)&&packed==type(uint128).max,"wide edge");','require(wide==(uint256(1)<<128)&&packed==type(uint256).max,"sentinel wide edge");')
test=test.replace('testPacked','testSentinel')
extra='''
 function testSentinelAllWidthLogicalExportImportAndClear() public {
  uint256[8] memory lows=[uint256(0),1,uint256(type(uint128).max)-1,uint256(type(uint128).max),uint256(type(uint128).max)+1,uint256(1)<<200,type(uint256).max-1,type(uint256).max];
  TestPackedHost target=new TestPackedHost();
  for(uint8 z;z<2;++z)for(uint256 i;i<lows.length;++i){
   uint128 h=i%2==0?uint128(i):type(uint128).max;
   a.seedPhase(z,i+1,h,lows[i]);b.seedPhase(z,i+1,h,lows[i]);
   (uint256 w,uint256 p,uint128 eh,uint256 el)=b.node(z,i+1);require(w==0&&p==0&&eh==h&&el==lows[i],"logical export");
   target.seedPhase(z,i+1,eh,el);
   (uint256 physical,uint256 wide)=b.physicalCarry(z,i+1);
   require(uint128(physical)==h,"full high");
   if(lows[i]<type(uint128).max)require(physical>>128==lows[i]&&wide==0,"compact physical");
   else require(physical>>128==type(uint128).max&&wide==lows[i],"wide physical");
  }
  require(a.digest()==b.digest()&&b.digest()==target.digest(),"canonical logical equality");
  for(uint8 z;z<2;++z)for(uint256 i;i<lows.length;++i){a.seedPhase(z,i+1,17,9);b.seedPhase(z,i+1,17,9);(uint256 p,uint256 w)=b.physicalCarry(z,i+1);require(p==uint256(17)+(uint256(9)<<128)&&w==0,"clear old spill");}
  _equal();
 }
'''
test=test.rsplit('\n}',1)[0]+extra+'\n}\n'
put(OWN/'test/LPPackedEngineering.t.sol',test)
put(OWN/'foundry.toml',(OLD/'foundry.toml').read_text(encoding='utf-8'))
shutil.copytree(OLD/'fixtures',OWN/'fixtures',dirs_exist_ok=True)
inp=json.loads((OLD/'MINIMAL_INPUT.json').read_text(encoding='utf-8'))
for path,row in inp['sources'].items():
    if path.startswith('node_modules/'):
        put(OWN/path,row['content'])
sources={str(p.relative_to(OWN)).replace('\\','/'):{'content':p.read_text(encoding='utf-8')} for folder in ('src','node_modules') for p in (OWN/folder).rglob('*.sol')}
inp['sources']=sources
put(OWN/'MINIMAL_INPUT.json',json.dumps(inp))
record={'baseline_git':'963e039caa163a4921d08ed4bfc6b3a44cb79d42','original_current_source_sha256':hashlib.sha256(raw).hexdigest(),'baseline_engine_sha256':hashlib.sha256(base.encode()).hexdigest(),'candidate_engine_sha256':hashlib.sha256(candidate.encode()).hexdigest(),'fixture_initial_carries_zero':True,'original_translation_evidence':str(OLD/'FIXTURE_TRANSLATION.json'),'root_edits':False,'candidate_encoding':'upper128==MAX128: spill exact uint256 low; all lower lows compact; high128 preserved','logical_wire_unchanged':True,'old_physical_state_must_not_be_reinterpreted':True}
put(OWN/'PREPARATION.json',json.dumps(record,indent=2))
print(json.dumps(record,indent=2))
