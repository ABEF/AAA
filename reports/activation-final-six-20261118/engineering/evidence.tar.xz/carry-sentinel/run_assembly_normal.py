from pathlib import Path
import runpy
p=Path(__file__).resolve().parent
s=(p/'run_normal.py').read_text(encoding='utf-8')
s=s.replace("p/'src/ExactLPAllocationSentinel.sol'","p/'assembly-screen01/ExactLPAllocationSentinel.sol'").replace("p/'normal-host01'","p/'assembly-normal01'")
exec(compile(s,str(p/'run_normal.py'),'exec'))
