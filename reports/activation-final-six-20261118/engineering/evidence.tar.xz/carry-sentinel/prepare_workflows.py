from pathlib import Path
import hashlib,json
R=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
P=R/'reports/activation-final-six-20261118';OLD=R/'reports/activation-gas-20261118'
sha=lambda b:hashlib.sha256(b).hexdigest()
rows=[]
for name in('compile_full_flow.py','run_full_flow.py','verify_full_flow.py','publish_final_flow.py'):
 raw=(OLD/name).read_bytes();text=raw.decode('utf-8').replace('\r\n','\n').replace('activation-gas-20261118','activation-final-six-20261118')
 text='# Adapted from historical activation-gas helper SHA256:'+sha(raw)+'; historical file unchanged.\n'+text
 if name=='compile_full_flow.py':
  needle="assert freeze['schema']==1 and freeze['source_sha256']==root_sources and freeze['fixture_sha256']==runner.FIXTURE_SHA256"
  assert text.count(needle)==1
  text=text.replace(needle,needle+"\n assert freeze['normal_build']['build_id']=='activation-final-six-20261118'")
 if name=='run_full_flow.py':
  needle="assert freeze['fixture_sha256']==FIXTURE_SHA256 and freeze['foundry_toml_sha256']==sha(original)"
  assert text.count(needle)==1
  text=text.replace(needle,needle+"\n assert freeze['normal_build']['build_id']=='activation-final-six-20261118'")
 if name=='verify_full_flow.py':
  needle="assert NORMAL_BINDING['schema']==1"
  assert text.count(needle)==1
  text=text.replace(needle,needle+"\nassert NORMAL_BINDING['build_id']=='activation-final-six-20261118'")
  needle="assert NORMAL_BINDING.get('normal_build_pass')is True and evidence['kind']=='actual_closed_normal_build'and evidence['pass']is True and evidence['all_pass']is True,'Unaccepted normal build'"
  assert text.count(needle)==1
  text=text.replace(needle,needle+"\n assert evidence['candidate_build_id']=='activation-final-six-20261118'and evidence['phase']=='admitted_without_recompilation','Fresh explicitly admitted final build required'")
 if name=='publish_final_flow.py':
  text=text.replace("              'BASELINE_COMPARISON.json','stderr.log']:","              'stderr.log']:")
  needle="for name in ['SOURCE_FREEZE.json','NORMAL_BINDING.json','RUN_WINDOW.json','FULL_COMPILE_INVENTORY.json','NONSELECTED_TEST_MAINTENANCE.json','PROVEN_RUNNER_ADOPTION.json','RESOLVED_REMAPPINGS.json']:\n  copy(name)"
  assert text.count(needle)==1
  text=text.replace(needle,"for name in ['SOURCE_FREEZE.json','NORMAL_BINDING.json','RUN_WINDOW.json']:\n  copy(name)\n for name in ['LAYOUT_ACCEPTANCE.json','BASELINE_COMPARISON.json','FULL_COMPILE_INVENTORY.json','NONSELECTED_TEST_MAINTENANCE.json','PROVEN_RUNNER_ADOPTION.json','RESOLVED_REMAPPINGS.json']:\n  if(V/name).is_file():copy(name)\n if(V/'full01/BASELINE_COMPARISON.json').is_file():copy('full01/BASELINE_COMPARISON.json')")
 dest=P/name
 if dest.exists():assert dest.read_text(encoding='utf-8').startswith('# Adapted from historical activation-gas helper SHA256:'+sha(raw)),dest
 dest.write_text(text,encoding='utf-8',newline='\n')
 rows.append({'file':name,'historical_source_sha256':sha(raw),'adapted_source_sha256':sha(dest.read_bytes()),'changes':'campaign-owned paths and explicit fresh-build/freeze checks; no price/financial/permission/budget changes'})
scope=(OLD/'FULL_FLOW_SCOPE.json').read_bytes();(P/'FULL_FLOW_SCOPE.json').write_bytes(scope)
fixture=R/'test/RoyaltyRoundsCapacity20261118.t.sol'
proof={'schema':1,'build_id':'activation-final-six-20261118','status':'PREPARED ONLY; no compilation/EVM/RPC executed','baseline_build':'activation-gas-20261118/build/final01',
 'fixture':fixture.relative_to(R).as_posix(),'fixture_sha256':sha(fixture.read_bytes()),'expected_fixture_sha256':'f648f3f21f2d3fbf80795211ec2afce7efca1a06d1bc43fc707188c389643e57',
 'fixture_byte_identical_to_affected_baseline':sha(fixture.read_bytes())=='f648f3f21f2d3fbf80795211ec2afce7efca1a06d1bc43fc707188c389643e57',
 'scope_file_byte_identical':sha(scope)==sha((P/'FULL_FLOW_SCOPE.json').read_bytes()),'scope_sha256':sha(scope),'helpers':rows,
 'fullflow_method':'testRoundsFull1000DenseCurrenciesOpeningRotationsAllFaultsAndGrowth()',
 'distinct_affected_existing_method_count':1,'new_test_methods':0,'export_cases':13,'unchanged_old_suites':0,
 'compile_then_execution_reuses_one_owned_cache':True,'normal_build':'compile once, then exact admission without recompilation',
 'existing_anvil_state_or_journals_modified':False,'public_signing_deployment_sealing':False,'production_approved':False}
assert proof['fixture_byte_identical_to_affected_baseline']
(P/'WORKFLOW_ADAPTATION.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
print(json.dumps(proof,indent=2))
