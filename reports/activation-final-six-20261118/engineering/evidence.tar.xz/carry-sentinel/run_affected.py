from pathlib import Path
import subprocess,time,json,hashlib
p=Path(__file__).resolve().parent
forge=Path('C:/Users/Ali/.codex/visualizations/2026/10/14/01a13899-2be7-76f2-a5d0-72e4804c67b9/foundry-v1.4.4/forge.exe')
solc='C:/Users/Ali/.codex/visualizations/2026/10/14/01a13899-2be7-76f2-a5d0-72e4804c67b9/toolchain-0.8.26/solc.exe'
assert hashlib.sha256(forge.read_bytes()).hexdigest()=='8500da38f541a1ebd5b97a34c8c5b9b057eba5ad160c657a5224b4e1c8f8e101'
t=time.monotonic()
args=[str(forge),'test','--root',str(p),'--use',solc,'--match-contract','LPPackedEngineeringTest','--json','-vv']
with(p/'AFFECTED_STDOUT.json').open('wb')as o,(p/'AFFECTED_STDERR.log').open('wb')as e:
 r=subprocess.run(args,stdout=o,stderr=e,cwd=p,timeout=600)
result={'exit_code':r.returncode,'seconds':time.monotonic()-t,'command':args,'scope':'seven adapted affected representation methods plus one new full-width logical export/import method; no root suite','root_edits':False}
(p/'AFFECTED_RUN.json').write_text(json.dumps(result,indent=2),encoding='utf-8');print(json.dumps(result,indent=2))
