from pathlib import Path
import hashlib,json
R=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
sha=lambda b:hashlib.sha256(b).hexdigest()
F5=R/'zzz_ops/factory_code_v5.py';raw=F5.read_bytes()
assert sha(raw)=='3e41c39666784e514d35a53e6ed7996b0bd3522126d22c55dcf63dfc943dfb46'
text=raw.decode('utf-8').replace('\r\n','\n').replace('payload5','payload6').replace('payload_v5','payload_v6').replace('factory-code-storage-v5.json','factory-code-storage-v6.json')
text=text.replace("ARTIFACT_CANONICAL_SHA256='6bad11a16db2e530765aeb738b7ad546d95ed35944b10a4b16d63670aee9a71c'","ARTIFACT_CANONICAL_SHA256=None  # Generated only from the admitted final normal build.")
text=text.replace("def load_artifact(path=ARTIFACT):\n","def load_artifact(path=ARTIFACT):\n    if ARTIFACT_CANONICAL_SHA256 is None:\n        raise ValueError('Payload6 awaits admitted final normal source pins')\n")
text=text.replace('SPEC=load_artifact()','SPEC=load_artifact() if ARTIFACT_CANONICAL_SHA256 is not None else None\n\n\ndef _require_spec():\n    if SPEC is None:raise ValueError(\'Payload6 awaits admitted final normal source pins\')')
for name,signature in [('parse_section','chain'),('verify_runtime_parts','values'),('verify_compiler_output','output')]:
 needle='def '+name+'('+signature+'):\n';assert text.count(needle)==1;text=text.replace(needle,needle+'    _require_spec()\n')
target=R/'zzz_ops/factory_code_v6.py';assert not target.exists();target.write_text(text,encoding='utf-8',newline='\n')
current=R/'config/production.example.json';old=current.read_bytes();archive=R/'config/production.schema17.payload5.example.json'
assert not archive.exists();archive.write_bytes(old)
config=json.loads(old)
assert all(c['factory_payload_version']==5 for c in config['chains'])
for chain in config['chains']:
 chain['factory_payload_version']=6
 section=chain['factory_code'];section['creation_code_length']=None;section['creation_code_hash']=None
 for part in section['parts']:
  for field in ('data_length','runtime_length','runtime_hash'):part[field]=None
  assert part['address']is None and all(v is None for k,v in part.items()if k.startswith('observed_'))
config['_notes'][0]='Fresh release explicitly selects factory_payload_version6 for reviewed packed private royalty state. Source payload pins await the admitted final normal build; no hash is guessed. Omission/3, explicit4 and explicit5 retain exact historical identities; the previous payload5 template is preserved byte-identically in production.schema17.payload5.example.json. No deployed address, observation, qualification, budget or operating approval is supplied.'
config['_notes'][-1]='Payload6 preserves constant-cost exact royalty rounds and the separate governed ERC20 balance-call cap. Payload5 remains an explicit historical source. royalty_read_policy fingerprint is computed offline from actual policy/cap/gas revision. Null cap/observations remain unverified; no gas policy, selected currency, address, service or release is approved.'
current.write_text(json.dumps(config,indent=2)+'\n',encoding='utf-8',newline='\n')
p=R/'zzz_ops/production_v15.py';s=p.read_text(encoding='utf-8')
s=s.replace('Omission/3 and explicit4 stay historical; only integer5 selects rounds.','Omission/3 and explicit4/5 stay exact; integer6 selects new private packing.')
s=s.replace('declared not in (3,4,5)','declared not in (3,4,5,6)').replace('factory_payload_version3,4 or5','factory_payload_version3,4,5 or6')
s=s.replace('    from zzz_ops import factory_code_v5\n    return factory_code_v5','    if declared==5:\n        from zzz_ops import factory_code_v5\n        return factory_code_v5\n    from zzz_ops import factory_code_v6\n    return factory_code_v6')
s=s.replace('chain.get(FACTORY_PAYLOAD_FIELD)==5','chain.get(FACTORY_PAYLOAD_FIELD) in (5,6)').replace('c.get(FACTORY_PAYLOAD_FIELD)==5','c.get(FACTORY_PAYLOAD_FIELD) in (5,6)').replace('requires explicit payload5','requires explicit payload5 or6')
p.write_text(s,encoding='utf-8',newline='\n')
p=R/'zzz_ops/production_observer_v15.py';s=p.read_text(encoding='utf-8');assert s.count('self.chain.get(P.FACTORY_PAYLOAD_FIELD)!=5')==1;s=s.replace('self.chain.get(P.FACTORY_PAYLOAD_FIELD)!=5','self.chain.get(P.FACTORY_PAYLOAD_FIELD) not in (5,6)');p.write_text(s,encoding='utf-8',newline='\n')
p=R/'zzz_ops/preseal_plan.py';s=p.read_text(encoding='utf-8');assert s.count('Verify exact fresh payload5/runtime identity')==1;s=s.replace('Verify exact fresh payload5/runtime identity','Verify exact selected payload5/6/runtime identity');p.write_text(s,encoding='utf-8',newline='\n')
out={'schema':1,'factory6_status':'UNGENERATED; awaits exact admitted final normal build','generated_hashes':False,'payload5_helper_sha256':sha(raw),'payload5_json_sha256':sha((R/'config/factory-code-storage-v5.json').read_bytes()),'historical_payload5_template_sha256':sha(archive.read_bytes()),'historical_template_byte_identical':archive.read_bytes()==old,'new_helper_sha256':sha(target.read_bytes()),'current_template_unknown_source_parts':True,'production_approved':False}
dest=R/'reports/activation-final-six-20261118/consumer';dest.mkdir(exist_ok=True);(dest/'PREPARATION.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
print(json.dumps(out,indent=2))
