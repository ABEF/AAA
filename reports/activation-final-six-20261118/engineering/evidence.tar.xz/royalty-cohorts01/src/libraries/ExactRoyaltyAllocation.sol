// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;

/// @notice Exact royalty allocation with bounded enrollment cohorts.
/// @dev Lifetime rounds/gross/paid debt are coefficients modulo2^256. Actual
/// receipts and payouts retain checked same-currency liabilities. Fresh round
/// books are not compatible with historical raw tree storage; canonical rows
/// flatten funded per-NFT rights and restore the cursor as an initial offset.
library ExactRoyaltyAllocation {
    // Low16bits: current cursor; next16: initial cursor; bit32: initialized.
    // Both cursors are validated below3000. One metadata write replaces three.
    struct Book { uint256 rounds; uint256 position; }
    // Fresh packed cohorts: end10, unit2, inline round243, high-bit spill tag.
    // Wide round coefficients remain full uint256 and modular, never money.
    struct Cohorts { mapping(uint256=>uint256) wideRounds; uint256[] rows; }
    error InvalidAllocation();

    function credit(Book storage book,uint256 amount,uint256 weight,uint256 cursor,uint256 globalBefore)
        internal returns(uint256 nextCursor,uint256 globalAfter) {
        _validate(weight,cursor);
        globalAfter=globalBefore+amount;
        uint256 position=book.position;
        if(position==0)position=(cursor<<16)|(uint256(1)<<32);
        uint256 turns;
        (nextCursor,turns)=_step(amount,weight,cursor);
        unchecked {
            book.rounds+=turns;
            book.position=(position&~uint256(type(uint16).max))|nextCursor;
        }
    }

    /// @notice Gross coefficient, before birth and paid-debt subtraction.
    function gross(Book storage book,uint256 first,uint256 last) internal view returns(uint256 value){
        _interval(first,last);
        uint256 position=book.position;
        if(position==0)return 0;
        unchecked {
            value=book.rounds*(last-first+1)+_prefix(first,last,position&type(uint16).max)
                -_prefix(first,last,(position>>16)&type(uint16).max);
        }
    }

    /// @notice Append a logical birth boundary, merging only equal unit/round.
    /// Enrolled count remains exact; no receipt or unit transition is merged away.
    function enroll(Cohorts storage cohort,uint256 end,uint256 rounds,uint256 unit) internal {
        if(end==0)return;
        if(end>1000 || unit==0 || unit>3)revert InvalidAllocation();
        uint256 length=cohort.rows.length;
        if(length!=0){
            uint256 previous;unchecked{previous=cohort.rows[length-1];}
            uint256 last=previous&1023;
            if(end==last)return;
            if(end<last)revert InvalidAllocation();
            if(((previous>>10)&3)==unit && _cohortRound(cohort,length-1,previous)==rounds){
                unchecked{cohort.rows[length-1]=(previous&~uint256(1023))|end;}
                return;
            }
        }
        uint256 row=end|(unit<<10);
        if(rounds>>243!=0){row|=uint256(1)<<255;cohort.wideRounds[length]=rounds;}
        else row|=rounds<<12;
        cohort.rows.push(row);
    }
    /// @notice First recorded cohort at or after a checked NFT ordinal.
    /// Search remains bounded by1000 NFTs, never by receipt history.
    function birth(Cohorts storage cohort,uint256 ordinal) internal view returns(uint256 end,uint256 rounds,uint256 unit){
        if(ordinal==0)revert InvalidAllocation();
        uint256 low;uint256 length=cohort.rows.length;uint256 high=length;
        unchecked {
            while(low<high){
                uint256 middle=(low+high)>>1;
                if((cohort.rows[middle]&1023)<ordinal)low=middle+1;else high=middle;
            }
        }
        if(low==length)revert InvalidAllocation();
        uint256 row=cohort.rows[low];
        end=row&1023;rounds=_cohortRound(cohort,low,row);unit=(row>>10)&3;
    }
    function _cohortRound(Cohorts storage cohort,uint256 index,uint256 row) private view returns(uint256){
        return row>>255==0?row>>12:cohort.wideRounds[index];
    }
    /// @notice Preview exactly the old raw-unit cyclic allocation.
    /// Validation and clipped future intervals are unchanged. The round identity
    /// may wrap in its intermediates; its mathematical result is within amount.
    function previewShare(uint256 amount,uint256 weight,uint256 cursor,
        uint256 firstTicket,uint256 lastTicket) internal pure returns(uint256 value) {
        _validate(weight,cursor);_interval(firstTicket,lastTicket);
        if(firstTicket>weight)return 0;
        if(lastTicket>weight)lastTicket=weight;
        (uint256 next,uint256 turns)=_step(amount,weight,cursor);
        unchecked {
            value=turns*(lastTicket-firstTicket+1)+_prefix(firstTicket,lastTicket,next)
                -_prefix(firstTicket,lastTicket,cursor);
        }
    }
    function _step(uint256 amount,uint256 weight,uint256 cursor)
        private pure returns(uint256 next,uint256 turns) {
        unchecked {
            next=cursor+amount%weight;turns=amount/weight;
            if(next>=weight){next-=weight;++turns;}
        }
    }
    function _prefix(uint256 first,uint256 last,uint256 cursor) private pure returns(uint256){
        if(first>cursor)return 0;
        unchecked{return (last<cursor?last:cursor)-first+1;}
    }
    function _validate(uint256 weight,uint256 cursor) private pure {
        if(weight>3000||cursor>=weight)revert InvalidAllocation();
    }
    function _interval(uint256 first,uint256 last) private pure {
        if(first==0||first>last||last>3000)revert InvalidAllocation();
    }
}
