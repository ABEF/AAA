from pathlib import Path
import json,subprocess,time,hashlib
V=Path('C:/Users/Ali/.codex/visualizations/2026/10/14/01a13899-2be7-76f2-a5d0-72e4804c67b9');O=V/'activation-final-six-20261118/feed-identity01/normal01';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();start=time.monotonic()
with(O/'compiler-input.json').open('rb')as i,(O/'compiler-output.json').open('xb')as o,(O/'stderr.log').open('xb')as e:p=subprocess.run([str(V/'toolchain-0.8.26/solc.exe'),'--standard-json'],stdin=i,stdout=o,stderr=e,timeout=120)
x=json.load((O/'compiler-output.json').open(encoding='utf-8'));r={'exit_code':p.returncode,'seconds':time.monotonic()-start,'errors':[e for e in x.get('errors',[])if e['severity']=='error'],'input_sha256':sha(O/'compiler-input.json'),'output_sha256':sha(O/'compiler-output.json')}
if not r['errors']:
 c=x['contracts']['src/ZZZV4SpotPriceFeed.sol']['ZZZV4SpotPriceFeed'];r.update(runtime=len(c['evm']['deployedBytecode']['object'])//2,creation=len(c['evm']['bytecode']['object'])//2);r.update(runtime_margin=24576-r['runtime'],full_initcode=r['creation']+544,initcode_margin=49152-r['creation']-544)
(O/'RESULT.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8');print(json.dumps(r))
