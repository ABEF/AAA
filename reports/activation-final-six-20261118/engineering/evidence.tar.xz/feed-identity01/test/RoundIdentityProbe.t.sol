// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;
struct MarketState {uint160 sqrtPriceX96;int24 tick;uint24 protocolFee;uint24 lpFee;uint128 liquidity;}
struct Config {bytes32 reviewHash;}
contract RoundIdentity {
 bytes32 public immutable poolId=keccak256("controlled-pool-id");
    function _roundIdOld(Config memory c,MarketState memory state,bytes32 ethIdentity) internal view returns(uint80 roundId) {
        bytes32 poolIdentity=keccak256(abi.encode(
            abi.encode(state.sqrtPriceX96,state.tick,state.protocolFee,state.lpFee),uint256(state.liquidity)));
        roundId=uint80(uint256(keccak256(abi.encode(address(this),block.chainid,poolId,c.reviewHash,poolIdentity,ethIdentity))));
        if(roundId==0)roundId=1;
    }
    function _roundIdNew(Config memory c,MarketState memory state,bytes32 ethIdentity) internal view returns(uint80 roundId) {
        bytes32 poolIdentity;
        // Preserve the nested ABI bytes/uint256 encoding: head(2), length, data(4).
        assembly("memory-safe") {
            let p:=mload(0x40)
            mstore(p,64)
            mstore(add(p,32),and(mload(add(state,128)),0xffffffffffffffffffffffffffffffff))
            mstore(add(p,64),128)
            mstore(add(p,96),and(mload(state),0xffffffffffffffffffffffffffffffffffffffff))
            mstore(add(p,128),signextend(2,mload(add(state,32))))
            mstore(add(p,160),and(mload(add(state,64)),0xffffff))
            mstore(add(p,192),and(mload(add(state,96)),0xffffff))
            poolIdentity:=keccak256(p,224)
        }
        roundId=uint80(uint256(keccak256(abi.encode(address(this),block.chainid,poolId,c.reviewHash,poolIdentity,ethIdentity))));
        if(roundId==0)roundId=1;
    }
 function oldRound(Config calldata c,MarketState calldata m,bytes32 eth)external view returns(uint80){return _roundIdOld(c,m,eth);}
 function newRound(Config calldata c,MarketState calldata m,bytes32 eth)external view returns(uint80){return _roundIdNew(c,m,eth);}
 function dirty(uint256 n)external view returns(uint80,uint80){
  MarketState memory m;Config memory c=Config(bytes32(n));assembly("memory-safe"){mstore(m,n)mstore(add(m,32),xor(n,1))mstore(add(m,64),xor(n,2))mstore(add(m,96),xor(n,3))mstore(add(m,128),xor(n,4))}
  return(_roundIdOld(c,m,bytes32(~n)),_roundIdNew(c,m,bytes32(~n)));
 }
 function sentinels(Config calldata c,MarketState calldata m,bytes32 eth)external view returns(uint80,uint80){
  bytes memory prefix=new bytes(237);for(uint256 i;i<prefix.length;++i)prefix[i]=bytes1(uint8(i));bytes32 h=keccak256(prefix);
  uint80 a=_roundIdOld(c,m,eth);uint80 b=_roundIdNew(c,m,eth);bytes memory suffix=new bytes(155);for(uint256 i;i<suffix.length;++i)suffix[i]=bytes1(uint8(i^67));require(keccak256(prefix)==h&&keccak256(suffix)!=0);return(a,b);
 }
}
contract RoundIdentityProbeTest {
 RoundIdentity p=new RoundIdentity();event IdentityGas(uint256 oldGas,uint256 newGas);
 function _data(uint256 n)private pure returns(Config memory c,MarketState memory m,bytes32 eth){c=Config(bytes32(n));m=MarketState(uint160(n),int24(int256(n)),uint24(n>>8),uint24(n>>20),uint128(~n));eth=keccak256(abi.encode(n));}
 function _expected(Config memory c,MarketState memory m,bytes32 eth)private view returns(uint80 result){
  bytes32 nested=keccak256(abi.encode(abi.encode(m.sqrtPriceX96,m.tick,m.protocolFee,m.lpFee),uint256(m.liquidity)));
  result=uint80(uint256(keccak256(abi.encode(address(p),block.chainid,p.poolId(),c.reviewHash,nested,eth))));if(result==0)result=1;
 }
 function testIdentityCanonicalAllWordsAndOuterRound()external view{
  for(uint256 i;i<128;++i){uint256 n=i==0?0:i==1?type(uint256).max:i==2?uint256(1)<<23:i==3?uint256(1)<<127:uint256(keccak256(abi.encode(i)));
   (Config memory c,MarketState memory m,bytes32 eth)=_data(n);uint80 a=p.oldRound(c,m,eth);require(a==_expected(c,m,eth)&&p.newRound(c,m,eth)==a);}
 }
 function testIdentityKnownSevenWordLayoutAndSignedTicks()external pure{
  int24[7]memory ticks=[type(int24).min,int24(-887272),int24(-1),int24(0),int24(1),int24(887272),type(int24).max];
  for(uint256 i;i<ticks.length;++i){MarketState memory m=MarketState(uint160(123456789+i),ticks[i],123,456,uint128(type(uint128).max-i));
   bytes memory nested=abi.encode(abi.encode(m.sqrtPriceX96,m.tick,m.protocolFee,m.lpFee),uint256(m.liquidity));
   bytes memory fixedWords=abi.encode(uint256(64),uint256(m.liquidity),uint256(128),m.sqrtPriceX96,m.tick,m.protocolFee,m.lpFee);
   require(nested.length==224&&keccak256(nested)==keccak256(fixedWords));}
 }
 function testIdentityDirtyNarrowWords()external view{for(uint256 i;i<64;++i){uint256 n=i==0?0:i==1?type(uint256).max:uint256(keccak256(abi.encode(i)));(uint80 a,uint80 b)=p.dirty(n);require(a==b&&a!=0);}}
 function testIdentityMemorySentinels()external view{(Config memory c,MarketState memory m,bytes32 eth)=_data(type(uint256).max);(uint80 a,uint80 b)=p.sentinels(c,m,eth);require(a==b&&a==_expected(c,m,eth));}
 function testIdentityGas()external{(Config memory c,MarketState memory m,bytes32 eth)=_data(type(uint256).max);
  uint256 a=gasleft();uint80 x=p.oldRound(c,m,eth);a-=gasleft();uint256 b=gasleft();uint80 y=p.newRound(c,m,eth);b-=gasleft();require(x==y&&b<a);emit IdentityGas(a,b);
 }
}
