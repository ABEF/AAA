// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;
import {ZZZRoyaltyRewards} from "../src/ZZZRoyaltyRewards.sol";
import {ZZZRoyaltyRewardsBaseline} from "../src/ZZZRoyaltyRewardsBaseline.sol";
import {ExactRoyaltyAllocation as Current} from "../src/libraries/ExactRoyaltyAllocation.sol";
import {ExactRoyaltyAllocationBaseline as Frozen} from "../src/libraries/ExactRoyaltyAllocationBaseline.sol";

interface VmRoyaltyStatus {
    function warp(uint256) external;
    function deal(address,uint256) external;
    function prank(address) external;
    function expectRevert(bytes4) external;
}
interface RoyaltyPublic {
    function activate(uint256,uint256) external;
    function addAsset(address) external;
    function setMintEnd(uint64) external;
    function sync(address) external returns(uint256);
    function claim(uint256,address) external returns(uint256);
    function claimable(uint256,address) external view returns(uint256);
    function activationCount() external view returns(uint256);
    function totalWeight() external view returns(uint256);
    function eligibleCount(address) external view returns(uint256);
    function eligibleWeight(address) external view returns(uint256);
    function allocationCursor(address) external view returns(uint256);
    function liabilities(address) external view returns(uint256);
    function orphaned(address) external view returns(uint256);
    function openingPool(address) external view returns(uint256);
    function accounted(address) external view returns(uint256);
    function canonicalCapture() external;
    function canonicalSettle() external;
    function canonicalCount() external view returns(uint256);
    function canonicalExport(uint256) external view returns(bytes memory);
    function canonicalImport(uint256,bytes calldata) external;
    function canonicalValidate() external view;
    function canonicalActivate() external;
    function canonicalRelease(uint256,address) external;
    function canonicalAccept(uint256,address) external payable;
    function canonicalRestore(uint256,address) external payable;
    function canonicalRecoverCancelled(address,address) external returns(uint256);
}
contract StatusNFT {
    mapping(uint256=>address) public ownerOf;
    mapping(uint256=>uint8) public rarityOf;
    uint256 public mintedCount;
    address public claimRouter;
    function put(uint256 id,uint256 weight,address owner) external {ownerOf[id]=owner;rarityOf[id]=uint8(weight-1);if(id>mintedCount)mintedCount=id;}
    function tokenAtOrdinal(uint256 ordinal) external pure returns(uint256){return ordinal;}
    function activate(address r,uint256 id,uint256 w) external {RoyaltyPublic(r).activate(id,w);}
    function add(address r,address asset) external {RoyaltyPublic(r).addAsset(asset);}
    function end(address r,uint64 t) external {RoyaltyPublic(r).setMintEnd(t);}
}
contract StatusPolicy {
    function royaltySyncGas() external pure returns(uint256){return 1_000_000;}
    function royaltyBalanceGas() external pure returns(uint256){return 50_000;}
}
contract StatusControl {
    uint8 public canonicalState;
    address public canonicalHandoff;
    address public protocolPolicy;
    address private nft;
    constructor(address n,address p){nft=n;protocolPolicy=p;canonicalHandoff=msg.sender;}
    function state(uint8 s) external {require(msg.sender==canonicalHandoff);canonicalState=s;}
    function canConfigure(address a) external view returns(bool){return a==canonicalHandoff;}
    function isSealed() external pure returns(bool){return true;}
    function paused() external pure returns(bool){return false;}
    function preparationActive() external pure returns(bool){return false;}
    function module(bytes32) external view returns(address){return nft;}
}
contract StatusToken {
    mapping(address=>uint256) private balances;
    bool public fault;
    function setFault(bool f) external {fault=f;}
    function balanceOf(address a) external view returns(uint256){require(!fault,"controlled currency fault");return balances[a];}
    function mint(address a,uint256 n) external {balances[a]+=n;}
    function transfer(address to,uint256 n) external returns(bool){balances[msg.sender]-=n;balances[to]+=n;return true;}
}
contract CurrentBookHarness {
    using Current for Current.Book;using Current for Current.Cohorts;
    Current.Book private book;Current.Cohorts private cohort;
    uint256 private liability;
    function prime(uint256 q,uint256 c,uint256 init) external {
        uint256 word=(init<<16)|c;
        if(q>>223!=0){book.wideRounds=q;word|=uint256(1)<<255;}
        else word|=q<<32;
        book.packed=word;liability=0;
    }
    function credit(uint256 a,uint256 w,uint256 c) external returns(uint256 next){(next,liability)=book.credit(a,w,c,liability);}
    function logical() external view returns(uint256,uint256,uint256){return(book.rounds(),uint16(book.packed),uint16(book.packed>>16));}
    function gross(uint256 f,uint256 l) external view returns(uint256){return book.gross(f,l);}
    function enroll(uint256 n,uint256 q) external {cohort.enroll(n,q);}
    function birth(uint256 n) external view returns(uint256,uint256){return cohort.birth(n);}
}
contract FrozenBookHarness {
    using Frozen for Frozen.Book;
    Frozen.Book private book;uint256 private liability;
    function prime(uint256 q,uint256 c,uint256 init) external {book.rounds=q;book.position=c|(init<<16)|(uint256(1)<<32);liability=0;}
    function credit(uint256 a,uint256 w,uint256 c) external returns(uint256 next){(next,liability)=book.credit(a,w,c,liability);}
    function logical() external view returns(uint256,uint256,uint256){return(book.rounds,uint16(book.position),uint16(book.position>>16));}
    function gross(uint256 f,uint256 l) external view returns(uint256){return book.gross(f,l);}
}
contract ExactRoyaltyStatusBook20261118Test {
    VmRoyaltyStatus constant vm=VmRoyaltyStatus(address(uint160(uint256(keccak256("hevm cheat code")))));
    StatusNFT private nft;StatusPolicy private policy;StatusToken private token;
    RoyaltyPublic private old;RoyaltyPublic private current;
    StatusControl private oldControl;StatusControl private currentControl;
    event ComponentGas(string scenario,uint256 baselineGas,uint256 candidateGas);
    receive() external payable {}
    function eq(uint256 a,uint256 b) private pure {require(a==b,"logical mismatch");}
    function _init() private {
        vm.warp(1000);vm.deal(address(this),1 ether);
        nft=new StatusNFT();policy=new StatusPolicy();token=new StatusToken();
        ZZZRoyaltyRewardsBaseline o=new ZZZRoyaltyRewardsBaseline(address(nft));
        ZZZRoyaltyRewards c=new ZZZRoyaltyRewards(address(nft));old=RoyaltyPublic(address(o));current=RoyaltyPublic(address(c));
        oldControl=new StatusControl(address(nft),address(policy));currentControl=new StatusControl(address(nft),address(policy));
        o.bindCanonicalController(address(oldControl));c.bindCanonicalController(address(currentControl));
        nft.end(address(old),1010);nft.end(address(current),1010);
        nft.add(address(old),address(token));nft.add(address(current),address(token));
    }
    function _activate(uint256 id,uint256 w) private {
        nft.put(id,w,address(uint160(0xB000+id)));
        nft.activate(address(old),id,w);nft.activate(address(current),id,w);
    }
    function _fund(uint256 n) private {
        (bool a,)=address(old).call{value:n}("");(bool b,)=address(current).call{value:n}("");require(a&&b);
        token.mint(address(old),n);token.mint(address(current),n);
    }
    function _same(address asset,uint256 ids) private view {
        eq(old.eligibleCount(asset),current.eligibleCount(asset));eq(old.eligibleWeight(asset),current.eligibleWeight(asset));
        eq(old.allocationCursor(asset),current.allocationCursor(asset));eq(old.accounted(asset),current.accounted(asset));
        eq(old.liabilities(asset),current.liabilities(asset));eq(old.openingPool(asset),current.openingPool(asset));eq(old.orphaned(asset),current.orphaned(asset));
        for(uint256 id=1;id<=ids;++id)eq(old.claimable(id,asset),current.claimable(id,asset));
    }
    function _claimBoth(uint256 id,address asset) private {
        address owner=nft.ownerOf(id);vm.prank(owner);uint256 a=old.claim(id,asset);
        vm.prank(owner);uint256 b=current.claim(id,asset);eq(a,b);
    }
    function testExactBookInlineWideAndModularWrap() public {
        CurrentBookHarness c=new CurrentBookHarness();FrozenBookHarness f=new FrozenBookHarness();
        uint256[7] memory rounds=[uint256(0),1,(uint256(1)<<223)-1,uint256(1)<<223,uint256(1)<<244,type(uint256).max-2,type(uint256).max];
        uint256[6] memory amounts=[uint256(1),2999,3000,9001,uint256(1)<<255,type(uint256).max];
        for(uint256 q;q<rounds.length;++q)for(uint256 a;a<amounts.length;++a){
            uint256 cursor=(q*333)%3000;uint256 init=(a*177)%3000;
            c.prime(rounds[q],cursor,init);f.prime(rounds[q],cursor,init);
            uint256 nc=c.credit(amounts[a],3000,cursor);eq(nc,f.credit(amounts[a],3000,cursor));
            (uint256 cq,uint256 cc,uint256 ci)=c.logical();(uint256 fq,uint256 fc,uint256 fi)=f.logical();eq(cq,fq);eq(cc,fc);eq(ci,fi);
            eq(c.gross(1,3000),f.gross(1,3000));eq(c.gross(2,4),f.gross(2,4));eq(c.gross(2997,3000),f.gross(2997,3000));
        }
        // Exact all-zero compact state after lifetime wrap is a valid zero base.
        c.prime(type(uint256).max,0,0);f.prime(type(uint256).max,0,0);
        eq(c.credit(1,1,0),f.credit(1,1,0));eq(c.gross(1,1),f.gross(1,1));
        eq(c.credit(1,1,0),f.credit(1,1,0));eq(c.gross(1,1),f.gross(1,1));
    }
    function testGenericCohortValidationRetained() public {
        CurrentBookHarness c=new CurrentBookHarness();c.enroll(0,10);
        c.enroll(1,7);c.enroll(1000,type(uint256).max);
        (uint256 end,uint256 q)=c.birth(1);eq(end,1);eq(q,7);
        (end,q)=c.birth(1000);eq(end,1000);eq(q,type(uint256).max);
        vm.expectRevert(Current.InvalidAllocation.selector);c.enroll(999,8);
        vm.expectRevert(Current.InvalidAllocation.selector);c.enroll(1001,8);
        vm.expectRevert(Current.InvalidAllocation.selector);c.birth(0);
        vm.expectRevert(Current.InvalidAllocation.selector);c.birth(1001);
    }
    function testEmptyBookLateFirstCursorIsExact() public {
        CurrentBookHarness c=new CurrentBookHarness();FrozenBookHarness f=new FrozenBookHarness();
        eq(c.credit(47,3000,1777),f.credit(47,3000,1777));
        (uint256 cq,uint256 cc,uint256 ci)=c.logical();(uint256 fq,uint256 fc,uint256 fi)=f.logical();
        eq(cq,fq);eq(cc,fc);eq(ci,fi);eq(ci,1777);
        eq(c.gross(1,3000),f.gross(1,3000));eq(c.gross(1775,1782),f.gross(1775,1782));
    }
    function testActualNormalizedTwoAndThreeBecomeUnitOne() public {
        for(uint256 w=2;w<=3;++w){
            _init();vm.warp(4610);_activate(1,w);_fund(11);_activate(2,w);_fund(7);_activate(3,1);
            _same(address(0),3);_same(address(token),3);eq(current.claimable(3,address(token)),0);
            _fund(2*w+1);_same(address(0),3);_same(address(token),3);
            for(uint256 id=1;id<=3;++id){_claimBoth(id,address(0));_claimBoth(id,address(token));}
            eq(current.accounted(address(0)),0);eq(current.accounted(address(token)),0);
        }
    }
    function testOpeningOriginalCurrencyFutureRightsAndCurrentOwner() public {
        _init();_activate(1,1);_activate(2,2);_fund(7);vm.warp(4610);_activate(3,3);
        _same(address(0),3);_same(address(token),3);eq(current.claimable(1,address(token)),3);eq(current.claimable(2,address(token)),4);eq(current.claimable(3,address(token)),0);
        nft.put(2,2,address(0xC222));
        for(uint256 id=1;id<=3;++id){_claimBoth(id,address(0));_claimBoth(id,address(token));}
        eq(current.liabilities(address(0)),0);eq(current.liabilities(address(token)),0);
        _fund(6);_same(address(0),3);_same(address(token),3);
        for(uint256 id=1;id<=3;++id){_claimBoth(id,address(0));_claimBoth(id,address(token));}
        eq(current.accounted(address(0)),0);eq(current.accounted(address(token)),0);
    }
    function testFaultedCurrencyKeepsCutoffThenEnrollsWaitingNFT() public {
        _init();_activate(1,2);_activate(2,3);_fund(11);token.setFault(true);vm.warp(4610);_activate(3,1);
        eq(current.eligibleCount(address(token)),2);eq(current.eligibleWeight(address(token)),5);
        _same(address(0),3);token.setFault(false);old.sync(address(token));current.sync(address(token));
        _same(address(token),3);eq(current.claimable(3,address(token)),0);
        for(uint256 id=1;id<=3;++id)_claimBoth(id,address(token));
        eq(current.liabilities(address(token)),0);_fund(6);_same(address(token),3);
    }
    function testActual16CurrencyOpeningComponentSavings() public {
        _init();_activate(1,1);_activate(2,2);
        StatusToken[15] memory extras;
        for(uint256 i;i<15;++i){extras[i]=new StatusToken();nft.add(address(old),address(extras[i]));nft.add(address(current),address(extras[i]));extras[i].mint(address(old),7);extras[i].mint(address(current),7);}
        _fund(7);vm.warp(4610);nft.put(3,3,address(0xB003));
        uint256 g=gasleft();nft.activate(address(old),3,3);uint256 oldGas=g-gasleft();
        g=gasleft();nft.activate(address(current),3,3);uint256 newGas=g-gasleft();
        emit ComponentGas("16ERC20+ETH opening; warm component not cold full Entry",oldGas,newGas);require(newGas<oldGas,"no component improvement");
        _same(address(0),3);_same(address(token),3);
        for(uint256 i;i<15;++i)_same(address(extras[i]),3);
    }
    function _handoff(bool aborting) private {
        _init();_activate(1,2);_activate(2,3);_fund(11);vm.warp(4610);_activate(3,1);
        // Current source, actual imported flat rights, deliberately synchronized target prefunds.
        RoyaltyPublic source=current;StatusControl sourceControl=currentControl;
        ZZZRoyaltyRewards targetHost=new ZZZRoyaltyRewards(address(nft));RoyaltyPublic target=RoyaltyPublic(address(targetHost));
        StatusControl targetControl=new StatusControl(address(nft),address(policy));targetHost.bindCanonicalController(address(targetControl));
        nft.end(address(target),5000);nft.add(address(target),address(token));
        (bool ok,)=address(target).call{value:2}("");require(ok);token.mint(address(target),3);
        target.sync(address(0));target.sync(address(token));eq(target.openingPool(address(0)),2);eq(target.openingPool(address(token)),3);
        sourceControl.state(1);source.canonicalCapture();source.canonicalSettle();targetControl.state(2);
        uint256 rows=source.canonicalCount();for(uint256 row;row<rows;++row)target.canonicalImport(row,source.canonicalExport(row));
        target.canonicalValidate();eq(target.openingPool(address(0)),0);eq(target.openingPool(address(token)),0);
        eq(target.orphaned(address(0)),2);eq(target.orphaned(address(token)),3);
        source.canonicalRelease(0,address(target));target.canonicalAccept(0,address(source));
        source.canonicalRelease(1,address(target));target.canonicalAccept(1,address(source));
        if(aborting){
            targetControl.state(4);target.canonicalRelease(0,address(source));source.canonicalRestore(0,address(target));
            target.canonicalRelease(1,address(source));source.canonicalRestore(1,address(target));sourceControl.state(0);
            target.canonicalRecoverCancelled(address(0),address(source));target.canonicalRecoverCancelled(address(token),address(source));
            eq(address(target).balance,0);eq(token.balanceOf(address(target)),0);
            for(uint256 id=1;id<=3;++id){vm.prank(nft.ownerOf(id));source.claim(id,address(token));}
            eq(source.liabilities(address(token)),0);
        }else{
            target.canonicalActivate();sourceControl.state(3);targetControl.state(0);
            uint256 sum;for(uint256 id=1;id<=3;++id){sum+=target.claimable(id,address(token));vm.prank(nft.ownerOf(id));target.claim(id,address(token));}
            eq(sum,11);eq(target.liabilities(address(token)),0);eq(target.orphaned(address(token)),3);
            token.mint(address(target),6);uint256 later;
            for(uint256 id=1;id<=3;++id){later+=target.claimable(id,address(token));vm.prank(nft.ownerOf(id));target.claim(id,address(token));}
            eq(later,6);eq(target.liabilities(address(token)),0);
        }
    }
    function testCanonicalFlattenImportPrefundsAndFuturePayouts() public {_handoff(false);}
    function testCanonicalAbortReturnsBackingAndPreservesSourceRights() public {_handoff(true);}
}
