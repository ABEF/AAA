// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;
struct MarketState { uint160 sqrtPriceX96; int24 tick; uint24 protocolFee; uint24 lpFee; uint128 liquidity; }
abstract contract CodecBase {
    struct ExecutionMarket {
        address core; address stateView; bytes32 poolId;
        MarketState origin; bytes32 expected;
    }
    struct ExecutionVenue {
        address core; address stateView; bytes32 poolId; MarketState expected;
        bool omitLiquidity;
    }
    struct Execution {
        address owner; address zzz; bytes32 ethPolicy; bytes32 zzzPolicy;
        bytes32 sequencerPolicy; uint64 sourceRevision; bytes32 gasPolicy;
        bytes32[4] roundHashes; bytes32[2] fingerprints;
        uint256[4] bounds; uint8 zzzDigits;
        ExecutionMarket[2] markets;
        bool managerLoan; bool swapped; bool pendingSwap; bytes32 destination;
        ExecutionVenue venue;
    }

    error InvalidState();
    bytes32 internal constant EXECUTION_LENGTH=keccak256("ZZZ_ORACLE_EXECUTION_LENGTH_V1");
    bytes32 internal constant EXECUTION_WORDS=keccak256("ZZZ_ORACLE_EXECUTION_WORDS_V1");
    uint256 internal constant EXECUTION_BYTES=49*32;
    uint256 internal constant QUOTE_FINGERPRINT_WORD=11;
    uint256 internal constant QUOTE_BOUNDS_WORD=13;
    uint256 internal constant QUOTE_DIGITS_WORD=17;
    uint256 internal constant QUOTE_PENDING_WORD=38;
    function _executionLength() internal view returns(uint256 length) {
        bytes32 slot=EXECUTION_LENGTH;
        assembly("memory-safe"){length:=tload(slot)}
        if(length!=0 && length!=EXECUTION_BYTES)revert InvalidState();
    }
    function _executionWord(uint256 index) internal view returns(uint256 word) {
        bytes32 base=EXECUTION_WORDS;
        assembly("memory-safe"){word:=tload(add(base,index))}
    }
    function _saveExecution(Execution memory c) internal {
        bytes memory encoded=abi.encode(c);uint256 length=encoded.length;
        if(length!=EXECUTION_BYTES)revert InvalidState();
        uint256 previous=_executionLength();bytes32 base=EXECUTION_WORDS;bytes32 slot=EXECUTION_LENGTH;
        assembly("memory-safe"){
            for{let i:=0}lt(i,length){i:=add(i,32)}{
                tstore(add(base,div(i,32)),mload(add(add(encoded,32),i)))
            }
            for{let i:=length}lt(i,previous){i:=add(i,32)}{tstore(add(base,div(i,32)),0)}
            tstore(slot,length)
        }
    }
    function _clearExecution() internal {
        uint256 length=_executionLength();bytes32 base=EXECUTION_WORDS;bytes32 slot=EXECUTION_LENGTH;
        assembly("memory-safe"){
            for{let i:=0}lt(i,length){i:=add(i,32)}{tstore(add(base,div(i,32)),0)}
            tstore(slot,0)
        }
    }
    function _loadQuote() internal view virtual returns(Execution memory);
    function store(Execution calldata c) external {_saveExecution(c);}
    function clear() external {_clearExecution();}
    function testLength(uint256 n) external {bytes32 slot=EXECUTION_LENGTH;assembly{tstore(slot,n)}}
    function mutate() external {Execution memory c=_loadQuote(); c.pendingSwap=!c.pendingSwap;
        c.bounds[0]^=type(uint256).max;_saveExecution(c);}
    function memorySentinels() external view returns(bytes32 h){bytes memory a=new bytes(129);for(uint256 i;i<a.length;++i)a[i]=bytes1(uint8(i));
        bytes32 beforeHash=keccak256(a);Execution memory c=_loadQuote();bytes memory b=new bytes(163);
        for(uint256 i;i<b.length;++i)b[i]=bytes1(uint8(i^99));require(keccak256(a)==beforeHash);
        h=keccak256(abi.encode(c));require(keccak256(b)!=0);}
    function readHash() external view returns(bytes32){return keccak256(abi.encode(_loadQuote()));}
}
contract OldCodec is CodecBase {
    function _loadQuote() internal view override returns(Execution memory c) {
        if(_executionLength()==0)return c;
        c.owner=address(uint160(_executionWord(0)));c.zzz=address(uint160(_executionWord(1)));
        c.ethPolicy=bytes32(_executionWord(2));c.zzzPolicy=bytes32(_executionWord(3));
        c.sequencerPolicy=bytes32(_executionWord(4));c.sourceRevision=uint64(_executionWord(5));
        c.gasPolicy=bytes32(_executionWord(6));
        for(uint256 i;i<2;++i)c.fingerprints[i]=bytes32(_executionWord(QUOTE_FINGERPRINT_WORD+i));
        for(uint256 i;i<4;++i)c.bounds[i]=_executionWord(QUOTE_BOUNDS_WORD+i);
        c.zzzDigits=uint8(_executionWord(QUOTE_DIGITS_WORD));
        c.pendingSwap=_executionWord(QUOTE_PENDING_WORD)!=0;
    }
}
contract NewCodec is CodecBase {
    function _loadQuote() internal view override returns(Execution memory c) {
        if(_executionLength()==0)return c;
        bytes32 base=EXECUTION_WORDS;
        // Project only canonical typed words used by the quote/control getters.
        // Full mutable-boundary validation still reads the complete49-word record.
        assembly ("memory-safe") {
            function words(dst,src,count,area) {
                for {let i:=0}lt(i,count){i:=add(i,1)} {
                    mstore(add(dst,mul(i,32)),tload(add(area,add(src,i))))
                }
            }
            words(c,0,7,base)
            words(mload(add(c,256)),11,2,base)
            words(mload(add(c,288)),13,4,base)
            mstore(add(c,320),tload(add(base,17)))
            mstore(add(c,448),tload(add(base,38)))
        }
    }
}
contract QuoteProbeTest {
    OldCodec old=new OldCodec();NewCodec fresh=new NewCodec();
    event QuoteGas(uint256 oldGas,uint256 newGas);
    function _data(uint256 n)private pure returns(CodecBase.Execution memory c){
        c.owner=address(uint160(n|1));c.zzz=address(type(uint160).max);
        c.ethPolicy=keccak256(abi.encode(n));c.zzzPolicy=bytes32(n);c.sequencerPolicy=bytes32(~n);
        c.sourceRevision=uint64(n);c.gasPolicy=bytes32(n<<5);
        for(uint256 i;i<4;++i)c.roundHashes[i]=keccak256(abi.encode(n,i));
        for(uint256 i;i<2;++i)c.fingerprints[i]=keccak256(abi.encode(i,n));
        for(uint256 i;i<4;++i)c.bounds[i]=n^(1<<i);
        c.zzzDigits=uint8(n);
        for(uint256 i;i<2;++i){
            c.markets[i].core=address(uint160(n^i));c.markets[i].stateView=address(uint160(~(n^i)));
            c.markets[i].poolId=bytes32(n^i);c.markets[i].expected=bytes32(~(n^i));
            c.markets[i].origin=MarketState(uint160(n^i),i==0?type(int24).min:type(int24).max,uint24(n>>(3+i)),uint24(n>>(5+i)),uint128(n^i));
        }
        c.managerLoan=n&1!=0;c.swapped=n&2!=0;c.pendingSwap=n&4!=0;c.destination=bytes32(n<<8);
        c.venue.core=address(uint160(n>>2));c.venue.stateView=address(uint160(n>>4));c.venue.poolId=bytes32(n>>6);
        c.venue.expected=MarketState(uint160(~n),int24(int256(~n)),uint24(~n),uint24(n),uint128(~n));
        c.venue.omitLiquidity=n&8!=0;
    }
    function _expected(CodecBase.Execution memory c)private pure returns(bytes32){
        CodecBase.Execution memory e;
        e.owner=c.owner;e.zzz=c.zzz;e.ethPolicy=c.ethPolicy;e.zzzPolicy=c.zzzPolicy;
        e.sequencerPolicy=c.sequencerPolicy;e.sourceRevision=c.sourceRevision;e.gasPolicy=c.gasPolicy;
        e.fingerprints=c.fingerprints;e.bounds=c.bounds;e.zzzDigits=c.zzzDigits;e.pendingSwap=c.pendingSwap;
        return keccak256(abi.encode(e));
    }
    function testPartialQuoteEmptyMatchesZero()external view {
        CodecBase.Execution memory zero;require(old.readHash()==_expected(zero));require(fresh.readHash()==old.readHash());}
    function testPartialQuoteAllSelectedAndUnselectedFields()external {
        for(uint256 i;i<32;++i){
            uint256 n=i==0?0:i==1?type(uint256).max:uint256(keccak256(abi.encode(i)));
            CodecBase.Execution memory c=_data(n);old.store(c);fresh.store(c);
            require(old.readHash()==_expected(c));require(fresh.readHash()==_expected(c));
        }
    }
    function testPartialQuoteRejectsInvalidLength()external {
        uint256[4] memory bad=[uint256(1),uint256(1567),uint256(1569),type(uint256).max];
        for(uint256 i;i<bad.length;++i){old.testLength(bad[i]);fresh.testLength(bad[i]);
            (bool a,bytes memory x)=address(old).staticcall(abi.encodeWithSelector(old.readHash.selector));
            (bool b,bytes memory y)=address(fresh).staticcall(abi.encodeWithSelector(fresh.readHash.selector));
            require(!a&&!b&&keccak256(x)==keccak256(y)&&x.length==4);}
    }
    function testPartialQuoteSaveMutateClearAndRecapture()external {
        CodecBase.Execution memory c=_data(13);old.store(c);fresh.store(c);old.mutate();fresh.mutate();
        c.pendingSwap=!c.pendingSwap;c.bounds[0]^=type(uint256).max;
        require(old.readHash()==_expected(c));require(fresh.readHash()==old.readHash());
        old.clear();fresh.clear();CodecBase.Execution memory zero;require(old.readHash()==_expected(zero));
        require(fresh.readHash()==old.readHash());c=_data(0);old.store(c);fresh.store(c);require(fresh.readHash()==_expected(c));
    }
    function testPartialQuoteMemorySentinelsPreserved()external {
        CodecBase.Execution memory c=_data(type(uint256).max);old.store(c);fresh.store(c);
        require(old.memorySentinels()==_expected(c));require(fresh.memorySentinels()==old.memorySentinels());
    }
    function testPartialQuoteGas()external {
        CodecBase.Execution memory c=_data(type(uint256).max);old.store(c);fresh.store(c);
        uint256 a=gasleft();bytes32 original=old.readHash();a-=gasleft();
        uint256 b=gasleft();bytes32 candidate=fresh.readHash();b-=gasleft();
        require(original==candidate && b<a);emit QuoteGas(a,b);
    }
}
