// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;
struct MarketState { uint160 sqrtPriceX96; int24 tick; uint24 protocolFee; uint24 lpFee; uint128 liquidity; }
struct Round { uint80 round; int256 answer; uint256 startedAt; uint256 updatedAt; uint80 answeredInRound; }
abstract contract HashBase {
    function _roundHash(Round memory r) internal pure virtual returns(bytes32);
    function _marketHash(MarketState memory r) internal pure virtual returns(bytes32);
    function _spotHash(MarketState memory r) internal pure virtual returns(bytes32);
    function all(Round calldata r,MarketState calldata m)external pure returns(bytes32,bytes32,bytes32){return(_roundHash(r),_marketHash(m),_spotHash(m));}
    function dirty(uint256 seed)external pure returns(bytes32,bytes32,bytes32){
        Round memory r;MarketState memory m;
        assembly("memory-safe") {
            mstore(r,seed) mstore(add(r,32),xor(seed,1)) mstore(add(r,64),xor(seed,2)) mstore(add(r,96),xor(seed,3)) mstore(add(r,128),xor(seed,4))
            mstore(m,seed) mstore(add(m,32),xor(seed,1)) mstore(add(m,64),xor(seed,2)) mstore(add(m,96),xor(seed,3)) mstore(add(m,128),xor(seed,4))
        }
        return(_roundHash(r),_marketHash(m),_spotHash(m));
    }
    function sentinels(Round calldata r,MarketState calldata m)external pure returns(bytes32,bytes32,bytes32){
        bytes memory prefix=new bytes(137);for(uint256 i;i<prefix.length;++i)prefix[i]=bytes1(uint8(i));bytes32 a=keccak256(prefix);
        (bytes32 rh,bytes32 mh,bytes32 sh)=(_roundHash(r),_marketHash(m),_spotHash(m));
        bytes memory suffix=new bytes(333);for(uint256 i;i<suffix.length;++i)suffix[i]=bytes1(uint8(i^77));
        require(keccak256(prefix)==a && keccak256(suffix)!=0);return(rh,mh,sh);
    }
}
contract OldHash is HashBase {
    function _roundHash(Round memory r)internal pure override returns(bytes32){return keccak256(abi.encode(r));}
    function _marketHash(MarketState memory r)internal pure override returns(bytes32){return keccak256(abi.encode(r));}
    function _spotHash(MarketState memory r)internal pure override returns(bytes32){return keccak256(abi.encode(r.sqrtPriceX96,r.tick,r.protocolFee,r.lpFee));}
}
contract NewHash is HashBase {
    function _roundHash(Round memory round) internal pure override returns(bytes32 hash) {
        assembly("memory-safe") {
            let p:=mload(0x40)
            mstore(p,and(mload(round),0xffffffffffffffffffff))
            mstore(add(p,32),mload(add(round,32)))
            mstore(add(p,64),mload(add(round,64)))
            mstore(add(p,96),mload(add(round,96)))
            mstore(add(p,128),and(mload(add(round,128)),0xffffffffffffffffffff))
            hash:=keccak256(p,160)
        }
    }
    function _marketHash(MarketState memory state) internal pure override returns(bytes32 hash) {
        assembly("memory-safe") {
            let p:=mload(0x40)
            mstore(p,and(mload(state),0xffffffffffffffffffffffffffffffffffffffff))
            mstore(add(p,32),signextend(2,mload(add(state,32))))
            mstore(add(p,64),and(mload(add(state,64)),0xffffff))
            mstore(add(p,96),and(mload(add(state,96)),0xffffff))
            mstore(add(p,128),and(mload(add(state,128)),0xffffffffffffffffffffffffffffffff))
            hash:=keccak256(p,160)
        }
    }
    function _spotHash(MarketState memory state) internal pure override returns(bytes32 hash) {
        assembly("memory-safe") {
            let p:=mload(0x40)
            mstore(p,and(mload(state),0xffffffffffffffffffffffffffffffffffffffff))
            mstore(add(p,32),signextend(2,mload(add(state,32))))
            mstore(add(p,64),and(mload(add(state,64)),0xffffff))
            mstore(add(p,96),and(mload(add(state,96)),0xffffff))
            hash:=keccak256(p,128)
        }
    }
}
contract StaticHashProbeTest {
    OldHash old=new OldHash();NewHash fresh=new NewHash();event HashGas(uint256 oldGas,uint256 newGas);
    function _data(uint256 seed)private pure returns(Round memory r,MarketState memory m){
        r=Round(uint80(seed),int256(seed),seed>>1,seed<<1,uint80(~seed));
        m=MarketState(uint160(seed),int24(int256(seed)),uint24(seed>>8),uint24(seed>>20),uint128(~seed));
    }
    function _eq(bytes32 a,bytes32 b,bytes32 c,bytes32 d,bytes32 e,bytes32 f)private pure {require(a==d&&b==e&&c==f);}
    function testStaticHashCanonicalWordsAndSignBoundaries()external view {
        for(uint256 i;i<64;++i){
            uint256 n=i==0?0:i==1?type(uint256).max:i==2?uint256(1)<<23:i==3?uint256(1)<<79:uint256(keccak256(abi.encode(i)));
            (Round memory r,MarketState memory m)=_data(n);
            (bytes32 a,bytes32 b,bytes32 c)=old.all(r,m);(bytes32 d,bytes32 e,bytes32 f)=fresh.all(r,m);_eq(a,b,c,d,e,f);
            require(a==keccak256(abi.encode(r))&&b==keccak256(abi.encode(m))&&c==keccak256(abi.encode(m.sqrtPriceX96,m.tick,m.protocolFee,m.lpFee)));
        }
    }
    function testStaticHashDirtyHighWordsAreCanonicalized()external view {
        for(uint256 i;i<64;++i){uint256 n=i==0?0:i==1?type(uint256).max:uint256(keccak256(abi.encode(i)));
            (bytes32 a,bytes32 b,bytes32 c)=old.dirty(n);(bytes32 d,bytes32 e,bytes32 f)=fresh.dirty(n);_eq(a,b,c,d,e,f);}
    }
    function testStaticHashMemorySentinels()external view {
        (Round memory r,MarketState memory m)=_data(type(uint256).max);
        (bytes32 a,bytes32 b,bytes32 c)=old.sentinels(r,m);(bytes32 d,bytes32 e,bytes32 f)=fresh.sentinels(r,m);_eq(a,b,c,d,e,f);
    }
    function testStaticHashGas()external {
        (Round memory r,MarketState memory m)=_data(type(uint256).max);
        uint256 a=gasleft();(bytes32 ah,bytes32 bh,bytes32 ch)=old.all(r,m);a-=gasleft();
        uint256 b=gasleft();(bytes32 dh,bytes32 eh,bytes32 fh)=fresh.all(r,m);b-=gasleft();_eq(ah,bh,ch,dh,eh,fh);
        require(b<a);emit HashGas(a,b);
    }
}
