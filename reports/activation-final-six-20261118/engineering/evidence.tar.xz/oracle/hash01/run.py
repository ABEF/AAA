from pathlib import Path
import json,hashlib,subprocess,time,os
V=Path('C:/Users/Ali/.codex/visualizations/2026/10/14/01a13899-2be7-76f2-a5d0-72e4804c67b9');O=V/'activation-final-six-20261118/oracle/hash01'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();forge=V/'foundry-v1.4.4/forge.exe';solc=V/'toolchain-0.8.26/solc.exe'
env={k:v for k,v in os.environ.items()if k.upper()in ['SYSTEMROOT','WINDIR','TEMP','TMP','USERPROFILE','APPDATA','LOCALAPPDATA','COMSPEC','PATHEXT']};env['PATH']=str(solc.parent)+';C:/Windows/System32';start=time.monotonic()
with(O/'raw.json').open('xb')as out,(O/'stderr.log').open('xb')as err:
 p=subprocess.run([str(forge),'test','--root',str(O),'--offline','--use',str(solc),'--json','-vv','--match-test','testStaticHash'],env=env,stdout=out,stderr=err,timeout=150)
r={'exit_code':p.returncode,'seconds':time.monotonic()-start,'probe_sha256':sha(O/'test/StaticHashProbe.t.sol'),'candidate_sha256':sha(O/'CANDIDATE_FUNCTIONS.sol.txt')};(O/'EXECUTION.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8');print(json.dumps(r));print((O/'stderr.log').read_text(encoding='utf-8')[:1000]);print((O/'raw.json').read_text(encoding='utf-8')[-5000:])
