# Isolated Oracle quote projection and static hash candidates

These candidates preserve the same execution record, source validation, control checks and every mutable-boundary proof. No ROOT file or existing environment is changed by these experiments. The parent must review/adopt the patch, produce the complete normal graph and remeasure affected complete operations before counting an activation as fitting20M with full20% padding.

## Candidate and checks

The partial getter still projects the same15canonical ABIwords: seven controls, two fingerprints, four bounds, fixed-ZZZdecimals and pendingSwap. The strict zero-or1568byte record-length guard is untouched. Fields are loaded into compiler-allocated nested memory at the same proven layout; only the private canonical typed writer/clear controls transient storage. Full49-word load, live controls, pending checks and all source/round/market validation functions are unchanged.

The quote component has six NEW methods: empty,32canonical vectors with every selected and unselected field distinguished (includingzero/MAX/narrow/signedextremes), invalid lengths1/1567/1569/MAX, repeated save/mutate/clear/recapture, memorysentinels and same-recordgas. Partial loader read/hash saves4716gas:18481→13765. Baseline worst cold trace has34executionBounds+10executionReferenceX96 calls.44×4716=207504 is only a linear component projection, not measured whole-call savings.

A separate static-hash candidate retains exact ABIhash bytes while avoiding generic repeated encoding. Each temporary copy explicitly masks narrow unsignedwords and signextendsint24, so it works even for dirty high memorybits. Round usesfivewords; market usesfive; spot usesfour. A bounded temporary area at the current free-memory pointer is hashed before any further allocation/call. No data pointer escapes. Source validation remains unchanged; hash normalization is not source admission.

Four NEW static-hash methods pass:64canonical vectors and independent ABIgroundtruth,64dirtyhighword vectors, sentinels and gas. Threehashes together11206→10037, saving1169. The feed's nested dynamic poolIdentity hash is unchanged; flattening it would change the wireidentity.

## Normal-source probe

The exact previous closed100-source input is reused with onlyOracle source changed and output selected forOracle. Same0.8.26/Cancun/viaIR/runs1/Yul-disabled settings. Quote-onlyOracle runtime23427, fullinit47941; combinedquote+hash23406, fullinit47920. Combined margins1170runtime/1232init bytes. Baseline23791runtime/48305fullinit. ABI and semantic storage layout are identical. This is Oracle size evidence only, not the48-gate wholegraph admission. Fresh source/runtime pins are still required on adoption.

No financial guard, gas/default limit, right, authority, ABI, canonical payload or environment is changed. Whole-operation savings remain unmeasured. Raw outputs, pinned executables, source hashes and exactpatch are indexed in EVIDENCE_INDEX.json. The original historical component/wholeflow evidence remains at its recorded source.
