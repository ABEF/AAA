from pathlib import Path
import json,hashlib,subprocess,time,os
V=Path('C:/Users/Ali/.codex/visualizations/2026/10/14/01a13899-2be7-76f2-a5d0-72e4804c67b9');O=V/'activation-final-six-20261118/oracle/normal01'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
solc=V/'toolchain-0.8.26/solc.exe';start=time.monotonic()
with(O/'compiler-input.json').open('rb')as inp,(O/'compiler-output.json').open('xb')as out,(O/'stderr.log').open('xb')as err:
 p=subprocess.run([str(solc),'--standard-json'],stdin=inp,stdout=out,stderr=err,timeout=450)
x=json.load((O/'compiler-output.json').open(encoding='utf-8'));errs=[e for e in x.get('errors',[])if e['severity']=='error'];print(json.dumps(errs))
r={'seconds':time.monotonic()-start,'exit_code':p.returncode,'errors':errs,'input_sha256':sha(O/'compiler-input.json'),'output_sha256':sha(O/'compiler-output.json'),'candidate_source_sha256':sha(O/'ZZZOracle.candidate.sol')}
if not errs:
 c=x['contracts']['src/ZZZOracle.sol']['ZZZOracle'];runtime=len(c['evm']['deployedBytecode']['object'])//2;creation=len(c['evm']['bytecode']['object'])//2
 r.update(runtime=runtime,runtime_margin=24576-runtime,creation=creation,full_initcode=creation+64,initcode_margin=49152-creation-64)
(O/'RESULT.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8');print(json.dumps(r))
