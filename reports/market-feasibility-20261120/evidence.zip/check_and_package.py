"""Offline current-evidence binding only. Never sends requests or executes archived code."""
from pathlib import Path
from fractions import Fraction
import datetime as dt, hashlib, json, sys, zipfile

R=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
V=Path(__file__).parent;E=V/'approved-transport';C=E/'capture';D=E/'discovery'
OUT=R/'reports/market-feasibility-20261120'
sys.path.insert(0,str(R))
from zzz_ops.abi import keccak256
def load(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,j):p.write_text(json.dumps(j,indent=2,sort_keys=True,ensure_ascii=False)+'\n',encoding='utf-8',newline='\n')
def words(x):
    assert isinstance(x,str) and x.startswith('0x') and (len(x)-2)%64==0
    return [int(x[i:i+64],16) for i in range(2,len(x),64)]

c=load(C/'CAPTURE.json');rpc=load(C/'RPC.json');analysis=load(E/'RESULTS.json')
assert c['request_count']==len(rpc['rows'])==33
assert c['canonical_final_recheck'] and c['source_pins_unchanged']
assert 0<c['phase_elapsed_seconds']<90 and rpc['maximum_calls']==33 and rpc['maximum_seconds']==90
assert rpc['actual_start_interval_seconds']==2 and rpc['retries']==0
block=c['anchor']['selector'];by={x['label']:x for x in rpc['rows']}
for i,row in enumerate(rpc['rows']):
    wire=C/row['raw_file'];b=wire.read_bytes()
    assert len(b)==row['raw_bytes']<=262144 and sha(wire)==row['raw_sha256']
    assert load(wire)==row['response'] and row['http_status']==200
    req=row['request'];resp=row['response']
    assert req['id']==resp['id']==i+1 and req['jsonrpc']==resp['jsonrpc']=='2.0'
    assert req['method'] in ['eth_chainId','eth_getBlockByNumber','eth_getCode','eth_getStorageAt','eth_call']
    if req['method'] in ['eth_getCode','eth_getStorageAt','eth_call']:assert req['params'][-1]==block
    if i:assert row['started_elapsed_seconds']-rpc['rows'][i-1]['started_elapsed_seconds']>=2
    assert row['timeout_seconds']<=12 and row['finished_elapsed_seconds']<90
assert by['chain']['response']['result']=='0x1237'
assert by['independent-genesis']['response']['result']['hash']=='0xaad15f3d702aaea00caf3e9bb56395efe9127bc3b31b24921abf1eee3409305c'
assert by['fresh-anchor']['response']['result']==by['final-canonical-numbered-header']['response']['result']==c['anchor']['header']==c['final_header']

primary=c['feeds']['chainlink_primary'];secondary=c['feeds']['chainlink_secondary'];pyth=c['feeds']['pyth'];api3=c['feeds']['api3']
assert primary['latestRoundData']==by['chainlink.primary.round']['response']['result']
assert primary['decimals']==by['chainlink.primary.decimals']['response']['result']
assert primary['aggregator']==by['chainlink_primary.aggregator']['response']['result']
assert secondary['aggregator']==by['chainlink_secondary.aggregator']['response']['result']
assert primary['aggregator']==secondary['aggregator']
assert pyth['observation']==by['pyth.observation']['response']['result']
assert api3['observation']=={'rpc_error':by['api3.observation']['response']['error']}
assert words(primary['latestRoundData'])[3]+primary['age_seconds']==c['anchor']['timestamp']
assert len(c['quotes'])==len(analysis['quotes'])==6
assert {(q['venue_label'],q['zero_for_one']) for q in c['quotes']}=={(name,direction) for name in ['selected','largest-known-active-L','cheap-fee-only'] for direction in [True,False]}
for q in c['quotes']:
    wire=by['quote.'+q['venue_label']+'.'+('ETH-to-ZZZ' if q['zero_for_one'] else 'ZZZ-to-ETH')]
    expected=wire['response'].get('result',{'rpc_error':wire['response'].get('error')})
    assert q['result']==expected
    assert q['gas_ceiling']==500000 and q['postspot'] is None and not q['qualified_usd']
    mirror=next(x for x in analysis['quotes'] if x['venue_label']==q['venue_label'] and x['zero_for_one']==q['zero_for_one'])
    assert all(mirror[k]==v for k,v in q.items())
    assert not mirror['whole_operation_qualified']
assert all(sha(R/p)==h for p,h in load(C/'SOURCE_PINS.json').items())
assert analysis['anchor']=={k:v for k,v in c['anchor'].items() if k!='header'}
assert len(c['known_pool_states'])==95
assert analysis['markets']['selected']['active_liquidity']=='0'
assert analysis['feeds']['chainlink']['usd']['numerator']=='17571034017'
assert analysis['feeds']['pyth']['age_seconds']==1147315
assert analysis['feeds']['api3']['current_read']['rpc_error']['data']=='0x8086c764'
assert analysis['sources_qualified']=={'independent_ETH_pair':False,'independent_ZZZ_pair':False}

disc=load(D/'RESULT.json');drpc=load(D/'RPC.json')
assert disc['requests']==len(drpc['rows'])==3 and disc['canonical_closed']
assert disc['range_start']==115708675 and disc['range_end']==c['anchor']['number']==119000058
assert disc['new_pool_keys']==[] and disc['raw_log_count']==0 and not disc['global_inventory_complete']
for i,row in enumerate(drpc['rows']):
    wire=D/row['raw_file'];assert sha(wire)==row['raw_sha256'] and load(wire)==row['response']
    assert row['http_status']==200 and row['request']['method'] in ['eth_getBlockByNumber','eth_getLogs']
    assert row['response'].get('error') is None
    if i:assert row['started_elapsed_seconds']-drpc['rows'][i-1]['started_elapsed_seconds']>=2
assert drpc['rows'][0]['response']['result']==drpc['rows'][2]['response']['result']==c['anchor']['header']
assert drpc['rows'][1]['response']['result']==[]
assert disc['prior_capture_sha256']==sha(C/'CAPTURE.json')
assert disc['initialize_abi_source_sha256']==sha(R/'node_modules/@uniswap/v4-core/src/interfaces/IPoolManager.sol')

failed=load(V/'capture/CAPTURE.json');frpc=load(V/'capture/RPC.json')
assert failed['request_count']==1 and failed['stopped']['exception_type']=='URLError'
assert failed['canonical_final_recheck'] is False and not failed['quotes']
assert 'http_status' not in frpc['rows'][0]

OUT.mkdir(exist_ok=False)
largest=analysis['markets']['active_by_rawL_not_TVL'][0];selected=analysis['markets']['selected']
ratio=Fraction(int(largest['eth_per_zzz']['numerator']),int(largest['eth_per_zzz']['denominator']))/Fraction(int(selected['eth_per_zzz']['numerator']),int(selected['eth_per_zzz']['denominator']))
summary={
 'schema':1,'date':'2026-11-20','source_baseline':c['source_baseline'],
 'anchor':analysis['anchor'],'anchor_utc':analysis['anchor_utc'],
 'canonical_closure':True,'actual_completed_public_HTTP_calls':36,
 'primary':analysis['network'],'discovery':disc,
 'restricted_transport_attempt':{'attempts':1,'response_received':False,'error_class':'URLError','retry_in_that_recorder':False,'further_detail':'No HTTP status or chain result retained; separate tool-authorized network-capable phase used identical recorder in exclusive output path.'},
 'feeds':analysis['feeds'],
 'markets':{k:analysis['markets'][k] for k in ['known_pool_count','active_reference_fee_only_count','active_strict_principal_fee_only_count','selected','active_by_rawL_not_TVL','global_highest_or_ownership_or_depth_qualified']},
 'largest_known_L_ETH_per_ZZZ_ratio_to_selected':{'numerator':str(ratio.numerator),'denominator':str(ratio.denominator),'approximate':float(ratio)},
 'quotes':analysis['quotes'],'source_proof':{'prior_recorder_sha256':sha(V/'old-capture.py'),'current_recorder_sha256':sha(E/'capture.py'),'recorder_delta':'Only source_baseline label changed; transport, methods, budgets, runtime checks and market logic unchanged','analyzer':'Exact prior analyzer, offline data replay only','discovery_delta':'Only starting anchor changed fromNov13 to exact already-closedNov16 anchor; transport/log logic and original bounds unchanged'},
 'sources_qualified':analysis['sources_qualified'],'production_approved':False,
 'deployable_configuration':False,'provider_adopted':False,'routes_adopted':[],
 'safeguards_changed':False,'public_transactions':0,'old_test_suites_rerun':0,
 'limitations':analysis['important_limits']+['No current decimals/admin/owner/burn/tax behavior qualification beyond outer runtime equality.','No newPoolKey in one filtered same-core interval does not prove global/provider-complete discovery.','Primary capture has33requests;95PoolKeys are read via4bulkstoragecalls, not95network requests.','The2positivequotes overlap the6directions and33primaryrequests; not extra scenario successes.','No Pyth update/publication, API3 activation/subscription purchase, provider adoption or governance operation performed.'],
}
save(OUT/'RESULTS.json',summary)
save(OUT/'CANDIDATE_CONFIG.json',load(E/'CANDIDATE_CONFIG.json'))

refs={
 'date':'2026-11-20','scope':'Primary documentation reviewed; reference index, not a raw HTML or signed-service archive.',
 'sources':[
  {'url':'https://docs.chain.link/changelog?product=Data+Feeds','supports':'Robinhood ETH/USD availability is documented; does not establish two independent services or operating policy.'},
  {'url':'https://docs.pyth.network/pro/contract-addresses','supports':'Core stores prices; Pro transaction-signed prices are a different interface. An address alone does not provide fresh publication.'},
  {'url':'https://docs.pyth.network/pro/sponsored-feeds','supports':'Current documented sponsored EVM list does not contain Robinhood; publication owner/transport/funding/recovery needs an explicit operating arrangement. No pusher installed.'},
  {'url':'https://docs.api3.org/dapps/integration/','supports':'API3 standard market plans specify24h heartbeat and3-month mainnet expiry; current activation/subscription is not established by those docs.'},
  {'url':'https://docs.api3.org/dapps/integration/aggregatorv2v3interface.html','supports':'API3 asynchronous prices do not provide meaningful Chainlink rounds; Oracle round-dependent compatibility needs reviewed custom adaptation, not weaker checks.'},
  {'url':'https://market.api3.org/robinhood?search=ETH%2FUSD','supports':'Official market is a commercial service lead; dynamic page did not expose readable activation terms in this tool. No subscription/fees selected.'},
 ],
 'unverified':'No newly authenticated exact-ZZZ independent on-chain price path found in this bounded primary-source review. This is not proof custom/private products or other markets do not exist.'
}
save(OUT/'PRIMARY_SOURCES.json',refs)
checks={'schema':1,'outcome':'PASS','scope':'Fresh artifact semantics and source/transport integrity, not EVM or application test cases',
        'actual_public_HTTP_requests':36,'restricted_transport_attempts':1,'primary_raw_responses_bound':33,
        'discovery_raw_responses_bound':3,'knownPoolKeys':95,'quote_directions_bound':6,
        'positive_quote_results':2,'application_RPC_errors':5,'network_calls_in_checker':0,
        'old_tests_or_suites_rerun':0,'new_application_tests':0,'chain_or_service_writes':0,
        'compiler_runs':0,'production_ready':False,'checker_sha256':sha(Path(__file__)),
        'semantic_claims':['exact canonical anchor and closing header','whitelisted methods/strictrequestIDs/rawresponsehashes','actual2sstartspacing/original90sdeadline/256KiBbound','wire-boundETHround/aggregator/Pyth/API3observations','complete6quoteencoding/value/errorrelationship','samecore/paircontiguousNov16toNov20filtereddiscovery','initialrestrictedURLErrorattemptretained','unchangedrecordermarketlogicwithbaseline-labeldelta']}
save(OUT/'VERIFICATION.json',checks)

# Freeze raw/source/failed-attempt data into a small archive; never execute archive members.
members={}
for p in V.rglob('*'):
    if p.is_file() and p.name!='evidence.zip':members[p.relative_to(V).as_posix()]=p
manifest={name:{'sha256':sha(p),'bytes':p.stat().st_size} for name,p in sorted(members.items())}
archive=OUT/'evidence.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for name,p in sorted(members.items()):z.writestr(name,p.read_bytes())
    z.writestr('manifest.json',(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode())
save(OUT/'EVIDENCE_MANIFEST.json',{'schema':1,'archive':'evidence.zip','bytes':archive.stat().st_size,'sha256':sha(archive),'hashed_members':manifest,'members_including_manifest':len(manifest)+1})
print(json.dumps({'output':str(OUT),'requests':36,'canonical':True,'known_pool_keys':95,'quotes':6,'new_keys':0,'archive_bytes':archive.stat().st_size,'archive_members':len(manifest)+1,'ETH':analysis['feeds']['chainlink']['usd']['decimal'],'largest_reference_ratio':float(ratio)}))
