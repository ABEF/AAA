// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;
import {IZZZBound, IZZZAccess, IZZZVault, IZZZNFT} from "./interfaces/IZZZ.sol";
import {Ids} from "./libraries/ZZZTypes.sol";
import {ZZZCanonicalHandoff} from "./ZZZCanonicalHandoff.sol";
import {ZZZRoyaltyFactory} from "./ZZZRoyaltyFactory.sol";
import {ZZZActivationAssetsFactory} from "./ZZZActivationAssetsFactory.sol";
import {IZZZProtocolPolicy} from "./interfaces/IZZZProtocolPolicy.sol";

interface ICanonicalOwnerBinding {
    function nft() external view returns (address);
    function vault() external view returns (address);
    function fees() external view returns (address);
}
interface IContributionIdentity { function zzz() external view returns (address); }
interface IContributionRegistry { function activationAssets() external view returns (IContributionIdentity); }
interface IExitIdentity { function currentZZZ() external view returns (address); }

/// @notice The selected governance wallet calls configuration directly. Its own
/// signature/nonce policy authorizes operations; there is no timelock or generic
/// transaction executor here. Module bindings are fixed at seal().
contract ZZZAccessController {
    uint256 public constant GOVERNANCE_VERSION = 2;
    address public governance;
    address public pendingGovernance;
    mapping(bytes32 => address) public module;
    mapping(address => bool) public keepers;
    mapping(address => bool) public guardians;
    address public bootstrap;
    bool public isSealed;
    bool public paused;
    /// @notice Irreversible principal retirement; ownership and rewards remain live.
    bool public lpExitStarted;
    bool public preparationActive;
    address public immutable royaltyFactory;
    address public immutable activationAssetsFactory;
    /// @notice Fixed noncustodial policy companion. Only its bounded settings
    /// change after sealing; the companion itself cannot be replaced.
    address public protocolPolicy;
    uint8 public canonicalState;
    bool public canonicalSettling;
    bool public preparationReadyDestination;
    uint256 public preparationNonce;
    bytes32 public preparationHash;
    uint256 public preparationStartedAt;
    /// @dev Public notice only. These commitments do not authenticate a remote
    /// deployment, approve a successor, freeze rights or authorize any export.
    struct PreparationNotice {
        uint256 destinationChain;
        address successorController;
        bytes32 deploymentCommitment;
        bytes32 reviewHash;
    }
    PreparationNotice public preparationNotice;
    event ModuleBound(bytes32 indexed id, address indexed implementation);
    event ProtocolPolicyBound(address indexed implementation, bytes32 codeHash);
    event SystemSealed();
    event PauseChanged(bool paused);
    event LPExitStarted();
    event KeeperChanged(address indexed account, bool enabled);
    event GuardianChanged(address indexed account, bool enabled);
    event PreparationStarted(bytes32 indexed noticeHash, uint256 indexed nonce,
        uint256 indexed destinationChain, address successorController, bytes32 deploymentCommitment, bytes32 reviewHash);
    event PreparationCancelled(bytes32 indexed noticeHash);
    event GovernanceProposed(address indexed governance, address indexed pending);
    event GovernanceAccepted(address indexed previous, address indexed current);
    error Unauthorized();
    error InvalidConfiguration();

    constructor(address initialGovernance, address initialKeeper, address initialGuardian) {
        if (initialGovernance == address(0) || initialGovernance == address(this) ||
            initialKeeper == address(0) || initialGuardian == address(0)) revert InvalidConfiguration();
        governance = initialGovernance;
        bootstrap = msg.sender;
        royaltyFactory = address(new ZZZRoyaltyFactory());
        activationAssetsFactory = address(new ZZZActivationAssetsFactory());
        keepers[initialKeeper] = true;
        emit KeeperChanged(initialKeeper, true);
        guardians[initialGuardian] = true;
        emit GuardianChanged(initialGuardian, true);
    }
    function canConfigure(address account) public view returns (bool) {
        return !preparationActive && ((isSealed && canonicalState == 0 && account == governance) ||
            (!isSealed && account == bootstrap));
    }
    /// @notice No delay. The current wallet proposes; the new wallet must accept
    /// to prevent an address typo silently destroying governance. Zero cancels.
    function proposeGovernance(address candidate) external {
        if (msg.sender != governance || canonicalState != 0 || preparationActive) revert Unauthorized();
        if (candidate == address(this) || candidate == governance) revert InvalidConfiguration();
        pendingGovernance = candidate;
        emit GovernanceProposed(governance,candidate);
    }
    function acceptGovernance() external {
        if (msg.sender != pendingGovernance || msg.sender == address(0) ||
            canonicalState != 0 || preparationActive) revert Unauthorized();
        address previous=governance;governance=msg.sender;pendingGovernance=address(0);
        emit GovernanceAccepted(previous,msg.sender);
    }
    function canonicalHandoff() public view returns (address) { return module[Ids.CANONICAL]; }
    /// @dev One fail-closed authorization read keeps the immutable modules small.
    function moduleAuthorized(bytes32 id, address caller) external view returns (bool) {
        return isSealed && canonicalState == 0 && caller != address(0) && caller == module[id];
    }
    function keeperAuthorized(address caller) external view returns (bool) {
        return isSealed && canonicalState == 0 && keepers[caller];
    }
    /// @notice Only the Vault's nonreentrant Migration entry can commit this
    /// terminal lock. Ordinary unpause cannot reopen contributions or maintenance.
    function startLPExit() external {
        if (msg.sender != module[Ids.VAULT] || !isSealed || !paused || lpExitStarted ||
            preparationActive || canonicalState != 0) revert Unauthorized();
        lpExitStarted = true;
        emit LPExitStarted();
    }
    /// @dev Only the immutable coordinator may change canonical authority.
    /// Pause/unpause and ordinary governance never bypass terminal retirement.
    function canonicalTransition(uint8 state, bool settling, bool clearPreparation) external {
        if (lpExitStarted || msg.sender != canonicalHandoff() || msg.sender == address(0) || state > 4 || (settling && state != 1)) revert Unauthorized();
        // States 3/4 are terminal; any impossible higher state also fails closed.
        if (canonicalState > 2) revert InvalidConfiguration();
        canonicalState = state;
        canonicalSettling = settling;
        if (clearPreparation) preparationActive = false;
    }
    /// @notice Announce a cancellable preparation window through the existing
    /// controller, without a waiting period. The source remains the sole canonical authority.
    function startPreparation(PreparationNotice calldata notice) external {
        if (msg.sender != governance || !isSealed || preparationActive || lpExitStarted || canonicalState != 0) revert Unauthorized();
        if (IZZZVault(module[Ids.VAULT]).canonicalChainId() != block.chainid ||
            notice.destinationChain != block.chainid || notice.successorController == address(0) ||
            (notice.destinationChain == block.chainid && notice.successorController == address(this)) ||
            notice.deploymentCommitment == bytes32(0) || notice.reviewHash == bytes32(0)) revert InvalidConfiguration();
        preparationReadyDestination = false;
        if (notice.destinationChain == block.chainid && notice.successorController.code.length != 0) {
            IZZZAccess destination = IZZZAccess(notice.successorController);
            // Freeze cannot authenticate a configuration that bootstrap changed
            // after the notice was reviewed. A usable local importer is already
            // sealed, inert and bound to this source when announcement executes.
            if (!destination.isSealed() || destination.canonicalState() != 2) revert InvalidConfiguration();
            ZZZCanonicalHandoff handoff = ZZZCanonicalHandoff(destination.canonicalHandoff());
            if (handoff.incomingSource() != address(this) ||
                handoff.deploymentCommitment() != notice.deploymentCommitment) revert InvalidConfiguration();
            preparationReadyDestination = true;
        }
        uint256 nonce = ++preparationNonce;
        bytes32 noticeHash = keccak256(abi.encode("ZZZ_CANONICAL_PREPARATION_V1", block.chainid, address(this),
            module[Ids.VAULT], module[Ids.NFT], nonce, notice));
        preparationNotice = notice;
        preparationHash = noticeHash;
        preparationStartedAt = block.timestamp;
        preparationActive = true;
        emit PreparationStarted(noticeHash, nonce, notice.destinationChain, notice.successorController,
            notice.deploymentCommitment, notice.reviewHash);
    }
    /// @notice No custody or rights leave during preparation, so cancellation
    /// needs no remote proof. Exact notice binding prevents cancelling a later notice.
    function cancelPreparation(bytes32 noticeHash) external {
        if (msg.sender != governance || !preparationActive || canonicalState != 0) revert Unauthorized();
        if (noticeHash != preparationHash) revert InvalidConfiguration();
        preparationActive = false;
        emit PreparationCancelled(noticeHash);
    }
    function bind(bytes32 id, address implementation) external {
        if (msg.sender != bootstrap || isSealed) revert Unauthorized();
        bytes32[16] memory supported=_moduleIds();bool known;
        for(uint256 i;i<supported.length;++i)if(id==supported[i]){known=true;break;}
        if(!known)revert InvalidConfiguration();
        if (implementation.code.length == 0 || module[id] != address(0) ||
            address(IZZZBound(implementation).access()) != address(this)) revert InvalidConfiguration();
        module[id] = implementation;
        emit ModuleBound(id, implementation);
    }
    function bindProtocolPolicy(address implementation) external {
        if (msg.sender != bootstrap || isSealed) revert Unauthorized();
        if (protocolPolicy != address(0) || implementation.code.length == 0 ||
            IZZZProtocolPolicy(implementation).access() != address(this) ||
            IZZZProtocolPolicy(implementation).PROTOCOL_POLICY_VERSION() != 1) revert InvalidConfiguration();
        protocolPolicy = implementation;
        emit ProtocolPolicyBound(implementation, implementation.codehash);
    }
    function seal() external {
        if (msg.sender != bootstrap || isSealed) revert Unauthorized();
        if (protocolPolicy.code.length == 0 ||
            IZZZProtocolPolicy(protocolPolicy).access() != address(this) ||
            IZZZProtocolPolicy(protocolPolicy).PROTOCOL_POLICY_VERSION() != 1) revert InvalidConfiguration();
        bytes32[16] memory required = _moduleIds();
        for (uint256 i; i < required.length; ++i) {
            if (module[required[i]].code.length == 0 || module[required[i]] == protocolPolicy) revert InvalidConfiguration();
            for (uint256 j; j < i; ++j) {
                if (module[required[i]] == module[required[j]]) revert InvalidConfiguration();
            }
        }
        if (ICanonicalOwnerBinding(module[Ids.NFT_CANONICAL]).nft() != module[Ids.NFT] ||
            ICanonicalOwnerBinding(module[Ids.VAULT_CANONICAL]).vault() != module[Ids.VAULT] ||
            ICanonicalOwnerBinding(module[Ids.FEES_CANONICAL]).fees() != module[Ids.FEES]) revert InvalidConfiguration();

        // The source identity is bootstrap-only. Never seal an unset token and
        // leave a deployment unable to accept its intended ZZZ contributions.
        address sourceZZZ = IContributionRegistry(module[Ids.POOLS]).activationAssets().zzz();
        if (sourceZZZ == address(0) || IExitIdentity(module[Ids.MIGRATION]).currentZZZ() != sourceZZZ) revert InvalidConfiguration();
        IZZZProtocolPolicy(protocolPolicy).validateMintRecipient();

        // NFT randomness is configured only before sealing. Do not irreversibly
        // lock the canonical collection while its mint configuration is absent.
        if (IZZZVault(module[Ids.VAULT]).canonicalChainId() == block.chainid &&
            !IZZZNFT(module[Ids.NFT]).randomnessConfigured()) revert InvalidConfiguration();
        isSealed = true;
        bootstrap = address(0);
        emit SystemSealed();
    }
    function setKeeper(address who, bool enabled) external {
        if (!canConfigure(msg.sender) || who == address(0)) revert Unauthorized();
        keepers[who] = enabled;
        emit KeeperChanged(who, enabled);
    }
    function setGuardian(address who, bool enabled) external {
        if (!canConfigure(msg.sender) || who == address(0)) revert Unauthorized();
        guardians[who] = enabled;
        emit GuardianChanged(who, enabled);
    }
    function setPaused(bool state) external {
        // Pause control remains available to drain incoming custody and park it.
        // Unpausing never bypasses the separate preparation guards.
        if (msg.sender != governance && !(!isSealed && msg.sender == bootstrap) &&
            !(state && guardians[msg.sender])) revert Unauthorized();
        paused = state;
        emit PauseChanged(state);
    }
    function _moduleIds() private pure returns(bytes32[16] memory) {
        return [Ids.VAULT,Ids.NFT,Ids.LIQUIDITY,Ids.REWARDS,Ids.MEMBERSHIP,
            Ids.FEES,Ids.STRATEGY,Ids.COMPOUNDER,Ids.BUYBACK,Ids.MIGRATION,
            Ids.ORACLE,Ids.POOLS,Ids.CANONICAL,Ids.NFT_CANONICAL,Ids.VAULT_CANONICAL,Ids.FEES_CANONICAL];
    }
}
