// SPDX-License-Identifier: MIT
pragma solidity 0.8.26;
import {ERC721} from "@openzeppelin/contracts/token/ERC721/ERC721.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {ZZZSeaDropToken} from "./base/ZZZSeaDropToken.sol";
import {Ids, PositionStatus} from "./libraries/ZZZTypes.sol";
import {IZZZVault, IZZZAccess} from "./interfaces/IZZZ.sol";
import {ZZZRoyaltyRewards} from "./ZZZRoyaltyRewards.sol";
import {ZZZClaimRouter} from "./ZZZClaimRouter.sol";
import {ZZZNFTMetadata} from "./ZZZNFTMetadata.sol";
import {ZZZRoyaltyFactory} from "./ZZZRoyaltyFactory.sol";
import {IZZZCanonicalAccess} from "./interfaces/IZZZCanonical.sol";
import {CanonicalNFTRecord} from "./interfaces/IZZZNFTCanonical.sol";
import {IZZZProtocolPolicy} from "./interfaces/IZZZProtocolPolicy.sol";
interface IZZZNFTSuccessor {
    function destinationController() external view returns (address);
}

/// @dev Minimal official VRF v2.5 subscription ABI. A matching selector does not
/// prove a coordinator verifies VRF proofs; actual network support, coordinator,
/// subscription and key require independent production review.
interface IZZZVRFCoordinator {
    struct RandomWordsRequest {
        bytes32 keyHash;
        uint256 subId;
        uint16 requestConfirmations;
        uint32 callbackGasLimit;
        uint32 numWords;
        bytes extraArgs;
    }
    function requestRandomWords(RandomWordsRequest calldata request) external returns (uint256 requestId);
}

/// @notice Canonical ownership and immutable revealed traits. NFT-sale royalties
/// have their own funded ledger; rarity never changes LP or collective rewards.
contract ZZZNFT is ERC721, ZZZSeaDropToken, ReentrancyGuard {
    string private metadataBase;
    bool private metadataConfigured;
    ZZZRoyaltyRewards public immutable royaltyRewards;
    ZZZClaimRouter public immutable claimRouter;
    ZZZNFTMetadata public immutable metadataRenderer;
    uint256 public constant MAX_SUPPLY = 1000;
    uint256 public constant MAX_METADATA_REFRESH_BATCH = 50;
    uint256 public mintedCount;
    uint256 public nextToFinalize = 1;
    uint256 public remainingToReveal = MAX_SUPPLY;
    uint16[3] public rarityRemaining = [600, 300, 100];
    mapping(uint256 => uint256) public mintOrdinalOf;
    mapping(uint256 => uint256) public tokenAtOrdinal;
    mapping(uint256 => address) public originalMintRecipient;
    mapping(uint256 => uint256) public requestOf;
    mapping(uint256 => bool) public traitsReady;
    mapping(uint256 => uint8) public rarityOf;
    mapping(uint256 => uint8) public colorOf;
    mapping(uint256 => uint8) public paletteOf;
    mapping(uint256 => uint8) public patternOf;
    // Sparse Fisher-Yates indices, encoded plus one so zero denotes identity.
    // Each rarity owns a finite, immutable artwork inventory independent of the
    // rarity draw. Neither owners nor governance can choose or reroll artwork.
    mapping(uint8 => mapping(uint256 => uint16)) private artworkDraw;
    struct RandomnessResult {
        uint256 nftId;
        uint256 rarityWord;
        uint256 colorWord;
        bool requested;
        bool fulfilled;
    }
    mapping(bytes32 => RandomnessResult) private randomness;
    mapping(uint256 => uint256) public requestEpochOf;
    uint256 private randomnessBaseEpoch;
    // A provider must not recycle a request ID for this consumer after rotation:
    // callbacks carry requestId, not our generation. Different providers may
    // independently use the same ID without colliding in the epoch namespace.
    mapping(bytes32 => bool) private providerRequestUsed;
    bool public mintPaused;
    event MintPauseChanged(bool paused);
    event MetadataBaseChanged(string newBase);
    event RandomnessRequested(uint256 indexed nftId, uint256 indexed requestId, uint256 indexed ordinal);
    event RandomnessReceived(uint256 indexed requestId);
    event TraitsFinalized(uint256 indexed nftId, uint8 rarity, uint8 color);
    event ArtworkFinalized(uint256 indexed nftId, uint8 palette, uint8 pattern);
    event MetadataUpdate(uint256 tokenId);
    event BatchMetadataUpdate(uint256 fromTokenId, uint256 toTokenId);

    constructor(address controller, string memory baseURI,address renderer)
        ERC721("ZZZ Permanent Liquidity Rights", "ZZZLP") ZZZSeaDropToken(controller) {
        if(renderer.code.length==0 || address(ZZZNFTMetadata(renderer).access())!=controller)
            revert InvalidConfiguration();
        metadataRenderer=ZZZNFTMetadata(renderer);
        metadataRenderer.validateBaseURI(baseURI);
        metadataBase = baseURI;
        metadataConfigured = bytes(baseURI).length != 0;
        royaltyRewards = ZZZRoyaltyFactory(access.royaltyFactory()).create();
        if (royaltyRewards.canonicalController() != controller || royaltyRewards.nft() != address(this)) revert InvalidConfiguration();
        claimRouter = new ZZZClaimRouter(controller, address(this), address(royaltyRewards));
    }

    function _policy() private view returns (IZZZProtocolPolicy) {
        return IZZZProtocolPolicy(access.protocolPolicy());
    }
    /// @notice Current read compatibility only. Governance writes the bound
    /// ProtocolPolicy directly; it never rewrites old requests or trait words.
    function randomnessCoordinator() external view returns(address) { return _policy().vrfPolicy().coordinator; }
    function keyHash() external view returns(bytes32) { return _policy().vrfPolicy().keyHash; }
    function subscriptionId() external view returns(uint256) { return _policy().vrfPolicy().subscriptionId; }
    function requestConfirmations() external view returns(uint16) { return _policy().vrfPolicy().requestConfirmations; }
    function callbackGasLimit() external view returns(uint32) { return _policy().vrfPolicy().callbackGasLimit; }
    function nativePayment() external view returns(bool) { return _policy().vrfPolicy().nativePayment; }
    function randomnessConfigured() external view returns(bool) { return _policy().vrfPolicy().configured; }
    function randomnessEpoch() public view returns(uint256) { return randomnessBaseEpoch + _policy().vrfPolicy().generation; }

    /// @notice Event-only invalidation from the immutable policy. Thresholds
    /// change appearance only; ownership, traits and earned rights stay intact.
    function policyMetadataChanged() external {
        address policy=access.protocolPolicy();
        if(policy==address(0) || msg.sender!=policy) revert Unauthorized();
        emit BatchMetadataUpdate(0,type(uint256).max);
    }

    /// @notice Stop new requests/mints independently of existing NFT rights and
    /// LP work. Governance can resume; global pause/lifecycle guards still apply.
    function setMintPaused(bool state) external onlyGovernance {
        mintPaused = state;
        emit MintPauseChanged(state);
    }

    /// @notice Match the final OpenSea stage; governance can revise it during
    /// the sale. Its close starts the fixed 1-hour royalty activation window.
    function setMintEnd(uint64 end) external onlyGovernance {
        royaltyRewards.setMintEnd(end);
    }
    /// @notice Increase royalty currency capacity after reviewed gas rehearsal.
    /// No currency is removed and no earned entitlement changes.
    function increaseRoyaltyAssetCapacity(uint8 capacity,bytes32 reviewHash) external onlyGovernance {
        royaltyRewards.increaseAssetCapacity(capacity,reviewHash);
    }

    function mint(address to, uint256 id) external onlyModule(Ids.VAULT) operating principalOperating nonReentrant {
        if(address(seaDropMint)!=address(0))revert Unauthorized();
        _mintDormant(to,id);
    }

    /// @notice SeaDrop validates gross payment and calls with zero ETH. Its
    /// atomic fee/creator settlement follows this callback. Free team NFTs use
    /// the same dormant issuance and original asynchronous randomness request.
    function mintSeaDrop(address minter,uint256 quantity)
        external payable live operating principalOperating nonReentrant {
        if(msg.value!=0)revert InvalidAmount();
        (uint256 first,bytes32 review,)=seaDropMint.beginMint(msg.sender,minter,quantity);
        IZZZVault vault=IZZZVault(access.module(Ids.VAULT));
        for(uint256 i;i<quantity;++i) {
            if(mintedCount+1!=first+i)revert InvalidState();
            _mintDormant(minter,vault.mintDormant(review));
        }
        seaDropMint.finishMint(review);
    }

    function mintStageOf(uint256 id) external view returns(uint8) {
        return address(seaDropMint)==address(0) ? 0 : seaDropMint.mintStage(mintOrdinalOf[id]);
    }

    function _mintDormant(address to,uint256 id) private {
        if (mintPaused) revert Paused();
        uint64 end = royaltyRewards.mintEnd();
        if (end == 0 || block.timestamp > end) revert NotReady();
        IZZZProtocolPolicy policy = _policy();
        IZZZProtocolPolicy.VrfPolicy memory vrf = policy.vrfPolicy();
        uint64 revision = policy.vrfRevision();
        if (!vrf.configured || vrf.coordinator.codehash != vrf.expectedCodeHash) revert NotReady();
        if (mintedCount == MAX_SUPPLY) revert InvalidState();
        address recipient = IZZZVault(access.module(Ids.VAULT)).mintProceedsRecipient();
        if (recipient == address(royaltyRewards) || recipient == address(this)) revert InvalidConfiguration();
        uint256 ordinal = ++mintedCount;
        mintOrdinalOf[id] = ordinal; tokenAtOrdinal[ordinal] = id;
        originalMintRecipient[id]=to;
        // Bind before the ERC721 receiver callback. Official fulfillment is
        // asynchronous; a synchronous coordinator callback is rejected.
        uint256 epoch = randomnessBaseEpoch + vrf.generation;
        uint256 requestId = IZZZVRFCoordinator(vrf.coordinator).requestRandomWords(
            IZZZVRFCoordinator.RandomWordsRequest(vrf.keyHash, vrf.subscriptionId, vrf.requestConfirmations,
                vrf.callbackGasLimit, 2, abi.encodeWithSelector(bytes4(keccak256("VRF ExtraArgsV1")), vrf.nativePayment)));
        bytes32 requestKey = _requestKey(epoch, requestId);
        bytes32 providerKey = keccak256(abi.encode(vrf.coordinator,requestId));
        if (requestId == 0 || randomness[requestKey].requested || providerRequestUsed[providerKey]) revert InvalidState();
        providerRequestUsed[providerKey] = true;
        randomness[requestKey].nftId = id; randomness[requestKey].requested = true;
        requestEpochOf[id] = epoch;
        requestOf[id] = requestId;
        _safeMint(to, id);
        if (mintPaused) revert Paused();
        if (royaltyRewards.mintEnd() != end) revert InvalidState();
        if(policy.vrfRevision() != revision || vrf.coordinator.codehash != vrf.expectedCodeHash) revert InvalidState();
        emit RandomnessRequested(id, requestId, ordinal);
    }

    /// @dev Bounded callback stores only authenticated words. Metadata work can
    /// neither consume its gas nor turn a fulfilled request into another draw.
    function rawFulfillRandomWords(uint256 requestId, uint256[] calldata words) external {
        IZZZProtocolPolicy.VrfPolicy memory vrf = _policy().vrfPolicy();
        // Keep the original request's address authorization even if its provider
        // later changes runtime: new requests stay code-pinned, while pending
        // original callbacks must be able to drain before a reviewed rotation.
        if (!vrf.configured || msg.sender != vrf.coordinator) revert Unauthorized();
        RandomnessResult storage result = randomness[_requestKey(randomnessBaseEpoch + vrf.generation, requestId)];
        if (!result.requested || result.fulfilled || words.length != 2) revert InvalidState();
        result.fulfilled = true; result.rarityWord = words[0]; result.colorWord = words[1];
        emit RandomnessReceived(requestId);
    }

    /// @notice Draw without replacement, strictly in mint order: exactly 600
    /// Commun, 300 Rare and 100 Legendary when all 1,000 NFTs are revealed.
    /// Missing earlier fulfillment blocks later reveals; no fallback or reroll.
    function finalizeTraits(uint256 id) external nonReentrant canonicalAccounting {
        _requireOwned(id);
        RandomnessResult storage result = randomness[_requestKey(requestEpochOf[id], requestOf[id])];
        if (!result.fulfilled || traitsReady[id] || mintOrdinalOf[id] != nextToFinalize || result.nftId != id) {
            revert NotReady();
        }
        uint256 rarityRoll = result.rarityWord % remainingToReveal;
        uint8 rarity = rarityRoll < rarityRemaining[0] ? 0 :
            rarityRoll < uint256(rarityRemaining[0]) + rarityRemaining[1] ? 1 : 2;
        (uint8 palette, uint8 pattern, uint8 color) = _drawArtwork(rarity, result.colorWord, rarityRemaining[rarity]);
        --rarityRemaining[rarity]; --remainingToReveal; ++nextToFinalize;
        rarityOf[id] = rarity; paletteOf[id] = palette; patternOf[id] = pattern;
        colorOf[id] = color;
        traitsReady[id] = true;
        emit TraitsFinalized(id, rarity, colorOf[id]);
        emit ArtworkFinalized(id, palette, pattern);
        emit MetadataUpdate(id);
    }

    function _drawArtwork(uint8 rarity, uint256 word, uint256 remaining) private returns (uint8, uint8, uint8) {
        uint256 draw = word % remaining;
        uint16 stored = artworkDraw[rarity][draw];
        uint256 entry = stored == 0 ? draw : uint256(stored) - 1;
        uint256 last = remaining - 1;
        if (draw != last) {
            uint16 replacement = artworkDraw[rarity][last];
            artworkDraw[rarity][draw] = replacement == 0 ? uint16(last + 1) : replacement;
        }
        delete artworkDraw[rarity][last];
        return metadataRenderer.artworkItem(rarity, entry);
    }

    /// @notice Called after the Vault commits successful share issuance.
    /// Eligibility persists through market decreases and migration states.
    function notifyContribution(uint256 id) external onlyModule(Ids.VAULT) operating {
        _requireOwned(id);
        if (!traitsReady[id] || IZZZVault(msg.sender).sharesOf(id) == 0) revert NotReady();
        if (royaltyRewards.weightOf(id) == 0) royaltyRewards.activate(id, uint256(rarityOf[id]) + 1);
        emit MetadataUpdate(id);
    }

    function addRoyaltyAsset(address token) external onlyGovernance { royaltyRewards.addAsset(token); }

    /// @notice Fixed 5% marketplace request, wholly payable to the holder pool.
    /// ERC2981 cannot enforce marketplace payment.
    function royaltyInfo(uint256, uint256 salePrice) external view returns (address receiver, uint256 royaltyAmount) {
        // floor(salePrice * 500 / 10000), without intermediate multiplication.
        return (address(royaltyRewards), salePrice / 20);
    }

    function supportsInterface(bytes4 interfaceId) public view override returns (bool) {
        return interfaceId == 0x2a55205a || interfaceId == 0x49064906 ||
            (interfaceId == 0x1890fe8e && address(seaDropMint)!=address(0)) || super.supportsInterface(interfaceId);
    }

    /// @notice Current local marked principal, idle and compound NAV share.
    /// External/parked custody or stale dependencies report unavailable.
    function currentLPValue(uint256 id) public view returns (bool available, uint256 valueUSD) {
        _requireOwned(id);
        return metadataRenderer.markedValue(id);
    }

    function evolution(uint256 id) public view returns (bool available, uint8 stage) {
        _requireOwned(id);
        return metadataRenderer.evolutionOf(id);
    }

    function tokenURI(uint256 id) public view override returns (string memory) {
        _requireOwned(id);
        return metadataRenderer.tokenMetadata(id);
    }

    /// @notice Permissionless indexer notification after market moves.
    function refreshMetadata(uint256 id) external { _requireOwned(id); emit MetadataUpdate(id); }

    /// @notice Notify a bounded inclusive range of mint ordinals without reading valuations.
    /// Ordinals are not token IDs: each notification uses the actual minted ID.
    function refreshMetadataRange(uint256 firstOrdinal, uint256 lastOrdinal) external {
        if (firstOrdinal == 0 || firstOrdinal > lastOrdinal || lastOrdinal > mintedCount ||
            lastOrdinal - firstOrdinal >= MAX_METADATA_REFRESH_BATCH) revert InvalidAmount();
        for (uint256 ordinal = firstOrdinal; ordinal <= lastOrdinal; ++ordinal) {
            uint256 id = tokenAtOrdinal[ordinal];
            _requireOwned(id);
            emit MetadataUpdate(id);
        }
    }

    function artworkBaseURI() external view returns (string memory) { return metadataBase; }

    /// @notice Only an initially empty base can be populated, once before seal.
    function setBaseURI(string calldata baseURI) external onlyGovernance {
        if (access.isSealed() || metadataConfigured || bytes(baseURI).length == 0) revert InvalidConfiguration();
        metadataRenderer.validateBaseURI(baseURI);
        metadataConfigured = true; metadataBase = baseURI;
        emit MetadataBaseChanged(baseURI);
        emit BatchMetadataUpdate(0, type(uint256).max);
    }
    function _requestKey(uint256 epoch, uint256 requestId) private pure returns (bytes32) {
        return keccak256(abi.encode(epoch, requestId));
    }
    function transferFrom(address from, address to, uint256 tokenId) public override canonicalAccounting {
        super.transferFrom(from, to, tokenId);
    }
    function safeTransferFrom(address from, address to, uint256 tokenId, bytes memory data)
        public override canonicalAccounting {
        super.safeTransferFrom(from, to, tokenId, data);
    }
    /// @dev Imports deliberately mint inert ownership without receiver callbacks;
    /// ordinary transfers/mints cannot execute while either deployment is frozen.
    function _update(address to, uint256 tokenId, address auth) internal override returns (address) {
        uint8 state = IZZZCanonicalAccess(address(access)).canonicalState();
        if (state != 0 && !(state == 2 && canonicalImporting && msg.sender == canonicalModule())) revert InvalidState();
        return super._update(to, tokenId, auth);
    }

    bool private canonicalImporting;
    function canonicalModule() public view returns (address) { return access.module(Ids.NFT_CANONICAL); }
    modifier onlyCanonicalWriter() {
        if (msg.sender != canonicalModule() || !access.isSealed() || access.canonicalState() != 2) revert Unauthorized();
        _;
    }
    function canonicalRandomness(uint256 id) external view returns (uint256,uint256,uint256,bool,bool) {
        RandomnessResult storage result = randomness[_requestKey(requestEpochOf[id], requestOf[id])];
        return (result.nftId,result.rarityWord,result.colorWord,result.requested,result.fulfilled);
    }
    function canonicalArtwork(uint8 rarity, uint256 item) external view returns (uint16) { return artworkDraw[rarity][item]; }
    function canonicalWriteHeader(uint256 count, uint256 next, uint256 remaining, uint16[3] calldata quotas, uint256 epoch)
        external onlyCanonicalWriter {
        // A fresh inert importer has not rotated its future provider. Imported
        // historical records remain below this new namespace permanently.
        if(_policy().vrfPolicy().generation != 0) revert InvalidState();
        mintedCount = count; nextToFinalize = next; remainingToReveal = remaining;
        rarityRemaining = quotas; randomnessBaseEpoch = epoch;
    }
    function canonicalWriteRecord(uint256 row, CanonicalNFTRecord calldata value) external onlyCanonicalWriter {
        bytes32 key = _requestKey(value.requestEpoch, value.requestId);
        if (randomness[key].requested) revert InvalidState();
        randomness[key] = RandomnessResult(value.id, value.rarityWord, value.colorWord, true, true);
        requestOf[value.id] = value.requestId; requestEpochOf[value.id] = value.requestEpoch;
        mintOrdinalOf[value.id] = row; tokenAtOrdinal[row] = value.id;
        originalMintRecipient[value.id]=value.originalRecipient;
        if(address(seaDropMint)!=address(0))seaDropMint.restoreMint(row,value.originalRecipient,value.mintStage);
        rarityOf[value.id] = value.rarity; colorOf[value.id] = value.color;
        paletteOf[value.id] = value.palette; patternOf[value.id] = value.pattern; traitsReady[value.id] = true;
        canonicalImporting = true; _mint(value.owner, value.id); canonicalImporting = false;
    }
    function canonicalWriteArtwork(uint8 rarity, uint256 item, uint16 value) external onlyCanonicalWriter {
        artworkDraw[rarity][item] = value;
    }
    function canonicalSuccessor() external view returns (address controller, address replacementNFT) {
        if (access.canonicalState() != 3) return (address(0), address(0));
        controller = IZZZNFTSuccessor(access.canonicalHandoff()).destinationController();
        replacementNFT = IZZZAccess(controller).module(Ids.NFT);
    }
    function canonicalRetire() external onlyHandoff {
        if (access.canonicalState() != 3) revert InvalidState();
        emit BatchMetadataUpdate(0, type(uint256).max);
    }
    // No burn or principal-redemption entrypoint. Standard ERC721 safe transfers.
}
