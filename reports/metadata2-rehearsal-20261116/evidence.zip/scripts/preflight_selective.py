"""Recording-fake branch preflight only; no process/node/RPC/compiler/test suite."""
from pathlib import Path
import ast,contextlib,hashlib,importlib.util,io,json,tempfile
E=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('selective_preflight',E/'selective_constructors.py')
C=importlib.util.module_from_spec(spec);spec.loader.exec_module(C)
P=C.P;L=C.L

class RecordingFake:
    def __init__(self):self.pending=None;self.code_pins={};self.nonce=0;self.reads=[];self.sends=[];self.current=None
    def guard(self):self.reads.append(('guard',None))
    def expect(self,label,payload,to,runtime,target):self.current=(label,payload,to,runtime,target)
    def wire(self,method,params=None):
        self.reads.append((method,params));label,payload,to,runtime,target=self.current
        if method=='eth_getTransactionCount':return hex(self.nonce)
        if method=='eth_call':return runtime if to is None else '0x'
        if method=='eth_estimateGas':return hex(100000)
        if method=='eth_gasPrice':return '0x1'
        if method=='eth_getTransactionReceipt':return {'status':'0x1','gasUsed':hex(100000),'contractAddress':target if to is None else None}
        if method=='eth_getTransactionByHash':return self.actual
        if method=='eth_getCode':return runtime
        if method=='debug_traceTransaction':return {'type':'CREATE','from':L.SENDER,'to':target,'input':payload,'output':runtime,'calls':[]}
        raise AssertionError('Unreviewed fake preflight method '+method)
    def mutate(self,method,params):
        assert method=='eth_sendTransaction'and len(params)==1
        request=params[0];self.sends.append(request.copy());self.nonce+=1
        txhash='0x'+self.nonce.to_bytes(32,'big').hex()
        self.actual={'from':request['from'],'to':request.get('to'),'input':request['data'],'nonce':request['nonce'],
                     'gas':request['gas'],'value':request['value'],'hash':txhash,'gasPrice':request['gasPrice']}
        return txhash

def main():
    sources=[E/'selective_constructors.py',E/'cold_metadata.py']
    before={str(path):hashlib.sha256(path.read_bytes()).hexdigest()for path in sources}
    for path in sources:ast.parse(path.read_bytes())
    artifacts=P.Artifacts(build_profile='metadata2-20261116')
    node=RecordingFake();completed=[]
    with tempfile.TemporaryDirectory(prefix='metadata2-offline-branch-')as folder,contextlib.redirect_stdout(io.StringIO()):
        case=C.SelectiveConstruction(node,artifacts,Path(folder));case.inputs={'governance':L.SENDER,'keeper':L.KEEPER,'guardian':L.GUARDIAN,'base_uri':C.URI}
        for ordinal,role in enumerate(C.TOP_ROLES,1):
            name,refs=next((name,refs)for key,name,refs in P.TOP if key==role)
            obj=artifacts.contract(name)[1];arguments=case.arguments(refs)
            payload='0x'+obj['evm']['bytecode']['object']+P.encode_constructor(P.TYPES[name],arguments).hex()
            runtime='0x'+obj['evm']['deployedBytecode']['object'];target='0x'+(0xe000+ordinal).to_bytes(20,'big').hex()
            node.expect('create:'+role,payload,None,runtime,target)
            case.addresses[role]=case.transaction('create:'+role,payload)
            completed.append('create:'+role)
            if role in ('migration','nft','nft_canonical'):
                payload=L.data('bind(bytes32,address)',('bytes32','address'),('0x'+C.keccak256(name.encode()).hex(),target))
                node.expect('bind:'+role,payload,case.addresses['access'],None,None)
                case.transaction('bind:'+role,payload,case.addresses['access']);completed.append('bind:'+role)
        assert completed==list(C.EXPECTED_LABELS)and len(node.sends)==8 and len(case.receipts)==8
        assert 'protocol_policy'not in case.addresses
        # All closed branches were exercised through the actual transaction
        # method with a recording fake, never a real Node or network socket.
        assert node.pending is None
    assert before=={str(path):hashlib.sha256(path.read_bytes()).hexdigest()for path in sources}
    result={'status':'recording_fake_branch_preflight_passed','actual_constructor_or_binding_transactions':0,'nodes_started':0,'RPC_calls':0,
      'compiler_runs':0,'old_test_methods_executed':0,'selected_new_branch_exercises':completed,'recorded_fake_sends':8,
      'runtime_scope':'Unpatched compiler templates in recording fake only; not constructor execution or actual runtime/gas qualification.',
      'source_sha256':before,'normal_build_profile':artifacts.profile,'normal_build_files':artifacts.file_pins}
    L.save(E/'OFFLINE_BRANCH_PREFLIGHT.json',result);print(json.dumps(result))

if __name__=='__main__':main()
