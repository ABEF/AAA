from pathlib import Path
import hashlib,json,subprocess
R=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2');E=Path(__file__).parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def git(*args):return subprocess.check_output(['git',*args],cwd=R,text=True).strip()
head=git('rev-parse','HEAD');assert head=='6626d6846edccf4660ad483919e34272d1d4271c'and git('branch','--show-current')=='main'
protected={'reports/source-checks.json':'049dca6943d06ba63de682dc8cdec2cf3935af1dc2e5479e9f3cf14e1af793c4','scripts/run-fork-checks.py':'875d27fb56963d92e6e7ec25b9f296b5559b830e007ad411afb856f0f0226f1b','tests_python/test_fork_runner.py':'6d50a612ec490ec0f3754d930ac6610173d96d0a684bbc5e4894eaedf4d9abc9','tests_python/test_frontend_history.py':'361f6a56153a4b3041b5b6f7eaaf399fea063bae9f46299da71397a08540c7eb'}
assert set(git('diff','--name-only').splitlines())==set(protected);assert not git('diff','--cached','--name-only');assert all(sha(R/n)==h for n,h in protected.items())
source={n:sha(R/n)for n in git('ls-files','src','zzz_ops','scripts').splitlines()}
docs=['AGENTS.md','PROJECT_CONTEXT.md','README.md','TODO.md','docs/WORK_HANDOFF.md','docs/OPERATOR_MANUAL.md','docs/DEPLOYMENT_PREPARATION.md','docs/IMPLEMENTATION_STATUS.md','docs/ROADMAP.md','docs/RELEASE_CHECKLIST.md','docs/DEPLOYMENT_ADDRESSES.md','docs/PRODUCTION_PREFLIGHT.md','docs/METADATA_LIFECYCLE.md','docs/NFT_METADATA.md','docs/ARTWORK_PUBLICATION.md','docs/README.md','reports/README.md','docs/project-todo.json']
for n in docs:
 target=E/'originals'/n;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes((R/n).read_bytes())
W=R.parent.parent/'aaa-website';website={n:sha(W/n)for n in('browser-wallet.js','deployment-config.js','integration-config.js','deployment-view.js')}
prior_families=['metadata-lifecycle-fixes-20261116','five-audit-reconciliation-20261116','local-deployment-rehearsal-20261115','deployment-preparation-20261115','manual-reference-swap-fix-20261115']
oldreports={p.relative_to(R).as_posix():sha(p)for f in prior_families for p in(R/'reports'/f).rglob('*')if p.is_file()}
v=E.parent;tools={n:sha(v/n)for n in('foundry-v1.4.4/anvil.exe','foundry-v1.4.4/forge.exe','toolchain-0.8.26/solc.exe')}
net=subprocess.run(['C:/Windows/System32/netstat.exe','-ano','-p','TCP'],stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=10)
assert net.returncode==0;ports={str(p):[]for p in(8902,57306)}
for line in net.stdout.decode(errors='replace').splitlines():
 parts=line.split()
 if len(parts)>=5 and parts[0]=='TCP'and parts[-1].isdigit():
  port=parts[1].rsplit(':',1)[-1]
  if port in ports and parts[2].endswith(':0'):ports[port].append(int(parts[-1]))
record={'head':head,'branch':'main','source_pins':source,'production_sources':{n:h for n,h in source.items()if n.startswith('src/')and n.endswith('.sol')},'protected':protected,'website_protected':website,'historical_report_pins':oldreports,'tools':tools,'docs':docs,'old_listener_observation_only':ports,'old_RPC_calls':0,'old_state_root_balance_equality_claimed':False,'status':git('status','--short'),'authorization':'User explicitly authorizes fresh isolated metadata2 constructors/bindings/coldtokenURI rehearsal; no public deployment,sealing,old-node contact,service/site/signer/journal changes.'}
(E/'BASELINE.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'head':head,'production_sources':len(record['production_sources']),'prior_report_files':len(oldreports),'protected_files':4,'old_ports_observed_without_RPC':ports,'new_node_started':False}))
