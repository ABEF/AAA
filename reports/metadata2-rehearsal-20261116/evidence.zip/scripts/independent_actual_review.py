"""Independent offline receipt/CREATE/runtime/cold-wire review. No RPC or EVM."""
from pathlib import Path
import base64,gzip,hashlib,json,sys

E=Path(__file__).resolve().parent;A=E/'attempt1'
R=Path(r'C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
sys.path.insert(0,str(R))
from zzz_ops.abi import keccak256

def require(ok,message):
    if not ok:raise ValueError(message)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def obj(path):return json.loads(Path(path).read_bytes())
def gz(path,limit=128*1024*1024):
    with gzip.open(path,'rb')as stream:raw=stream.read(limit+1)
    require(len(raw)<=limit,'Bounded evidence exceeded');return raw
def canon(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True).encode()
def w(value):return int(value).to_bytes(32,'big')
def encode(types,values):
    head=[];tail=b''
    for typ,value in zip(types,values):
        if typ=='address':head.append(w(int(value,16)))
        elif typ in ('string','bytes'):
            raw=value.encode()if typ=='string'else value
            head.append(w(32*len(types)+len(tail)));tail+=w(len(raw))+raw+b'\0'*((-len(raw))%32)
        else:raise ValueError('Unexpected independent constructor type')
    return b''.join(head)+tail
def create_address(sender,nonce):
    # Closed small CREATE nonce domain for this campaign, independently RLP encoded.
    require(0<=nonce<128,'Unexpected CREATE nonce')
    item=b'\x80'if nonce==0 else bytes([nonce])
    return '0x'+keccak256(b'\xd6\x94'+bytes.fromhex(sender[2:])+item)[-20:].hex()
def decode_uri(raw):
    value=bytes.fromhex(raw[2:]);require(int.from_bytes(value[:32],'big')==32,'URI ABI offset')
    size=int.from_bytes(value[32:64],'big');require(len(value)==64+(size+31)//32*32 and not any(value[64+size:]),'URI ABI bounds')
    uri=value[64:64+size].decode();prefix='data:application/json;base64,'
    require(uri.startswith(prefix),'URI scheme');decoded=base64.b64decode(uri[len(prefix):],validate=True)
    return uri,json.loads(decoded),decoded

result=obj(A/'RESULT.json');addresses=obj(A/'addresses.json');instances=obj(A/'instances.json')
wire=json.loads(gz(A/'node/rpc-records.json.gz'));process=obj(A/'node/process.json');cleanup=obj(A/'node/cleanup.json')
approval=obj(E/'SAFETY_APPROVED.json');stage=obj(A/'source-stage.json')
require(len(addresses)==len(set(addresses.values()))==len(instances)==12,'Actual instance count')
require(stage['source_sha256']==approval['source_sha256'],'Approved source stage differs')
for path,pin in stage['source_sha256'].items():require(sha(Path(path).read_bytes())==pin,'Live source bytes changed')
require(process['binary_sha256']==approval['anvil_sha256'],'Anvil binary pin differs')
require(process['port']not in (8902,57306)and process['chain_id']==4663 and process['minimal_environment']is True and process['size_limit_override']is False and process['public_rpc']is False,'Isolation scope differs')
command=process['command'];require(command[command.index('--host')+1]=='127.0.0.1'and command[command.index('--accounts')+1]=='0'and command[command.index('--gas-limit')+1]=='32000000'and '--disable-code-size-limit'not in command and '--fork-url'not in command,'Unsafe Anvil arguments')
ownership=obj(A/'node/socket-ownership.json')
require(ownership and all(row['observed_listener_pids']==[process['pid']]and row['port']==process['port']for row in ownership),'PID ownership evidence differs')
require(cleanup['owned_node_stopped']is True and cleanup['pending_submission']is None and cleanup['failure_type']is None and cleanup['existing_nodes_contacted']is False,'Cleanup unresolved')
for index,row in enumerate(wire,1):
    require(row['request']['id']==row['response']['id']==index,'Wire identity sequence')
mutations=[row for row in wire if row['request']['method']in ('eth_sendTransaction','anvil_impersonateAccount')]
require(len(mutations)==9 and mutations[0]['request']['method']=='anvil_impersonateAccount','Unexpected mutation count')
sender='0x000000000000000000000000000000000000a0a0'
require(mutations[0]['request']['params']==[sender],'Impersonation target differs')
sends=[row for row in mutations if row['request']['method']=='eth_sendTransaction']
require(len(sends)==8,'Expected eight included local transactions')
require(set(row['request']['method']for row in wire)<=set(('eth_chainId','eth_getBlockByNumber','eth_getCode','eth_getBalance','eth_getTransactionCount','eth_getTransactionReceipt','eth_getTransactionByHash','eth_estimateGas','eth_call','eth_gasPrice','debug_traceTransaction','debug_traceCall','eth_getStorageAt','anvil_impersonateAccount','eth_sendTransaction')),'Unexpected RPC method')
B=R/'reports/metadata-lifecycle-fixes-20261116/build'
normal= (B/'compiler-output.json.gz').read_bytes()
require(sha(normal)=='4acc319da1a5b4e8a4c112fb9a6c0832d3943d2722d2d17f30dd288c125f3a0f','Normal output pin')
compiled=json.loads(gzip.decompress(normal))['contracts']
def contract(name):return compiled['src/'+name+'.sol'][name]
ledger=bytes.fromhex(contract('ZZZRoyaltyRewards')['evm']['bytecode']['object'])
specs={
 'access':('ZZZAccessController',None,('address','address','address'),(sender,'0x000000000000000000000000000000000000beef','0x000000000000000000000000000000000000a0a1')),
 'metadata_renderer':('ZZZNFTMetadata',None,('address',),(addresses['access'],)),
 'migration':('ZZZMigration',None,('address',),(addresses['access'],)),
 'nft':('ZZZNFT',None,('address','string','address'),(addresses['access'],'ipfs://metadata2-controlled-construction/',addresses['metadata_renderer'])),
 'nft_canonical':('ZZZNFTCanonical',None,('address','address'),(addresses['access'],addresses['nft'])),
 'royalty_factory':('ZZZRoyaltyFactory','access',(),()),
 'activation_assets_factory':('ZZZActivationAssetsFactory','access',(),()),
 'custody_validation':('ZZZCustodyValidation','migration',('address',),(addresses['access'],)),
 'royalty_rewards':('ZZZRoyaltyRewards','royalty_factory',('address',),(addresses['nft'],)),
 'claim_router':('ZZZClaimRouter','nft',('address','address','address'),(addresses['access'],addresses['nft'],addresses['royalty_rewards'])),
 'royalty_data_part0':('ZZZRoyaltyCodeData','royalty_factory',('bytes',),(ledger[:24573],)),
 'royalty_data_part1':('ZZZRoyaltyCodeData','royalty_factory',('bytes',),(ledger[24573:],))}
require(set(specs)==set(addresses),'Independent constructor graph differs')
expected_inputs={};expected_runtime_lengths={}
for role,(name,parent,types,values)in specs.items():
    item=contract(name);abi=next(row['inputs']for row in item['abi']if row['type']=='constructor')if types else []
    require(tuple(x['type']for x in abi)==types,'Constructor ABI differs')
    full=bytes.fromhex(item['evm']['bytecode']['object'])+encode(types,values)
    require(len(full)<=49152,'Full constructor EIP3860 limit')
    expected_inputs[addresses[role]]='0x'+full.hex()
    expected_runtime_lengths[addresses[role]]=len(bytes.fromhex(item['evm']['deployedBytecode']['object']))if name!='ZZZRoyaltyCodeData'else 3+len(values[0])

labels=('create:access','create:metadata_renderer','create:migration','bind:migration','create:nft','bind:nft','create:nft_canonical','bind:nft_canonical')
receipts=[];frames={};nonce={};gas=[]
def collect(frame,top_nonce=None):
    require(not frame.get('error'),'Reverted included CREATE/call frame')
    if frame.get('type')in ('CREATE','CREATE2'):
        require(frame['type']=='CREATE','Unexpected CREATE2')
        creator=frame['from'].lower();target=frame['to'].lower()
        sequence=top_nonce if creator==sender else nonce.get(creator,1)
        require(target==create_address(creator,sequence),'CREATE address/creator nonce differs')
        nonce[creator]=sequence+1
        require(target not in frames and frame['input'].lower()==expected_inputs[target],'Normal full constructor input differs')
        require(len(bytes.fromhex(frame['output'][2:]))==expected_runtime_lengths[target]<=24576,'Normal runtime size differs')
        frames[target]=frame
    for child in frame.get('calls',[]):collect(child)

for index,label in enumerate(labels):
    row=obj(A/(f'{index+1:02d}-'+label.replace(':','-')+'.json'));tx=row['transaction'];receipt=row['receipt'];sent=sends[index]
    require(row['label']==label and tx['hash']==receipt['transactionHash']==sent['response']['result'],'Included hash/label differs')
    request=sent['request']['params'][0]
    require(request['from']==sender and int(request['value'],16)==0 and int(request['nonce'],16)==int(tx['nonce'],16)==index,'Exact sender/value/nonce differs')
    require(request['data'].lower()==tx['input'].lower()and int(request['gas'],16)==int(tx['gas'],16)==row['padded_gas'],'Exact submitted gas/input differs')
    require(row['padding_bps']==12500 and row['padded_gas']==(row['estimated_gas']*12500+9999)//10000<=32000000 and int(receipt['status'],16)==1 and int(receipt['gasUsed'],16)<=row['padded_gas'],'Gas/status/padding differs')
    require(any(r['request']['method']=='eth_getTransactionReceipt'and r['request']['params']==[tx['hash']]and r['response'].get('result')==receipt for r in wire),'Receipt not in actual wire')
    if label.startswith('create:'):
        role=label[7:];require(receipt['contractAddress'].lower()==addresses[role]and tx.get('to')is None and tx['input'].lower()==expected_inputs[addresses[role]],'Top-level creation input/target differs')
        raw=gz(A/(f'{index+1:02d}-'+label.replace(':','-')+'-trace.json.gz'))
        trace=json.loads(raw);require(any(r['request']['method']=='debug_traceTransaction'and r['request']['params'][0]==tx['hash']and r['response'].get('result')==trace for r in wire),'Trace not in actual wire')
        collect(trace,index)
        require('0x'+bytes.fromhex(trace['output'][2:]).hex()==row['simulation_return'].lower(),'Simulation/actual return differs')
    else:
        role=label[5:];name=specs[role][0]
        calldata='0x'+(keccak256(b'bind(bytes32,address)')[:4]+keccak256(name.encode())+w(int(addresses[role],16))).hex()
        require(tx['input'].lower()==calldata and tx['to'].lower()==addresses['access']and row['simulation_return']=='0x','Exact bootstrap binding differs')
    receipts.append(row);gas.append({'label':label,'gas_used':int(receipt['gasUsed'],16),'estimate':row['estimated_gas'],'padded':row['padded_gas']})
require(set(frames)==set(addresses.values()),'Missing actual child CREATE proof')
before=obj(A/'state-before-cold.json');after=obj(A/'state-after-cold.json')
require(before==after,'Actual state changed during metadata reads')
require(len(before['codes'])==23 and len(before['nonces'])==len(before['balances'])==23,'Account snapshot coverage')
for target,frame in frames.items():
    require(before['codes'][target].lower()==frame['output'].lower(),'Actual getCode differs from normal constructor return')
    require(int(before['nonces'][target],16)==nonce.get(target,1),'Actual child nonce differs from CREATE sequence')
for item in instances:
    target=item['address'];raw=bytes.fromhex(before['codes'][target][2:])
    require(item['full_initcode_hex'].lower()==expected_inputs[target] and item['create_proof']['output'].lower()==before['codes'][target].lower()and item['runtime_sha256']==sha(raw)and item['runtime_keccak256']=='0x'+keccak256(raw).hex(),'Reported instance pin differs')
bindings=obj(A/'bindings-before-cold.json')
for item in bindings:
    calldata='0x'+keccak256(item['signature'].encode())[:4].hex()+''.join(x[2:].rjust(64,'0')for x in item.get('arguments',[]))
    require(item['actual'].lower()==item['expected'].lower(),'Binding actual/expected differs')
    require(any(r['request']['method']=='eth_call'and r['request']['params'][0].get('to')==addresses[item['role']]and r['request']['params'][0].get('data')==calldata and r['response'].get('result')==item['actual'] for r in wire),'Binding read missing wire provenance')

cold=obj(A/'COLD_RESULTS.json');overrides=obj(A/'OVERRIDES.json');trace=obj(A/'COLD_TRACE.json')
require(cold['verification_passed']is True and not cold['case_failures']and not cold['gas_review_semantic_mismatches'],'Cold diagnostic issues remain')
require(cold['scenario_count']==len(cold['cases'])==20 and len([c for c in cold['cases']if c['status']=='controlled_read_measured'])==19,'Cold case count differs')
require(cold['before']==cold['after'] and cold['overridden_storage_before']==cold['overridden_storage_after'],'Cold state snapshot differs')
token=(1<<256)-1;token_data='0x'+(keccak256(b'tokenURI(uint256)')[:4]+w(token)).hex();coldgas=[]
for case in cold['cases']:
    matching=[r for r in wire if r['request']['method']=='eth_call'and len(r['request']['params'])==3 and r['request']['params'][0].get('to')==addresses['nft']and r['request']['params'][0].get('data')==token_data and r['request']['params'][2]==overrides[case['id']]]
    require(matching and all(set(entry)=={'stateDiff'}for entry in overrides[case['id']].values()),'Cold input/runtime override differs')
    require(sha(canon(overrides[case['id']]))==case['override_sha256'],'Cold override hash differs')
    if case['status']=='expected_exact_revert':
        expected='0x'+(keccak256(b'ERC721NonexistentToken(uint256)')[:4]+w(token)).hex()
        require(case['reference']['error']['data']==expected,'Wrong absent-token error')
        continue
    raw=case['reference']['result'];uri,value,decoded=decode_uri(raw)
    require(value==case['decoded']and sha(decoded)==case['decoded_json_sha256']and len(str(token))==78,'Decoded full-width metadata differs')
    spec=case['scenario'];active=spec['active'];closed=active and spec['status']==5
    require(value['metadata_schema']==2 and value['metadata_snapshot_block']==cold['block']['number']and value['metadata_snapshot_timestamp']==cold['block']['timestamp'],'Cold context differs')
    require(value['royalty_activated']is active and value['lp_exited']is closed and value['canonical_state']==spec['canonical']and value['activation_closed']is(spec['exit']or spec['canonical']in(3,4)),'Cold lifecycle rights differ')
    require(case['estimate_semantics_match']is True and case['padded_semantics_match']is True and case['padded_gas']==(case['estimated_gas']*12000+9999)//10000,'Cold gas semantics/padding differs')
    for gas_limit in (case['estimated_gas'],case['padded_gas']):
        require(any(int(r['request']['params'][0]['gas'],16)==gas_limit and r['response'].get('result')==raw for r in matching),'Exact reviewed gas call missing healthy wire result')
    require(all('accessList'not in r['request']['params'][0]and r['request']['params'][1]==hex(cold['block']['number'])for r in matching),'Call warming/block differs')
    coldgas.append({'id':case['id'],'estimate':case['estimated_gas'],'padded':case['padded_gas'],'adjacent':case['adjacent_reference_transition']})
require(cold['cold_trace_proven']is True and len(trace)==1,'Cold trace proof unavailable')
item=trace[0];detail=item['result']['result'];first=next(op for op in detail['structLogs']if op['op']=='SLOAD')
cost=first['gasCost'];cost=int(cost,16)if type(cost)is str else cost
require(cost==2100 and any(op['depth']==2 for op in detail['structLogs']),'Cold first-SLOAD/override execution proof differs')
require(any(r['request']['method']=='debug_traceCall'and r['response'].get('result')==detail and set(r['request']['params'][2])=={'disableStack','disableMemory','disableStorage','stateOverrides'}for r in wire),'Opcode trace not bound to wire')
require(sum(x['gas_used']for x in gas)==result['total_receipt_gas']==41327001,'Actual total gas differs')
summary={'status':'PASS_SCOPED_INDEPENDENT_EVIDENCE_REVIEW','source_hashes':stage['source_sha256'],
 'actual_wire_responses':len(wire),'actual_receipts':8,'actual_top_level_constructions':5,'actual_internal_instances':7,
 'actual_instances':12,'binding_reads_checked':len(bindings),'normal_initcode_runtime_and_CREATE_addresses_independently_reconciled':True,
 'constructor_gas':gas,'total_receipt_gas':sum(x['gas_used']for x in gas),
 'worst_padded_constructor':max(gas,key=lambda x:x['padded']),
 'valid_cold_scenarios':19,'exact_nonexistent_negative':1,'cold_RPCs':cold['read_RPCs'],
 'first_SLOAD_gas_cost':cost,'cold_estimate_and_20pct_padded_calls_match_exact_full_reference':True,
 'worst_cold_estimate':max(coldgas,key=lambda x:x['estimate']),
 'actual_account_snapshot_count':23,'actual_before_after_state_root_and_code_storage_nonce_balance_unchanged':True,
 'owned_node_stopped_recorded':True,'no_additional_node_RPC_EVM_or_tests_executed':True,
 'production_approved':False,'release_ready':False,
 'limits':['Partial transient metadata read snapshots, not reachable sealed mint states or economic operation verification.',
 'Cheap typed custody/price doubles exclude actual dual-feed/market/provider/OpenSea read gas.',
 'Cold binary brackets are adjacent observed semantic transitions, not a global gas-minimum/monotonicity proof.',
 'Constructed local addresses and runtimes are evidence only; not production inventory or legacy-environment adoption.']}
(E/'INDEPENDENT_ACTUAL_REVIEW.json').write_text(json.dumps(summary,indent=2)+'\n',encoding='utf8')
print(json.dumps(summary))
