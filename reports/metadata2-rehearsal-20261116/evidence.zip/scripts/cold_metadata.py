"""External, controlled metadata2 read fixtures; not production configuration.

The constructor runner owns the new node. This callback only performs fresh
read-only RPC calls at one fixed block. The actual twelve constructed instances
receive no code overrides; fixture storage changes exist only in each call.
No mint, seal, exit, transfer, node reset or persistent state write is performed.
"""
from pathlib import Path
import base64, copy, hashlib, json, re, time
from zzz_ops.abi import keccak256

ZERO='0x'+'0'*40
CAP=32_000_000
MAX_READS=900
MAX_SECONDS=360
# Worst-width uint256 exercises78-digit name serialization/calldata; this is
# a controlled identity, not a claim to reproduce a real mint's hash.
TOKEN=(1<<256)-1
OWNER='0x00000000000000000000000000000000000a11ce'
ZZZ='0x7dbf38976f6d3b9c529e7d9484a71898b409ee6a'
FIXTURE={name:'0x'+f'{0xd200+i:040x}' for i,name in enumerate(
    ('vault','policy','liquidity','fees','pools','strategy','oracle','handoff','successor_access','successor_nft'))}
MODULE_NAMES={'vault':'ZZZVault','nft':'ZZZNFT','liquidity':'ZZZLiquidityManager',
    'fees':'ZZZFeeController','strategy':'ZZZStrategy','oracle':'ZZZOracle',
    'pools':'ZZZPoolRegistry','migration':'ZZZMigration','canonical':'ZZZCanonicalHandoff',
    'nft_canonical':'ZZZNFTCanonical'}

def require(ok,message):
    if not ok:raise ValueError(message)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def word(value):return int(value).to_bytes(32,'big')
def hexword(value):return '0x'+word(value).hex()
def addr(value):return int(value,16)
def selector(signature):return keccak256(signature.encode())[:4]
def data(signature,*values):return '0x'+(selector(signature)+b''.join(word(v) for v in values)).hex()
def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode()
def save(path,value):Path(path).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n',encoding='utf-8')
def push(value):
    raw=word(value).lstrip(b'\0') or b'\0'
    return bytes([0x5f+len(raw)])+raw
def return_words(values,storage=False):
    body=b'\x50'
    for i,value in enumerate(values):
        body+=push(value)+(b'\x54' if storage else b'')+push(i*32)+b'\x52'
    return body+push(len(values)*32)+b'\x5f\xf3'
def typed_runtime(specifications):
    """Tiny closed selector dispatch. No external call, write or dynamic loop."""
    count=len(specifications);offset=5+11*count+3;branches=[];bodies=[]
    for signature,builder in specifications:
        body=builder(offset) if callable(builder) else builder
        branches.append(b'\x80\x63'+selector(signature)+b'\x14\x61'+offset.to_bytes(2,'big')+b'\x57')
        piece=b'\x5b'+body;bodies.append(piece);offset+=len(piece)
    return b'\x5f\x35\x60\xe0\x1c'+b''.join(branches)+b'\x5f\x5f\xfd'+b''.join(bodies)
def guarded_price(base):
    # Body starts after its JUMPDEST. Failure flag is local fixture storage0.
    prefix=b'\x50\x5f\x54\x15'
    destination=base+1+len(prefix)+4+3
    return prefix+b'\x61'+destination.to_bytes(2,'big')+b'\x57\x5f\x5f\xfd\x5b'+push(1<<96)+b'\x5f\x52\x60\x20\x5f\xf3'

def fixture_runtimes():
    pool_key=(0,addr(ZZZ),10020,200,0)
    pool_id=int.from_bytes(keccak256(b''.join(word(v) for v in pool_key)),'big')
    bodies={
      'vault':[
        ('nftBucket(uint256)',return_words((0,),True)),
        ('sharesOf(uint256)',return_words((1,),True)),
        ('bucketTotalShares(uint256)',return_words((2,),True)),
        ('nftStatus(uint256)',return_words((3,),True)),
        ('group(uint256)',return_words(tuple(range(16,24)),True))],
      'policy':[('metadataPolicy()',return_words((1000*10**18,10000*10**18,0)))],
      'liquidity':[('portfolioAmounts(uint256)',return_words((0,1),True))],
      'fees':[('compoundBalance(uint256,address)',return_words((0,),True))],
      'pools':[('accounting(bytes32)',return_words(pool_key+(1,1,5000,8500,500,200,43200,100*10**18,1_000_000*10**18)))],
      'strategy':[('validateExitPrice(bytes32)',guarded_price)],
      # Native ETH and fixed ZZZ both have synthetic $1/18-decimal fixture
      # value. This cheap CALDLATALOAD is NOT actual dual-feed gas evidence.
      'oracle':[('value(address,uint256)',b'\x50\x60\x24\x35\x5f\x52\x60\x20\x5f\xf3')],
      'handoff':[('destinationController()',return_words((0,),True))],
      'successor_access':[('module(bytes32)',return_words((addr(FIXTURE['successor_nft']),)))],
      'successor_nft':[('fixtureMarker()',return_words((1,)))]}
    return {name:typed_runtime(rows) for name,rows in bodies.items()},pool_id

def genesis_alloc():
    runtimes,_=fixture_runtimes()
    return {FIXTURE[name]:{'balance':'0x0','nonce':'0x1','code':'0x'+raw.hex(),'storage':{}}
        for name,raw in runtimes.items()}

class Layout:
    def __init__(self,artifacts):
        self.output=artifacts.output
        self.layouts={}
    def get(self,name):
        if name not in self.layouts:
            value=self.output['contracts']['src/'+name+'.sol'][name]['storageLayout']
            require(type(value)is dict and type(value['storage'])is list,'Missing trusted storage layout')
            self.layouts[name]=value
        return self.layouts[name]
    def field(self,name,label):
        matches=[r for r in self.get(name)['storage'] if r['label']==label]
        require(len(matches)==1,'Ambiguous trusted field')
        return matches[0]
    def slot(self,name,label):return int(self.field(name,label)['slot'])
    def mapping(self,name,label,key):
        item=self.field(name,label);typ=self.get(name)['types'][item['type']]
        require(typ['encoding']=='mapping','Expected trusted mapping')
        return int.from_bytes(keccak256(word(key)+word(int(item['slot']))),'big')
    def member(self,name,label,key,member):
        item=self.field(name,label);types=self.get(name)['types'];mapping=types[item['type']]
        matches=[r for r in types[mapping['value']]['members'] if r['label']==member]
        require(len(matches)==1,'Ambiguous trusted struct member')
        return self.mapping(name,label,key)+int(matches[0]['slot']),matches[0]['offset']
    def packed(self,name,label,value,base=0):
        item=self.field(name,label);size=int(self.get(name)['types'][item['type']]['numberOfBytes'])
        require(0<=value<1<<(8*size),'Packed fixture value outside trusted type')
        shift=8*item['offset'];mask=((1<<(8*size))-1)<<shift
        return (base&~mask)|(value<<shift)

def scenarios():
    # Each row is a controlled *read* state, not a live protocol transaction.
    cases=[
      dict(id='dormant_unrevealed',active=False,revealed=False),
      dict(id='dormant_revealed',active=False),
      dict(id='activated',nav=100*10**18),
      dict(id='enhanced_boundary',nav=1000*10**18),
      dict(id='singularity_boundary',nav=10000*10**18),
      dict(id='unavailable_price_guard',price_failure=True),
      dict(id='parked',status=4),
      dict(id='exit_started_bucket_open',exit=True,phase=1),
      dict(id='exit_closed_unallocated',exit=True,phase=2,status=5),
      dict(id='exit_allocated_not_ready',exit=True,phase=2,status=5,allocated=True,eth=7,zzz=11),
      dict(id='exit_payable',exit=True,phase=3,status=5,allocated=True,eth=7,zzz=11),
      dict(id='exit_paid',exit=True,phase=3,status=5,allocated=True,paid=True,eth=7,zzz=11),
      dict(id='exit_exact_zero',exit=True,phase=3,status=5,allocated=True),
      dict(id='terminal_dormant',active=False,exit=True,phase=1),
      dict(id='replacement_preparing',preparing=True),
      dict(id='canonical_frozen',canonical=1,status=4),
      dict(id='canonical_importing',canonical=2,status=4),
      dict(id='canonical_retired',canonical=3,status=4),
      dict(id='canonical_cancelled',canonical=4,status=4),
      dict(id='invalid_nonexistent',active=False,nonexistent=True,expected_error='ERC721NonexistentToken(uint256)')]
    default=dict(active=True,revealed=True,nav=100*10**18,status=1,canonical=0,phase=0,
        exit=False,preparing=False,allocated=False,paid=False,eth=0,zzz=0)
    return [dict(default,**row) for row in cases]

def make_override(case,addresses,layout,bootstrap):
    """Only trusted-layout stateDiff on real targets; fixture code is genesis."""
    access=addresses['access'];nft=addresses['nft'];migration=addresses['migration'];royalties=addresses['royalty_rewards']
    result={}
    def put(target,slot,value):
        result.setdefault(target,{'stateDiff':{}})['stateDiff'][hexword(slot)]=hexword(value)
    def setfield(target,name,label,value):put(target,layout.slot(name,label),value)
    for role,name in MODULE_NAMES.items():
        target=addresses[role] if role in ('nft','migration','nft_canonical') else FIXTURE[role if role!='canonical' else 'handoff']
        put(access,layout.mapping('ZZZAccessController','module',int.from_bytes(keccak256(name.encode()),'big')),addr(target))
    packed5=layout.packed('ZZZAccessController','bootstrap',addr(bootstrap))
    packed5=layout.packed('ZZZAccessController','lpExitStarted',int(case['exit']),packed5)
    packed5=layout.packed('ZZZAccessController','preparationActive',int(case['preparing']),packed5)
    # Preserve actual constructor bootstrap/unsealed/paused values. These are
    # partial metadata read snapshots, not a simulated completed seal or mint.
    put(access,layout.slot('ZZZAccessController','bootstrap'),packed5)
    packed6=layout.packed('ZZZAccessController','protocolPolicy',addr(FIXTURE['policy']))
    packed6=layout.packed('ZZZAccessController','canonicalState',case['canonical'],packed6)
    put(access,layout.slot('ZZZAccessController','protocolPolicy'),packed6)
    if not case.get('nonexistent'):
        put(nft,layout.mapping('ZZZNFT','_owners',TOKEN),addr(OWNER))
        put(nft,layout.mapping('ZZZNFT','_balances',addr(OWNER)),1)
        for label,value in (('mintedCount',1),('nextToFinalize',2 if case['revealed'] else 1),('remainingToReveal',999)):
            setfield(nft,'ZZZNFT',label,value)
        put(nft,layout.mapping('ZZZNFT','tokenAtOrdinal',1),TOKEN)
        for label,value in (('mintOrdinalOf',1),('originalMintRecipient',addr(OWNER)),
            ('requestOf',1),('traitsReady',int(case['revealed'])),('rarityOf',2),('colorOf',0),('paletteOf',0),('patternOf',3)):
            put(nft,layout.mapping('ZZZNFT',label,TOKEN),value)
    weight=3 if case['active'] else 0
    put(royalties,layout.mapping('ZZZRoyaltyRewards','weightOf',TOKEN),weight)
    setfield(royalties,'ZZZRoyaltyRewards','totalWeight',weight)
    setfield(royalties,'ZZZRoyaltyRewards','activationCount',int(case['active']))
    put(royalties,layout.mapping('ZZZRoyaltyRewards','activationOrdinal',TOKEN),int(case['active']))
    setfield(migration,'ZZZMigration','exitPhase',case['phase'])
    for member,value in (('ethAmount',case['eth']),('zzzAmount',case['zzz'])):
        slot,offset=layout.member('ZZZMigration','principalOf',TOKEN,member)
        require(offset==0,'Unexpected principal numeric packing');put(migration,slot,value)
    slot,offset=layout.member('ZZZMigration','principalOf',TOKEN,'allocated');paid_slot,paid_offset=layout.member('ZZZMigration','principalOf',TOKEN,'paid')
    require(slot==paid_slot,'Unexpected principal flag layout')
    put(migration,slot,(int(case['allocated'])<<(8*offset))|(int(case['paid'])<<(8*paid_offset)))
    _,pool_id=fixture_runtimes()
    shares=case.get('shares',1) if case['active'] else 0
    status=case['status'] if case['active'] else 3
    for slot,value in ((0,1 if shares else 0),(1,shares),(2,case.get('supply',1)),(3,status)):
        put(FIXTURE['vault'],slot,value)
    position=(pool_id,1 if status==1 else 0,case.get('idle0',0),case.get('idle1',0),100*10**18,1<<96,0,status)
    for slot,value in enumerate(position,16):put(FIXTURE['vault'],slot,value)
    for slot,value in enumerate((case['nav']//2,case['nav']-case['nav']//2)):
        put(FIXTURE['liquidity'],slot,value)
    put(FIXTURE['fees'],0,case.get('compound',0));put(FIXTURE['strategy'],0,int(case.get('price_failure',False)))
    put(FIXTURE['handoff'],0,0 if case.get('missing_successor') else addr(FIXTURE['successor_access']))
    actual=set(addresses.values())
    for target,entry in result.items():
        require(set(entry)=={'stateDiff'},'Runtime or account override forbidden')
        require(target in actual or target in FIXTURE.values(),'Unexpected override target')
    return result

def state_diff_manifest(addresses,artifacts,bootstrap):
    """Exact union for runner's independent override/read-only allowlist."""
    layout=Layout(artifacts);slots={}
    for case in scenarios():
        for target,entry in make_override(case,addresses,layout,bootstrap).items():
            slots.setdefault(target,set()).update(entry['stateDiff'])
    return {target:sorted(values)for target,values in slots.items()}

def getter_manifest(addresses):
    rows=[]
    for role,signature,args in (
        ('access','bootstrap()',()),('access','isSealed()',()),('access','paused()',()),('access','preparationActive()',()),
        ('access','canonicalState()',()),('access','lpExitStarted()',()),('nft','mintedCount()',()),
        ('nft','balanceOf(address)',(addr(OWNER),)),('nft','ownerOf(uint256)',(TOKEN,)),
        ('nft','artworkBaseURI()',()),('nft','tokenURI(uint256)',(TOKEN,)),
        ('royalty_rewards','weightOf(uint256)',(TOKEN,)),('royalty_rewards','totalWeight()',()),
        ('migration','exitPhase()',()),('migration','principalOf(uint256)',(TOKEN,))):
        rows.append({'to':addresses[role],'data':data(signature,*args),'role':role,'signature':signature})
    return rows

def call_manifest(addresses):
    return {(row['to'].lower(),row['data'].lower())for row in getter_manifest(addresses)}

def decode_uri(raw):
    require(type(raw)is str and re.fullmatch(r'0x(?:[0-9a-fA-F]{2})*',raw),'Malformed tokenURI ABI')
    value=bytes.fromhex(raw[2:]);require(len(value)>=64 and int.from_bytes(value[:32],'big')==32,'Noncanonical tokenURI string offset')
    length=int.from_bytes(value[32:64],'big');require(length<=32768 and len(value)==64+((length+31)//32)*32 and not any(value[64+length:]),'Noncanonical tokenURI length/padding')
    uri=value[64:64+length].decode('utf-8');prefix='data:application/json;base64,'
    require(uri.startswith(prefix),'Unexpected tokenURI scheme')
    decoded=base64.b64decode(uri[len(prefix):],validate=True)
    def pairs(rows):
        result={}
        for key,v in rows:require(key not in result,'Duplicate metadata key');result[key]=v
        return result
    return uri,json.loads(decoded,object_pairs_hook=pairs),decoded

def validate_json(case,value,block,stamp,base_uri):
    traits={row['trait_type']:row['value'] for row in value['attributes']}
    require(value['metadata_schema']==2 and value['metadata_snapshot_block']==block and value['metadata_snapshot_timestamp']==stamp,'Wrong schema or read context')
    require(value['canonical_state']==case['canonical'] and value['replacement_preparing'] is case['preparing'] and value['collection_lp_exit_started'] is case['exit'] and value['collection_exit_phase']==case['phase'],'Wrong lifecycle flags')
    active=case['active'];closed=active and case['status']==5
    available=not active or closed or case['status']==1 and not case.get('price_failure',False)
    amount=0 if not active or closed else ((case['nav']+case.get('idle0',0)+case.get('idle1',0)+2*case.get('compound',0))*case.get('shares',1)//case.get('supply',1))
    require(value['valuation_available'] is available and value['royalty_activated'] is active and value['lp_exited'] is closed,'Wrong availability, activation or exit state')
    require(value['lp_value_usd_18']==(str(amount) if available else None),'Wrong marked synthetic value')
    stage=0 if not active else 4 if closed else 3 if amount>=10000*10**18 else 2 if amount>=1000*10**18 else 1
    label=('Dormant','Activated','Enhanced','Singularity','LP exited')[stage] if available else 'Valuation unavailable'
    require(traits['Evolution']==label,'Wrong evolution')
    expected_image=base_uri+'cyan-ribs-legendary-'+('activated' if not available or stage==4 else ('dormant','activated','enhanced','singularity')[stage])+'.svg'
    if case['revealed']:require(value['image']==expected_image and traits['NFT-sale royalty weight']==3,'Wrong fixed artwork/rarity trait')
    else:require(value['image'].startswith('data:image/svg+xml;base64,') and traits['Rarity']=='Unrevealed','Wrong pending reveal')
    require(value['activation_closed'] is (case['exit'] or case['canonical'] in (3,4)),'Wrong permanent closure')
    principal='unavailable_on_this_deployment' if case['canonical'] else 'not_applicable' if not active else 'not_started' if not case['exit'] else 'awaiting_allocation' if not case['allocated'] else 'paid' if case['paid'] else 'zero_entitlement' if not(case['eth'] or case['zzz']) else 'payable' if case['phase']==3 else 'allocated_pending_readiness'
    require(value['principal_return_status']==principal and value['principal_allocated'] is case['allocated'] and value['principal_paid'] is case['paid'],'Wrong principal settlement status')
    lifecycle={1:'Replacement frozen',2:'Replacement importing',3:'Replaced',4:'Cancelled import'}.get(case['canonical']) or ('Replacement preparing' if case['preparing'] else 'Activation closed' if case['exit'] and not active else 'LP exited' if closed else 'LP exit in progress' if case['exit'] else 'LP parked' if case['status']==4 else 'Operating' if active else 'Awaiting activation')
    require(traits['Lifecycle']==lifecycle,'Wrong lifecycle label')
    if case['canonical']==3:
        require(value['successor_controller']==FIXTURE['successor_access'] and value['successor_nft']==FIXTURE['successor_nft'],'Wrong successor identity')
    else:require(value['successor_controller'] is None and value['successor_nft'] is None,'Invented successor')
    return {'schema':2,'evolution':label,'lifecycle':lifecycle,'valuation_available':available,'value_usd_18':str(amount) if available else None,'royalty_activated':active,'principal_return_status':principal}

def run_cold_reads(node,addresses,artifacts,output):
    output=Path(output);output.mkdir(exist_ok=True)
    start=time.monotonic();initial_reads=len(node.records);layout=Layout(artifacts)
    def rpc(method,params):
        require(len(node.records)-initial_reads<MAX_READS and time.monotonic()-start<MAX_SECONDS,'Cold-read budget exhausted')
        before=len(node.records)
        try:return {'result':node.wire(method,params)}
        except ValueError:
            require(len(node.records)==before+1,'Local read failed without captured RPC response')
            record=node.records[-1]
            require(record['request']['method']==method and record['request']['params']==params and 'error'in record['response'],'Unexpected local read failure')
            return {'error':record['response']['error']}
    def read(target,signature,*args):
        outcome=rpc('eth_call',[{'to':target,'data':data(signature,*args),'gas':hex(CAP)},block])
        require('result'in outcome,'Baseline getter failed');return outcome['result']
    head=rpc('eth_getBlockByNumber',['latest',False]);require('result'in head,'Missing owned head')
    header=head['result'];number=int(header['number'],16);stamp=int(header['timestamp'],16);block=hex(number)
    required=('access','migration','metadata_renderer','nft','nft_canonical','royalty_rewards')
    require(all(role in addresses for role in required),'Incomplete actual constructor graph')
    require(not set(addresses.values()).intersection(FIXTURE.values()),'Fixture/actual address collision')
    def baseline():
        result={'codes':{},'getters':{},'balances':{},'nonces':{}}
        for role,target in addresses.items():
            outcome=rpc('eth_getCode',[target,block]);require('result'in outcome,'Missing actual code')
            result['codes'][role]=sha(bytes.fromhex(outcome['result'][2:]))
            result['balances'][role]=rpc('eth_getBalance',[target,block])
            result['nonces'][role]=rpc('eth_getTransactionCount',[target,block])
        for role,signature,args in (
            ('access','bootstrap()',()),('access','isSealed()',()),('access','paused()',()),('access','preparationActive()',()),
            ('access','canonicalState()',()),('access','lpExitStarted()',()),('nft','mintedCount()',()),
            ('nft','balanceOf(address)',(addr(OWNER),)),('royalty_rewards','weightOf(uint256)',(TOKEN,)),
            ('royalty_rewards','totalWeight()',()),('migration','exitPhase()',()),('migration','principalOf(uint256)',(TOKEN,))):
            result['getters'][role+'.'+signature]=read(addresses[role],signature,*args)
        return result
    before=baseline();require(int(before['getters']['access.isSealed()'],16)==0 and int(before['getters']['nft.mintedCount()'],16)==0,'Actual graph must stay unsealed/zero-NFT')
    bootstrap='0x'+before['getters']['access.bootstrap()'][-40:]
    require(int(before['getters']['access.paused()'],16)==0,'Unexpected actual controller pause')
    original_owner=rpc('eth_call',[{'to':addresses['nft'],'data':data('ownerOf(uint256)',TOKEN),'gas':hex(CAP)},block])
    require('error'in original_owner,'Actual graph unexpectedly owns fixture NFT')
    base_result=read(addresses['nft'],'artworkBaseURI()');raw=bytes.fromhex(base_result[2:]);length=int.from_bytes(raw[32:64],'big');base_uri=raw[64:64+length].decode()
    fixtures,_=fixture_runtimes()
    for role,target in FIXTURE.items():
        code=rpc('eth_getCode',[target,block]);require(code.get('result')=='0x'+fixtures[role].hex(),'Controlled fixture not installed at genesis')
    slot_manifest=state_diff_manifest(addresses,artifacts,bootstrap)
    slot_before={target:{slot:rpc('eth_getStorageAt',[target,slot,block])for slot in slots}for target,slots in slot_manifest.items()}
    rows=[];overrides={};trace=[]
    def checkpoint(row):
        rows.append(row)
        save(output/'COLD_PROGRESS.json',{'cases':rows,'read_RPCs':len(node.records)-initial_reads})
    for case in scenarios():
        override=make_override(case,addresses,layout,bootstrap);overrides[case['id']]=override
        tx={'to':addresses['nft'],'data':data('tokenURI(uint256)',TOKEN),'gas':hex(CAP)}
        outcome=rpc('eth_call',[tx,block,override]);row={'id':case['id'],'scenario':case,'override_sha256':sha(canonical(override)),'reference_gas':CAP,'reference':outcome}
        if 'expected_error'in case:
            try:
                require('error'in outcome,'Invalid fixture unexpectedly returned metadata')
                error=outcome['error'];payload=error.get('data');require(type(payload)is str and re.fullmatch(r'0x(?:[0-9a-fA-F]{2})*',payload),'Negative case lacks exact revert bytes')
                expected='0x' if case['expected_error']=='empty_revert' else '0x'+selector(case['expected_error']).hex()
                require(payload==expected if expected=='0x' else payload.startswith(expected),'Negative case failed for wrong selector')
                row['status']='expected_exact_revert'
            except ValueError as exc:row.update(status='unexpected_negative_result',model_error=str(exc))
            checkpoint(row);continue
        if 'result'not in outcome:
            row['status']='unexpected_reference_revert';checkpoint(row);continue
        try:
            uri,value,decoded=decode_uri(outcome['result']);row['decoded']=value
            row['expected_semantics']=validate_json(case,value,number,stamp,base_uri)
        except (ValueError,KeyError,TypeError,UnicodeError) as exc:
            row.update(status='unexpected_reference_semantics',model_error=str(exc));checkpoint(row);continue
        row.update(reference_abi_sha256=sha(bytes.fromhex(outcome['result'][2:])),decoded_json_sha256=sha(decoded),uri_bytes=len(uri.encode()),json_bytes=len(decoded))
        reference=outcome['result'];cache={CAP:{'result':reference}}
        def at(gas):
            if gas not in cache:cache[gas]=rpc('eth_call',[dict(tx,gas=hex(gas)),block,override])
            result=cache[gas]
            if 'error'in result:
                message=str(result['error'].get('message','')).lower()
                require(any(text in message for text in ('out of gas','outofgas','gas required exceeds','execution reverted','intrinsic gas too low')),'Unknown read failure cannot define a gas boundary')
            return result,'result'in result and result['result']==reference
        estimate=rpc('eth_estimateGas',[tx,block,override])
        if 'result'not in estimate:
            row.update(status='estimate_unavailable',estimate=estimate);checkpoint(row);continue
        estimated=int(estimate['result'],16);require(21000<=estimated<=CAP,'Invalid local estimate')
        padded=(estimated*12000+9999)//10000;require(padded<=CAP,'Controlled read padding exceeds node ceiling')
        estimated_result,estimate_same=at(estimated);padded_result,padded_same=at(padded)
        low,high=21000,CAP
        while high-low>1:
            middle=(low+high)//2
            if at(middle)[1]:high=middle
            else:low=middle
        high_result,high_same=at(high);low_result,low_same=at(low)
        require(high_same and not low_same and high==low+1,'Missing exact adjacent semantic bracket')
        def kind(result):return 'exact_reference' if result.get('result')==reference else 'successful_different_metadata' if 'result'in result else 'rpc_revert_or_failure'
        row.update(status='controlled_read_measured',estimated_gas=estimated,padded_gas=padded,
            estimate_semantics_match=estimate_same,padded_semantics_match=padded_same,
            estimate_response_kind=kind(estimated_result),padded_response_kind=kind(padded_result),
            adjacent_reference_transition={'matching_gas':high,'nonmatching_gas':low,'lower_response_kind':kind(low_result)},
            lowest_observed_EVM_success_gas=min(gas for gas,result in cache.items() if 'result'in result),
            globally_minimum_or_monotonicity_proven=False,
            gas_samples=[{'gas':gas,'response_kind':kind(result),'response':result}for gas,result in sorted(cache.items())])
        if case['id']=='enhanced_boundary':
            options={'disableStack':True,'disableMemory':True,'disableStorage':True,'stateOverrides':override}
            traced=rpc('debug_traceCall',[dict(tx,gas=hex(50000)),block,options])
            item={'case':case['id'],'options':{'disableStack':True,'disableMemory':True,'disableStorage':True,'stateOverrides_sha256':row['override_sha256']},'result':traced,'cold_storage_proven':False}
            if 'result'in traced:
                detail=traced['result'];logs=detail.get('structLogs',[])
                first=next((op for op in logs if op.get('op')=='SLOAD'),None)
                # This deliberately small trace may exhaust gas. Reaching the
                # renderer (depth2) proves the overridden owned NFT check passed;
                # without override this actual zero-NFT graph reverts at depth1.
                reached_renderer=any(op.get('depth')==2 for op in logs)
                if first and reached_renderer:
                    cost=first.get('gasCost');cost=int(cost,16)if type(cost)is str and cost.startswith('0x')else cost
                    item.update(first_SLOAD=first,cold_storage_proven=cost==2100,override_reached_renderer=True,
                        trace_gas_ceiling=50000,intentionally_may_exhaust_gas=True,trace_failed=detail.get('failed'))
            trace.append(item)
        rights=rpc('eth_call',[{'to':addresses['royalty_rewards'],'data':data('weightOf(uint256)',TOKEN),'gas':hex(CAP)},block,override])
        if rights.get('result')!=hexword(3 if case['active'] else 0):row.update(status='unexpected_royalty_weight',royalty_read=rights)
        else:row['royalty_weight_read']=rights['result']
        checkpoint(row)
    after=baseline();require(before==after,'Read fixture changed actual constructor state/code')
    slot_after={target:{slot:rpc('eth_getStorageAt',[target,slot,block])for slot in slots}for target,slots in slot_manifest.items()}
    require(slot_after==slot_before,'Transient fixture changed actual storage')
    after_head=rpc('eth_getBlockByNumber',[block,False]);require(after_head.get('result')==header,'Pinned constructor block changed')
    latest=rpc('eth_getBlockByNumber',['latest',False]);require(latest.get('result')==header,'A new head appeared during controlled reads')
    after_owner=rpc('eth_call',[{'to':addresses['nft'],'data':data('ownerOf(uint256)',TOKEN),'gas':hex(CAP)},block])
    require(after_owner==original_owner,'Read fixture persisted ownership')
    failures=[row['id']for row in rows if row['status']not in ('controlled_read_measured','expected_exact_revert')]
    cold_proven=any(item['cold_storage_proven']for item in trace)
    gas_mismatches=[row['id']for row in rows if row['status']=='controlled_read_measured'and
        not(row['estimate_semantics_match']and row['padded_semantics_match'])]
    verified=not failures and cold_proven and not gas_mismatches
    result={'schema':'metadata2-controlled-cold-reads1','status':'controlled_read_measurements_complete'if not failures else'controlled_read_measurements_complete_with_failures',
      'verification_passed':verified,'gas_review_semantic_mismatches':gas_mismatches,
      'verification_issues':(['unexpected_case_result']if failures else[])+(['cold_storage_not_proven']if not cold_proven else[])+(['estimate_or_padding_semantics_differ']if gas_mismatches else[]),
      'production_approved':False,'actual_mint_seal_financial_operations':False,
      'block':{'number':number,'hash':header['hash'],'timestamp':stamp},'actual_addresses':addresses,
      'base_uri':base_uri,'base_uri_utf8_bytes':len(base_uri.encode()),'base_uri_content_published_or_CID_qualified':False,
      'before':before,'after':after,'actual_state_and_all_constructed_code_unchanged':True,
      'overridden_storage_before':slot_before,'overridden_storage_after':slot_after,
      'cases':rows,'scenario_count':len(rows),'case_failures':failures,'read_RPCs':len(node.records)-initial_reads,
      'read_budget':MAX_READS,'elapsed_seconds':time.monotonic()-start,
      'call_accessList_or_blockOverride_used':False,'warmness_scope':'Each eth_call/estimate is independent; fixed block; no accessList. Debug trace must prove first SLOAD2100 with matching override result, else cold proof remains unavailable.',
      'cold_trace_proven':cold_proven,
      'source_price_cost_qualified':False,'actual_provider_OpenSea_read_gas_qualified':False,
      'minimum_scope':'Exact adjacent observed semantic transition from bounded binary search; no global monotonicity/minimum theorem. Successful degraded fallback is not healthy metadata qualification.',
      'fixture_scope':'Partial read-only lifecycle snapshots using exact trusted-layout transient stateDiff; not reachable-state, mint, activation, liquidity, payout or royalty-ledger operational rehearsal. Cheap deterministic synthetic USD and custody getters exclude real dual-feed/external venue gas.'}
    save(output/'COLD_RESULTS.json',result);save(output/'OVERRIDES.json',overrides)
    save(output/'FIXTURES.json',{'runtime_codes':{name:'0x'+raw.hex()for name,raw in fixtures.items()},'genesis_alloc':genesis_alloc(),'storage_layouts':layout.layouts,'state_diff_manifest':slot_manifest,'getter_manifest':getter_manifest(addresses)})
    save(output/'COLD_TRACE.json',trace)
    return result
