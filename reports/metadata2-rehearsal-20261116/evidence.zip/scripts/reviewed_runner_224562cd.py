"""Exactly five changed normal constructions on a new owned loopback chain.

External one-campaign runner; never a deployer, public signer or existing-node
client. Root creates SAFETY_APPROVED.json only after independent source review.
"""
from pathlib import Path
import gzip,hashlib,importlib.util,json,re,sys,time

R=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
E=Path(__file__).resolve().parent;V=E.parent
sys.path.insert(0,str(R))
from zzz_ops import deployment_plan as P
from zzz_ops.abi import keccak256

spec=importlib.util.spec_from_file_location('reviewed_owned_local_node',R/'scripts/rehearse-local-deployment.py')
L=importlib.util.module_from_spec(spec);spec.loader.exec_module(L)
ANVIL=V/'foundry-v1.4.4/anvil.exe'
TOP_ROLES=('access','metadata_renderer','migration','nft','nft_canonical')
INTERNAL_ROLES=('royalty_factory','activation_assets_factory','custody_validation','royalty_rewards','claim_router')
EXPECTED_LABELS=('create:access','create:metadata_renderer','create:migration','bind:migration',
                 'create:nft','bind:nft','create:nft_canonical','bind:nft_canonical')
URI='ipfs://metadata2-controlled-construction/'
sha=lambda raw:hashlib.sha256(raw).hexdigest()
require=L.require

def minimal_genesis():
    return {'config':{'chainId':L.CHAIN,'homesteadBlock':0,'eip150Block':0,'eip155Block':0,'eip158Block':0,
      'byzantiumBlock':0,'constantinopleBlock':0,'petersburgBlock':0,'istanbulBlock':0,'berlinBlock':0,
      'londonBlock':0,'shanghaiTime':0,'cancunTime':0},'nonce':'0x0','timestamp':hex(int(time.time())),
      'extraData':'0x','gasLimit':hex(L.CAP),'difficulty':'0x0','mixHash':'0x'+'0'*64,'coinbase':P.ZERO,
      'baseFeePerGas':'0x3b9aca00','alloc':{L.SENDER:{'balance':hex(10**25),'nonce':'0x0','code':'0x','storage':{}}}}

class SelectiveConstruction(L.Rehearsal):
    def transaction(self,label,payload,to=None):
        require(len(self.receipts)<8 and label==EXPECTED_LABELS[len(self.receipts)],'Outside exact five-create/three-bind sequence')
        if to is None:
            role=label.removeprefix('create:');name,refs=next((name,refs)for key,name,refs in P.TOP if key==role)
            expected='0x'+self.artifacts.contract(name)[1]['evm']['bytecode']['object']+P.encode_constructor(P.TYPES[name],self.arguments(refs)).hex()
            require(role in TOP_ROLES and payload==expected,'Creation is not the reviewed selected normal object')
        else:
            role=label.removeprefix('bind:');name=next(name for key,name,_ in P.TOP if key==role)
            require(role in ('migration','nft','nft_canonical')and to==self.addresses['access']and
                payload==L.data('bind(bytes32,address)',('bytes32','address'),('0x'+keccak256(name.encode()).hex(),self.addresses[role])),
                'Not an exact selected bootstrap binding')
        # Same owned-node simulation/padding/nonce/receipt/CREATE sequence as
        # the maintained full rehearsal, with only the three selected bindings.
        # Do not inherit its unrelated protocol_policy address assumption.
        tx={'from':L.SENDER,'value':'0x0','data':payload,'gas':hex(L.CAP)}
        if to is not None:tx['to']=to
        require(to is not None or 0<len(payload[2:])//2<=49152,'Full initcode exceeds original limit')
        self.node.guard();before=self.nonces();simulated=self.node.wire('eth_call',[tx,'latest'])
        estimated=int(self.node.wire('eth_estimateGas',[tx]),16);padded=(estimated*L.PADDING+9999)//10000
        require(21000<=padded<=L.CAP,'Padded construction exceeds original node cap')
        tx['gas']=hex(padded);require(self.node.wire('eth_call',[tx,'latest'])==simulated,'Padded simulation differs')
        require(self.nonces()==before,'Simulation changed actual sender/factory nonce')
        tx['nonce']=before[L.SENDER];tx['gasPrice']=self.node.wire('eth_gasPrice')
        self.node.pending='submission_uncertain_do_not_resend'
        txhash=self.node.mutate('eth_sendTransaction',[tx]);self.node.pending=txhash
        receipt=None;until=time.monotonic()+20
        while time.monotonic()<until:
            receipt=self.node.wire('eth_getTransactionReceipt',[txhash])
            if receipt:break
            time.sleep(.05)
        require(receipt is not None and int(receipt['status'],16)==1,'Missing successful receipt; no automatic retry')
        self.node.pending=None;actual=self.node.wire('eth_getTransactionByHash',[txhash])
        require(actual['input'].lower()==payload.lower()and int(actual['nonce'],16)==int(before[L.SENDER],16)and
            int(actual['gas'],16)==padded and actual['from'].lower()==L.SENDER and int(actual['value'],16)==0 and
            int(receipt['gasUsed'],16)<=padded,'Included transaction differs from exact construction review')
        result=None
        if to is None:
            result=receipt['contractAddress'].lower();require(self.node.wire('eth_getCode',[result,'latest']).lower()==simulated.lower(),'Constructor return differs from simulation')
            trace=self.node.wire('debug_traceTransaction',[txhash,{'tracer':'callTracer'}]);raw=P.canonical(trace)
            trace_name=f'{len(self.receipts)+1:02d}-'+label.replace(':','-')+'-trace.json.gz'
            with gzip.open(self.output/trace_name,'xb')as stream:stream.write(raw)
            def collect(frame):
                require(not frame.get('error'),'Included CREATE trace contains a reverted child')
                if frame.get('type')in ('CREATE','CREATE2'):
                    require(frame['type']=='CREATE'and frame.get('to')and frame.get('input')and frame.get('output'),'Expected exact CREATE frame')
                    target=frame['to'].lower();require(target not in self.creates,'Duplicate actual CREATE')
                    self.creates[target]={'creator':frame['from'].lower(),'input':frame['input'].lower(),'output':frame['output'].lower(),
                        'transaction_hash':txhash,'trace_file':trace_name,'trace_sha256':sha(raw)}
                    self.node.code_pins[target]=frame['output'].lower()
                for child in frame.get('calls',[]):collect(child)
            collect(trace)
        else:require(simulated=='0x'and actual['to'].lower()==to,'Selected binding target/output differs')
        row={'label':label,'transaction':actual,'receipt':receipt,'estimated_gas':estimated,'padded_gas':padded,
             'padding_bps':L.PADDING,'simulation_return':simulated,'nonce_before':before,'simulation_nonce_unchanged':True}
        L.save(self.output/(f'{len(self.receipts)+1:02d}-'+label.replace(':','-')+'.json'),row);self.receipts.append(row)
        print(json.dumps({'completed':label,'receipt_gas':int(self.receipts[-1]['receipt']['gasUsed'],16),
                          'padded_gas':self.receipts[-1]['padded_gas']}),flush=True)
        return result

    def run_selected(self):
        self.inputs={'governance':L.SENDER,'keeper':L.KEEPER,'guardian':L.GUARDIAN,'base_uri':URI}
        for role in TOP_ROLES:
            name,refs=next((name,refs)for key,name,refs in P.TOP if key==role)
            payload='0x'+self.artifacts.contract(name)[1]['evm']['bytecode']['object']+P.encode_constructor(P.TYPES[name],self.arguments(refs)).hex()
            self.addresses[role]=self.transaction('create:'+role,payload)
            if role=='access':self.factory_addresses=[self.getter(self.addresses['access'],s)for s in ('royaltyFactory()','activationAssetsFactory()')]
            if role in ('migration','nft','nft_canonical'):
                self.transaction('bind:'+role,L.data('bind(bytes32,address)',('bytes32','address'),
                    ('0x'+keccak256(name.encode()).hex(),self.addresses[role])),self.addresses['access'])
        require(len(self.receipts)==8,'Wrong selected transaction count')
        self.all_addresses=self.verify_instances()
        self.initial_bindings=self.binding_reads()
        L.save(self.output/'bindings-before-cold.json',self.initial_bindings)
        return self.all_addresses

    def verify_instances(self):
        a=dict(self.addresses)
        for role,parent,getter in (('royalty_factory','access','royaltyFactory()'),('activation_assets_factory','access','activationAssetsFactory()'),
          ('custody_validation','migration','validation()'),('royalty_rewards','nft','royaltyRewards()'),('claim_router','nft','claimRouter()')):
            a[role]=self.getter(a[parent],getter)
        for i in range(2):a['royalty_data_part'+str(i)]=self.getter(a['royalty_factory'],'part'+str(i)+'()')
        require(len(a)==len(set(a.values()))==12 and set(self.creates)==set(a.values()),'Expected exactly12 actual selected instances')
        ledger=bytes.fromhex(self.artifacts.contract('ZZZRoyaltyRewards')[1]['evm']['bytecode']['object'])
        discovered={'Registry.activationAssets()':None,'NFT.royaltyRewards()':a['royalty_rewards']}
        specs={role:(name,None,refs)for role,name,refs in P.TOP if role in TOP_ROLES}
        specs.update({role:(name,parent,refs)for role,name,parent,refs,_ in P.INTERNAL if role in INTERNAL_ROLES})
        specs.update({f'royalty_data_part{i}':('ZZZRoyaltyCodeData','royalty_factory',(f'd:{i}',))for i in range(2)})
        rows=[]
        for role,(name,parent,refs)in specs.items():
            values=[]
            for ref in refs:
                prefix,key=ref.split(':',1)
                if prefix=='p':value=a[key]
                elif prefix=='i':value=self.inputs[key]
                elif prefix=='g':value=discovered[key]
                elif prefix=='d':value=ledger[:24573]if key=='0'else ledger[24573:]
                else:raise ValueError('Unknown selected constructor argument')
                values.append(value)
            source,obj,abi=self.artifacts.contract(name)
            require(tuple(x['type']for x in abi)==P.TYPES[name],'Changed constructor ABI')
            encoded=P.encode_constructor(P.TYPES[name],values);full='0x'+obj['evm']['bytecode']['object']+encoded.hex()
            proof=self.creates[a[role]];runtime=self.node.wire('eth_getCode',[a[role],'latest']).lower()
            require(proof['creator']==(L.SENDER if parent is None else a[parent])and proof['input']==full.lower()and proof['output']==runtime,
                    'Selected constructor input/creator/output does not reconcile')
            expected_size=len(bytes.fromhex(obj['evm']['deployedBytecode']['object']))
            if name=='ZZZRoyaltyCodeData':
                expected='0x'+(b'\x5f\x5f\xfd'+values[0]).hex();expected_size=len(bytes.fromhex(expected[2:]))
                require(runtime==expected,'Inert data return differs from trusted ledger slice')
            require(len(bytes.fromhex(full[2:]))<=49152 and len(bytes.fromhex(runtime[2:]))==expected_size<=24576,'Original size limits violated')
            rows.append({'role':role,'contract':name,'source':source,'address':a[role],'creator_role':parent,'full_initcode_hex':full,
              'runtime_bytes':expected_size,'runtime_sha256':sha(bytes.fromhex(runtime[2:])),'runtime_keccak256':'0x'+keccak256(bytes.fromhex(runtime[2:])).hex(),
              'creation_object_sha256':sha(bytes.fromhex(obj['evm']['bytecode']['object'])),'create_proof':proof})
        L.save(self.output/'instances.json',rows);L.save(self.output/'addresses.json',a)
        return a

    def binding_reads(self):
        a=self.all_addresses;rows=[]
        def check(role,signature,value,types=(),values=()):
            actual=self.call(a[role],signature,types,values)
            expected='0x'+(int(value).to_bytes(32,'big').hex()if type(value)is int else bytes.fromhex(value[2:]).rjust(32,b'\0').hex())
            require(actual.lower()==expected.lower(),'Selected binding/state differs: '+role+'.'+signature)
            rows.append({'role':role,'signature':signature,'arguments':list(values),'actual':actual,'expected':expected})
        for role in P.MODULES:
            name=next(name for key,name,_ in P.TOP if key==role)
            check('access','module(bytes32)',a[role]if role in ('migration','nft','nft_canonical')else P.ZERO,
                  ('bytes32',),('0x'+keccak256(name.encode()).hex(),))
        for role in ('metadata_renderer','migration','nft','nft_canonical','custody_validation','claim_router','activation_assets_factory'):check(role,'access()',a['access'])
        for role,signature,value in (('access','bootstrap()',L.SENDER),('access','governance()',L.SENDER),('access','protocolPolicy()',P.ZERO),
          ('access','royaltyFactory()',a['royalty_factory']),('access','activationAssetsFactory()',a['activation_assets_factory']),
          ('royalty_factory','controller()',a['access']),('royalty_rewards','canonicalController()',a['access']),('royalty_rewards','nft()',a['nft']),
          ('claim_router','nft()',a['nft']),('claim_router','royalties()',a['royalty_rewards']),('custody_validation','migration()',a['migration']),
          ('nft','metadataRenderer()',a['metadata_renderer']),('nft_canonical','nft()',a['nft']),('nft','royaltyRewards()',a['royalty_rewards']),
          ('nft','claimRouter()',a['claim_router']),('migration','validation()',a['custody_validation']),('migration','currentZZZ()',P.ZERO),('nft','seaDropMint()',P.ZERO)):
            check(role,signature,value)
        for signature in ('isSealed()','paused()','preparationActive()','lpExitStarted()','canonicalState()'):check('access',signature,0)
        for role,signature,value in (('metadata_renderer','METADATA_LIFECYCLE_VERSION()',2),('migration','exitPhase()',0),('nft','mintedCount()',0),
          ('nft','nextToFinalize()',1),('nft','remainingToReveal()',1000),('nft','mintPaused()',0),('royalty_rewards','assetCount()',1),('royalty_rewards','totalWeight()',0)):
            check(role,signature,value)
        check('access','keepers(address)',1,('address',),(L.KEEPER,));check('access','guardians(address)',1,('address',),(L.GUARDIAN,))
        ledger=bytes.fromhex(self.artifacts.contract('ZZZRoyaltyRewards')[1]['evm']['bytecode']['object'])
        check('royalty_factory','royaltyCodeHash()','0x'+keccak256(ledger).hex());check('royalty_factory','creationCodeLength()',len(ledger))
        for i,piece in enumerate((ledger[:24573],ledger[24573:])):
            check('royalty_factory','part'+str(i)+'()',a['royalty_data_part'+str(i)])
            check('royalty_factory','part'+str(i)+'CodeHash()','0x'+keccak256(b'\x5f\x5f\xfd'+piece).hex())
        raw=self.call(a['nft'],'artworkBaseURI()');expected='0x'+P.encode_constructor(('string',),(URI,)).hex()
        require(raw==expected,'Actual immutable metadata URI differs');rows.append({'role':'nft','signature':'artworkBaseURI()','actual':raw,'expected':expected})
        return rows

class ColdReadOnly:
    """Read-only campaign facade: real target code cannot be replaced."""
    def __init__(self,node,addresses,call_manifest,slot_manifest,fixtures,block):
        self.node=node;self.addresses=addresses;self.started=time.monotonic();self.reads=0
        self.calls=set(call_manifest);self.slots=slot_manifest;self.fixtures=fixtures;self.block=block
    @property
    def records(self):return self.node.records
    def wire(self,method,params=None):
        require(self.reads<900 and time.monotonic()-self.started<360,'Cold-read work/time budget exhausted')
        require(method in ('eth_call','eth_estimateGas','debug_traceCall','eth_getBlockByNumber','eth_getCode','eth_getStorageAt',
                           'eth_getBalance','eth_getTransactionCount','eth_chainId'),'Outside read-only cold measurement methods')
        params=params or [];overrides={}
        if method in ('eth_call','eth_estimateGas','debug_traceCall'):
            require(2<=len(params)<=3 and type(params[0])is dict,'Unexpected cold call shape')
            tx=params[0];require((tx.get('to','').lower(),tx.get('data','').lower())in self.calls,'Cold call is outside frozen exact read manifest')
            require(params[1]==self.block,'Cold reads must use exact pinned constructor block')
            require(set(tx)<= {'from','to','data','gas','value'} and tx.get('from',L.SENDER).lower()==L.SENDER and
                    int(tx.get('value','0x0'),16)==0 and 0<int(tx.get('gas',hex(L.CAP)),16)<=L.CAP,'Cold read exceeds fixed transaction scope')
            if method=='debug_traceCall':
                require(len(params)==3 and type(params[2])is dict,'Trace options required')
                options=params[2];require(set(options)=={'disableStack','disableMemory','disableStorage','stateOverrides'}and
                  options['disableStack']is True and options['disableMemory']is True and options['disableStorage']is True and
                  int(tx.get('gas',hex(L.CAP)),16)<=50000,'Only bounded50k read-only opcode trace is admitted')
                overrides=options.get('stateOverrides',{})
            elif len(params)==3:overrides=params[2]
            require(type(overrides)is dict and len(overrides)<=16,'Unbounded cold override inventory')
            for address,row in overrides.items():
                require(re.fullmatch(r'0x[0-9a-fA-F]{40}',address)is not None and type(row)is dict,'Invalid controlled override entry')
                require(address.lower()in self.slots and set(row)=={'stateDiff'},'Code/account override or undeclared state target forbidden')
                diff=row.get('stateDiff',{});require(type(diff)is dict and len(diff)<=128 and all(
                    re.fullmatch(r'0x[0-9a-fA-F]{64}',slot)is not None and re.fullmatch(r'0x[0-9a-fA-F]{64}',value)is not None
                    for slot,value in diff.items()),'Unbounded or invalid storage-layout override')
                require(set(diff)<=set(self.slots[address.lower()]),'Storage override is outside frozen exact slot manifest')
        else:
            if method=='eth_chainId':require(params==[],'Unexpected chain read parameters')
            elif method=='eth_getBlockByNumber':require(params in (['latest',False],[self.block,False]),'Unexpected header read parameters')
            elif method=='eth_getStorageAt':require(len(params)==3 and params[0].lower()in self.slots and params[1]in self.slots[params[0].lower()]and params[2]==self.block,'Undeclared slot read')
            else:require(len(params)==2 and params[0].lower()in set(self.addresses.values())|set(self.fixtures)and params[1]==self.block,'Unexpected account read')
        self.reads+=1
        return self.node.wire(method,params)

def main():
    require((E/'BASELINE.json').is_file(),'Root baseline required')
    approval=json.loads((E/'SAFETY_APPROVED.json').read_bytes())
    callback_path=E/'cold_metadata.py'
    sources={str(Path(__file__).resolve()):sha(Path(__file__).read_bytes()),str(callback_path):sha(callback_path.read_bytes()),
             **{str(R/name):sha((R/name).read_bytes())for name in ('scripts/rehearse-local-deployment.py','zzz_ops/deployment_plan.py','zzz_ops/abi.py')}}
    require(approval['source_sha256']==sources and approval['anvil_sha256']==sha(ANVIL.read_bytes()),'Safety-reviewed source/binary pins differ')
    artifacts=P.Artifacts(build_profile='metadata2-20261116');output=E/'attempt1';require(not output.exists(),'Exclusive new attempt required')
    callback_spec=importlib.util.spec_from_file_location('reviewed_cold_reads',callback_path)
    callback=importlib.util.module_from_spec(callback_spec);callback_spec.loader.exec_module(callback)
    output.mkdir();L.save(output/'source-stage.json',{'source_sha256':sources,'accepted_build_profile':artifacts.profile,
        'accepted_build_files_sha256':artifacts.file_pins,'source_pins':artifacts.source_pins,'expected_actual_transactions':list(EXPECTED_LABELS),
        'normal_runtime_limit':24576,'normal_full_initcode_limit':49152,'local_block_gas_limit':L.CAP,'padding_bps':L.PADDING,
        'public_rpc':False,'existing_nodes_contacted':False,'seal_or_mint_authorized':False})
    fixture_alloc=callback.genesis_alloc();initial=minimal_genesis()
    require(set(fixture_alloc)==set(callback.FIXTURE.values())and len(fixture_alloc)==10 and L.SENDER not in fixture_alloc,'Unexpected exact counterpart genesis inventory')
    initial['alloc'].update(fixture_alloc)
    L.save(output/'controlled-fixtures.json',fixture_alloc)
    # Only these additional bounded reads are available to the callback facade.
    L.READS=L.READS|{'debug_traceCall','eth_getStorageAt'}
    try:
        with L.Node(ANVIL,output/'node',initial)as node:
            case=SelectiveConstruction(node,artifacts,output);addresses=case.run_selected()
            require(not set(addresses.values()).intersection(fixture_alloc),'Actual/counterpart address collision')
            layout=callback.Layout(artifacts);slot_manifest={}
            for scenario in callback.scenarios():
                override=callback.make_override(scenario,addresses,layout,L.SENDER)
                for target,row in override.items():
                    require(set(row)=={'stateDiff'},'Only transient stateDiff allowed')
                    slot_manifest.setdefault(target.lower(),set()).update(row['stateDiff'])
            slot_manifest={target:sorted(slots)for target,slots in slot_manifest.items()}
            require(slot_manifest==callback.state_diff_manifest(addresses,artifacts,L.SENDER),'Cold exact slot manifest disagreement')
            call_manifest={(row['to'].lower(),row['data'].lower())for row in callback.getter_manifest(addresses)}
            require(len(call_manifest)==15,'Unexpected exact baseline/metadata read manifest')
            L.save(output/'cold-access-manifest.json',{'calls':sorted(call_manifest),'storage_slots':slot_manifest})
            head=node.wire('eth_getBlockByNumber',['latest',False]);block=head['number']
            accounts=set(addresses.values())|set(fixture_alloc)|{L.SENDER}
            def snapshot():
                header=node.wire('eth_getBlockByNumber',['latest',False])
                require(header['number']==block,'Owned head changed during read campaign')
                count=len(node.records)
                try:node.wire('eth_call',[{'to':addresses['nft'],'data':L.data('ownerOf(uint256)',('uint256',),(str(callback.TOKEN),))},block])
                except ValueError:
                    require(len(node.records)==count+1,'Unminted owner probe lacks actual response')
                    error=node.records[-1]['response'].get('error',{})
                    require(error.get('data')=='0x'+keccak256(b'ERC721NonexistentToken(uint256)')[:4].hex()+P.encode_constructor(('uint256',),(str(callback.TOKEN),)).hex(),
                        'Unminted owner probe failed for wrong reason')
                else:raise ValueError('Actual unminted graph unexpectedly owns controlled token')
                return {'header':{key:header[key]for key in ('hash','stateRoot','number','timestamp')},'unminted_owner_probe':error,
                    'nonces':{a:node.wire('eth_getTransactionCount',[a,block])for a in sorted(accounts)},
                    'balances':{a:node.wire('eth_getBalance',[a,block])for a in sorted(accounts)},
                    'codes':{a:node.wire('eth_getCode',[a,block])for a in sorted(accounts)},
                    'storage':{a:{slot:node.wire('eth_getStorageAt',[a,slot,block])for slot in slots}for a,slots in slot_manifest.items()}}
            before=snapshot()
            L.save(output/'state-before-cold.json',before);node.guard()
            cold=ColdReadOnly(node,addresses,call_manifest,slot_manifest,fixture_alloc,block);cold_result=callback.run_cold_reads(cold,addresses,artifacts,output)
            L.save(output/'cold-summary.json',cold_result);node.guard()
            after=snapshot()
            require(after==before,'Read-only cold campaign changed actual header/account/code/storage state')
            require(case.binding_reads()==case.initial_bindings,'Read-only cold campaign changed binding/state getters')
            L.save(output/'state-after-cold.json',after)
            require(len(case.receipts)==8 and len([row for row in node.records if row['request']['method']=='anvil_impersonateAccount'])==1 and
                    len([row for row in node.records if row['request']['method']=='eth_sendTransaction'])==8,'Unexpected actual mutation count')
            artifacts.check_sources();require(all(sha(Path(path).read_bytes())==pin for path,pin in sources.items()),'Reviewed source changed during campaign')
            result={'status':'selective_metadata2_construction_and_cold_reads_completed','accepted_build_profile':artifacts.profile,
                'actual_top_level_creations':5,'actual_internal_instances':7,'actual_bindings':3,'actual_receipts':8,'actual_instances':12,
                'constructor_gas':{row['label']:{'estimate':row['estimated_gas'],'padded':row['padded_gas'],'used':int(row['receipt']['gasUsed'],16)}for row in case.receipts},
                'total_receipt_gas':sum(int(row['receipt']['gasUsed'],16)for row in case.receipts),'cold_reads':cold.reads,
                'cold_fixture_scope':'Per-call stateDiff and typed controlled counterparts; real target runtime code preserved. No actual mint/LP/seal.',
                'production_approved':False,'release_ready':False,'public_transactions':0,'existing_nodes_contacted':False,'sealed':False,
                'unchanged_top_level_constructors_reexecuted':0,'compiler_runs':0,'unchanged_test_methods_executed':0}
            L.save(output/'RESULT.json',result)
        print(json.dumps(result),flush=True)
    except BaseException as error:
        L.save(output/'FAILED.json',{'error_type':type(error).__name__,'message':str(error)if type(error)is ValueError else 'Inspect preserved raw bounded evidence',
                    'public_transactions':0,'existing_nodes_contacted':False,'automatic_retry':False})
        raise

if __name__=='__main__':main()
