from pathlib import Path
import hashlib,json
E=Path(__file__).resolve().parent
R=Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
review=json.loads((E/'FINAL_PRE_START_REVIEW.json').read_bytes())
delta=json.loads((E/'FINAL_DELTA_REVIEW.json').read_bytes())
assert review['status']=='CLEARED_FOR_EXACT_ISOLATED_CAMPAIGN_ONLY'
assert delta['status']=='EXACT_DELTA_CLEARED_FOR_ISOLATED_CAMPAIGN'
assert delta['final_runner_sha256']=='b47b34366252ab195fe2253fa02ec5d9e6fc16539f942e4598435e2051d796fc'
assert sha(E/'selective_constructors.py')=='b47b34366252ab195fe2253fa02ec5d9e6fc16539f942e4598435e2051d796fc'
assert sha(E/'cold_metadata.py')=='464649e30f883d499ae0ea17706dc7f8dc6771f6360584b6e5c222eab8596ed4'
sources={str(E/name):sha(E/name)for name in ('selective_constructors.py','cold_metadata.py')}
sources.update({str(R/name):sha(R/name)for name in ('scripts/rehearse-local-deployment.py','zzz_ops/deployment_plan.py','zzz_ops/abi.py')})
assert all(review['source_sha256'][p]==pin for p,pin in sources.items()if not p.endswith('selective_constructors.py'))
binary=E.parent/'foundry-v1.4.4/anvil.exe'
assert sha(binary)==review['anvil_sha256']
result={'source_sha256':sources,'anvil_sha256':sha(binary),'root_reviewed':True,
        'independent_review_sha256':sha(E/'FINAL_PRE_START_REVIEW.json'),
        'result_delta_review_sha256':sha(E/'FINAL_DELTA_REVIEW.json'),
        'scope':'One new PID-owned loopback selective five-constructor/three-binding campaign; no public transaction, seal, mint, old-node access or environment adoption.'}
with (E/'SAFETY_APPROVED.json').open('x',encoding='utf-8')as stream:json.dump(result,stream,indent=2)
print(json.dumps({'approved':True,'public_deployment':False,'source_count':len(sources)}))
