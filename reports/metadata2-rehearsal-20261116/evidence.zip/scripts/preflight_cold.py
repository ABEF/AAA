"""Offline fixture encoding/layout checks only; no EVM, compiler, node or RPC."""
from pathlib import Path
import ast,gzip,hashlib,importlib.util,json,sys
from types import SimpleNamespace
R=Path(r'C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
E=Path(__file__).resolve().parent
sys.path.insert(0,str(R))
raw=(E/'cold_metadata.py').read_bytes();ast.parse(raw)
spec=importlib.util.spec_from_file_location('cold_metadata',E/'cold_metadata.py')
C=importlib.util.module_from_spec(spec);spec.loader.exec_module(C)
source=R/'reports/metadata-lifecycle-fixes-20261116/build/compiler-output.json.gz'
compressed=source.read_bytes()
assert hashlib.sha256(compressed).hexdigest()=='4acc319da1a5b4e8a4c112fb9a6c0832d3943d2722d2d17f30dd288c125f3a0f'
output=json.loads(gzip.decompress(compressed));artifacts=SimpleNamespace(output=output)
roles=('access','metadata_renderer','migration','nft','nft_canonical','royalty_rewards','royalty_factory',
    'activation_assets_factory','royalty_data_part0','royalty_data_part1','claim_router','custody_validation')
addresses={name:'0x'+f'{0xc100+i:040x}'for i,name in enumerate(roles)}
bootstrap='0x000000000000000000000000000000000000a0a0'
layout=C.Layout(artifacts);cases=C.scenarios();assert len(cases)==20 and len({c['id']for c in cases})==20
runtimes,pool=C.fixture_runtimes();alloc=C.genesis_alloc();assert len(runtimes)==len(alloc)==10
dispatch=[]
for role,code in runtimes.items():
    assert code[:5]==bytes.fromhex('5f3560e01c')
    cursor=5;rows=[]
    while code[cursor:cursor+2]==bytes.fromhex('8063'):
        selector=code[cursor+2:cursor+6];assert code[cursor+6:cursor+8]==bytes.fromhex('1461')and code[cursor+10]==0x57
        destination=int.from_bytes(code[cursor+8:cursor+10],'big')
        assert code[destination]==0x5b
        rows.append({'selector':'0x'+selector.hex(),'destination':destination});cursor+=11
    assert code[cursor:cursor+3]==bytes.fromhex('5f5ffd')and len({r['selector']for r in rows})==len(rows)
    if role=='strategy':
        body=code[rows[0]['destination']+1:]
        assert body[:5]==bytes.fromhex('505f541561')and body[7:12]==bytes.fromhex('575f5ffd5b')
        target=int.from_bytes(body[5:7],'big');assert code[target]==0x5b and code[target+1:target+1+len(C.push(1<<96))]==C.push(1<<96)
    dispatch.append({'role':role,'bytes':len(code),'sha256':hashlib.sha256(code).hexdigest(),'branches':rows})
manifest=C.state_diff_manifest(addresses,artifacts,bootstrap)
for case in cases:
    override=C.make_override(case,addresses,layout,bootstrap)
    for target,row in override.items():
        assert set(row)=={'stateDiff'} and set(row['stateDiff'])<=set(manifest[target])
        assert all(len(k)==len(v)==66 for k,v in row['stateDiff'].items())
    access=override[addresses['access']]['stateDiff']
    packed5=int(access[C.hexword(layout.slot('ZZZAccessController','bootstrap'))],16)
    assert packed5&((1<<160)-1)==int(bootstrap,16)
    assert packed5>>(20*8)&0xffff==0
    assert packed5>>(22*8)&255==int(case['exit'])and packed5>>(23*8)&255==int(case['preparing'])
    packed6=int(access[C.hexword(layout.slot('ZZZAccessController','protocolPolicy'))],16)
    assert packed6&((1<<160)-1)==int(C.FIXTURE['policy'],16)and packed6>>(20*8)&255==case['canonical']
    if not case.get('nonexistent'):
        token_order=layout.mapping('ZZZNFT','tokenAtOrdinal',1)
        assert int(override[addresses['nft']]['stateDiff'][C.hexword(token_order)],16)==C.TOKEN
    assert C.data('tokenURI(uint256)',C.TOKEN)=='0x'+C.selector('tokenURI(uint256)').hex()+'ff'*32
result={'status':'offline_fixture_encoding_layout_checks_passed','callback_sha256':hashlib.sha256(raw).hexdigest(),
    'accepted_compiler_output_gzip_sha256':hashlib.sha256(compressed).hexdigest(),
    'scenario_count':len(cases),'actual_normal_roles':list(addresses),'token_decimal_digits':len(str(C.TOKEN)),
    'distinct_fixture_roles':10,'dispatchers':dispatch,'union_storage_slots':sum(map(len,manifest.values())),
    'override_target_count':len(manifest),'state_diff_manifest_example':manifest,'getter_manifest_example':C.getter_manifest(addresses),
    'production_or_test_EVM_executions':0,'compiler_runs':0,'RPC_calls':0,'node_started':False,
    'scope':'Pure Python syntax, selector destinations, fixed bytes, uint256/packing and accepted storage-layout derivation. Not EVM behavior or gas proof.'}
(E/'COLD_PREFLIGHT.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
assert raw==(E/'cold_metadata.py').read_bytes()
print(json.dumps({k:result[k]for k in ('status','callback_sha256','scenario_count','token_decimal_digits','union_storage_slots','RPC_calls')}))
