"""Killable isolated API workers with bounded parallel admission."""
from __future__ import annotations

import json
import multiprocessing
import queue
from pathlib import Path
import tempfile
import threading
import time

from frontend_api.service import Projection, UnknownNFT
from frontend_api.http_runtime import ServiceBusy
from zzz_ops.errors import RpcError, WorkLimit
from zzz_ops.work_budget import request_scope

MAX_RESULT = 1024 * 1024
HARD_SECONDS = 30


def _run(output, config, activation_config, action, payload, transaction_config=None):
    # Catch/sanitize failures inside the child: multiprocessing must never print
    # upstream exception strings or configured credentials in a traceback.
    try:
        from frontend_api.activation import ActivationTransactions, ActivationInputError
        p = Projection(config)
        with request_scope():
            if action == 'protocol':
                result = p.protocol()
            elif action == 'mint_readiness':
                result = p.mint_readiness()
            elif action == 'nft':
                result = p.nft(payload)
            elif action == 'wallet':
                result = p.wallet(payload)
            elif action == 'wallet_page':
                result = p.wallet_page(*payload)
            elif action == 'collection':
                result = p.collection(*payload)
            elif action == 'wallet_summary':
                result = p.wallet_summary(*payload)
            elif action == 'wallet_earnings':
                result = p.wallet_earnings(*payload)
            elif action == 'wallet_view':
                result = p.wallet_view(*payload)
            elif action == 'earnings':
                result = p.earnings(payload)
            elif action == 'activation' and activation_config is not None:
                result = ActivationTransactions(p, activation_config).prepare(payload)
            elif action == 'transactions' and transaction_config is not None:
                from frontend_api.transactions import Transactions
                result = Transactions(p, transaction_config).prepare(payload)
            elif action == 'claim_plan' and transaction_config is not None:
                from frontend_api.transactions import Transactions
                result = Transactions(p, transaction_config).plan_claims(payload)
            else:
                raise ValueError('Unsupported operation')
        envelope = {'ok': result}
    except WorkLimit as exc:
        envelope = {'error': exc.reason}
    except UnknownNFT:
        envelope = {'error': 'nft_not_minted'}
    except BaseException as exc:
        # Map only the exact known input exception; no names or messages leak.
        from frontend_api.activation import ActivationInputError
        from frontend_api.transactions import TransactionInputError
        envelope = {'error': 'invalid_activation' if isinstance(exc, ActivationInputError) else
                    'invalid_transaction' if isinstance(exc, TransactionInputError) else 'unavailable'}
    try:
        encoded = json.dumps(envelope, separators=(',', ':'), allow_nan=False).encode()
        if len(encoded) > MAX_RESULT:
            encoded = b'{"error":"result_limit"}'
        Path(output).write_bytes(encoded)
    except BaseException:
        # Parent rejects missing/partial/malformed output after the child exits.
        pass


class WorkerClient:
    """One child per operation, no orphan work after the response deadline.

    The supervisor uses spawn on every OS. A worker can read RPC/history but
    cannot sign or broadcast. Each client handles one child; WorkerPool owns a
    finite set of independent clients. Proxy/rate limits remain required.
    """

    def __init__(self, config, activation_config=None, *, transaction_config=None):
        # Validate before accepting requests, without network calls.
        self.config = json.loads(json.dumps(config))
        self.activation_config = json.loads(json.dumps(activation_config))
        self.transaction_config = json.loads(json.dumps(transaction_config))
        if activation_config is not None and transaction_config is not None:
            raise ValueError('Use separate listeners for activation and mint/claim preparation')
        p = Projection(self.config)
        self.chain = p.chain
        if activation_config is not None:
            from frontend_api.activation import ActivationTransactions
            ActivationTransactions(p, self.activation_config)
        if transaction_config is not None:
            from frontend_api.transactions import Transactions
            Transactions(p, self.transaction_config)
        self._lock = threading.Lock()
        self._unreaped = None

    def _request(self, action, payload=None):
        from frontend_api.activation import ActivationInputError
        from frontend_api.transactions import TransactionInputError
        if not self._lock.acquire(blocking=False):
            raise RpcError('Request worker unavailable')
        # Check quarantine under admission, not before it: a caller can be
        # preempted while the preceding request is finishing failed cleanup.
        if self._unreaped is not None:
            self._lock.release()
            raise RpcError('Request worker unavailable')
        started = time.monotonic()
        event = 'failed'
        process = None
        directory = None
        try:
            directory = tempfile.TemporaryDirectory(prefix='popl-read-')
            output = Path(directory.name) / 'result.json'
            arguments = (str(output), self.config, self.activation_config, action, payload)
            if self.transaction_config is not None:
                arguments += (self.transaction_config,)
            process = multiprocessing.get_context('spawn').Process(target=_run, args=arguments, daemon=True)
            process.start()
            process.join(max(0, HARD_SECONDS - (time.monotonic() - started)))
            if process.is_alive():
                event = 'deadline'
                raise WorkLimit('deadline')
            if time.monotonic() - started >= HARD_SECONDS:
                event = 'deadline'
                raise WorkLimit('deadline')
            if process.exitcode != 0 or not output.is_file() or output.stat().st_size > MAX_RESULT:
                raise RpcError('Request worker did not produce a bounded result')
            envelope = json.loads(output.read_bytes())
            if not isinstance(envelope, dict):
                raise RpcError('Invalid request result')
            if set(envelope) == {'error'}:
                code = envelope['error']
                if code in ('deadline', 'rpc_budget', 'snapshot_expired'):
                    event = code
                    raise WorkLimit(code)
                if code == 'nft_not_minted':
                    raise UnknownNFT('NFT not minted')
                if code == 'invalid_activation':
                    from frontend_api.activation import ActivationInputError
                    raise ActivationInputError('Invalid activation request')
                if code == 'invalid_transaction':
                    raise TransactionInputError('Invalid transaction request')
                raise RpcError('Request worker unavailable')
            if set(envelope) != {'ok'} or not isinstance(envelope['ok'], dict):
                raise RpcError('Invalid request result')
            result = envelope['ok']
            if 'expires_at' in result and time.time() >= result['expires_at']:
                event = 'snapshot_expired'
                raise WorkLimit('snapshot_expired')
            provenance = result.get('provenance', {})
            if 'block_timestamp' in provenance:
                stamp = provenance['block_timestamp']
                if not time.time()-self.config['max_block_age_seconds'] < stamp <= time.time()+30:
                    event = 'snapshot_expired'
                    raise WorkLimit('snapshot_expired')
            event = 'ok'
            return result
        except (WorkLimit, UnknownNFT, ActivationInputError, TransactionInputError):
            raise
        except Exception:
            raise RpcError('Request worker unavailable') from None
        finally:
            # Terminate stuck DNS/read/SQLite calls, then reap. No thread-pool
            # timeout that silently leaves the upstream work running.
            alive = False
            cleanup_failed = False
            try:
                if process is not None and process.pid is not None:
                    for stop in (process.terminate, process.kill):
                        if process.is_alive():
                            try:
                                stop()
                                process.join(1)
                            except (OSError, ValueError):
                                pass
                    alive = process.is_alive()
                    if alive:
                        self._unreaped = process
                        event = 'worker_cleanup_failed'
                        cleanup_failed = True
                    else:
                        process.close()
            except Exception:
                # If cleanup cannot be established, refuse another worker.
                alive = True
                self._unreaped = process or True
                cleanup_failed = True
            try:
                if directory is not None and not alive:
                    directory.cleanup()
                elif directory is not None:
                    # Retain cleanup state rather than racing a still-live worker;
                    # this client refuses ALL subsequent work and needs supervision.
                    self._unreaped_directory = directory
            except Exception:
                cleanup_failed = True
            finally:
                if cleanup_failed:
                    # Poison before releasing admission, including for direct
                    # WorkerClient callers outside the pool's exclusive lease.
                    self._unreaped = self._unreaped or True
                    event = 'worker_cleanup_failed'
                self._lock.release()
            print(json.dumps({'event': 'api_request', 'outcome': event,
                              'elapsed_ms': int((time.monotonic()-started)*1000)}), flush=True)
            if cleanup_failed:
                raise RpcError('Request worker cleanup failed') from None

    def protocol(self):
        return self._request('protocol')

    def mint_readiness(self):
        return self._request('mint_readiness')

    def nft(self, identifier):
        return self._request('nft', identifier)

    def wallet(self, owner):
        return self._request('wallet', owner)

    def wallet_page(self, owner, block_number, offset=0):
        return self._request('wallet_page', [owner, block_number, offset])

    def wallet_summary(self, owner, block_number, offset=0):
        return self._request('wallet_summary', [owner, block_number, offset])

    def collection(self, block_number, offset=0):
        return self._request('collection', [block_number, offset])

    def wallet_earnings(self, owner, block_number, offset=0):
        return self._request('wallet_earnings', [owner, block_number, offset])

    def wallet_view(self, owner, block_number, offset=0, asset_offset=0):
        return self._request('wallet_view', [owner, block_number, offset, asset_offset])

    def earnings(self, identifier=None):
        return self._request('earnings', identifier)

    def prepare(self, payload):
        if self.activation_config is None and self.transaction_config is None:
            raise RpcError('Transaction preparation is disabled')
        return self._request('activation' if self.activation_config is not None else 'transactions', payload)

    def plan_claims(self, payload):
        if self.transaction_config is None:
            raise RpcError('Claim planning is disabled')
        return self._request('claim_plan', payload)


class WorkerPool:
    """No waiting queue or shared Projection/RPC/request budget across callers.

    Each lease owns one supervisor. Every request still creates a fresh child,
    checks freshness after completion and reaps it before returning the lease.
    Failed cleanup quarantines that slot until an operator restarts the service.
    """

    def __init__(self, config, activation_config=None, *, transaction_config=None, workers=4):
        if type(workers) is not int or not 1 <= workers <= 8:
            raise ValueError('workers must be between 1 and 8')
        self._available = queue.Queue(maxsize=workers)
        for _ in range(workers):
            client = WorkerClient(config, activation_config, transaction_config=transaction_config)
            self._available.put_nowait(client)
            self.chain = client.chain

    def _dispatch(self, method, *args):
        try:
            client = self._available.get_nowait()
        except queue.Empty:
            raise ServiceBusy('Request capacity unavailable') from None
        try:
            return getattr(client, method)(*args)
        finally:
            if client._unreaped is None:
                self._available.put_nowait(client)
            else:
                print(json.dumps({'event': 'api_worker_quarantined',
                                  'operator_action': 'inspect_and_restart'}), flush=True)

    def protocol(self):
        return self._dispatch('protocol')

    def mint_readiness(self):
        return self._dispatch('mint_readiness')

    def nft(self, identifier):
        return self._dispatch('nft', identifier)

    def wallet(self, owner):
        return self._dispatch('wallet', owner)

    def wallet_page(self, owner, block_number, offset=0):
        return self._dispatch('wallet_page', owner, block_number, offset)

    def wallet_summary(self, owner, block_number, offset=0):
        return self._dispatch('wallet_summary', owner, block_number, offset)

    def collection(self, block_number, offset=0):
        return self._dispatch('collection', block_number, offset)

    def wallet_earnings(self, owner, block_number, offset=0):
        return self._dispatch('wallet_earnings', owner, block_number, offset)

    def wallet_view(self, owner, block_number, offset=0, asset_offset=0):
        return self._dispatch('wallet_view', owner, block_number, offset, asset_offset)

    def earnings(self, identifier=None):
        return self._dispatch('earnings', identifier)

    def prepare(self, payload):
        return self._dispatch('prepare', payload)

    def plan_claims(self, payload):
        return self._dispatch('plan_claims', payload)
