"""Production read path: bounded current-holdings earnings, never wallet tenure.

Replay each epoch once for at most 16 NFTs, preserving each NFT's fractions.
All chunks must share one canonical inventory and block before being summed.
"""
import hashlib
from collections import defaultdict
from types import SimpleNamespace

from frontend_api.earnings_replay import Replay, require, royalty_profile
from frontend_api.earnings_prices import value_report
from frontend_api.history import HistoryError, conversion_report, merge_conversions
from frontend_api.portfolio import CHUNK_SIZE
from zzz_ops.abi import address
from zzz_ops.work_budget import checkpoint, expire_at


ASSET_CHUNK_SIZE = 4


def asset_page(engine, offset):
    """The cursor covers the complete descriptor union, including LP-only assets."""
    assets = tuple(sorted(engine.descriptors))
    if (not assets or len(assets) > 2048 or type(offset) is not int or offset < 0 or offset % ASSET_CHUNK_SIZE or
            offset >= len(assets)):
        raise ValueError('Invalid wallet earnings asset cursor')
    selected = assets[offset:offset + ASSET_CHUNK_SIZE]
    return dict(asset_offset=offset, asset_chunk_size=ASSET_CHUNK_SIZE,
        asset_count=len(assets), asset_ids=list(assets), selected_asset_ids=list(selected),
        asset_inventory_sha256=hashlib.sha256(','.join(assets).encode('ascii')).hexdigest(),
        next_asset_offset=offset + len(selected) if offset + len(selected) < len(assets) else None)


def read(engine, wallet_address, block_number, offset, *, asset_offset=None):
    p = engine.p
    wallet = address(wallet_address)
    asset_cursor = None if asset_offset is None else asset_page(engine, asset_offset)
    descriptors = (engine.descriptors if asset_cursor is None else
                   {a:engine.descriptors[a] for a in asset_cursor['selected_asset_ids']})
    if type(block_number) is not int or type(offset) is not int or not 0 <= offset < 1000 or offset % CHUNK_SIZE:
        raise ValueError('Invalid wallet earnings cursor')
    safe, head, _ = p._snapshot()
    require(p.start <= block_number <= safe['number'], 'Earnings block is not confirmed')
    header = p._header(hex(block_number))
    p._fresh(header)
    expire_at(header['timestamp'] + p.max_age, p.clock)
    block = {'blockHash': header['hash'], 'requireCanonical': True}
    life = p._verify_deployment(block)
    lp, royalties = p._admitted(block)
    history = engine.history_snapshot(p, header, block, lp, royalties)
    ids = sorted(i for i, owner in history.owners.items() if owner == wallet)
    count = p._uint('nft', 'balanceOf(address)', wallet, block=block)
    require(count == len(ids) and count <= 1000, 'Earnings inventory differs from canonical balance')
    if offset >= count and not (offset == count == 0):
        raise ValueError('Cursor is outside earnings inventory')
    selected = tuple(ids[offset:offset + CHUNK_SIZE])
    ordinals = {}
    for i in selected:
        require(p._addr('nft', 'ownerOf(uint256)', i, block=block) == wallet, 'Earnings owner differs')
        ordinal = p._uint('nft', 'mintOrdinalOf(uint256)', i, block=block)
        require(ordinal > 0 and p._uint('nft', 'tokenAtOrdinal(uint256)', ordinal, block=block) == i,
                'Earnings NFT identity differs')
        ordinals[i] = ordinal
    epochs = []
    histories = {p.contracts['access'].address: history}
    if p.lineage:
        # Verify receipt pairs, deployment origin, cutoff chronology and anchors once.
        p.lineage.financial(p, header, block, life, history, None, None, verified_epochs=epochs,
                            history_reader=engine.history_snapshot, verified_histories=histories)
    else:
        require(life['predecessor_controller'] is None, 'Complete predecessor history is required')
        epochs = [(p, header, None)]
    if p.accounting_version==7:
        from frontend_api.earnings_exact_lp import ExactReplay
        model=ExactReplay(header['timestamp'],selected=selected)
    else:model = Replay(header['timestamp'], selected=selected)
    claims = defaultdict(lambda: [0, 0])
    conversions, lp_conversions, provenance = {}, {}, []
    start = engine.replay_start(epochs)
    for index, (peer, cutoff, lower) in enumerate(epochs):
        checkpoint()
        at = {'blockHash': cutoff['hash'], 'requireCanonical': True}
        emitters = engine.check_profile(peer, at)
        a, b = peer._admitted(at)
        prefix = index < start
        if prefix:
            replayed = histories[peer.contracts['access'].address]
        else:
            begin_lower = None if index == start and getattr(engine.checkpoint, 'lineage_checkpoint', False) else lower
            model.begin(emitters, a, b, begin_lower, fee_intake_version=peer.fee_intake_version,royalty_settlement_version=royalty_profile(peer))
            replayed = engine.history_snapshot(peer, cutoff, at, a, b, consumer=model, extra_emitters=tuple(emitters.values()))
            model.finish()
            engine.reconcile(peer, model, at, a, b, replayed.provenance['minted_count'])
        for i in selected:
            ordinal = peer._uint('nft', 'mintOrdinalOf(uint256)', i, block=at)
            if i in replayed.owners:
                require(ordinal == ordinals[i] and peer._uint('nft', 'tokenAtOrdinal(uint256)', ordinal, block=at) == i,
                        'Predecessor earnings identity differs')
                if not prefix:
                    bucket, shares = model.shares.get(i, (0, 0))
                    require(peer._uint('vault', 'sharesOf(uint256)', i, block=at) == shares and
                            peer._uint('vault', 'nftBucket(uint256)', i, block=at) == bucket and
                            peer._uint('royalties', 'weightOf(uint256)', i, block=at) == model.weights.get(i, 0),
                            'Selected earnings rights differ from chain')
                    if peer.accounting_version==7:
                        require(peer._uint('rewards','rewardBucket(uint256)',i,block=at)==bucket,'Selected exact LP bucket differs')
                        for asset in a:
                            actual=tuple(int(w,16) for w in peer._call(peer.contracts['rewards'].address,
                                'claimableComponents(uint256,address)',i,asset,block=at,words=2))
                            require(actual==model.components(i,asset),'Selected exact LP components differ')
            else:
                require(ordinal == 0 and ordinals[i] > replayed.provenance['minted_count'],
                        'Missing predecessor NFT contradicts mint order')
            merge_conversions(conversions, replayed.conversions, i)
            merge_conversions(lp_conversions, replayed.lp_conversions, i)
        for (i, asset), amounts in replayed.claims.items():
            if i in ordinals:
                claims[i, asset][0] += amounts[0]
                claims[i, asset][1] += amounts[1]
        provenance.append({'controller': peer.contracts['access'].address, 'history': dict(replayed.provenance),
                           'activation_cutoff': None if lower is None else {'block': lower[0], 'transaction': lower[1]}})
    for i in selected:
        account = SimpleNamespace(nft_id=i, totals=model.account_totals[i], scaled=model.accounts[i],
                                  cohorts=model.cohorts, weights=model.weights,
                                  activation_order=model.activation_order,royalty_opening=model.royalty_opening,
                                  initial_royalty_allocations=model.initial_royalty_allocations,
                                  ticket_offsets=model.ticket_offsets,royalty_cursors=model.royalty_cursors)
        financial = {'previously_claimed': {'assets': [dict(asset=a, lp_raw=str(claims[i, a][0]),
                     royalties_raw=str(claims[i, a][1])) for a in engine.descriptors]},
                     'lp_conversions': conversion_report(lp_conversions, i, engine.descriptors, {}),
                     'royalty_conversions': conversion_report(conversions, i, engine.descriptors, {})}
        engine.check_paid(p, account, financial, block,
                          lp if asset_cursor is None else [a for a in lp if a in descriptors],
                          royalties if asset_cursor is None else [a for a in royalties if a in descriptors])
    result = model.report(descriptors)
    prices = ((engine.prices.read(block,timestamp=header['timestamp']) if asset_cursor is None else
               engine.prices.read(block,timestamp=header['timestamp'],selected=tuple(descriptors))) if engine.prices else {
        a: {'available': False, 'usd_per_token_18': None, 'reason': 'price_not_configured'} for a in descriptors})
    value_report(result, descriptors, prices)
    result.update(schema=1, chain_id=p.chain, wallet=wallet, nft_contract=p.contracts['nft'].address,
        inventory_sha256=hashlib.sha256(','.join(map(str, ids)).encode('ascii')).hexdigest(),
        count=count, offset=offset, chunk_size=CHUNK_SIZE, token_ids=list(map(str, selected)),
        next_offset=offset + len(selected) if offset + len(selected) < count else None,
        ownership_scope='Lifetime earnings of NFTs owned at this snapshot, including earlier owners; not personal wallet income.',
        lifecycle=life, provenance=dict(block_number=header['number'], block_hash=header['hash'],
        block_timestamp=header['timestamp'], observed_head=head, confirmations=p.confirmations,
        configuration_sha256=p.identity, epochs=provenance, finality='confirmation_depth_only',
        completeness='Complete configured indexed history and pinned RPC reconciliation; not a log-completeness proof.'))
    if asset_cursor is not None:
        result.update(asset_cursor)
    for peer, cutoff, _ in epochs:
        require(p._header(hex(cutoff['number'])) == cutoff, 'Earnings epoch changed during replay')
    engine.finish_checkpoint()
    p._finish(header)
    return result
