import ast, copy, hashlib, json
from pathlib import Path
base=Path(r'C:\Users\Ali\.codex\visualizations\2026\10\14\01a13899-2be7-76f2-a5d0-72e4804c67b9\compact-wallet-20261121')
before_path=base/'python-stage01.TEST_SOURCE.py'
after_path=base/'python-stage02.TEST_SOURCE.py'
before=before_path.read_bytes(); after=after_path.read_bytes()
a=ast.parse(before.decode('utf-8-sig')); b=ast.parse(after.decode('utf-8-sig'))
method='test_default_admission_ideal_clock_covers_complete_compact_refresh_and_visible_cards'
def methods(tree):
    return {cls.name+'.'+fn.name:fn for cls in tree.body if isinstance(cls,ast.ClassDef)
        for fn in cls.body if isinstance(fn,(ast.FunctionDef,ast.AsyncFunctionDef)) and fn.name.startswith('test_')}
old=methods(a); new=methods(b)
changed=[name for name in old if ast.dump(old[name],include_attributes=False)!=ast.dump(new[name],include_attributes=False)]
assert old.keys()==new.keys() and changed==['WalletViewWireTests.'+method]
assert len(old)==18
for tree in (a,b):
    for cls in tree.body:
        if isinstance(cls,ast.ClassDef):
            cls.body=[node if not isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)) or node.name!=method
                else ast.FunctionDef(name=node.name,args=node.args,body=[ast.Pass()],decorator_list=node.decorator_list)
                for node in cls.body]
assert ast.dump(a,include_attributes=False)==ast.dump(b,include_attributes=False)
result=dict(schema=1,kind='Static_AST_affected_method_scope',before_sha256=hashlib.sha256(before).hexdigest(),
    after_sha256=hashlib.sha256(after).hexdigest(),changed_methods=changed,unchanged_methods=17,
    change='Two visible-card request count expressions corrected from min(count,16) to 2*min(count,8); one affected method rerun.',
    ast_equal_outside_affected_method=True,test_body_executions=0)
(base/'AFFECTED_ADMISSION_SCOPE.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,sort_keys=True))

