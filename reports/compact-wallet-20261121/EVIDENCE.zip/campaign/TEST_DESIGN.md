# Focused new compact-wallet / earnings-selection verification design

Prepared 21 November 2026; DESIGN ONLY. No production edit, test method, population, API request, node, service, network or signing action has run for this design. Final endpoint/schema/cursor names remain the parent agent's decision.

## Preserved fixture reuse

Use the external wallet-view-20261121/backend_producer.py definitions WalletFixture, ReadOnlyRPC, h/static_data/expected/measure/loaded_sources as setup/reference sources only. Importing this external file is inert because its main is guarded. Do not invoke its historical scenario(), maximum_currency_refusal() or main(); do not invoke any old unittest method. WalletFixture's Fresh7API constructor invokes neutral FrontendPolicyV6Tests.setUp and cleanup registration, never its body. Record this explicitly; constructor/setup reuse is not an old passing test rerun. Copy into a new draft only if setup must be changed; retain the original helper hash and the complete derivative hash.

Exact existing pins:

- external backend_producer.py SHA256 e33edb79077f8f13ad2b0bd1a803679fe77348e91a747293c37a57d61edfe941
- saved backend-stage03/scenario-1.json SHA256 c433dcad7665191883612d5f6d2d2bf76c5010805bd238621b5dc2e26d64c886
- saved backend-stage04/scenario-17.json SHA256 5daf083c506507813b59c8101434a2c37f862e42cec1991a22fd6452180131a3
- saved backend-stage04/scenario-1000.json SHA256 05b08fae5741a57987a9a38b847a98d6edc554a64a4a3a60766589effeb38362
- current Fresh7API helper file SHA256 0d60a942f7f04892f5c16655563d6d4482d6684286091acd4755e013c6212375

FIXTURE_DERIVATION.json's existing producer_sha256 field denotes the saved scenario artifact bytes, not the producer Python source. New metadata must name these two identities distinctly without editing historical artifacts.

Saved scenario files include exact production Python DTOs, source hashes, raw-history hash, expected values, runtime/code pins and unique RPC transcripts. They can supply independent historical expectations to a NEW consumer test without executing their producer. They are synthetic V9/source9, not current normal F6/V10 EVM. Source9/source10 native constructor/reader compositions need separate, honestly labeled controlled fixtures.

## Capacity constraints to expose in qualification

Default admission is one shared client: 1 read/s, burst12, two active. Maximum snapshot age stays120s. Request budgets stay25s/1024 RPC/2048 POST; worker hard timeout30s and result1MiB stay unchanged. A 1,000-NFT common-three-currency compact page that truly combines the three old16-ID requests needs63 pages plus protocol=64 requests, idealized52s after burst. Measure actual producer work and a clock-controlled admission schedule; request count alone is not provider/host freshness qualification.

A fixed16-NFT,65-royalty-currency selection requires1,040 unique royalty claimable getters before any other work. A simple extra currency page per16NFT group therefore needs at least126 pages for1,000 NFTs, excluding protocol, if every group spans all65. It cannot establish an under120-request maximum-wallet journey. Keep the 1,000/common-currency admission scope and65-currency finite-selection scope separate unless the implemented schedule actually proves the cross-product under the unchanged budgets.

Current check_paid repeats pending(asset), royaltiesOpen() and claimable(NFT,asset) inside the NFT/asset loop. Fixed-block pending/opened observations may be captured once per request/asset with preserved canonical proofs; never cache across requests or anchors. This reduces redundant calls but does not remove the1,040 distinct claimable lower bound. Record actual call signatures/multiplicity so a mock cannot hide unchanged capacity.

## New backend checks, each a distinct selected method

1. Compact16-ID route composes ownership plus LP and ETH summaries over one freshly proven snapshot, returning exact sorted IDs, count, digest, lifecycle and history with no second ownership pass. Compare amounts against literal expected(count) arithmetic and preserved DTO values, not a concurrently executed legacy handler.
2. New1/17/1,000 populated journeys: actual Projection/History/ExactReplay/price verification; new isolated SQLite raw logs and no checkpoint mutation; traverse only the new endpoints; every response <=1MiB, every request <=1024 RPC/2048 POST and25s. Record per-action and total calls/time/bytes, source identities and all response DTOs. Independent expected raw LP totals are96n/12n all-time,48n/6n last24h; royalties31n/13n; LP value1000e18*n+n(n+1)/2; remaining ETH139(n-1). Full-day cutoff, first-NFT prior-owner claim/LP conversion/transfer history must retain exact income semantics.
3. Earnings selection65 royalty currencies with16 NFTs: NEW route/cursor traversal across all selected assets and NFTs, sum original raw amounts once, assert each partition equals independent31n/13n royalty arithmetic and96n/12n LP, with compound/buyback excluded. Added63 currencies from WalletFixture are unpriced: nonzero royalty USD stays unavailable while priced LP/raw royalty remains exact. Do not invent prices or swap currencies to make totals available. If full1000x65 is requested, derive a new fixture and run that NEW cross-product once with honest resulting request count and wallclock limits.
4. Cursor validation before production read: exact integers (bool rejected), canonical bounds, snapshot start/confirmed range, page alignment/selection bounds, empty wallet valid zero case, terminal partial NFT page(992..999) and terminal partial currency page. Invalid offsets/counts cannot dispatch production work.
5. Inventory contradictions: canonical balance differs; owner mismatch; duplicate/changed/missing NFT identity; mint ordinal/tokenAtOrdinal mismatch; runtime/controller/module/source/canonical peer mismatch; lifecycle/history/deployment origin change. Fail the complete page rather than publish partial membership.
6. Selection contradictions: wrong/repeated/omitted/extra currency, inconsistent descriptor decimals/code pin, wrong currency digest/order/count, selection cursor that skips/repeats/overlaps, wrong next offsets/terminal flag, asset identity drift between epochs. Reconciliation must cover every returned NFT/currency pair; an omitted pair cannot become zero.
7. Fixed-block guarantees: every monetary/identity/code read uses EIP1898 exact block hash + requireCanonical; final canonical header/deployment/epoch identity rechecked. Late expiry, reorg or history/checkpoint source drift yields refusal; retain no partial result.
8. Independent availability: LP getter unavailable leaves LP null but ETH and independent earnings valid; native reward failure leaves ETH null but LP and independent earnings valid; nonzero unpriced earnings leaves only USD unavailable with raw unchanged; zero raw can value0 without a mark. Shared core ownership/source failure refuses all. WorkLimit never becomes zero or an incomplete success.
9. Original-currency rules: LP ZZZ and ERC20 royalties never enter ETH header; claims, conversion credits, imports and principal never create income; transferred NFT lifetime earnings follow current snapshot ownership. Do not add or run royalty conversion behavior.
10. Request-local reuse correctness: duplicate reads actually decrease while every distinct NFT/currency claimable is still authenticated. A stale value from a prior anchor/request cannot survive; faults or changed shared pending/open status are not bypassed by a cache.

## New HTTP/worker boundary checks

Use new explicitly named test methods. Test handler route extraction/normalization and reject malformed paths before begin_work; unknown schema/cursor never falls back to old route. Worker _run, IsolatedProjection and AdmittedProjection each dispatch the exact new action/positional payload; no unrestricted action name or arbitrary RPC capability. Exercise actual isolated-worker JSON serialization/1MiB/deadline failure sanitization with a dedicated new inert worker seam and exact current source pins where feasible. Exercise handler against a newly owned ephemeral loopback server only, exact Host/body/framing rules retained, no service restart.

Actual ClientAdmission with a controlled monotonic clock must consume one token for every compact or selected read under the same client key, preserve max2 active, return429 plus Retry-After after the burst, and not reset admission for subroutes. Model the exact64-request common-currency schedule and prove the final admitted read is52s under idealized zero work; then add measured bounded service work/latency honestly. A scheduler may respect429/Retry-After but must not switch keys or open parallel admission identities.

## New consumer checks

No import of old test modules/bodies. Safe fixture helpers plus new producer exports only. Cover source9 and source10 separately; unknown wire/source profiles refuse before provider access. Capture wallet/config/provenance/IDs/descriptors/cursors immutably before awaits. Bound financial requests to at most2, preserve independent branch settlement, and cancel/recheck expiry after awaited native/identity/final verification.

For two-dimensional earnings, maintain an explicit coverage set or rectangle proof for the entire NFT x currency domain. Test an omitted middle asset page, duplicate last page, repeated currency with a new cursor, inconsistent page width, overlapping NFT selections and forged total count: no complete earnings publication. Sum raw BigInts by asset/metric across complete pages first, then floor each current-price asset valuation once; do not sum per-page USD floors. Verify nonzero unpriced assets leave affected USD unavailable. Mixed per-page prices/descriptors/fingerprints refuse, including price0 as a fake available mark.

Compact ownership can only become the same complete immutable inventory after all pages have exact count/order/digest/header/history/lifecycle matching plus final native/canonical checks. Individual cards remain independent latest reads. A financial failure cannot retarget or erase a completed healthy ownership result; a shared inventory/source contradiction invalidates associated totals. Empty inventory cannot report positive LP/ETH/earned raw.

## Stage selection / evidence

Allocate disjoint explicit stages after implementation names stabilize: backend-small+negative new methods; backend1000 producer once; backend65 selection producer once; HTTP/worker new methods; JS new methods; any failed new methods get an isolated repair rerun only. Archive selection list, raw stdout/stderr, exit code, counts, elapsed times, before/after source hashes, per-request metrics, complete source/fixture derivation and failures. Do not rerun an earlier passing stage to get a one-command green total. Do not call old scenario or population functions, old test bodies, whole suites, build/compiler, provider, chain, journal or service actions.

After production source changes, run the relevant offline workload inventory --check and review/regenerate source trust pins as required by the project; never bypass old checkpoint semantic-source identity. Preserve all four tracked dirty files and unrelated untracked drafts. New production/API source requires fresh explicit current evidence pins, not historical fixture relabeling.

