"""Derive NEW portable compact DTOs from already completed producer exports; no test/producer calls."""
import copy
import hashlib
import json
from pathlib import Path

WORK = Path(r'C:\Users\Ali\.codex\visualizations\2026\10\14\01a13899-2be7-76f2-a5d0-72e4804c67b9\compact-wallet-20261121')
DEST = Path(r'C:\Users\Ali\Desktop\2.x holas\Oto\aaa-website\tests\fixtures\compact-wallet-20261121')
SOURCES = [('backend-stage01', 'scenario-1.json'), ('backend-stage02', 'scenario-17.json'),
           ('backend-stage03', 'scenario-16-65currencies.json'), ('backend-stage04', 'scenario-1000.json')]
CONFIG_KEYS = ('assets', 'chain_id', 'confirmations', 'contracts', 'deployment_block',
               'deployment_block_hash', 'max_block_age_seconds')
rows = []
DEST.mkdir(parents=True, exist_ok=False)
for stage, name in SOURCES:
    source_path = WORK / stage / name
    original_bytes = source_path.read_bytes()
    source = json.loads(original_bytes)
    output = {key: copy.deepcopy(source[key]) for key in ('schema', 'kind', 'qualification', 'profile',
        'owner', 'former_owner', 'count', 'royalty_count', 'descriptor_count', 'token_ids', 'protocol',
        'pages', 'expected', 'facts')}
    output['read_configuration'] = {key: copy.deepcopy(source['read_configuration'][key]) for key in CONFIG_KEYS}
    output['rpc_responses'] = [copy.deepcopy(row) for row in source['rpc_responses']
        if row['method'] in ('eth_chainId', 'eth_blockNumber', 'eth_getBlockByNumber', 'eth_getBlockByHash')]
    output.update(source_stage=stage, producer_fixture_sha256=hashlib.sha256(original_bytes).hexdigest(),
        producer_script_sha256=source['source_hashes']['EXTERNAL/compact_producer.py'],
        neutral_helper_source_sha256=source['source_hashes']['EXTERNAL/neutral_backend_producer.py'],
        producer_source_identity_sha256=source['source_identity_sha256'],
        configuration_scope='Non-deployable consumer subset; DTO provenance retains original complete producer configuration identity.',
        rpc_scope='Exact saved chain/header replies only. No monetary/native graph transcript; controlled native graph seams must be labeled separately.')
    for key in ('protocol', 'pages', 'expected'):
        assert output[key] == source[key], 'Original DTO or independent expectation changed'
    body = (json.dumps(output, sort_keys=True, separators=(',', ':'), allow_nan=False) + '\n').encode()
    target = DEST / name
    target.write_bytes(body)
    rows.append(dict(source_stage=stage, producer_artifact_name=name,
        producer_artifact_sha256=hashlib.sha256(original_bytes).hexdigest(),
        producer_script_source_sha256=output['producer_script_sha256'],
        neutral_helper_source_sha256=output['neutral_helper_source_sha256'],
        portable_fixture_sha256=hashlib.sha256(body).hexdigest(), portable_bytes=len(body),
        protocol_pages_expected_byte_values_unchanged=True))
manifest = dict(schema=1, kind='NEW_compact_wallet_fixture_derivation', transformation_source_sha256=
    hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    production_producer_or_test_reexecuted=False, original_DTO_values_changed=False,
    omitted='Monetary/native graph RPC transcripts, raw-history/metric/source maps, private temporary DB path and runtime-only configuration.',
    fixtures=rows)
(WORK / 'FIXTURE_DERIVATION.json').write_text(json.dumps(manifest, indent=2) + '\n', encoding='utf-8')
print(json.dumps(manifest, sort_keys=True))

