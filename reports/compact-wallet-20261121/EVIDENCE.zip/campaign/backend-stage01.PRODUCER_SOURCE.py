"""NEW compact wallet producer qualification; synthetic runtime/RPC and isolated raw DB.
Reuses neutral WalletFixture setup only. Never calls historical scenario/main/test bodies.
"""
from __future__ import annotations
import argparse
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import time

ROOT = Path(r'C:\Users\Ali\Desktop\2.x holas\Oto\zzz-protocol-v2-reviewed\zzz-protocol-v2')
WORK = Path(r'C:\Users\Ali\.codex\visualizations\2026\10\14\01a13899-2be7-76f2-a5d0-72e4804c67b9')
NEUTRAL_PATH = WORK / 'wallet-view-20261121' / 'backend_producer.py'
NEUTRAL_HASH = 'e33edb79077f8f13ad2b0bd1a803679fe77348e91a747293c37a57d61edfe941'
assert hashlib.sha256(NEUTRAL_PATH.read_bytes()).hexdigest() == NEUTRAL_HASH
sys.path.insert(0, str(ROOT))
spec = importlib.util.spec_from_file_location('new_compact_neutral_setup', NEUTRAL_PATH)
neutral = importlib.util.module_from_spec(spec)
spec.loader.exec_module(neutral)
from zzz_ops.work_budget import Budget, request_scope
from zzz_ops.abi import keccak256
from zzz_ops import price_policy as D

MAX_RESULT = 1024 * 1024
PERIODS = ('all_time', 'last_24h')
FIELDS = ('lp_individual', 'lp_collective', 'royalties')

def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()

def sources():
    result = {}
    for module in list(sys.modules.values()):
        name = getattr(module, '__file__', None)
        if name:
            path = Path(name).resolve()
            if path.suffix == '.py' and path.is_relative_to(ROOT):
                result[path.relative_to(ROOT).as_posix()] = hashlib.sha256(path.read_bytes()).hexdigest()
    for directory in ('frontend_api', 'zzz_ops', 'indexer'):
        for path in (ROOT / directory).glob('*.py'):
            result[path.relative_to(ROOT).as_posix()] = hashlib.sha256(path.read_bytes()).hexdigest()
    result['EXTERNAL/neutral_backend_producer.py'] = NEUTRAL_HASH
    result['EXTERNAL/compact_producer.py'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    return dict(sorted(result.items()))

class FullyPricedFixture(neutral.WalletFixture):
    """Only newly declared controlled feeds extend neutral setup; all 66 descriptors priced."""
    def install_prices(self):
        oracle, code = neutral.addr(31000), '0x600bface'
        self.inner.codes[oracle] = code
        self.put(oracle, 'access()', values=(self.c['access'],))
        self.put(self.c['access'], 'module(bytes32)', ('0x' + keccak256(b'ZZZOracle').hex(),), (oracle,))
        self.put(oracle, 'sequencerFeed()', values=(neutral.ZERO,))
        self.put(oracle, 'activeSequencerPolicy()', values=('0x' + '0' * 64,))
        self.put(oracle, 'PRICING_VERSION()', values=(2,))
        descriptors = sorted(self.config['assets'], key=lambda row: row['address'])
        self.put(oracle, 'policyCount()', values=(len(descriptors),))
        feeds, self.literal_prices = [], {}
        source_code = '0x600bfeed'
        source_hash = '0x' + keccak256(bytes.fromhex(source_code[2:])).hex()
        for index, descriptor in enumerate(descriptors):
            asset = descriptor['address']
            answer = neutral.FEED_ANSWERS.get(asset, (index + 2) * 100000000 + 3)
            self.literal_prices[asset] = answer * 10**10
            record = neutral.make_policy(asset, descriptor['decimals'], oracle, index, 32000 + 2 * index, source_hash)
            observation = neutral.bounds(record, oracle, answer=answer, stamp=neutral.STAMP - 20)
            self.put(oracle, 'activePolicy(address)', (asset,), (record['policy_id'],))
            self.put(oracle, 'policyAt(uint256)', (index,), (record['policy_id'],))
            self.put(oracle, 'policy(bytes32)', (record['policy_id'],), D.flat(record['policy']))
            self.put(oracle, 'priceBounds(address)', (asset,), tuple(observation[k] for k in ('lower', 'upper', 'fingerprint')))
            for side in ('primary', 'secondary'):
                source = record['policy'][side]['source']
                self.inner.codes[source] = source_code
                self.put(source, 'decimals()', values=(8,))
                self.put(source, 'latestRoundData()', values=neutral.source_round(answer, neutral.STAMP - 20))
            feeds.append(dict(asset=asset, priced_token=asset, token_code_hash=descriptor['code_hash'], price_policy=record))
        self.config['earnings_history']['prices'] = dict(pricing_version=2,
            oracle=dict(address=oracle, code_hash='0x' + keccak256(bytes.fromhex(code[2:])).hex()), sequencer=None, feeds=feeds)

def literal_expected(fixture):
    count = fixture.count
    assets = sorted(row['address'] for row in fixture.config['assets'])
    decimals = {row['address']: row['decimals'] for row in fixture.config['assets']}
    prices = getattr(fixture, 'literal_prices', neutral.PRICES)
    result = dict(raw={}, usd={}, lp_usd_18=str(count * 1000 * 10**18 + count * (count + 1) // 2),
        claimable_eth_wei=str((count - 1) * 139))
    for period, individual, collective, royalties in (('all_time', 96, 12, 31), ('last_24h', 48, 6, 13)):
        rows = {asset: dict(lp_individual=str(individual * count if asset in fixture.pair else 0),
            lp_collective=str(collective * count if asset in fixture.pair else 0),
            royalties=str(royalties * count if asset in fixture.royalties else 0)) for asset in assets}
        result['raw'][period] = rows
        result['usd'][period] = {field: str(sum(int(row[field]) * prices[asset] // 10**decimals[asset]
            for asset, row in rows.items())) for field in FIELDS}
    if len(assets) == 3:
        previous = neutral.expected(count)
        for key in ('raw', 'usd', 'lp_usd_18', 'claimable_eth_wei'):
            assert result[key] == previous[key], ('literal regression', key)
    return result

def measure(fixture, action, function, *args, source_identity):
    before = len(fixture.rpc.calls)
    started = time.perf_counter()
    budget = Budget()
    with request_scope(budget):
        result = function(*args)
    elapsed = time.perf_counter() - started
    body = json.dumps(result, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()
    physical = len(fixture.rpc.calls) - before
    rpc_used, posts_used = 1024 - budget.calls, 2048 - budget.posts
    assert physical <= rpc_used <= 1024, (physical, rpc_used)
    assert 0 <= posts_used <= 2048
    assert len(body) <= MAX_RESULT and elapsed < 25
    return result, dict(action=action, physical_rpc_calls=physical, budget_rpc_calls=rpc_used,
        budget_posts=posts_used, elapsed_seconds=elapsed, json_bytes=len(body),
        limit_seconds=25, limit_rpc=1024, limit_posts=2048, limit_bytes=MAX_RESULT,
        source_identity_sha256=source_identity)

def scenario(count, royalty_count, output):
    fixture_type = FullyPricedFixture if royalty_count == 65 else neutral.WalletFixture
    fixture = fixture_type(count, royalty_count=royalty_count)
    pages, metrics = [], []
    try:
        pinned_sources = sources()
        source_identity = digest(pinned_sources)
        protocol, metric = measure(fixture, 'protocol', fixture.p.protocol, source_identity=source_identity)
        metrics.append(metric)
        assert protocol['wallet_view_profile'] == 1
        full_assets = sorted(row['address'] for row in fixture.config['assets'])
        want = literal_expected(fixture)
        raw = {period: {asset: {field: 0 for field in FIELDS} for asset in full_assets} for period in PERIODS}
        coverage = set()
        summaries = []
        identity = None
        for offset in range(0, count, 16):
            for asset_offset in range(0, len(full_assets), 4):
                page, metric = measure(fixture, 'wallet_view', fixture.p.wallet_view,
                    neutral.OWNER, neutral.BLOCK, offset, asset_offset, source_identity=source_identity)
                metrics.append(dict(metric, offset=offset, asset_offset=asset_offset))
                pages.append(page)
                selected_ids = [str(i) for i in fixture.ids[offset:offset + 16]]
                selected_assets = full_assets[asset_offset:asset_offset + 4]
                assert page['schema'] == 1 and page['kind'] == 'fixed_block_wallet_view_page'
                assert page['token_ids'] == selected_ids and page['selected_asset_ids'] == selected_assets
                assert page['asset_ids'] == full_assets and page['asset_count'] == len(full_assets)
                assert page['asset_offset'] == asset_offset and page['asset_chunk_size'] == 4
                assert page['next_asset_offset'] == (asset_offset + len(selected_assets) if asset_offset + len(selected_assets) < len(full_assets) else None)
                assert page['count'] == count and page['offset'] == offset and page['chunk_size'] == 16
                assert page['next_offset'] == (offset + len(selected_ids) if offset + len(selected_ids) < count else None)
                assert page['inventory_sha256'] == hashlib.sha256(','.join(map(str, fixture.ids)).encode('ascii')).hexdigest()
                assert page['asset_inventory_sha256'] == hashlib.sha256(','.join(full_assets).encode('ascii')).hexdigest()
                proof = (page['chain_id'], page['wallet'], page['nft_contract'], page['inventory_sha256'],
                    page['asset_inventory_sha256'], page['provenance']['block_number'], page['provenance']['block_hash'],
                    page['provenance']['block_timestamp'], page['provenance']['configuration_sha256'], digest(page['lifecycle']), digest(page['history']))
                if identity is None:
                    identity = proof
                assert identity == proof, 'Page identity/provenance drift'
                assert page['wallet'] == neutral.OWNER and page['chain_id'] == 31337
                assert page['provenance']['block_number'] == neutral.BLOCK
                assert page['provenance']['block_timestamp'] == neutral.STAMP
                if asset_offset == 0:
                    assert isinstance(page['summary'], dict)
                    summaries.append(page['summary'])
                else:
                    assert page['summary'] is None
                earnings = page['earnings']
                assert earnings['token_ids'] == selected_ids
                assert earnings['selected_asset_ids'] == selected_assets
                for identifier in selected_ids:
                    for asset in selected_assets:
                        pair = identifier, asset
                        assert pair not in coverage, 'Repeated NFT/currency rectangle'
                        coverage.add(pair)
                for period in PERIODS:
                    rows = earnings[period]
                    assert [row['asset'] for row in rows] == selected_assets
                    for row in rows:
                        assert row['current_price']['available'] is True
                        expected_price = getattr(fixture, 'literal_prices', neutral.PRICES)[row['asset']]
                        assert row['current_price']['usd_per_token_18'] == str(expected_price)
                        for field in FIELDS:
                            amount = int(row[field + '_raw'])
                            per_nft = {'all_time': dict(lp_individual=96, lp_collective=12, royalties=31),
                                'last_24h': dict(lp_individual=48, lp_collective=6, royalties=13)}[period][field]
                            applies = row['asset'] in (fixture.royalties if field == 'royalties' else fixture.pair)
                            assert amount == per_nft * len(selected_ids) if applies else amount == 0
                            raw[period][row['asset']][field] += amount
                            assert row['usd_at_current_price_18'][field] == str(amount * expected_price // 10**row['decimals'])
                print(json.dumps(dict(case_count=count, royalty_count=royalty_count, **metrics[-1]), sort_keys=True), flush=True)
        assert coverage == {(str(identifier), asset) for identifier in fixture.ids for asset in full_assets}
        for period in PERIODS:
            assert {asset: {field: str(value) for field, value in row.items()} for asset, row in raw[period].items()} == want['raw'][period]
            prices = getattr(fixture, 'literal_prices', neutral.PRICES)
            decimals = {row['address']: row['decimals'] for row in fixture.config['assets']}
            valued = {field: str(sum(row[field] * prices[asset] // 10**decimals[asset] for asset, row in raw[period].items())) for field in FIELDS}
            assert valued == want['usd'][period]
        assert sum(int(row['lp_usd_18']) for row in summaries) == int(want['lp_usd_18'])
        assert sum(int(row['claimable_eth_wei']) for row in summaries) == int(want['claimable_eth_wei'])
        assert sources() == pinned_sources, 'Source changed during producer case'
        result = dict(schema=1, kind='NEW_actual_compact_wallet_backend_synthetic_transport',
            qualification='Production Projection/SQLite History/ExactReplay/Prices; every runtime, getter and feed synthetic V9/source9. No F6/V10 EVM/provider/host acceptance.',
            profile=dict(accounting_version=7, lp_allocation_version=1, royalty_settlement_version=4, royalty_reporting_schema=5, canonical='V9'),
            owner=neutral.OWNER, former_owner=neutral.FORMER, count=count, royalty_count=royalty_count, descriptor_count=len(full_assets),
            token_ids=list(map(str, fixture.ids)), read_configuration=fixture.config, pins=fixture.c, codes=fixture.inner.codes,
            protocol=protocol, pages=pages, expected=want, request_metrics=metrics, source_hashes=pinned_sources,
            source_identity_sha256=source_identity, raw_history=dict(events=len(fixture.rows), blocks=90, start=10, through=neutral.BLOCK,
                sha256=digest(fixture.rows), checkpoint=None), rpc_responses=list(fixture.rpc.unique.values()),
            facts=dict(current_snapshot_ownership=True, earlier_owner_history_retained=True, last24h_cutoff_excluded=neutral.DAY_BLOCK,
                last24h_next_block_included=neutral.DAY_BLOCK + 1, lp_conversion_creates_income=False,
                claims_create_income=False, royalty_conversion_added=False, all_descriptors_fully_priced=True),
            old_test_bodies_run=0, old_scenario_or_main_calls=0)
        output.write_text(json.dumps(result, sort_keys=True, separators=(',', ':'), allow_nan=False) + '\n', encoding='utf-8')
        summary = dict(count=count, royalty_count=royalty_count, descriptor_count=len(full_assets), requests=len(metrics),
            complete_nft_currency_pairs=len(coverage), total_rpc=sum(row['budget_rpc_calls'] for row in metrics),
            total_physical_rpc=sum(row['physical_rpc_calls'] for row in metrics), max_rpc=max(row['budget_rpc_calls'] for row in metrics),
            total_seconds=sum(row['elapsed_seconds'] for row in metrics), max_seconds=max(row['elapsed_seconds'] for row in metrics),
            max_json_bytes=max(row['json_bytes'] for row in metrics), output_sha256=hashlib.sha256(output.read_bytes()).hexdigest(),
            source_identity_sha256=source_identity)
        return summary
    except BaseException as exc:
        partial = dict(schema=1, count=count, royalty_count=royalty_count, completed_requests=len(metrics),
            request_metrics=metrics, exception_type=type(exc).__name__, message=str(exc), source_hashes=sources())
        output.with_suffix('.FAILURE.json').write_text(json.dumps(partial, indent=2) + '\n', encoding='utf-8')
        raise
    finally:
        fixture.close()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--counts', nargs='+', type=int, default=[])
    parser.add_argument('--maximum-currency', action='store_true')
    args = parser.parse_args()
    if args.output.exists():
        raise ValueError('Use a new stage output path; preserve prior failures and passing evidence')
    args.output.mkdir(parents=True)
    results = []
    try:
        for count in args.counts:
            results.append(scenario(count, 2, args.output / ('scenario-' + str(count) + '.json')))
        if args.maximum_currency:
            results.append(scenario(16, 65, args.output / 'scenario-16-65currencies.json'))
        result = dict(schema=1, stage='NEW_compact_wallet_backend_qualification', scenarios=results,
            old_test_bodies_run=0, old_scenario_or_main_calls=0,
            limits=dict(seconds=25, rpc=1024, posts=2048, result_bytes=MAX_RESULT), source_hashes=sources())
        (args.output / 'RESULT.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
        print(json.dumps(result, sort_keys=True), flush=True)
    except BaseException as exc:
        (args.output / 'FAILURE.json').write_text(json.dumps(dict(schema=1, completed=results,
            exception_type=type(exc).__name__, message=str(exc), source_hashes=sources()), indent=2) + '\n', encoding='utf-8')
        raise

if __name__ == '__main__':
    main()

