"""NEW offline wallet producer qualification draft, never a service or chain job.

Production Projection/History/ExactReplay/Prices execute. Runtime, financial
getters, oracle feeds and the owned SQLite database are newly synthetic. Only
Fresh7API neutral setup is reused; no historical test method/population runs.
No checkpoints, network, subprocess, signer, chain node or repository writes.
"""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
from pathlib import Path
import sqlite3
import sys
import tempfile
import time
import unittest

ROOT = Path(r'C:\Users\Ali\Desktop\2.x holas\Oto\zzz-protocol-v2-reviewed\zzz-protocol-v2')
sys.path.insert(0, str(ROOT))

from frontend_api.service import Projection, ZERO
from frontend_api.earnings_exact_lp import ExactReplay
from indexer.monitor import Indexer
from tests_python.test_exact_lp_profile7 import Fresh7API
from tests_python.test_frontend_api import addr, words
from tests_python.test_dual_price_integration import make_policy, source_round, bounds
from zzz_ops import price_policy as D
from zzz_ops.abi import calldata, keccak256
from zzz_ops.errors import WorkLimit
from zzz_ops.work_budget import Budget, request_scope

OWNER, FORMER = addr(30), addr(32)
ZZZ, USD6 = addr(20), addr(21)
BUCKET, BLOCK = 7, 99
STAMP = 1000000 + BLOCK * 1200
NOW = STAMP + 1
FIELDS = ('lp_individual', 'lp_collective', 'royalties')
DAY_BLOCK = BLOCK - 86400 // 1200
MAX_RESULT = 1024 * 1024
FEED_ANSWERS = {ZERO: 2000 * 10**8, ZZZ: 123456789, USD6: 100000001}
PRICES = {a: answer * 10**10 for a, answer in FEED_ANSWERS.items()}


def h(number):
    return '0x' + hashlib.sha256(('NEW-wallet-producer-' + str(number)).encode()).hexdigest()


def static_data(signature, *args):
    # zzz_ops.abi intentionally rejects zero address input; preserve exact ABI.
    value = calldata(signature, *[addr(1) if x == ZERO else x for x in args])
    for i, arg in enumerate(args):
        if arg == ZERO:
            begin = 10 + 64 * i
            value = value[:begin] + '0' * 64 + value[begin + 64:]
    return value


class ReadOnlyRPC:
    """Authenticate every production request, recording exact synthetic replies."""
    def __init__(self, inner, nft):
        self.inner, self.nft = inner, nft
        self.calls = []
        self.unique = {}
        self.by_method = {}

    def hash(self, number):
        return self.inner.anchor if number == 10 else self.inner.hash if number == BLOCK else h(number)

    def header(self, number):
        return dict(number=hex(number), hash=self.hash(number), parentHash=self.hash(number - 1),
                    timestamp=hex(1000000 + number * 1200), gasLimit=hex(40000000))

    def call(self, method, params=None):
        params = [] if params is None else params
        if any(token in method.lower() for token in ('send', 'sign', 'anvil', 'estimate', 'trace')):
            raise AssertionError('NEW wallet qualification is strictly read only')
        if method == 'eth_blockNumber':
            value = hex(110)
        elif method == 'eth_getBlockByNumber':
            assert len(params) == 2 and params[1] is False
            value = self.header(int(params[0], 16))
        elif method == 'eth_getBlockByHash':
            number = next((n for n in range(9, 111) if self.hash(n) == params[0]), None)
            assert number is not None and params[1] is False
            value = self.header(number)
        elif method == 'eth_getCode' and params == [self.nft, dict(blockHash=h(9), requireCanonical=True)]:
            value = '0x'
        elif method == 'eth_getCode' and params == [self.nft, dict(blockHash=self.hash(10), requireCanonical=True)]:
            # Production History independently proves absence at9 and the exact
            # pinned NFT runtime at10. No historical financial view is reused.
            value = self.inner.codes[self.nft]
        else:
            actual = params
            if method in ('eth_call', 'eth_getCode', 'eth_getStorageAt'):
                assert params[-1] == dict(blockHash=self.hash(BLOCK), requireCanonical=True), (method, params)
                if method == 'eth_call':
                    assert set(params[0]) == {'to', 'data'}
                actual = [*params[:-1], dict(blockHash=self.inner.hash, requireCanonical=True)]
            value = self.inner.call(method, actual)
        row = dict(method=method, params=copy.deepcopy(params), result=copy.deepcopy(value))
        self.calls.append(row)
        self.by_method[method] = self.by_method.get(method, 0) + 1
        key = json.dumps([method, params], sort_keys=True, separators=(',', ':'))
        if key in self.unique:
            assert self.unique[key]['result'] == value, 'Synthetic fixed-block reply drifted'
        self.unique[key] = row
        return value


class WalletFixture:
    """New collection, events and literal getters over neutral current7 graph."""
    def __init__(self, count, *, royalty_count=2, output=None):
        assert count in (1, 16, 17, 1000)
        self.cleanup = unittest.TestCase()
        self.fresh = Fresh7API(self.cleanup)
        self.inner, self.q = self.fresh.rpc, self.fresh.q
        self.c = dict(self.fresh.c)
        self.config = copy.deepcopy(self.fresh.config)
        self.ids = tuple((1 << 255) + ordinal for ordinal in range(1, count + 1))
        self.count = count
        self.c.update(fees=addr(40), membership=addr(41))
        self.roles = {role: self.c[role] for role in ('nft', 'vault', 'rewards', 'royalties', 'handoff', 'fees', 'membership')}
        self.pair = [ZERO, ZZZ]
        self.royalties = [ZERO, USD6]
        if royalty_count > 2:
            self.royalties += [addr(35000 + n) for n in range(royalty_count - 2)]
            for n, token in enumerate(self.royalties[2:]):
                code = '0x600b' + f'{n:04x}'
                self.inner.codes[token] = code
                self.put(token, 'decimals()', values=(18,))
                self.config['assets'].append(dict(address=token, decimals=18, symbol='NEW' + str(n),
                    code_hash='0x' + keccak256(bytes.fromhex(code[2:])).hex()))
        self.rpc = ReadOnlyRPC(self.inner, self.c['nft'])
        self.temp = tempfile.TemporaryDirectory(prefix='new-wallet-view-')
        self.cleanup.addCleanup(self.temp.cleanup)
        self.database = Path(self.temp.name) / 'new-raw.sqlite'
        contracts = sorted(self.roles.values())
        self.config['history'] = dict(database=str(self.database), start_block=10,
            start_parent_hash=h(9), contracts=contracts, max_events=10000)
        extra = {}
        for role, label in (('fees', 'ZZZFeeController'), ('membership', 'ZZZMembership')):
            code = '0x600b' + f'{int(self.c[role], 16):04x}'
            self.inner.codes[self.c[role]] = code
            extra[role] = dict(address=self.c[role], code_hash='0x' + keccak256(bytes.fromhex(code[2:])).hex())
            self.put(self.c[role], 'access()', values=(self.c['access'],))
            self.put(self.c['access'], 'module(bytes32)', ('0x' + keccak256(label.encode()).hex(),), (self.c[role],))
        self.config['earnings_history'] = dict(schema=1, deployments=[dict(controller=self.c['access'], **extra)], prices=None)
        self.put(self.c['fees'], 'FEE_INTAKE_VERSION()', values=(1,))
        self.put(self.c['royalties'], 'assetCount()', values=(len(self.royalties),))
        for n, token in enumerate(self.royalties):
            self.put(self.c['royalties'], 'assets(uint256)', (n,), (token,))
        cfg = dict(database=str(self.database), chain_id=31337, start_block=10,
            start_parent_hash=h(9), contracts=contracts, rpc_urls=['http://127.0.0.1:1'])
        self.index = Indexer(cfg, self.rpc)
        self.cleanup.addCleanup(self.index.db.close)
        with self.index.db:
            for number in range(10, BLOCK + 1):
                header = self.rpc.header(number)
                self.index.db.execute('INSERT INTO blocks VALUES(?,?,?,?,?)',
                    (31337, number, header['hash'], header['parentHash'], int(header['timestamp'], 16)))
            self.index.db.execute('UPDATE cursors SET next_block=100')
        self.rows, self.indices = [], {}
        self.populate()
        self.install_views()
        self.install_prices()
        self.p = Projection(self.config, self.rpc, clock=lambda: NOW)

    def close(self):
        self.cleanup.doCleanups()

    def put(self, target, signature, args=(), values=(0,)):
        self.inner.responses[target, static_data(signature, *args)] = words(*values)

    def emit(self, role, signature, indexed=(), data=(), block=20):
        log_index = self.indices.get(block, 0)
        self.indices[block] = log_index + 1
        row = dict(address=self.roles[role], blockNumber=hex(block), blockHash=self.rpc.hash(block),
            transactionHash=h(1000 + block), logIndex=hex(log_index), removed=False,
            topics=['0x' + keccak256(signature.encode()).hex(), *[words(v) for v in indexed]], data=words(*data))
        self.rows.append(row)

    def fee(self, asset, block, units):
        base = units * self.count
        self.emit('rewards', 'PoolRewardsCredited(uint256,address,uint256,uint256)', (BUCKET, asset), (16 * base, 2 * base), block)
        self.emit('fees', 'FeesAllocated(uint256,address,uint256,uint256)', (BUCKET, asset), (20 * base, 0), block)

    def royalty(self, asset, block, per_nft, initial=False):
        amount = per_nft * self.count
        self.emit('royalties', 'RoyaltiesAllocated(address,uint256,uint256,uint256,uint256,uint256)',
            (asset,), (amount, self.count, self.count, 0, 0), block)
        self.emit('royalties', 'InitialRoyaltiesAllocated(address,uint256,uint256,uint256)' if initial else
            'RoyaltiesReceived(address,uint256,bool)', (asset,),
            (amount, self.count, self.count) if initial else (amount, 1), block)

    def populate(self):
        for asset in self.royalties:
            self.emit('royalties', 'AssetAdded(address,uint256)', (asset,), (0,), 10)
        end = 1000000 + 14 * 1200
        self.emit('royalties', 'MintEndConfigured(uint64,uint256)', (), (end, end + 3600), 10)
        for ordinal, identifier in enumerate(self.ids, 1):
            self.emit('nft', 'Transfer(address,address,uint256)', (ZERO, FORMER if ordinal == 1 else OWNER, identifier), (), 11)
            self.emit('rewards', 'ShareWeightSynchronized(uint256,uint256,uint256,uint256,uint256,uint256)',
                (identifier, BUCKET), (ordinal, 0, 100, ordinal * 100), 13)
            self.emit('rewards', 'CollectiveWeightSynchronized(uint256,uint256,uint256,uint256,uint256)',
                (identifier,), (ordinal, 0, 1, ordinal), 13)
            self.emit('membership', 'MembershipActivated(uint256)', (identifier,), (), 13)
            self.emit('royalties', 'Activated(uint256,uint256)', (identifier,), (1,), 13)
            self.emit('vault', 'SharesAdded(uint256,uint256,uint256,uint256)', (identifier, BUCKET), (100, 100 * 10**18), 13)
        for asset in self.royalties:
            self.emit('royalties', 'RoyaltiesReceived(address,uint256,bool)', (asset,), (7 * self.count, 0), 14)
        self.emit('royalties', 'RoyaltyOpeningFinalized(uint256,uint256,uint256)', (), (end + 3600, self.count, self.count), 20)
        for block, units in ((20, 1), (DAY_BLOCK, 2), (DAY_BLOCK + 1, 3)):
            for asset in self.pair:
                self.fee(asset, block, units)
            for asset in self.royalties:
                self.royalty(asset, block, {20: 7, DAY_BLOCK: 11, DAY_BLOCK + 1: 13}[block], initial=block == 20)
        first = self.ids[0]
        # Conversion spends source components96+12 and credits native48+6.
        # The original earned source currencies and earned ETH are unchanged.
        self.emit('rewards', 'LPRewardsConverted(uint256,address,uint256,uint256,uint256,uint256)',
            (first, ZZZ), (96, 12, 48, 6), 91)
        self.emit('rewards', 'Claimed(uint256,address,address,uint256)', (first, ZERO, FORMER), (162,), 92)
        self.emit('royalties', 'Claimed(uint256,address,address,uint256)', (first, ZERO, FORMER), (31,), 93)
        self.emit('nft', 'Transfer(address,address,uint256)', (FORMER, OWNER, first), (), 95)
        self.rows.sort(key=lambda row: (int(row['blockNumber'], 16), int(row['logIndex'], 16)))
        with self.index.db:
            self.index.db.executemany('INSERT INTO logs VALUES(?,?,?,?,?,?,?,?,?)', [
                (31337, int(row['blockNumber'], 16), row['blockHash'], row['transactionHash'],
                 int(row['logIndex'], 16), row['address'], None, None, json.dumps(row)) for row in self.rows])

    def install_views(self):
        # Literal final-state getters below are independent of ExactReplay.
        # Equal100 shares and rarity1 make each funded phase exactly divisible.
        n = self.count
        self.put(self.c['nft'], 'mintedCount()', values=(n,))
        self.put(self.c['nft'], 'balanceOf(address)', (OWNER,), (n,))
        self.put(self.c['nft'], 'balanceOf(address)', (FORMER,), (0,))
        self.put(self.c['membership'], 'totalEligible()', values=(n,))
        for sig, value in (('totalWeight()', n), ('activationCount()', n), ('mintEnd()', 1000000 + 14 * 1200),
                           ('mintEndRevision()', 1),
                           ('royaltiesOpenAt()', 1000000 + 14 * 1200 + 3600), ('royaltiesOpen()', 1)):
            self.put(self.c['royalties'], sig, values=(value,))
        self.put(self.c['vault'], 'bucketTotalShares(uint256)', (BUCKET,), (n * 100,))
        # Keep the actual eight-word group and physical LP coherent with this
        # newly populated collection. The neutral adapter recomputes amounts
        # and both fingerprints from ticks/slot0/this positive liquidity.
        self.q.position[4] = n * 100 * 10**18
        self.q.position[6] = 0
        self.q.now = STAMP
        self.q.physical_liquidities[123] = n * 10**9
        # Both components per NFT are96/12 before first NFT conversion/claim.
        self.put(self.c['rewards'], 'allocationTree(uint256)', (0,), (n, (n - 1) * 12, (n - 1) * 12))
        self.put(self.c['rewards'], 'allocationTree(uint256)', (BUCKET,), (n * 100, (n - 1) * 96, (n - 1) * 96))
        for asset in self.pair:
            self.put(self.c['rewards'], 'directLiabilities(address)', (asset,), (0,))
            self.put(self.c['rewards'], 'liabilities(address)', (asset,), ((n - 1) * 108,))
            self.put(self.c['rewards'], 'orphaned(address)', (asset,), (0,))
            self.put(self.c['fees'], 'dust(uint256,address)', (BUCKET, asset), (0,))
        for ordinal, identifier in enumerate(self.ids, 1):
            for sig, args, value in (('ownerOf(uint256)', (identifier,), OWNER),
                    ('mintOrdinalOf(uint256)', (identifier,), ordinal), ('tokenAtOrdinal(uint256)', (ordinal,), identifier),
                    ('currentLPValue(uint256)', (identifier,), None)):
                self.put(self.c['nft'], sig, args, (1, (1000 * 10**18) + ordinal) if value is None else (value,))
            for role, sig, value in (('vault', 'nftStatus(uint256)', 1), ('vault', 'nftBucket(uint256)', BUCKET),
                    ('vault', 'sharesOf(uint256)', 100), ('rewards', 'rewardBucket(uint256)', BUCKET),
                    ('royalties', 'weightOf(uint256)', 1), ('royalties', 'ticketStart(uint256)', ordinal)):
                self.put(self.c[role], sig, (identifier,), (value,))
            for asset in self.pair:
                component = (0, 0) if ordinal == 1 else (96, 12)
                self.put(self.c['rewards'], 'claimableComponents(uint256,address)', (identifier, asset), component)
                self.put(self.c['rewards'], 'claimable(uint256,address)', (identifier, asset), (sum(component),))
            for asset in self.royalties:
                self.put(self.c['royalties'], 'claimable(uint256,address)', (identifier, asset),
                    (0 if ordinal == 1 and asset == ZERO else 31,))
        for asset in self.royalties:
            for sig, value in (('eligibleCount(address)', n), ('eligibleWeight(address)', n),
                    ('allocationCursor(address)', 0), ('pending(address)', 0), ('openingPool(address)', 0)):
                self.put(self.c['royalties'], sig, (asset,), (value,))

    def install_prices(self):
        oracle, code = addr(31000), '0x600bface'
        self.inner.codes[oracle] = code
        self.put(oracle, 'access()', values=(self.c['access'],))
        self.put(self.c['access'], 'module(bytes32)', ('0x' + keccak256(b'ZZZOracle').hex(),), (oracle,))
        self.put(oracle, 'sequencerFeed()', values=(ZERO,))
        self.put(oracle, 'activeSequencerPolicy()', values=('0x' + '0' * 64,))
        self.put(oracle, 'PRICING_VERSION()', values=(2,))
        self.put(oracle, 'policyCount()', values=(3,))
        feeds = []
        source_code = '0x600bfeed'
        source_hash = '0x' + keccak256(bytes.fromhex(source_code[2:])).hex()
        for index, asset in enumerate((ZERO, ZZZ, USD6)):
            record = make_policy(asset, 6 if asset == USD6 else 18, oracle, index, 32000 + 2 * index, source_hash)
            answer = FEED_ANSWERS[asset]
            observation = bounds(record, oracle, answer=answer, stamp=STAMP - 20)
            self.put(oracle, 'activePolicy(address)', (asset,), (record['policy_id'],))
            self.put(oracle, 'policyAt(uint256)', (index,), (record['policy_id'],))
            self.put(oracle, 'policy(bytes32)', (record['policy_id'],), D.flat(record['policy']))
            self.put(oracle, 'priceBounds(address)', (asset,), tuple(observation[k] for k in ('lower', 'upper', 'fingerprint')))
            for side in ('primary', 'secondary'):
                source = record['policy'][side]['source']
                self.inner.codes[source] = source_code
                self.put(source, 'decimals()', values=(8,))
                self.put(source, 'latestRoundData()', values=source_round(answer, STAMP - 20))
            descriptor = next(row for row in self.config['assets'] if row['address'] == asset)
            feeds.append(dict(asset=asset, priced_token=asset, token_code_hash=descriptor['code_hash'], price_policy=record))
        self.config['earnings_history']['prices'] = dict(pricing_version=2,
            oracle=dict(address=oracle, code_hash='0x' + keccak256(bytes.fromhex(code[2:])).hex()), sequencer=None, feeds=feeds)


def expected(count):
    periods = {}
    usd = {}
    for period, individual, collective, royalty in (('all_time', 96, 12, 31), ('last_24h', 48, 6, 13)):
        periods[period] = {asset: dict(lp_individual=individual * count if asset in (ZERO, ZZZ) else 0,
            lp_collective=collective * count if asset in (ZERO, ZZZ) else 0,
            royalties=royalty * count if asset in (ZERO, USD6) else 0) for asset in (ZERO, ZZZ, USD6)}
        usd[period] = {field: str(sum(row[field] * PRICES[asset] // 10**(6 if asset == USD6 else 18)
            for asset, row in periods[period].items())) for field in FIELDS}
    return dict(raw={p: {a: {f: str(v) for f, v in row.items()} for a, row in assets.items()} for p, assets in periods.items()},
        usd=usd, lp_usd_18=str(count * 1000 * 10**18 + count * (count + 1) // 2),
        claimable_eth_wei=str((count - 1) * 139),
        day_boundary=dict(excluded_block=DAY_BLOCK, included_block=DAY_BLOCK + 1, timestamp=STAMP - 86400),
        financial_scope='Current NFT ownership includes earlier-owner lifetime income; conversion and claims do not create income.',
        converted_source_raw='108', conversion_native_credit_raw='54', native_lp_claim_raw='162', native_royalty_claim_raw='31')


def measure(fixture, label, function, *args):
    start = len(fixture.rpc.calls)
    started = time.perf_counter()
    with request_scope() as budget:
        result = function(*args)
    elapsed = time.perf_counter() - started
    body = json.dumps(result, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()
    calls = len(fixture.rpc.calls) - start
    assert calls == 1024 - budget.calls and calls <= 1024
    assert len(body) <= MAX_RESULT and elapsed < 25
    return result, dict(action=label, rpc_calls=calls, remaining_rpc=budget.calls,
        elapsed_seconds=elapsed, json_bytes=len(body), limit_seconds=25, limit_rpc=1024, limit_bytes=MAX_RESULT)


def assert_expected(parts, want):
    for period in ('all_time', 'last_24h'):
        raw = {asset: {field: 0 for field in FIELDS} for asset in (ZERO, ZZZ, USD6)}
        for part in parts:
            for row in part[period]:
                assert row['current_price']['available'] is True
                assert row['current_price']['usd_per_token_18'] == str(PRICES[row['asset']])
                for field in FIELDS:
                    raw[row['asset']][field] += int(row[field + '_raw'])
                    mark = int(row[field + '_raw']) * PRICES[row['asset']] // 10**row['decimals']
                    assert row['usd_at_current_price_18'][field] == str(mark)
        assert {a: {f: str(v) for f, v in row.items()} for a, row in raw.items()} == want['raw'][period]


def loaded_sources():
    result = {}
    for module in list(sys.modules.values()):
        name = getattr(module, '__file__', None)
        if name:
            path = Path(name).resolve()
            if path.suffix == '.py' and path.is_relative_to(ROOT):
                result[path.relative_to(ROOT).as_posix()] = hashlib.sha256(path.read_bytes()).hexdigest()
    result['EXTERNAL/backend_producer.py'] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    return dict(sorted(result.items()))


def scenario(count, output):
    fixture = WalletFixture(count)
    try:
        p, metrics = fixture.p, []
        protocol, metric = measure(fixture, 'protocol', p.protocol)
        metrics.append(metric)
        inventory, summaries, earnings = [], [], []
        for offset in range(0, count, 16):
            for label, function, destination in (('wallet_page', p.wallet_page, inventory),
                    ('wallet_summary', p.wallet_summary, summaries), ('wallet_earnings', p.wallet_earnings, earnings)):
                result, metric = measure(fixture, label, function, OWNER, BLOCK, offset)
                destination.append(result)
                metrics.append(dict(metric, offset=offset))
        want = expected(count)
        assert sum(int(row['lp_usd_18']) for row in summaries) == int(want['lp_usd_18'])
        assert sum(int(row['claimable_eth_wei']) for row in summaries) == int(want['claimable_eth_wei'])
        assert [identifier for row in inventory for identifier in row['token_ids']] == list(map(str, fixture.ids))
        assert_expected(earnings, want)
        result = dict(schema=1, kind='NEW_actual_backend_synthetic_transport_wallet_fixture',
            qualification='Production Python producer and SQLite replay only; all runtimes/views/feeds/depth are synthetic; no EVM/provider/browser/host acceptance.',
            profile=dict(accounting_version=7, lp_allocation_version=1, royalty_settlement_version=4, royalty_reporting_schema=5, canonical='V9'),
            owner=OWNER, former_owner=FORMER, token_ids=list(map(str, fixture.ids)), read_configuration=fixture.config,
            pins=fixture.c, codes=fixture.inner.codes, protocol=protocol,
            inventory_pages=inventory, summary_pages=summaries, earnings_pages=earnings, expected=want,
            raw_history=dict(events=len(fixture.rows), blocks=90, start=10, through=BLOCK, checkpoint=None,
                sha256=hashlib.sha256(json.dumps(fixture.rows, sort_keys=True, separators=(',', ':')).encode()).hexdigest()),
            request_metrics=metrics, rpc_responses=list(fixture.rpc.unique.values()), source_hashes=loaded_sources())
        # Exact per-request DTOs are retained; no real transport has served them.
        output.write_text(json.dumps(result, sort_keys=True, separators=(',', ':'), allow_nan=False) + '\n', encoding='utf-8')
        return dict(count=count, requests=len(metrics), max_rpc=max(row['rpc_calls'] for row in metrics),
            total_rpc=sum(row['rpc_calls'] for row in metrics), max_seconds=max(row['elapsed_seconds'] for row in metrics),
            total_seconds=sum(row['elapsed_seconds'] for row in metrics), max_json_bytes=max(row['json_bytes'] for row in metrics),
            source_hashes=result['source_hashes'], output_sha256=hashlib.sha256(output.read_bytes()).hexdigest())
    finally:
        fixture.close()


def maximum_currency_refusal():
    fixture = WalletFixture(16, royalty_count=65)
    try:
        started = len(fixture.rpc.calls)
        try:
            fixture.p.wallet_earnings(OWNER, BLOCK, 0)
        except WorkLimit as exc:
            calls = len(fixture.rpc.calls) - started
            assert exc.reason == 'rpc_budget' and calls == 1024
            return dict(outcome='expected_refusal', reason='rpc_budget', calls=calls,
                currencies=65, selected=16, limit_unchanged=True)
        raise AssertionError('65currency16NFT request unexpectedly succeeded')
    finally:
        fixture.close()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--counts', type=int, nargs='+', default=[1, 17, 1000])
    parser.add_argument('--maximum-refusal', action='store_true')
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    before = loaded_sources()
    results = []
    try:
        for count in args.counts:
            result = scenario(count, args.output / ('scenario-' + str(count) + '.json'))
            results.append(result)
            print(json.dumps({k: v for k, v in result.items() if k != 'source_hashes'}, sort_keys=True), flush=True)
        refusal = maximum_currency_refusal() if args.maximum_refusal else None
        result = dict(schema=1, stage='NEW_backend_wallet_draft', scenarios=results,
            maximum_currency=refusal, before_sources=before, after_sources=loaded_sources(), old_test_methods_executed=0,
            limits=dict(seconds=25, rpc=1024, result_bytes=MAX_RESULT), production_files_changed=False)
        (args.output / 'RESULT.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
    except BaseException as exc:
        failure = dict(schema=1, completed=results, exception_type=type(exc).__name__, message=str(exc),
            after_sources=loaded_sources(), old_test_methods_executed=0)
        (args.output / 'FAILURE.json').write_text(json.dumps(failure, indent=2) + '\n', encoding='utf-8')
        raise


if __name__ == '__main__':
    main()
