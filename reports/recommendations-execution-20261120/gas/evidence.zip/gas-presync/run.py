"""One NEW retained-state optional-sync qualification, never public RPC."""
from pathlib import Path
import copy,datetime,gzip,hashlib,importlib.util,json,os,socket,subprocess,sys,time,urllib.request

R=Path.cwd(); E=Path(__file__).resolve().parent
V=Path('C:/Users/Ali/.codex/visualizations/2026/10/14/01a13899-2be7-76f2-a5d0-72e4804c67b9')
F=V/'maximum-workload-20261119/producer06'
sys.path.insert(0,str(R))
from zzz_ops.abi import calldata,decode_words,keccak256
spec=importlib.util.spec_from_file_location('retained_contribution',R/'reports/maximum-workload-20261119/tools/verify_contributions.py')
h=importlib.util.module_from_spec(spec);spec.loader.exec_module(h)
sha=lambda b:hashlib.sha256(b).hexdigest()
SOURCE=F/'cold-contributions/max64-twolp-999-opening-zzz-allslow/VERIFICATION.json'
assert sha(SOURCE.read_bytes())=='81a2bf61f4c73076d01bf9b76a7feefd255c0858cb0ebf431fffb8a4789a719e'
original=json.loads(SOURCE.read_bytes());case=original['profile']
assert original['verification_complete'] and not original['meets_reviewed_execution_profile']
assert original['estimated_gas']==27142801 and original['padded_gas']==32571362
baseline=json.loads((F.parent/'BASELINE.json').read_bytes())
for name,pin in {**baseline['source_sha256'],**baseline['protected_sha256']}.items():
    assert sha((R/name).read_bytes())==pin,name
assert len(baseline['source_sha256'])==61
h.F=F;h.ARTIFACT=F/'producer-artifact.json';h.ARTIFACT_SHA256=original['source_artifact_sha256']
assert sha(h.ARTIFACT.read_bytes())==h.ARTIFACT_SHA256
assert sha(h.ANVIL.read_bytes())==h.ANVIL_SHA256
alloc,omitted,merge=h.source_state(case)
block=case['block']; ZERO=h.ZERO
genesis={'config':{'chainId':block['chain_id'],'homesteadBlock':0,'eip150Block':0,'eip155Block':0,'eip158Block':0,
 'byzantiumBlock':0,'constantinopleBlock':0,'petersburgBlock':0,'istanbulBlock':0,'berlinBlock':0,'londonBlock':0,
 'terminalTotalDifficulty':0,'shanghaiTime':0,'cancunTime':0},'number':hex(block['number']),'nonce':'0x0',
 'timestamp':hex(block['timestamp']),'extraData':'0x','gasLimit':hex(96_000_000),'difficulty':'0x0',
 'mixHash':'0x'+'0'*64,'coinbase':ZERO,'baseFeePerGas':'0x0','alloc':alloc}
with (E/'genesis.json').open('x',encoding='utf-8') as stream:json.dump(genesis,stream,separators=(',',':'))
with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
env={k:os.environ[k] for k in ('SystemRoot','WINDIR','SystemDrive','COMSPEC','PATHEXT','TEMP','TMP','USERPROFILE','LOCALAPPDATA','APPDATA','PROGRAMDATA') if k in os.environ}
env['PATH']=str(h.ANVIL.parent)+os.pathsep+str(Path(os.environ.get('SystemRoot','C:/Windows'))/'System32')
command=[str(h.ANVIL),'--host','127.0.0.1','--port',str(port),'--accounts','0','--silent','--init',str(E/'genesis.json'),
 '--gas-limit','96000000','--chain-id',str(block['chain_id']),'--hardfork','cancun','--no-mining']
wire=[];start=time.monotonic();proc=None;out={'schema':1,'new_partition':'max64/two-LP optional syncAll then fresh ZZZ activation',
 'original_direct_cold_refusal_preserved':True,'original_direct_estimate':27142801,'original_padded':32571362,
 'production_approved':False,'public_calls':0,'source_changed':False,'owned_node_stopped':False}
opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
allowed=h.ALLOWED|{'anvil_impersonateAccount','anvil_stopImpersonatingAccount','eth_getTransactionCount','eth_sendTransaction','eth_getTransactionReceipt','evm_setNextBlockTimestamp','evm_mine'}
def rpc(method,params=None):
    assert method in allowed and len(wire)<1600 and time.monotonic()-start<900
    q={'jsonrpc':'2.0','id':len(wire)+1,'method':method,'params':params or []};raw=json.dumps(q,separators=(',',':')).encode()
    row={'request':q};wire.append(row)
    with opener.open(urllib.request.Request('http://127.0.0.1:'+str(port),raw,{'Content-Type':'application/json'}),timeout=60) as response:body=response.read(64*1024*1024+1)
    assert len(body)<=64*1024*1024;answer=json.loads(body);row['response']=answer
    assert answer.get('jsonrpc')=='2.0' and answer.get('id')==q['id']
    if 'error' in answer:raise RuntimeError(method+': '+str(answer['error']))
    return answer['result']
anchor=None
def read(address,signature,*args,count=1):
    words=decode_words(rpc('eth_call',[{'from':case['sender'],'to':address,'data':calldata(signature,*args)},anchor]))
    assert len(words)==count,(signature,len(words));return words
def number(address,signature,*args):return int(read(address,signature,*args)[0],16)
def head():
    global anchor
    blockrow=rpc('eth_getBlockByNumber',['latest',False]);anchor={'blockHash':blockrow['hash'],'requireCanonical':True};return blockrow
def trace(tx):
    value=rpc('debug_traceCall',[tx,anchor,{'tracer':'callTracer','tracerConfig':{'withLog':True},'timeout':'45s'}]);assert not value.get('error'),value.get('error');return value
def send(tx):
    before=head();sender=tx['from'];assert rpc('eth_getCode',[sender,anchor])=='0x'
    nonce=rpc('eth_getTransactionCount',[sender,'pending'])
    rpc('anvil_impersonateAccount',[sender])
    try:
        rpc('evm_setNextBlockTimestamp',[int(before['timestamp'],16)+1])
        digest=rpc('eth_sendTransaction',[{**tx,'gasPrice':'0x0','nonce':nonce}]);rpc('evm_mine')
        receipt=rpc('eth_getTransactionReceipt',[digest]);assert receipt and receipt['status']=='0x1'
        assert receipt['from'].lower()==sender and receipt['to'].lower()==tx['to']
        head();return receipt
    finally:rpc('anvil_stopImpersonatingAccount',[sender])
topic=lambda s:'0x'+keccak256(s.encode()).hex()
allocation_topic=topic('RoyaltiesAllocated(address,uint256,uint256,uint256,uint256,uint256)')
def allocation_logs(logs,royalty):return [x for x in logs if x['address'].lower()==royalty and x.get('topics',[None])[0]==allocation_topic]
try:
    with (E/'anvil.log').open('xb') as log:proc=subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    out.update(owned_pid=proc.pid,owned_port=port,owned_command=command,listener=h.listener_identity(proc,port),state_merge=merge)
    before=head();assert int(before['number'],16)==block['number'] and int(before['timestamp'],16)==block['timestamp']
    assert int(rpc('eth_chainId'),16)==block['chain_id']
    pins=case['pins'];royalty='0x'+read(pins['nft'],'royaltyRewards()')[0][-40:]
    for role,address in pins.items():
        assert '0x'+h.keccak256(bytes.fromhex(rpc('eth_getCode',[address,anchor])[2:])).hex()==case['runtime_hashes'][role],role
    zzz='0x'+read(pins['activation_assets'],'zzz()')[0][-40:]
    physical_before=h.physical_portfolio(case,read,zzz)
    shares_before=number(pins['vault'],'bucketTotalShares(uint256)',case['shared_bucket'])
    opening_before={'opening_finalized':number(royalty,'openingFinalized()'),'mint_end':number(royalty,'mintEnd()'),'royalties_open_at':number(royalty,'royaltiesOpenAt()'),'timestamp':int(before['timestamp'],16)}
    assert opening_before['timestamp']>=opening_before['royalties_open_at']
    assets=['0x'+read(royalty,'assets(uint256)',i)[0][-40:] for i in range(65)]
    assert len(set(assets))==65 and assets[0]==ZERO
    assert number(royalty,'activationCount()')==999 and number(royalty,'totalWeight()')==1499
    assert number(royalty,'weightOf(uint256)',case['nft_id'])==0
    assert number(pins['protocol_policy'],'royaltyBalanceGas()')==50_000 and number(pins['protocol_policy'],'royaltySyncGas()')==1_000_000
    for asset in assets:
        assert number(royalty,'openingPool(address)',asset)==2996 and number(royalty,'liabilities(address)',asset)==0
        assert number(royalty,'eligibleCount(address)',asset)==999 and number(royalty,'eligibleWeight(address)',asset)==1499
        assert number(royalty,'claimable(uint256,address)',case['nft_id'],asset)==0
    sync_tx={'from':case['sender'],'to':royalty,'value':'0x0','data':calldata('syncAll()'),'gas':hex(24_000_000)}
    sync_estimate=int(rpc('eth_estimateGas',[sync_tx,anchor]),16);sync_padded=(sync_estimate*125+99)//100
    assert sync_padded<=24_000_000
    sync_tx['gas']=hex(sync_padded);assert rpc('eth_call',[sync_tx,anchor])=='0x'
    sync_receipt=send(sync_tx);logs=allocation_logs(sync_receipt['logs'],royalty)
    assert len(logs)==65 and {'0x'+x['topics'][1][-40:] for x in logs}==set(assets)
    for row in logs:assert [int(w,16) for w in decode_words(row['data'])]==[2996,999,1499,0,1497]
    # 2996=2*1499-2. Independent ticket oracle captures rotating exact-unit remainder.
    expected=lambda first,last: (last-first+1)+(max(0,min(last,1497)-first+1))
    incumbent_ids=[]
    for mint_ordinal in (1,500,999):
        identifier=number(pins['nft'],'tokenAtOrdinal(uint256)',mint_ordinal)
        weight=number(royalty,'weightOf(uint256)',identifier)
        if weight:
            first=number(royalty,'ticketStart(uint256)',identifier);incumbent_ids.append((identifier,expected(first,first+weight-1)))
    assert incumbent_ids
    assert h.physical_portfolio(case,read,zzz)==physical_before
    assert number(pins['vault'],'bucketTotalShares(uint256)',case['shared_bucket'])==shares_before
    assert number(royalty,'mintEnd()')==opening_before['mint_end'] and number(royalty,'royaltiesOpenAt()')==opening_before['royalties_open_at']
    assert number(royalty,'activationCount()')==999 and number(royalty,'weightOf(uint256)',case['nft_id'])==0
    for asset in assets:
        assert number(royalty,'liabilities(address)',asset)==2996 and number(royalty,'openingPool(address)',asset)==0
        assert number(royalty,'accounted(address)',asset)==2996 and number(royalty,'allocationCursor(address)',asset)==1497
        assert number(royalty,'claimable(uint256,address)',case['nft_id'],asset)==0
        for identifier,value in incumbent_ids:assert number(royalty,'claimable(uint256,address)',identifier,asset)==value
    # Refresh the exact entrant call against the confirmed post-sync anchor.
    entry_tx={'from':case['sender'],'to':case['destination'],'value':hex(case['value']),'data':case['data'],'gas':hex(32_000_000)}
    entry_estimate=int(rpc('eth_estimateGas',[entry_tx,anchor]),16);entry_padded=(entry_estimate*120+99)//100
    out.update(sync_estimate=sync_estimate,sync_padded_full25pct=sync_padded,sync_receipt=sync_receipt,
        fresh_activation_estimate=entry_estimate,fresh_activation_padded_full20pct=entry_padded,
        activation_fits32m=entry_padded<=32_000_000,operator_actual_sync_gas=int(sync_receipt['gasUsed'],16),
        all65_opening_cohorts_protected=True,incumbent_samples=incumbent_ids,whole_unit_oracle='amount2996,weight1499: quotient1,remainder1497,cursor0',
        source_opening_allocation='old999 NFTs/weight1499; entrant dormant and claimable0')
    out.update(principal_before=physical_before,shares_before=shares_before,opening_cutoff_unchanged=opening_before,sync_did_not_change_principal_or_shares=True)
    assert entry_padded<=32_000_000,'Optional synchronization still does not admit this activation'
    entry_tx['gas']=hex(entry_padded);assert rpc('eth_call',[entry_tx,anchor])=='0x'
    entry_trace=trace(entry_tx);measured=h.measure_trace(entry_trace,entry_tx,case,read)
    physical=h.physical_portfolio(case,read,'0x'+read(pins['activation_assets'],'zzz()')[0][-40:])
    residual=h.residual_trace(entry_trace,case,physical);assert residual['verified']
    frame_logs=[log for frame in h.frames(entry_trace) for log in frame.get('logs',[])]
    assert not allocation_logs(frame_logs,royalty),'Pre-synced entry unexpectedly allocated more old funds'
    entry_receipt=send(entry_tx)
    assert number(royalty,'activationCount()')==1000 and number(royalty,'totalWeight()')==1500
    for asset in assets:
        assert number(royalty,'eligibleCount(address)',asset)==1000 and number(royalty,'eligibleWeight(address)',asset)==1500
        assert number(royalty,'liabilities(address)',asset)==2996 and number(royalty,'accounted(address)',asset)==2996
        assert number(royalty,'claimable(uint256,address)',case['nft_id'],asset)==0
        for identifier,value in incumbent_ids:assert number(royalty,'claimable(uint256,address)',identifier,asset)==value
    out.update(entry_receipt=entry_receipt,entry_financial_trace=measured,residual_financial_trace=residual,
        new_entrant_received_no_earlier_royalty_units=True,all65_incumbent_samples_unchanged=True,
        actual_activation_gas=int(entry_receipt['gasUsed'],16),verification_complete=True,
        direct_cold_case_closed=False,operating_default_changed=False,
        limit='New royalties between sync and entry may restore expensive work. Local zero fees are not Robinhood fee approval.')
except Exception as exc:
    import traceback
    out.update(verification_complete=False,error=type(exc).__name__+': '+str(exc),error_location=traceback.format_exc())
finally:
    if proc is not None:
        proc.terminate()
        try:proc.wait(timeout=10)
        except subprocess.TimeoutExpired:proc.kill();proc.wait(timeout=10)
        out['owned_node_stopped']=proc.poll() is not None
    raw=json.dumps(wire,separators=(',',':')).encode();(E/'rpc-records.json.gz').write_bytes(gzip.compress(raw,mtime=0))
    out.update(rpc_requests=len(wire),rpc_records_sha256=sha((E/'rpc-records.json.gz').read_bytes()),elapsed_seconds=time.monotonic()-start,
        script_sha256=sha(Path(__file__).read_bytes()),source_verification_sha256=sha(SOURCE.read_bytes()))
    with (E/'RESULT.json').open('x',encoding='utf-8') as f:json.dump(out,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in out.items() if isinstance(v,(bool,int,float,str)) and k not in ('error_location',)}))
raise SystemExit(0 if out.get('verification_complete') else 1)
