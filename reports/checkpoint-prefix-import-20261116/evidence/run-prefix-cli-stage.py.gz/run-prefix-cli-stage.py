"""Execute only new prefix CLI/publication methods, with exclusive scoped evidence."""
import datetime
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import unittest

ROOT = Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
sys.path.insert(0, str(ROOT))
from zzz_ops.evidence import Evidence

spec = importlib.util.spec_from_file_location('scoped_python_runner', ROOT/'scripts/run_python_tests.py')
runner = importlib.util.module_from_spec(spec); spec.loader.exec_module(runner)
stage, output = sys.argv[1], Path(sys.argv[2])
representative = ('tests_python.test_checkpoint_prefix_import_cli.'
                  'CheckpointPrefixImportPublicationTests.'
                  'test_real_prepared_pair_publishes_exclusively_with_false_adoption_flags')
if stage not in ('representative', 'adversarial', 'harness-repair'):
    raise ValueError('Unexpected offline test stage')
with Evidence(output, with_log=True, kind='checkpoint_prefix_import_cli_evidence') as evidence:
    before = runner.inputs()
    selected, classes = runner.select_tests(('test_checkpoint_prefix_import_cli',))
    if stage == 'harness-repair':
        previous = json.loads((Path(__file__).parent/'cli-publication-adversarial-01.json').read_text(encoding='utf-8'))
        failed = {row[0].split(' (')[0] for row in previous['errors']+previous['failures']}
        selected = {name: item for name, item in selected.items() if name in failed}
    else:
        selected = {name: item for name, item in selected.items()
                    if (name == representative) == (stage == 'representative')}
    if not selected:
        raise ValueError('Empty scoped selection')
    result = unittest.TextTestRunner(stream=evidence.log, verbosity=2,
                                    resultclass=runner.Results).run(unittest.TestSuite(selected.values()))
    after = runner.inputs()
    changed = sorted(name for name in before.keys() | after.keys() if before.get(name) != after.get(name))
    report = dict(observed_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  scope='Only new CLI/publication cases; controlled reusable fixture helpers, no historical test bodies, public RPC, Solidity or deployment.',
                  stage=stage, execution_performed=True, selected_methods=list(selected),
                  executed_methods=result.methods, tests_run=result.testsRun,
                  failures=[(case.id(), reason) for case, reason in result.failures],
                  errors=[(case.id(), reason) for case, reason in result.errors],
                  skips=[(case.id(), reason) for case, reason in result.skipped],
                  source_sha256_before=before, source_sha256_after=after,
                  source_changes_during_run=changed,
                  external_runner_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  successful=not changed and result.wasSuccessful() and
                             result.testsRun == len(selected) and result.methods == list(selected),
                  production_approved=False, approved=False, installed=False,
                  public_requests=0, solidity_tests_executed=0)
    log = evidence.read_log(); evidence.finish(report)
print(log)
print(json.dumps({key: report[key] for key in ('stage', 'tests_run', 'successful')}))
raise SystemExit(0 if report['successful'] else 1)
