"""Pin existing stage evidence and unchanged-case reuse; executes no tests."""
import ast
import hashlib
import json
from pathlib import Path

ROOT = Path('C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
OUT = Path(__file__).parent
TEST = 'tests_python/test_checkpoint_prefix_import_cli.py'
sha = lambda raw: hashlib.sha256(raw).hexdigest()
reports = {label: json.loads((OUT/name).read_text(encoding='utf-8')) for label, name in (
    ('representative', 'cli-publication-representative-01.json'),
    ('adversarial', 'cli-publication-adversarial-01.json'),
    ('repair', 'cli-publication-harness-repair-01.json'))}
final = (ROOT/TEST).read_bytes()
initial = final.decode('utf-8').replace(
    "                        patch.object(CLI, 'publish'), \\\n                        patch.object(CLI, stage, side_effect=error('rpc_budget' if error is WorkLimit else secret)):",
    "                        patch.object(CLI, 'publish'), patch.object(CLI, stage, side_effect=error(secret)):")
initial = initial.replace('(ValueError, OSError, RpcError)', '(ValueError, OSError)').encode('utf-8')
assert sha(initial) == reports['adversarial']['source_sha256_before'][TEST]
assert sha(final) == reports['repair']['source_sha256_before'][TEST]
for name, data in (('test_checkpoint_prefix_import_cli-stage01.py', initial),
                   ('test_checkpoint_prefix_import_cli-final.py', final)):
    with (OUT/name).open('xb') as handle:
        handle.write(data)

def methods(raw):
    return {f'tests_python.test_checkpoint_prefix_import_cli.{cls.name}.{method.name}':
                sha(ast.dump(method, include_attributes=False).encode('utf-8'))
            for cls in ast.parse(raw.decode('utf-8')).body if isinstance(cls, ast.ClassDef)
            for method in cls.body if isinstance(method, ast.FunctionDef) and method.name.startswith('test_')}

old_cases, final_cases = methods(initial), methods(final)
failed = {row[0].split(' (')[0] for row in reports['adversarial']['errors']+reports['adversarial']['failures']}
successful_initial = set(reports['representative']['executed_methods']) | (set(reports['adversarial']['executed_methods'])-failed)
assert len(successful_initial) == 16
assert set(reports['repair']['executed_methods']) == failed
assert all(old_cases[name] == final_cases[name] for name in successful_initial)
assert len(successful_initial | failed) == len(final_cases) == 26
assert all(not report['source_changes_during_run'] for report in reports.values())
assert reports['representative']['successful'] is True and reports['repair']['successful'] is True
application = ('frontend_api/earnings_checkpoint_import.py', 'scripts/import-earnings-checkpoint.py')
assert all(len({report['source_sha256_before'][name] for report in reports.values()}) == 1 for name in application)
manifest = dict(scope='No test execution: exact staged evidence and case-AST provenance only.',
                test_source_initial_sha256=sha(initial), test_source_final_sha256=sha(final),
                selected_case_ast_sha256=final_cases,
                reused_unchanged_successes=sorted(successful_initial),
                corrected_harness_cases=sorted(failed),
                distinct_passing_methods=26, initial_adversarial_stage_successful=False,
                harness_corrections='Catch the actual HistoryError/RpcError hierarchy and construct WorkLimit with an allowed reason; no application behavior changed.',
                unchanged_application_sha256={name: reports['repair']['source_sha256_before'][name] for name in application},
                evidence_sha256={path.name: sha(path.read_bytes()) for path in sorted(OUT.glob('cli-publication-*.json'))} |
                                {path.name: sha(path.read_bytes()) for path in sorted(OUT.glob('cli-publication-*.log'))},
                production_approved=False, approved=False, installed=False)
with (OUT/'cli-selected-case-pins.json').open('x', encoding='utf-8') as handle:
    json.dump(manifest, handle, indent=2); handle.write('\n')
print(json.dumps({key: manifest[key] for key in ('distinct_passing_methods', 'test_source_initial_sha256', 'test_source_final_sha256', 'unchanged_application_sha256')}))
