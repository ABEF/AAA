from pathlib import Path
import importlib.util,sys,gzip,json,hashlib
ROOT=Path(r'C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
E=Path(__file__).resolve().parent;V=E.parent
spec=importlib.util.spec_from_file_location('rehearsal',ROOT/'scripts/rehearse-manual-recovery.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
p=E/'rpc/c14-attempt3/active-c14/manual'
raw={name:json.loads((p/(name+'.json')).read_bytes()) for name in ('before','after','receipt','review','transaction')}
cases=m.parse_export(E/'exports/0-attempt3',E/'current-host/out/ManualRecoveryQualification.t.sol/ManualRecoveryQualificationTest.json');case=next(row for row in cases if row['label']=='active-c14')
records=json.loads(gzip.decompress((p.parent/'rpc-records.json.gz').read_bytes()))
class Replay:
    calls=[]
    def call(self,method,params):
        matches=[row['response'] for row in records if row['method']==method and row['params']==params and 'result' in row['response']]
        assert matches and all(item['result']==matches[0]['result'] for item in matches)
        self.calls.append({'method':method,'params':params,'recorded_matches':len(matches)})
        return matches[0]['result']
replay=Replay();assertions=m.verify_post(replay,case,raw['before'],raw['after'],raw['receipt'],action='C',minimum_liquidity=int(case['selection']['minimumLiquidity']),closed_by_receipt=True)
initial,final=(raw['review']['simulation'][key] for key in ('initial','final'));receipt=raw['receipt'];tx=raw['transaction'];r=raw['review']
assert int(final['padded_gas'])==(int(final['estimated_gas'])*125+99)//100
assert int(final['gas_limit_cap'])==24_000_000 and int(final['block_gas_limit'])==32_000_000
assert tx['input']==r['transaction']['data'] and int(tx['gas'],16)==int(final['padded_gas']) and int(receipt['status'],16)==1
out={'schema':1,'successful':True,'evidence_scope':'Offline reconciliation of the one already-included actual C14 receipt; zero EVM or CLI reruns',
 'original_failed_verifier_preserved':True,'verifier_correction':'C completeConsolidation intentionally increments portfolio control revisions and emits PortfolioApplied; the former unchanged-control expectation was wrong.',
 'assertions':assertions,'recorded_header_queries':replay.calls,'source_sha256':m.sha((ROOT/'scripts/rehearse-manual-recovery.py').read_bytes()),
 'original_evidence_sha256':{name:m.sha((p/(name+'.json')).read_bytes()) for name in raw},
 'transaction_hash':receipt['transactionHash'],'gas':{'initial_estimate':int(initial['estimated_gas']),'final_estimate':int(final['estimated_gas']),'required_25_percent_padded_gas':int(final['padded_gas']),'profile_cap':24_000_000,'remaining_profile_margin':24_000_000-int(final['padded_gas']),'receipt_gas_used':int(receipt['gasUsed'],16),'effective_gas_price_wei':int(receipt['effectiveGasPrice'],16)}}
m.save(p/'RECONCILIATION.json',out);print(json.dumps(out,indent=2))
