from pathlib import Path
import datetime,hashlib,json,os,subprocess,time,sys
E=Path(__file__).resolve().parent;V=E.parent;P=E/'current-host';O=E/(sys.argv[1] if len(sys.argv)>1 else 'compile-1');O.mkdir(exist_ok=False)
names=('SystemRoot','WINDIR','SystemDrive','COMSPEC','PATHEXT','TEMP','TMP','USERPROFILE','LOCALAPPDATA','APPDATA','PROGRAMDATA')
env={n:os.environ[n] for n in names if n in os.environ}
env.update(RAYON_NUM_THREADS='2',FOUNDRY_OFFLINE='true',PATH=str(V/'foundry-v1.4.4')+os.pathsep+str(V/'toolchain-0.8.26')+os.pathsep+str(Path(env.get('SystemRoot','C:/Windows'))/'System32'))
prep=json.loads((P/'PREPARED.json').read_bytes())
before={n:hashlib.sha256((P/n).read_bytes()).hexdigest() for n in prep['source_sha256']};assert before==prep['source_sha256']
cmd=[str(V/'foundry-v1.4.4/forge.exe'),'test','--root',str(P),'--use',str(V/'toolchain-0.8.26/solc.exe'),
    '--match-contract','^ManualRecoveryQualificationTest$','--list','--json']
(O/'START.json').write_text(json.dumps({'command':cmd,'selected_old_test_methods':0,'executed_test_methods':0,
    'source_sha256':before,'started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2))
start=time.monotonic()
with (O/'stdout.json').open('xb') as out,(O/'stderr.txt').open('xb') as err:
    proc=subprocess.run(cmd,cwd=P,env=env,stdout=out,stderr=err,timeout=1200,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
after={n:hashlib.sha256((P/n).read_bytes()).hexdigest() for n in before};assert after==before
record={'exit_code':proc.returncode,'seconds':time.monotonic()-start,'source_unchanged':after==before,'executed_tests':0}
(O/'RESULT.json').write_text(json.dumps(record,indent=2));print(json.dumps(record));raise SystemExit(proc.returncode)
