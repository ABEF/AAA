from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys,time
E=Path(__file__).resolve().parent;V=E.parent;P=E/'current-host'
METHODS=['testActualManualC14ConsolidatesExistingMain','testActualManualD14ReplacesBothLegs',
    'testActualParkedD14RetainsFinancialGuards','testActualParkedD0ExplicitOracleOutage']
index=int(sys.argv[1]);name=METHODS[index];O=E/'exports'/(str(index)+('-'+sys.argv[2] if len(sys.argv)>2 else ''));O.mkdir(exist_ok=False)
names=('SystemRoot','WINDIR','SystemDrive','COMSPEC','PATHEXT','TEMP','TMP','USERPROFILE','LOCALAPPDATA','APPDATA','PROGRAMDATA')
env={n:os.environ[n] for n in names if n in os.environ}
env.update(RAYON_NUM_THREADS='2',FOUNDRY_OFFLINE='true',PATH=str(V/'foundry-v1.4.4')+os.pathsep+str(V/'toolchain-0.8.26')+os.pathsep+str(Path(env.get('SystemRoot','C:/Windows'))/'System32'),
    POPL_MANUAL_RECOVERY_EXPORT_ROOT=str(O),POPL_MANUAL_RECOVERY_TIMESTAMP=str(int(time.time())))
prep=json.loads((P/'PREPARED.json').read_bytes());before={n:hashlib.sha256((P/n).read_bytes()).hexdigest() for n in prep['source_sha256']};assert before==prep['source_sha256']
cmd=[str(V/'foundry-v1.4.4/forge.exe'),'test','--root',str(P),'--use',str(V/'toolchain-0.8.26/solc.exe'),
    '--match-contract','^ManualRecoveryQualificationTest$','--match-test','^'+name+r'(?:\(\))?$','--json','-vvv']
(O/'START.json').write_text(json.dumps({'command':cmd,'new_method':name,'old_test_methods_selected':0,
    'real_export_timestamp':int(env['POPL_MANUAL_RECOVERY_TIMESTAMP']),'source_sha256':before,
    'started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2))
start=time.monotonic()
with (O/'forge.json').open('xb') as out,(O/'forge.stderr').open('xb') as err:
    proc=subprocess.Popen(cmd,cwd=P,env=env,stdout=out,stderr=err,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    (O/'PID.json').write_text(json.dumps({'owned_forge_pid':proc.pid}))
    try:code=proc.wait(timeout=180)
    except subprocess.TimeoutExpired:proc.kill();proc.wait(timeout=10);raise
after={n:hashlib.sha256((P/n).read_bytes()).hexdigest() for n in before};assert before==after
data=json.loads((O/'forge.json').read_bytes());rows=[{'suite':suite,'name':method,'status':row['status'],'reason':row.get('reason')}
    for suite,group in data.items() for method,row in group.get('test_results',{}).items()]
record={'exit_code':code,'seconds':time.monotonic()-start,'source_unchanged':before==after,
    'selected_methods':rows,'old_test_methods_executed':0}
(O/'RESULT.json').write_text(json.dumps(record,indent=2));print(json.dumps(record));raise SystemExit(code)
