from pathlib import Path
import hashlib,json,sys
E=Path(__file__).parent;R=Path(r'C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2');N=Path(sys.argv[1]).resolve()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
start=json.loads((N/'START.json').read_bytes());result=json.loads((N/'RESULT.json').read_bytes())
inp=json.loads((N/'compiler-input.json').read_bytes());out=json.loads((N/'compiler-output.json').read_bytes())
assert result['exit_code']==0 and result['errors']==[] and result['gates_pass'] and result['source_unchanged']
assert len(result['gates'])==48 and len(inp['sources'])==len(out['sources'])==100
assert set(inp['sources'])==set(out['sources'])==set(start['source_sha256'])
assert all((R/n).read_bytes()==entry['content'].encode('utf-8') for n,entry in inp['sources'].items())
assert start['source_sha256']=={n:sha(R/n) for n in inp['sources']}
assert sha(Path(start['command'][0]))==start['compiler_sha256']
assert inp['settings']==start['settings'] and start['codegen_settings_unchanged']
original=json.loads((R/'reports/gas-feasibility-20261111/build/production-size-gates.json').read_bytes())
gates={**result,'all_pass':True,'settings':inp['settings'],
 'source_sha256':{n:h for n,h in start['source_sha256'].items() if n.startswith('src/')},
 'dependency_source_sha256':{n:h for n,h in start['source_sha256'].items() if not n.startswith('src/')},
 'compiler_content_sha256':{n:hashlib.sha256(row['content'].encode()).hexdigest() for n,row in inp['sources'].items()},
 'build_input_sha256':{n:sha(R/n) for n in original['build_input_sha256']},
 'compiler_input_sha256':sha(N/'compiler-input.json'),'compiler_output_sha256':sha(N/'compiler-output.json'),
 'solc_exit_code':0,'solc_executable_sha256':start['compiler_sha256'],
 'closed_input_inventory':True,'unchanged_before_build':True,'unchanged_during_build':True,'solc_executable_unchanged':True,
 'source_count':100,'compiled_source_count':100,'unexpected_implicit_sources':[],'missing_compiled_sources':[],
 'source_binding_scope':'Root mechanical recovery of exact successful frozen compile, not another compiler run or test. Original RESULT and START remain immutable.',
 'normal_limits':{'runtime_bytes':24576,'initcode_with_original_minimum_arguments_bytes':49152},
 'not_qualified':'Dynamic constructor exact values, actual public deployment, external dependencies/fees and maximum operating workloads remain separate.'}
path=N/'normal-size-evidence.json';assert not path.exists();path.write_text(json.dumps(gates,indent=2)+'\n',encoding='utf-8')
# Static runner consumes the same current compiler output, never recompiles.
static=N/'static-size-input.json';static.write_text(json.dumps(gates,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'all_pass':True,'source_count':100,'gates':48,'evidence':str(path),
 'margins':[{k:row[k] for k in ('name','runtime','runtime_margin','creation','minimum_args')} for row in gates['gates'] if row['name'] in ('ZZZOracle','ZZZVault','ZZZLiquidityManager','ZZZContributionPricing')]}))
