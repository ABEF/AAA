from pathlib import Path
import hashlib,json,subprocess
E=Path(__file__).parent;R=Path(r'C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
b=json.loads((E/'BASELINE.json').read_bytes())
for n,h in b['solidity_sources'].items():
    raw=subprocess.check_output(['git','show',b['baseline']+':'+n],cwd=R)
    assert hashlib.sha256(raw).hexdigest()==h
    p=E/'baseline-source'/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(raw)
print(json.dumps({'archived_exact_baseline_solidity':len(b['solidity_sources'])}))
