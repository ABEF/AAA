from pathlib import Path
import json,subprocess,sys,time
E=Path(__file__).resolve().parent;methods=json.loads((E/'NEW_METHODS.json').read_bytes());excluded={'testManualReferenceC14ETHToZZZ','testManualReferenceD14ETHToZZZ'};rows=[];start=time.monotonic()
for name in methods:
 if name in excluded:continue
 code=subprocess.run([sys.executable,'-I','-B','-X','utf8',str(E/'run_method.py'),'new',name],timeout=210).returncode
 result=json.loads((E/'exports'/('new-'+name)/'RESULT.json').read_bytes());rows.append({'name':name,'exit_code':code,'result':result})
(E/'NEW_STAGE2_AGGREGATE.json').write_text(json.dumps({'rows':rows,'seconds':time.monotonic()-start,'new_methods':len(rows),'old_methods':0},indent=2));raise SystemExit(any(row['exit_code'] for row in rows))
