from pathlib import Path
import gzip,hashlib,json
E=Path(__file__).parent;R=Path(r'C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2');N=E/'normal-4'
old=json.loads(gzip.decompress((R/'reports/gas-feasibility-20261111/build/compiler-output.json.gz').read_bytes()))
new=json.loads((N/'compiler-output.json').read_bytes())
def sha(raw):return hashlib.sha256(raw).hexdigest()
def code(obj,section):return bytes.fromhex(obj['evm'][section]['object'])
def body(raw):
    assert len(raw)>2
    length=int.from_bytes(raw[-2:],'big');assert length+2<len(raw)
    return raw[:-length-2]
rows=[]
for source,name in [('src/ZZZOracle.sol','ZZZOracle'),('src/ZZZVault.sol','ZZZVault'),('src/ZZZStrategy.sol','ZZZStrategy')]:
    a=old['contracts'][source][name];b=new['contracts'][source][name]
    ar=code(a,'deployedBytecode');br=code(b,'deployedBytecode');ac=code(a,'bytecode');bc=code(b,'bytecode')
    rows.append({'source':source,'name':name,'source_unchanged':(R/source).read_bytes()==(E/'baseline-source'/source).read_bytes(),
     'existing_abi_equal':a['abi']==b['abi'],'runtime_template_bytes_before':len(ar),'runtime_template_bytes_after':len(br),
     'runtime_executable_body_equal':body(ar)==body(br),'before_body_sha256':sha(body(ar)),'after_body_sha256':sha(body(br)),
     'creation_bytes_before':len(ac),'creation_bytes_after':len(bc),
     'note':'Compiler templates only; constructor immutables and deployed address/runtime admission remain separate. New child creation can change parent initcode even with identical runtime body.'})
record={'schema':1,'scope':'Offline exact accepted old/new compiler bytecode template comparison; no compiler/test execution.',
 'old_compiler_output_sha256':sha(gzip.decompress((R/'reports/gas-feasibility-20261111/build/compiler-output.json.gz').read_bytes())),
 'new_compiler_output_sha256':sha((N/'compiler-output.json').read_bytes()),'rows':rows}
(E/'NORMAL_EQUIVALENCE.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'rows':[{k:row[k] for k in ('name','runtime_executable_body_equal','runtime_template_bytes_before','runtime_template_bytes_after','creation_bytes_before','creation_bytes_after')} for row in rows]}))
