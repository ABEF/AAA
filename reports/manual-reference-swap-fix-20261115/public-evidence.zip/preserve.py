from pathlib import Path
import datetime,hashlib,json,sys,urllib.request
E=Path(__file__).parent;W=Path(r'C:/Users/Ali/Desktop/2.x holas/Oto/aaa-website')
stage=sys.argv[1];assert stage in ('before','after')
out=E/('PRESERVATION_'+stage.upper()+'.json');assert not out.exists()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
paths=['browser-wallet.js','deployment-config.js','integration-config.js']
web={n:sha(W/n) for n in paths}
dist={p.relative_to(W/'dist').as_posix():sha(p) for p in sorted((W/'dist').rglob('*')) if p.is_file()}
rpc={'endpoint':'http://127.0.0.1:57306','scope':'Bounded read-only historical8902 RPC snapshot; no admin/mining/signing/send call','methods':[]}
def call(method,params):
    assert method in ('eth_chainId','eth_getBlockByNumber','eth_getBalance','eth_getTransactionCount')
    rpc['methods'].append(method)
    body=json.dumps({'jsonrpc':'2.0','id':len(rpc['methods']),'method':method,'params':params}).encode()
    req=urllib.request.Request(rpc['endpoint'],body,{'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=2) as response:raw=response.read(1024*1024+1)
    if len(raw)>1024*1024:raise ValueError('bounded_response')
    data=json.loads(raw)
    if 'error' in data:raise ValueError('read_refused')
    return data['result']
def header(h):
    if not isinstance(h,dict):raise ValueError('missing_header')
    return {n:h.get(n) for n in ('number','hash','parentHash','stateRoot','timestamp','gasLimit')}
try:
    rpc['chain_id']=call('eth_chainId',[]);rpc['genesis']=header(call('eth_getBlockByNumber',['0x0',False]));rpc['latest']=header(call('eth_getBlockByNumber',['latest',False]))
    rpc['wallets']={}
    for a in ('0x70997970c51812dc3a010c7d01b50e0d17dc79c8','0x3c44cdddb6a900fa2b585dd299e03d12fa4293bc'):
        rpc['wallets'][a]={'balance':call('eth_getBalance',[a,'latest']),'nonce':call('eth_getTransactionCount',[a,'latest'])}
    rpc['available']=True
except Exception:
    rpc['available']=False;rpc['reason']='historical_loopback_read_unavailable';rpc.pop('wallets',None)
d={'date':'2026-11-15','observed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'website_sources':web,'dist':dist,'rpc':rpc,
 'browser_journals':'Not accessed or changed; no browser/computer-use tool used','heartbeat':'User-paused; not accessed/resumed'}
if stage=='after':
    b=json.loads((E/'PRESERVATION_BEFORE.json').read_bytes())
    d['comparison']={'website_source_bytes_unchanged':web==b['website_sources'],'dist_bytes_unchanged':dist==b['dist']}
    if rpc['available'] and b['rpc']['available']:
        d['comparison'].update(genesis_unchanged=rpc['genesis']==b['rpc']['genesis'],latest_state_root_unchanged=rpc['latest']['stateRoot']==b['rpc']['latest']['stateRoot'],wallets_unchanged=rpc['wallets']==b['rpc']['wallets'])
out.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'stage':stage,'dist_files_hashed':len(dist),'historical_rpc_available':rpc['available'],'read_calls':len(rpc['methods']),**d.get('comparison',{})}))
