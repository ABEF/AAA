from pathlib import Path
import json,hashlib,gzip,importlib.util,zipfile
R=Path(r'C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2');E=Path(__file__).resolve().parent;S=E/'public-derived-2';S.mkdir(exist_ok=False)
H=lambda raw:hashlib.sha256(raw).hexdigest();files={};derived={};rawfiles={}
def record(path):rawfiles[path.relative_to(E).as_posix()]={'bytes':path.stat().st_size,'sha256':H(path.read_bytes())}
for name in ('rpc','exports','normal-1','normal-2','normal-3','normal-4','host-syntax-1','focused-compile-1','focused-compile-2','focused-compile-3'):
 for path in (E/name).rglob('*'):
  if path.is_file():record(path)
(S/'RAW_CAPTURE_MANIFEST.json').write_text(json.dumps({'schema':1,'scope':'Original complete scoped captures retained under this external evidence root; public derived records are explicitly marked. No testout/cache duplication.','external_root':str(E),'files':rawfiles},indent=2));files['RAW_CAPTURE_MANIFEST.json']=S/'RAW_CAPTURE_MANIFEST.json'
for parent in sorted((E/'rpc').glob('*/*')):
 if not parent.is_dir():continue
 for path in parent.rglob('*'):
  if path.is_file() and path.name not in ('genesis.json','rpc-records.json.gz'):files[path.relative_to(E).as_posix()]=path
 path=parent/'rpc-records.json.gz'
 if path.exists():
  rows=json.loads(gzip.decompress(path.read_bytes()));first=[i for i,row in enumerate(rows) if row['method']=='eth_getTransactionReceipt' and (row['response'].get('result') or {}).get('status')=='0x1']
  selected=[(i,row) for i,row in enumerate(rows) if first and i>=min(first) and row['method'] in ('eth_call','eth_getBlockByHash','eth_getTransactionReceipt')]
  if selected:
   relative=(parent.relative_to(E)/'rpc-records.post-receipt.json.gz').as_posix();p=S/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(gzip.compress(json.dumps([row for _,row in selected],separators=(',',':')).encode(),mtime=0));files[relative]=p
   derived[relative]={'source':path.relative_to(E).as_posix(),'source_sha256':H(path.read_bytes()),'original_indices':[i for i,_ in selected],'rule':'Exact original post-first-confirmed-receipt records; no result rewritten.'}
for path in (E/'rpc').glob('*/*.json'):files[path.relative_to(E).as_posix()]=path
spec=importlib.util.spec_from_file_location('recovery',R/'scripts/rehearse-manual-recovery.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
artifact=E/'focused-fixed/out/ManualRecoveryQualification.t.sol/ManualRecoveryQualificationTest.json';cases={}
for folder in sorted((E/'exports').iterdir()):
 if not folder.is_dir():continue
 for name in ('START.json','RESULT.json','PID.json','forge.stderr'):
  if (folder/name).exists():files[(folder.relative_to(E)/name).as_posix()]=folder/name
 data=json.loads((folder/'forge.json').read_bytes());excerpt={suite:{'test_results':{name:{key:row.get(key) for key in ('status','reason','logs','kind','duration')} for name,row in group.get('test_results',{}).items()}} for suite,group in data.items()}
 relative=(folder.relative_to(E)/'producer-results-excerpt.json').as_posix();p=S/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps({'derived_excerpt':True,'original_forge_sha256':H((folder/'forge.json').read_bytes()),'results':excerpt},indent=2));files[relative]=p
 if folder.name.startswith('adapted-'):cases[folder.name]=m.parse_export(folder,artifact)
(S/'CAPTURE_CASES.json').write_text(json.dumps(cases,indent=2));files['CAPTURE_CASES.json']=S/'CAPTURE_CASES.json';(S/'DERIVED_RECORDS.json').write_text(json.dumps(derived,indent=2));files['DERIVED_RECORDS.json']=S/'DERIVED_RECORDS.json'
for directory in ('actual-provenance',):
 for path in (E/directory).rglob('*'):
  if path.is_file():files[path.relative_to(E).as_posix()]=path
for directory in ('normal-1','normal-2','normal-3','normal-4','host-syntax-1','focused-compile-1','focused-compile-2','focused-compile-3'):
 for name in ('START.json','RESULT.json','production-size-gates.json','stderr.txt','stderr.log'):
  if (E/directory/name).exists():files[directory+'/'+name]=E/directory/name
for path in E.glob('*.json'):
 if path.name not in ('PUBLIC_MANIFEST.json','PUBLIC_BUNDLE.json'):files[path.name]=path
for path in E.glob('*.py'):files[path.name]=path
for path in E.glob('*STAGE*.sol'):files[path.name]=path
for name in ('test/ManualReferenceSwapQualification.t.sol','test/ManualRecoveryQualification.t.sol','scripts/rehearse-manual-reference.py','scripts/rehearse-manual-recovery.py'):
 files['source/'+name]=R/name
files['focused-fixed/PREPARED.json']=E/'focused-fixed/PREPARED.json'
manifest={'schema':1,'scope':'Public subset: all four actual current core captures/full calltrees; exact original post-receipt wire slices and producer excerpts; normal/compiler and full unit traces retained externally by raw manifest. Derived files are not relabelled original raw captures.','baseline_commit':'da24f65','external_full_archive':{'kind':'hash_manifest_of_complete_original_files','manifest_file':'RAW_CAPTURE_MANIFEST.json','manifest_sha256':H((S/'RAW_CAPTURE_MANIFEST.json').read_bytes()),'external_root':str(E)},'files':{name:{'bytes':path.stat().st_size,'sha256':H(path.read_bytes())} for name,path in sorted(files.items())}}
raw=(json.dumps(manifest,indent=2,sort_keys=True)+'\n').encode();(E/'PUBLIC_MANIFEST.json').write_bytes(raw)
with zipfile.ZipFile(E/'public-evidence.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for name,path in sorted(files.items()):archive.write(path,name)
 archive.writestr('MANIFEST.json',raw)
p=E/'public-evidence.zip';summary={'bytes':p.stat().st_size,'sha256':H(p.read_bytes()),'files':len(files)+1,'uncompressed_bytes':sum(row['bytes'] for row in manifest['files'].values()),'raw_manifest_sha256':H((S/'RAW_CAPTURE_MANIFEST.json').read_bytes())};(E/'PUBLIC_BUNDLE.json').write_text(json.dumps(summary,indent=2));print(json.dumps(summary))
