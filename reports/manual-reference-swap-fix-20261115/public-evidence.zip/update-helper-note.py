from pathlib import Path
import json
R=Path(r'C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
p=R/'docs/function-reference-notes.json';raw=p.read_bytes();j=json.loads(raw);f=j['contracts']['ZZZContributionPricing']['functions']
assert f.pop('beginEmergencyExecution(uint256)') and f.pop('endEmergencyExecution(uint256)')
f['emergencyExecution(uint256,bool)']={
 'purpose':'Open a transaction-bound ETH/fixed-ZZZ manual price scope, or validate and clear it after Vault settlement/economic checks and the final emergency fingerprint. C retains later price-independent custody/policy checks.',
 'access':'Only the immutable Vault migrationBudget companion. Its fixed nonreentrant begin/end wrappers validate the active manual authority/lifecycle; this helper preserves bucket exclusivity and Oracle scope ownership.',
 'inputs':{'0':'Positive exact current manual bucket ID; closing must match the scope opened.','1':'True to capture before first fingerprint/harvest/unwind; false to validate and clear after the final fingerprint.'},'status':'internal'}
p.write_text(json.dumps(j,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\r\n' if b'\r\n' in raw else '\n')
p=R/'docs/operator-call-examples.json';raw=p.read_bytes();j=json.loads(raw);rows=j['rows']
assert rows.pop('ZZZContributionPricing.beginEmergencyExecution(uint256)') and rows.pop('ZZZContributionPricing.endEmergencyExecution(uint256)')
rows['ZZZContributionPricing.emergencyExecution(uint256,bool)']={'role':'M','short':'Manage priced manual scope','arguments':['$BUCKET_ID','$OPENING_SCOPE'],'value':None}
p.write_text(json.dumps(j,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\r\n' if b'\r\n' in raw else '\n')
print(json.dumps({'new_callable_helpers':4,'existing_examples_unchanged':1009}))
