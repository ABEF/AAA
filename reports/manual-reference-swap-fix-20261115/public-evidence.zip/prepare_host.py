"""Snapshot only the new host's import closure; reuse accepted object cache."""
from pathlib import Path,PurePosixPath
import hashlib,json,posixpath,re,shutil
R=Path(r'C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
E=Path(__file__).resolve().parent;V=E.parent;P=E/'current-host'
OLD=V/'manual-recovery-rehearsal-20261115-a5a0233/current-host'
NORMAL=R/'reports/gas-feasibility-20261111/normal'
sha=lambda b:hashlib.sha256(b).hexdigest()
remaps={'@openzeppelin/contracts/':'node_modules/@openzeppelin/contracts/',
    '@uniswap/v4-core/':'node_modules/@uniswap/v4-core/',
    '@uniswap/v4-periphery/':'node_modules/@uniswap/v4-periphery/',
    'v4-core/':'node_modules/@uniswap/v4-core/','permit2/':'node_modules/@uniswap/v4-periphery/lib/permit2/',
    'solmate/':'node_modules/@uniswap/v4-core/lib/solmate/','forge-std/':'lib/forge-std/src/'}
def resolve(source,imported):
    if imported.startswith('.'):return posixpath.normpath(str(PurePosixPath(source).parent/imported))
    for prefix,target in remaps.items():
        if imported.startswith(prefix):return target+imported[len(prefix):]
    return imported
names={};todo=['test/ManualReferenceSwapQualification.t.sol','test/ManualRecoveryQualification.t.sol']
while todo:
    name=todo.pop()
    if name in names:continue
    path=(R/name).resolve();assert path.is_relative_to(R) and path.is_file(),name
    raw=path.read_bytes();names[name]=sha(raw)
    for imported in re.findall(r'import\s+[\s\S]*?["\']([^"\']+)["\']\s*;',raw.decode('utf-8')):
        todo.append(resolve(name,imported))
P.mkdir(exist_ok=False)
for name,pin in names.items():
    target=P/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/name,target)
    assert sha(target.read_bytes())==pin
for name in ('out','cache'):
    if (OLD/name).is_dir():shutil.copytree(OLD/name,P/name)
(P/'empty').mkdir()
text='[profile.default]\nfs_permissions=[{access="read-write",path="'+str(E/'exports').replace('\\','/')+'"}]\n'
text+='src="empty"\ntest="test"\nout="out"\ncache_path="cache"\nevm_version="cancun"\noptimizer=true\noptimizer_runs=1\noptimizer_details={yul=false}\nvia_ir=true\nffi=false\nremappings=[\n'
text+=''.join(json.dumps(prefix+'='+target)+',\n' for prefix,target in remaps.items())+']\n'
(P/'foundry.toml').write_text(text,encoding='utf-8')
(E/'exports').mkdir(exist_ok=True)
production={path.relative_to(R).as_posix():sha(path.read_bytes()) for path in (R/'src').rglob('*.sol')}
assert len(production)==61
record={'root':str(P),'new_host':'test/ManualReferenceSwapQualification.t.sol','adapted_host':'test/ManualRecoveryQualification.t.sol','source_sha256':names,
    'production61_sha256':production,'closure_source_count':len(names),'old_test_methods_selected':0,
    'reused_cache_source':str(OLD),'normal_or_static_build':False,
    'compiler':str(V/'toolchain-0.8.26/solc.exe'),
    'settings':{'optimizer':{'enabled':True,'runs':1,'details':{'yul':False}},'viaIR':True,'evmVersion':'cancun'}}
(P/'PREPARED.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
print(json.dumps({'sources':len(names),'production_sources':len(production),'host_sha256':names['test/ManualRecoveryQualification.t.sol']}))
