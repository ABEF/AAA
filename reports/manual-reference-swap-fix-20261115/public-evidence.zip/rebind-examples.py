from pathlib import Path
import hashlib,json,sys
E=Path(__file__).parent;R=Path(r'C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2');sys.path.insert(0,str(R))
from zzz_ops.function_reference import canonical_json
old=json.loads((E/'originals/docs/function-reference.json').read_bytes());new=json.loads((R/'docs/function-reference.json').read_bytes())
old_abi=old['abi_snapshot'];new_abi=new['abi_snapshot'];assert set(old_abi)==set(new_abi)
added={}
def key(item):return item['type']+':'+item.get('name','')+':'+','.join(x['type'] for x in item.get('inputs',[]))
for c in old_abi:
    a={key(row):row for row in old_abi[c]['abi']};b={key(row):row for row in new_abi[c]['abi']}
    assert not set(a)-set(b)
    assert all(a[k]==b[k] for k in a),(c,'changed existing ABI')
    if set(b)-set(a):added[c]=[b[k] for k in sorted(set(b)-set(a))]
assert {c:len(rows) for c,rows in added.items()}=={'ZZZContributionPricing':1,'ZZZLPBalanceMath':2}
p=R/'docs/operator-call-examples.json';raw=p.read_bytes();j=json.loads(raw);baseline=json.loads((E/'originals/docs/operator-call-examples.json').read_bytes())
assert all(j['rows'][name]==row for name,row in baseline['rows'].items())
assert len(j['rows'])==len(baseline['rows'])+3==1012
before=j['reference_sha256'];j['reference_sha256']=hashlib.sha256(canonical_json(new).encode()).hexdigest()
p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n',encoding='utf-8',newline='\r\n' if b'\r\n' in raw else '\n')
proof={'schema':1,'existing_abis_byte_for_byte_equal':True,'new_abi_methods':added,'existing1009examples_unchanged':True,
 'new_example_count':3,'total_examples':1012,'reference_before':before,'reference_after':j['reference_sha256'],
 'source_snapshot_boundary':'Fresh source/runtime/normal compiler pins; old reviews/artifacts remain original bytes and are never rehashed.'}
(E/'FUNCTION_REFERENCE_REVIEW.json').write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'existing_ABIs_preserved':True,'new_methods':3,'new_examples':3,'total_examples':1012}))
