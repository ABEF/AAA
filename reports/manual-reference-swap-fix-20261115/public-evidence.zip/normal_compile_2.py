from pathlib import Path
import gzip,json,hashlib,subprocess,os,time
R=Path(r'C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2');E=Path(__file__).resolve().parent;V=E.parent;O=E/'normal-2';O.mkdir(exist_ok=False)
base=R/'reports/gas-feasibility-20261111/build';raw=gzip.decompress((base/'compiler-input.json.gz').read_bytes());j=json.loads(raw)
changed=[];pins={}
for name,source in j['sources'].items():
 current=(R/name).read_bytes();pins[name]=hashlib.sha256(current).hexdigest()
 if source['content']!=current.decode('utf-8'):changed.append(name);source['content']=current.decode('utf-8')
assert len(j['sources'])==100 and len(changed)==6,changed
payload=json.dumps(j,separators=(',',':'),ensure_ascii=True).encode();(O/'compiler-input.json').write_bytes(payload)
expected={'src/ZZZContributionPricing.sol','src/ZZZMigrationBudget.sol','src/ZZZCustodyValidation.sol','src/ZZZLiquidityManager.sol','src/ZZZLPBalanceMath.sol','src/ZZZLPBalancer.sol'}
assert set(changed)==expected,changed
names=('SystemRoot','WINDIR','SystemDrive','COMSPEC','PATHEXT','TEMP','TMP','USERPROFILE','LOCALAPPDATA','APPDATA','PROGRAMDATA')
env={name:os.environ[name] for name in names if name in os.environ};env['PATH']=str(V/'toolchain-0.8.26')+os.pathsep+str(Path(env.get('SystemRoot','C:/Windows'))/'System32')
command=[str(V/'toolchain-0.8.26/solc.exe'),'--standard-json'];record={'command':command,'compiler_sha256':hashlib.sha256(Path(command[0]).read_bytes()).hexdigest(),'baseline_compiler_input_sha256':hashlib.sha256(raw).hexdigest(),'input_sha256':hashlib.sha256(payload).hexdigest(),'sources':100,'production_sources':61,'changed_sources':changed,'source_sha256':pins,'codegen_settings_unchanged':True,'settings':j['settings'],'new_test_methods_executed':0}
(O/'START.json').write_text(json.dumps(record,indent=2));start=time.monotonic()
with (O/'compiler-input.json').open('rb') as stream,(O/'compiler-output.json').open('xb') as out,(O/'stderr.txt').open('xb') as err:
 proc=subprocess.Popen(command,stdin=stream,stdout=out,stderr=err,cwd=O,env=env,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0));(O/'PID.json').write_text(json.dumps({'owned_pid':proc.pid}))
 try:code=proc.wait(timeout=900)
 except subprocess.TimeoutExpired:proc.kill();proc.wait(timeout=10);raise
assert pins=={name:hashlib.sha256((R/name).read_bytes()).hexdigest() for name in pins},'Source changed during compile'
output=json.loads((O/'compiler-output.json').read_bytes());errors=[row for row in output.get('errors',[]) if row['severity']=='error'];gates=[]
if not errors:
 for gate in json.loads((base/'production-size-gates.json').read_bytes())['gates']:
  contract=output['contracts'][gate['path']][gate['name']];creation=len(contract['evm']['bytecode']['object'])//2;runtime=len(contract['evm']['deployedBytecode']['object'])//2
  gates.append({**gate,'creation':creation,'runtime':runtime,'runtime_margin':24576-runtime,'maximum_total_argument_bytes':49152-creation,'runtime_ok':runtime<=24576,'creation_ok':creation+gate['minimum_args']<=49152})
result={'exit_code':code,'elapsed_seconds':time.monotonic()-start,'errors':errors,'gates':gates,'gates_pass':len(gates)==48 and all(gate['runtime_ok'] and gate['creation_ok'] for gate in gates),'source_unchanged':True,'compiled_source_count':len(output.get('sources',{})),'settings_unchanged':True,'compiler_output_sha256':hashlib.sha256((O/'compiler-output.json').read_bytes()).hexdigest()}
(O/'RESULT.json').write_text(json.dumps(result,indent=2));(O/'production-size-gates.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k!='gates'}));raise SystemExit(0 if code==0 and not errors and result['gates_pass'] else 1)
