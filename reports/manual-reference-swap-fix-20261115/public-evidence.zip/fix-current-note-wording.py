from pathlib import Path
import hashlib,json,sys
E=Path(__file__).parent;R=Path(r'C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2');sys.path.insert(0,str(R))
p=R/'docs/function-reference-notes.json';raw=p.read_bytes();j=json.loads(raw)
mark=j['contracts']['ZZZContributionPricing']['functions']['markMaintenance(uint256)']
mark['access']='Only the fixed Vault migrationBudget companion. State-changing noncustodial scope capture, not a stateless or operator-callable read.'
mark['purpose']='Capture original normal-maintenance prices and actual both-leg/idle values. During priced manual recovery, reuse the earlier Budget-owned capture and preserve the explicitly retained mask.'
f=j['contracts']['ZZZLiquidityManager']['functions']
f['balance(bytes32,uint256,uint256,uint256,uint256)']['purpose']='Balance only this exact attributed ETH/ZZZ budget with at most one swap. Ordinary execution selects the reviewed catalogue; priced manual execution proves the exact caller-selected admitted venue/direction/amount before settlement.'
f['balance(bytes32,uint256,uint256,uint256,uint256)']['access']='Only the sealed fixed Vault; exact current module, short deadline and structural native admission. Operations-enabled remains mandatory for ordinary execution or retained emergency bit8. No arbitrary recipient.'
f['unlockCallback(bytes)']['notes']='Ordinary and priced manual execution use an exact actual-core output/post-state quote. Oracle proves the complete price/tick/fees/liquidity immediately after core.swap, before settlement callbacks, then validates later boundaries. Only the proven own transition may change a registered external reference. Explicit masks without2/4 retain their unpriced path and caller floors.'
p.write_text(json.dumps(j,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\r\n' if b'\r\n' in raw else '\n')
print(json.dumps({'related_note_functions_corrected':3,'abi_change':False}))
