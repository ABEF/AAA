from pathlib import Path
import json
E=Path(__file__).parent;R=Path(r'C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
p=R/'docs/function-reference-notes.json';raw=p.read_bytes();notes=json.loads(raw);contracts=notes['contracts']
new={
 'ZZZContributionPricing':{
  'beginEmergencyExecution(uint256)':{'purpose':'Capture one transaction-bound ETH/fixed-ZZZ price vector before priced manual fingerprints, harvest or unwind. Does not choose a route, floor, mask or caller.',
   'access':'Only the fixed Vault migrationBudget companion while its emergency context is active; refuses another pricing/maintenance scope.',
   'inputs':{'0':'Positive exact manual bucket ID; fixed Budget supplies its current emergency bucket.'},'status':'internal'},
  'endEmergencyExecution(uint256)':{'purpose':'Validate the full final own-swap/source proof and clear the matching manual price scope after final custody and economic checks.',
   'access':'Only the fixed Vault migrationBudget companion during its active emergency; exact matching active scope required.',
   'inputs':{'0':'Exact bucket used to begin this priced manual scope.'},'status':'internal'}},
 'ZZZLPBalanceMath':{
  'executionValidateExitPrice(bytes32)':{'purpose':'Check actual pool spot against the captured independent reference without reinstating the separate operations-enabled emergency bit.',
   'access':'Anyone; read-only helper. Manager separately enforces authority, structural admission and the retained safeguard mask.',
   'inputs':{'0':'Exact admitted native ETH/fixed-ZZZ PoolId selected by the reviewed manual request.'},
   'outputs':{'0':'Current Q64.96 spot after independent-reference band validation. This read alone does not authorize execution.'}},
  'executionMinimumOutputForExit(bytes32,bool,uint256)':{'purpose':'Compute captured gross-loss and after-known-fee additional-loss output floors without reinstating operations-enabled admission.',
   'access':'Anyone; read-only helper. Does not waive caller floors, Manager permissions or the separately retained emergency checks.',
   'inputs':{'0':'Exact admitted native ETH/fixed-ZZZ swap venue PoolId.','1':'True ETH to ZZZ; false ZZZ to ETH.','2':'Positive exact raw input amount, bounded by uint128; manual request has the stronger signed-int128 bound.'},
   'outputs':{'0':'Stronger raw output floor from captured input/output bounds, governed gross loss and actual directional fees plus additional-loss limit.'}}},
 'ZZZLPBalancer':{
  'quoteEmergencySwap(bytes32,bool,uint256)':{'purpose':'Produce the exact operator-selected native swap output and full post-core state without settlement; all quote state rolls back. It cannot select a different route or input.',
   'access':'Only the sealed controller-bound fixed Manager. Manager applies the explicit retained operations bit; structural native admission remains.',
   'inputs':{'0':'Exact admitted manual native ETH/fixed-ZZZ swap PoolId.','1':'True ETH to ZZZ; false reverse.','2':'Positive exact raw input, signed-int128 bounded.'},
   'outputs':{'0':'Expected actual-core raw output after directional fees and price impact.','1':'Exact MarketState(sqrtPriceX96,tick,protocolFee,lpFee,liquidity) for authentication before settlement.'},'status':'internal'}}}
for c,items in new.items():
    f=contracts[c]['functions']
    assert not set(f)&set(items)
    f.update(items)
contracts['ZZZContributionPricing']['functions']['endMaintenance(uint256)']['purpose']='Validate and clear ordinary maintenance pricing after Budget custody/portfolio/loss checks. During an explicit emergency, its separately owned scope remains until the final manual fingerprint and endEmergencyExecution.'
ending='\r\n' if b'\r\n' in raw else '\n';p.write_text(json.dumps(notes,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline=ending)
# Existing examples remain identical; add exactly the new fixed-helper templates.
p=R/'docs/operator-call-examples.json';raw=p.read_bytes();examples=json.loads(raw);rows=examples['rows']
added={
 'ZZZContributionPricing.beginEmergencyExecution(uint256)':{'role':'M','short':'Begin priced manual scope','arguments':['$BUCKET_ID'],'value':None},
 'ZZZContributionPricing.endEmergencyExecution(uint256)':{'role':'M','short':'Clear priced manual scope','arguments':['$BUCKET_ID'],'value':None},
 'ZZZLPBalanceMath.executionValidateExitPrice(bytes32)':{'role':'R','short':'Validate manual spot band','arguments':['$POOL_ID'],'value':None},
 'ZZZLPBalanceMath.executionMinimumOutputForExit(bytes32,bool,uint256)':{'role':'R','short':'Read guarded manual output','arguments':['$POOL_ID','$ZERO_FOR_ONE','$EXACT_INPUT'],'value':None},
 'ZZZLPBalancer.quoteEmergencySwap(bytes32,bool,uint256)':{'role':'M','short':'Quote exact manual swap','arguments':['$POOL_ID','$ZERO_FOR_ONE','$EXACT_INPUT'],'value':None}}
assert not set(rows)&set(added);rows.update(added)
ending='\r\n' if b'\r\n' in raw else '\n';p.write_text(json.dumps(examples,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline=ending)
(E/'NEW_FUNCTION_NOTES.json').write_text(json.dumps({'note_functions':new,'operator_templates':added,'reference_digest_update':'Pending exact new normal compiler ABI/source generation; do not bypass its mechanical check.'},indent=2)+'\n',encoding='utf-8')
print(json.dumps({'new_helper_notes':sum(len(x) for x in new.values()),'new_examples':len(added),'ordinary_examples_preserved':1009}))
