from pathlib import Path
import gzip,hashlib,json,shutil
E=Path(__file__).parent;R=Path(r'C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2');N=E/'normal-4';P=R/'reports/manual-reference-swap-fix-20261115';B=P/'build';B.mkdir(parents=True,exist_ok=True)
def sha(raw):return hashlib.sha256(raw).hexdigest()
def save(p,d):p.write_text(json.dumps(d,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
inp=json.loads((N/'compiler-input.json').read_bytes());gates=json.loads((N/'normal-size-evidence.json').read_bytes());assert gates['all_pass']
for name in ('compiler-input.json','compiler-output.json'):
    raw=(N/name).read_bytes();(B/(name+'.gz')).write_bytes(gzip.compress(raw,mtime=0));assert gzip.decompress((B/(name+'.gz')).read_bytes())==raw
shutil.copyfile(N/'normal-size-evidence.json',B/'production-size-gates.json')
shutil.copyfile(N/'START.json',B/'START.json');shutil.copyfile(N/'RESULT.json',B/'RESULT.json');shutil.copyfile(E/'NORMAL_EQUIVALENCE.json',B/'EQUIVALENCE.json')
save(B/'source-manifest.json',{'schema':1,'baseline':'da24f65e6e10e5e0185cb0a0b229944f803b58b2','source_count':100,'production_sources':61,
 'exact_source_sha256':{name:sha((R/name).read_bytes()) for name in inp['sources']},
 'all_raw_equals_compiler_content':all((R/name).read_bytes()==row['content'].encode() for name,row in inp['sources'].items()),
 'settings':inp['settings'],'no_setting_limit_or_default_changed':True})
attempts=[]
for i in range(1,5):
    folder=E/('normal-'+str(i));start=json.loads((folder/'START.json').read_bytes());result=json.loads((folder/'RESULT.json').read_bytes())
    failed=[{k:row[k] for k in ('name','runtime','creation','minimum_args','runtime_ok','creation_ok')} for row in result['gates'] if not row['runtime_ok'] or not row['creation_ok']]
    attempts.append({'attempt':i,'accepted':i==4,'compiler_exit_code':result['exit_code'],'errors':result['errors'],
       'elapsed_seconds':result['elapsed_seconds'],'all48_gates_pass':result['gates_pass'],'failed_gates':failed,
       'source_changed_between_attempts':i>1,'source_bracket_unchanged':result['source_unchanged'],
       'compiler_input_sha256':sha((folder/'compiler-input.json').read_bytes()),'compiler_output_sha256':sha((folder/'compiler-output.json').read_bytes()),
       'start_sha256':sha((folder/'START.json').read_bytes()),'result_sha256':sha((folder/'RESULT.json').read_bytes()),
       'source_sha256':start['source_sha256'],'external_original_directory':str(folder)})
    if i<4:
        dest=B/'failed-attempts'/str(i);dest.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(folder/'START.json',dest/'START.json');shutil.copyfile(folder/'RESULT.json',dest/'RESULT.json')
save(B/'ATTEMPTS.json',{'scope':'Real changed-source normal compiler/size attempts, not EVM tests; failed stages retained, no gate relaxed.','attempts':attempts})
shutil.copyfile(E/'FUNCTION_REFERENCE_REVIEW.json',P/'FUNCTION_REFERENCE_REVIEW.json')
shutil.copyfile(E/'PLAN.md',P/'PLAN.md')
save(B/'ARTIFACTS.json',{'schema':1,'scope':'Exact build evidence raw bytes; this manifest excludes itself','sha256':{p.relative_to(B).as_posix():sha(p.read_bytes()) for p in sorted(B.rglob('*')) if p.is_file() and p.name!='ARTIFACTS.json'}})
print(json.dumps({'normal_stages':4,'accepted_stage':4,'unchanged_codegen_settings':True,'gates':48,'public_build_files':len(list(B.rglob('*')))}))
