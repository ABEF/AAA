from pathlib import Path
import json
R=Path(r'C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
p=R/'docs/function-reference-notes.json';raw=p.read_bytes();j=json.loads(raw)
f=j['contracts']['ZZZLPBalancer']['functions'];assert f.pop('quoteEmergencySwap(bytes32,bool,uint256)')
f['quoteSwap(bytes32,bool,uint256)']['purpose']='Produce the exact requested full-input actual-core output and expected MarketState without settlement; every quote state change reverts. Structural admission remains; quote-only reads do not require operations-enabled. The actual Manager separately enforces ordinary or retained emergency operations controls.'
j['contracts']['ZZZContributionPricing']['functions']['endMaintenance(uint256)']['purpose']='Validate and clear ordinary maintenance pricing after Budget custody/portfolio/loss checks. During explicit emergency, the separately owned scope stays until the final manual fingerprint and emergencyExecution closing call.'
p.write_text(json.dumps(j,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\r\n' if b'\r\n' in raw else '\n')
p=R/'docs/operator-call-examples.json';raw=p.read_bytes();j=json.loads(raw);assert j['rows'].pop('ZZZLPBalancer.quoteEmergencySwap(bytes32,bool,uint256)')
p.write_text(json.dumps(j,indent=2,ensure_ascii=False)+'\n',encoding='utf-8',newline='\r\n' if b'\r\n' in raw else '\n')
print(json.dumps({'new_callable_helpers':3,'examples_total':len(j['rows'])}))
