from pathlib import Path
import difflib,hashlib,json,re,shutil
E=Path(__file__).parent;R=Path(r'C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2');P=R/'reports/manual-reference-swap-fix-20261115';REPORT='reports/manual-reference-swap-fix-20261115/REVIEW.md'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
accepted=[];gas=[]
for p in sorted((E/'rpc').glob('*/REFERENCE_ACCEPTANCE.json')):
    acceptance=json.loads(p.read_bytes());assert acceptance['reference_swap_accepted']
    for name,h in acceptance['source_sha256'].items():assert sha(R/'src'/(name+'.sol'))==h
    case=next(d for d in p.parent.iterdir() if d.is_dir() and (d/'manual/review.json').exists());q=case/'manual'
    review=json.loads((q/'review.json').read_bytes());tx=json.loads((q/'transaction.json').read_bytes());receipt=json.loads((q/'receipt.json').read_bytes())
    final=review['simulation']['final'];estimate=int(final['estimated_gas']);pad=(estimate*125+99)//100
    assert int(final.get('padded_gas',final.get('transaction_gas')))==pad==int(tx['gas'],16)<=24_000_000
    assert tx['input']==review['transaction']['data'] and tx['to']==review['transaction']['to'] and int(tx['value'],16)==0
    assert int(receipt['status'],16)==1 and receipt['transactionHash']==tx['hash'] and int(receipt['gasUsed'],16)<=pad
    assert review['arguments']['checks']=='14' and int(review['arguments']['minimumOut'])>0 and int(review['arguments']['minimumLiquidity'])>0
    assert json.loads((case/'cleanup.json').read_bytes())['owned_node_stopped']
    row={'case':case.name,'action':review['action'],'source_acceptance':p.relative_to(E).as_posix(),'transaction_hash':receipt['transactionHash'],
       'estimate':estimate,'exact25percent_padded':pad,'receipt_gas':int(receipt['gasUsed'],16),'headroom_to24M':24_000_000-pad,
       'review_sha256':sha(q/'review.json'),'transaction_sha256':sha(q/'transaction.json'),'receipt_sha256':sha(q/'receipt.json')}
    gas.append(row);accepted.append(case.name)
assert sorted(accepted)==['active-c14','active-d14','parked-d14'],accepted
new={};changed={};failed=[]
for p in sorted((E/'exports').glob('*/RESULT.json')):
    d=json.loads(p.read_bytes());assert d['source_unchanged']
    for row in d['selected_methods']:
        name=row['name'].removesuffix('()')
        if row['status']=='Success':
            if name.startswith('testManualReference'):new.setdefault(name,[]).append(p.relative_to(E).as_posix())
            elif name.startswith('testActual'):
                assert name!='testActualParkedD0ExplicitOracleOutage';changed.setdefault(name,[]).append(p.relative_to(E).as_posix())
        else:failed.append({'method':name,'path':p.relative_to(E).as_posix(),'reason':row.get('reason')})
assert len(new)==25 and len(changed)==3,(len(new),len(changed))
assert all(len(v)==1 for v in new.values()) and all(len(v)==1 for v in changed.values()),'Successful methods repeated unexpectedly'
shutil.copyfile(E/'CALLBACK_TRACE_REVIEW.json',P/'CALLBACK_TRACE_REVIEW.json')
(P/'GAS_AND_TRANSACTIONS.json').write_text(json.dumps(gas,indent=2)+'\n',encoding='utf-8')
(P/'UNIT_METHODS.json').write_text(json.dumps({'schema':1,'new_unique_successes':new,'changed_unique_successes':changed,'failed_new_fixture_attempts':failed,
 'unchanged_methods_rerun':0,'scope':'Source/branch stages remain in original START/RESULT/forge captures; successful methods are not rerun after unrelated fixture-only branch fixes.'},indent=2)+'\n',encoding='utf-8')
worst=max(row['exact25percent_padded'] for row in gas);changed_files=[]
def edit(name,fn):
    p=R/name;raw=p.read_bytes();bom=raw.startswith(b'\xef\xbb\xbf');body=raw[3:] if bom else raw;lines=body.decode().splitlines(keepends=True)
    norm=''.join(line.rstrip('\r\n')+'\n' for line in lines);updated=fn(norm)
    if updated==norm:return
    ending='\r\n' if body.count(b'\r\n')>body.count(b'\n')/2 else '\n';out=[]
    for tag,a,b,c,d in difflib.SequenceMatcher(a=norm.splitlines(keepends=True),b=updated.splitlines(keepends=True),autojunk=False).get_opcodes():
        out.extend(lines[a:b] if tag=='equal' else [x.rstrip('\r\n')+ending for x in updated.splitlines(keepends=True)[c:d]])
    p.write_bytes((b'\xef\xbb\xbf' if bom else b'')+''.join(out).encode());changed_files.append(name)
def prepend(name,text):edit(name,lambda t:t[:t.index('\n\n')+2]+text+'\n\n'+t[t.index('\n\n')+2:])
summary='''The [guarded manual reference-swap fix](%s) extends execution1/LP3 to priced
paused manual C/D. One transaction-bound vector precedes fingerprints/harvest;
the exact caller-selected core swap/output/full post-state is proved before
settlement, with live source/control/callback validation retained. No cap,
permission, default or automatic bypass changes. Masks0/8 remain unpriced;
bits1/16 retain their own eligibility checks. Six Solidity sources change;
same-core principal-as-reference remains excluded.25 new/3 adapted methods,
three actual unchanged-CLI local manual receipts and the complete park→recovery
journey pass. Worst full25%% padded manual gas%s/24M.48 normal size gates pass;
Manager101/Vault32/Oracle3runtime bytes and Oracle79init bytes remain. Current
strict review565=113 individually current+452 exact referenced-source reuse.
Old artifacts/runtimes/profile labels remain historical; new exact pins and
fresh reviews are required. No deployment/service/site/signing/journal or
existing-chain change; heartbeat stays paused. Real markets/complete target
fees, maximum state, host/contract-wallet operation and independent audit remain.
'''
for name,rel in [('AGENTS.md',''),('PROJECT_CONTEXT.md',''),('docs/WORK_HANDOFF.md','../')]:
    def memory(t,rel=rel):
        start=t.index('The [isolated manual recovery rehearsal]');end=t.index('Manual LP preparation now has',start)
        t=t[:start]+(summary%(rel+REPORT,f'{worst:,}'))+'\n'+t[end:]
        t=t.replace('Emergency retained-price\nfingerprints remain stricter; see the new manual rehearsal limitation above.',
          'Priced manual fingerprints now use the same authenticated own-transition\nproof with fresh exact runtimes; the earlier rejected source stays historical.')
        t=t.replace('Emergency retained-price\nfingerprints remain stricter; see the new manual rehearsal limitation above.',
          'Priced manual paths now share the authenticated transition proof described\nabove, without bypassing live source or financial checks.')
        if name=='AGENTS.md':
            old='- CI/check-slither-review selects the [current strict review](reports/gas-feasibility-20261111/static-review.json):567records,\n 13individually reassessed Oracle contexts/554unique exact referenced-source reuse.'
            new='- CI/check-slither-review selects the [current strict review](reports/manual-reference-swap-fix-20261115/static-review.json):565records,\n 113individually reassessed current contexts/452unique exact referenced-source reuse.\n The earlier gas-feasibility567(13/554) remains historical at its exact source.'
            assert old in t;t=t.replace(old,new)
        return t
    edit(name,memory)
edit('README.md',lambda t:t.replace('''[Actual local recovery and manual gas checks](reports/manual-recovery-rehearsal-20261115/REVIEW.md) now cover C/D,
including a complete park→recovery journey, without changing production contracts
or safeguards. Worst padded manual call:13,010,802/24M. Target-chain fees, real
markets and operating approval remain open.''','''[Guarded manual reference swaps](%s) now authenticate their exact own-swap
transition instead of rejecting a valid reference-venue trade. Financial,
authority and live-source protections remain. New local C/D/Parked receipts fit
24M with full25%% padding; production qualification and deployment remain separate.'''%REPORT))
prepend('docs/IMPLEMENTATION_STATUS.md','''The [current manual reference fix](../%s) is locally verified:
25 new/3 adapted methods, exact same-reference C/D/Parked local receipts,48 normal
gates and source-bound static coverage. Existing ABIs stay; three fixed helper
methods are added (959 callable functions/1012 complete operator examples).
Exact new runtime/source pins and reviews are mandatory; no installed consumer,
public signer or contract changes automatically.'''%REPORT)
edit('docs/README.md',lambda t:t.replace('This closes controlled local\ncomposition only; emergency reference-as-venue coupling remains open.',
 'That earlier record closes its controlled local\ncomposition only. The [current guarded manual fix](../'+REPORT+') now\naccepts a proven own swap through an external reference, retaining all selected\nfinancial/live checks. New pins and current-source gas evidence remain required.'))
edit('docs/ROADMAP.md',lambda t:t.replace('operator/host envelopes. Resolve retained emergency reference-as-venue coupling\nwithout automatic mask fallback.',
 'operator/host envelopes. The [current source fix](../'+REPORT+') resolves\nretained emergency reference-as-venue self-rejection with exact own-transition\nproof; no mask fallback. Its new source/gas scope stays separate from old receipts.'))
edit('docs/RELEASE_CHECKLIST.md',lambda t:t.replace('adopted. Retained emergency reference-as-venue coupling is unresolved.',
 'adopted. The [current source fix](../'+REPORT+') resolves the specific\nmanual own-reference rejection; its bounded local acceptance does not qualify\nreal market depth, target fees or production operation.'))
prepend('docs/AUDIT_FINDINGS.md','''The [manual reference-swap source fix](../%s) resolves the reproduced
emergency-only self-rejection: captured starting prices and exact own-swap proof
replace comparison against a changing live fingerprint. Live freshness/agreement,
original caller/economic floors and callbacks remain checked.25 new/3 adapted
methods and actual local C/D/Parked receipts pass; no weaker guard/default or
automatic fallback. Prior rejection and gas evidence keep their original scope.'''%REPORT)
edit('docs/AUDIT_FINDINGS.md',lambda t:re.sub(r'The strict pointer selects the \[reference-execution record\]\([^\n]+',
 'The strict pointer now selects the [manual-reference review](../reports/manual-reference-swap-fix-20261115/static-review.json):565 records,113 individually current/452 unique exact referenced-source reuses. Earlier567/541/560/558 records remain historical at their original source; no installed environment is upgraded.',t,count=1))
prepend('docs/ROBINHOOD_GAS.md','''[Current manual reference-venue measurements](../%s) use the fixed
source and actual local CLI/receipts. Worst exact25%% padded manual gas%s/24M;
this supersedes the earlier non-reference manual row only for these controlled
new-source cases. Keep12M defaults, full padding and fee/caller limits. These
Anvil31337 execution measurements do not quote complete Robinhood4663 fees or
approve provider, maximum workload, configuration adoption or deployment.'''%(REPORT,f'{worst:,}'))
prepend('reports/README.md','''[Guarded manual reference-swap fix](manual-reference-swap-fix-20261115/REVIEW.md)
records six-file code changes,25 new/3 adapted methods, actual same-reference C/D/
Parked local receipts,48 normal gates and565 source-bound static dispositions.
Historical rejection/failed size/fixture stages remain preserved. No unchanged
suite repeats, live rollout or independent production approval.''')
ledger=json.loads((R/'docs/project-todo.json').read_bytes());tasks={t['id']:t for a in ledger['areas'] for t in a['tasks']}
entry=next(i for i,x in enumerate(tasks['lp-execution-routing']['acceptance']) if x.startswith('[Actual manual limitation]'))
tasks['lp-execution-routing']['acceptance'][entry]='[Historical manual limitation](reports/manual-recovery-rehearsal-20261115/REVIEW.md) reproduced live-fingerprint self-rejection. The [current fix]('+REPORT+') captures the original vector before manual work and authenticates exactly the selected core output/full state before settlement.25 new/3 adapted methods and actual same-reference C/D/Parked receipts pass without weakening selected guards. Source/ABI/runtime pins must be renewed explicitly; real markets/fees/maximum-state/host approval remain open.'
tasks['operation-review']['acceptance'].append('[Guarded reference-swap fix]('+REPORT+') closes the reproduced manual-only self-coupling through captured prices and exact own-transition proof. Current three same-reference CLI transactions fit24M with full25%; all selected limits and request fields remain. Old da24 gas and Catalog provenance stay historical. Complete target fees/provider/market/maximum-state and actual contract-wallet/host qualification remain open.')
area=next(a for a in ledger['areas'] if any(t['id']=='lp-execution-routing' for t in a['tasks']));index=next(i for i,t in enumerate(area['tasks']) if t['id']=='lp-execution-routing')+1
area['tasks'].insert(index,{'id':'manual-reference-swap-proof','status':'done','title':'Preserve safeguards for manual swaps through a price reference',
 'text':'Priced manual C/D now use a whole-operation captured vector and exact caller-selected actual-core swap/output/full-state proof. Live source/control/callback validation remains. Original inputs/masks/floors, governance-only permission, unpriced recovery choices and defaults stay. Fresh exact pins/reviews required; no automatic deployment or adoption.',
 'href':'docs/REFERENCE_SWAP_EXECUTION.md','acceptance':[
 '[Source and verification]('+REPORT+'):25 distinct new methods plus3 deliberately adapted legacy expectations, with explicit source/branch reuse and original fixture failures. Unchanged suites/oldD0/public RPC work are not rerun. All nine actual late mutation callbacks complete successfully before later production rejection; rollback is checked.',
 'Actual unchanged-CLI C14/ActiveD14/ParkedD14 same-reference receipts preserve exact original input/minOut/minL/expiry and match actual-core quote/fullstate. Complete park→recovery stays on one new owned chain. Full25% padded maximum'+f'{worst:,}'+'/24M;32M local blocks. No default/financial guard/permission relaxed, no extra route or automatic14→0 fallback.',
 'All48 normal runtime/initcode gates pass at original settings; failed changed-source attempts1–3 retained. FinalManager101/Vault32/Oracle3 runtime headroom and Oracle79 initcode-argument headroom remain tight. Source-exact static565=113 individually current+452 unique exact referenced-source reuse, not independent audit.',
 'Existing signatures/storage/codec/capability versions remain; three fixed helper methods extend ABI without new module/custody/authority. New source/code/consumer pins are mandatory; original artifacts/journals/runtimes stay historical. Same-core principal-as-reference remains prohibited and financial/source disagreement can still legitimately reject. Real markets, fees, maximum state, hosts and independent approval remain open.']})
ledger['reviewed']='2026-11-15';edit('docs/project-todo.json',lambda t:json.dumps(ledger,indent=2,ensure_ascii=False)+'\n')
(E/'ROOT_DOCUMENT_PATHS.json').write_text(json.dumps(changed_files,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'updated_files':changed_files,'new_methods':25,'adapted_methods':3,'worst_padded':worst,'open_tasks':sum(t['status'] in ('todo','progress') for a in ledger['areas'] for t in a['tasks'])}))
