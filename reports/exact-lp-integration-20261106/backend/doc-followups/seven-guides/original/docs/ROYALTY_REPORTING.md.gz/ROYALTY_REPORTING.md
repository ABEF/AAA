# Original-currency royalty balances and history

Fresh reporting5 authenticates ROYALTY_SETTLEMENT_VERSION4, the exact runtime
and canonicalV8. Use `"royalty_reporting":{"schema":5,"converter":null}`.
Royalties stay in original units: no converter, unwrap, route, feed or keeper
is required for a raw claim. LP conversion remains independent.

| Reporting | Royalty capability | Scope |
| --- | --- | --- |
|5|4|Current GCD-normalized whole-unit allocation and one-hour opening. |
|4|3|Historical opening window with scaled royalty fractions. |
|3|2|Historical original-currency allocation without the opening window. |
|1/2|Earlier|Their separately pinned conversion/custody semantics only. |

Never relabel old runtimes, histories, transaction journals or checkpoints.

## Balances and opening state

Read separate addresses, raw amounts, decimals and symbols. WETH is not ETH;
never add incompatible raw currencies. Missing reads/metadata stay unavailable,
not zero. Missing USD prices do not prevent supported original-unit claims.

Opening status contains configured, mint_end, claims_open_at, claims_open,
activation_window_seconds3600 and status. Both backend and website check the
deadline/flag against the SAME confirmed snapshot timestamp. An inconsistent
flag or a positive locked royalty claim is rejected. Dormant cards show no
deadline. LP-only balances and claims remain independent of the royalty lock.

Use effectiveEligibleCount for the cutoff/outage cohort. Fresh NFT views read
ticketStart and allocationCursor, not removed royalty index/SCALE/fraction
getters. Source ticketStart is ONE-based(first1,dormant0); internal replay/checkpoint
`ticket_offsets` are ZERO-based. Convert only at the explicit source boundary.
The currency cursor is zero-based raw weight, not an NFT ticket start. Old readers
retain their explicit getter sets.

## Exact earned and paid history

For settlement4, RoyaltiesAllocated is the sole income-credit event. Reconstruct
the captured activation prefix, its GCD-normalized weights, original ticket
mapping and raw cursor. The receipt, InitialRoyaltiesAllocated and recovery
events also record provenance/lifecycle, but never credit that income again.
Claims, transfers and canonical import are not new income. Claims alone record
actual paid amounts. Current ownership carries all unpaid rights.

Replay independently checks q/remainder rotation and raw cursor divisibility;
pending initial/ordinary receipts are projected under the actual captured
cohort. GCD normalization preserves ideal whole-unit shares when all are integral;
nonintegral mixed cohorts use deterministic rotation, not nearest rounding per NFT.
See [the exact rule](EXACT_ROYALTY_ALLOCATION.md).

Checkpoint state preserves original activation order, ticket starts, currency
cursors, opening/cutoff state and whole royalty units. Historical/LP scaled
fractions remain separate. Compare raw replay against checkpoint plus suffix.
Semantic source changes require reviewed rebuild/re-pin. The full rolling24-hour
earnings period stays86,400seconds; it is not the one-hour opening window.

## Lineage, capacity and unsigned claims

Each predecessor declares its OWN royalty_reporting schema and runtime pins;
no omitted/inherited field may turn V8 into an older V6 reader. Matching new
peers carry reporting5. Historical peers keep their own declared profiles.
Existing lineage/workload release limitations remain; a profile declaration is
not operating qualification.

Inventory13 permits65royalty currencies includingETH and97combined descriptors.
Operating ERC20 capacity starts16 and can increase to64 only after review. Work,
RPC/history/checkpoint budgets are not raised automatically. A new admission
requires reviewed client descriptors and a separately authorized configuration
rollout; raw claims need no USD feed.

The router still permits32selected NFT/currency/ledger entries. Simulate exact
claims and use smaller healthy batches if gas or a currency failure prevents
one batch. Failed selected payouts revert atomically; LP-only claims remain a
separate choice. Source helpers understand reporting5, but complete fresh native6
site integration/qualification remains open; public signing stays disabled.

See [settlement/operator steps](ROYALTY_SETTLEMENT.md), [claim router](CLAIM_ROUTER.md),
[window](ROYALTY_LAUNCH_WINDOW.md) and [current audit](../reports/last24h-audit-20261105/REVIEW.md).
No existing service/site/deployment is updated by source publication.
