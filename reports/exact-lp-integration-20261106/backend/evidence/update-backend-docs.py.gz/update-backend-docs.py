from pathlib import Path

import json

ROOT=Path(r"C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2")

def edit(name,changes):

 p=ROOT/'docs'/name;raw=p.read_bytes();s=raw.decode().replace('\r\n','\n')

 for old,new in changes:

  assert old in s,(name,old[:100]);s=s.replace(old,new)

 out=s.replace('\n','\r\n').encode() if b'\r\n' in raw else s.encode();p.write_bytes(out)

edit('FRONTEND_API.md',[

('Fresh source uses accounting6,','Fresh source uses accounting7/exact LP1,'),

('Fresh configuration uses explicit `accounting_version:6`, `custody_version:5` and `fee_intake_version:1`\nwith read schema2. It verifies Vault6, direct governance2, custody5 and the\nexplicit `ZZZ_CANONICAL_SAME_CHAIN_EXACT_ROYALTIES_V8` admission domain.', 'Fresh configuration uses explicit `accounting_version:7`, `custody_version:5`,\n`protocol_policy_version:1`, `fee_intake_version:1` and royalty_reporting schema5\nwith read schema2. It verifies Vault7, Rewards LP-allocation1, direct governance2,\ncustody5 and `ZZZ_CANONICAL_SAME_CHAIN_EXACT_LP_V9`.'),

('Profile6 requires these additional','Profile7 requires these additional'),

('| Principal and strategy | `pools`, `liquidity`, `strategy`, `budget` |','| Principal and strategy | `pools`, `liquidity`, `strategy`, `budget` |\n| Exact LP canonical companion | `rewards_canonical`; authenticate Rewards.canonicalModule(), child access()/rewards() and Handoff.moduleAt(3) |'),

('Capabilities are accounting6/','Capabilities are accounting7/LP-allocation1/'),

('Fresh6 independently','Fresh7 independently'),('Accounting6 uses an explicit physical-only','Accounting7 uses an explicit physical-only'),

('Accounting1-5 readers remain explicit historical profiles. Omitting the version\nselects legacy1, never6. Their codecs, addresses, runtimes, timing and journals\nare not rewritten. API6 predecessor history requires explicit accounting6 and canonicalV8\nthroughout;', 'Accounting1-6 readers remain explicit historical profiles. Omitting the version\nselects legacy1, never7. Their codecs, addresses, runtimes, timing and journals\nare not rewritten. API7 predecessor history requires explicit accounting7 and canonicalV9\nthroughout; accounting6/V8 remains a separate historical profile;'),

('Read accounting6 semantics and the existing schema2 envelope are unchanged.','The schema2 envelope and direct Entry3 tuple remain; accounting7 explicitly\nchanges LP allocation/getter semantics. Old index getters are not queried on7.'),

('Production inventory schema15/reinvest1','Production inventory schema16/exact LP1/reinvest1'),('17 modules/18 callable helpers','17 modules/19 callable helpers'),

('Historical schema13/12/10/9/8/7/6','Historical schema15/14/13/12/10/9/8/7/6'),

('The existing earnings schema1 may explicitly include checkpoint1 through','Historical explicit accounting6 earnings schema1 may include checkpoint1 through'),

('not an HTTP-supplied file or automatically trusted cached total. Fresh accounting6/','not an HTTP-supplied file or automatically trusted cached total. Accounting6/'),

('Other history/preparation consumers are not silently switched to checkpoints.','Accounting7 rejects checkpoint1 before restoring state and uses complete bounded\nraw history. Exact-LP checkpoint2 remains open. Other history/preparation\nconsumers are not silently switched to checkpoints.'),

('The required base shape is below; bracketed values are **unusable placeholders**, not\nan approved deployment configuration.', 'The following block is the explicit historical accounting4 base shape only;\nfresh7 additionally needs the complete role graph above, explicit custody5,\nProtocolPolicy1 and original-currency royalty schema5. Bracketed values are\n**unusable placeholders**, not an approved deployment configuration.'),

('and Portfolio2 with the complete execution/dependency graph above.','and Portfolio2 with its execution/dependency graph. Fresh7 adds LP-allocation1,\nV9 and the fixed Rewards canonical companion; it never aliases the old6 reader.'),

('## Accounting6 policy observation','## Accounting7 policy and exact LP observation'),

('Inventory is schema15/reinvest1; public signing remains disabled. [Exact profile](POSITION_V6.md).','Inventory is schema16/LP-allocation1/reinvest1; public signing remains disabled.\n[Exact profile](POSITION_V7.md). Earned LP uses actual weight-sync/fee events and\nexact whole-unit trees; `claimableComponents`, `allocationTree`, funded liabilities\nand direct credits reconcile at each pinned epoch. Claims/conversions/imports\nare not new income. Source consumer9 does not update the served websites.')])

edit('FRONTEND_HISTORY.md',[

('Fresh reads explicitly use accounting6/ProtocolPolicy1/fee-intake1 and same-chain\ncanonical adaptable-policyV6. Accounting5/4 withV5 and accounting3/V4 remain\nexplicit historical profiles.','Fresh reads explicitly use accounting7/LP-allocation1/ProtocolPolicy1/fee-intake1\nand same-chain canonicalV9. Accounting6/V8 and earlier admitted variants,\naccounting5/4 withV5 and accounting3/V4 remain explicit historical profiles.'),

('truncating lifetime history. Current bounds are at most 33 LP currencies (native\nETH plus 32 ERC20s), 17 royalty currencies and 1,000 NFTs. Historical accounting\n1 supports 32 ERC20 LP assets.', 'truncating lifetime history. Fresh7 fixes LP currencies to native ETH and its\none ZZZ; royalty4 supports at most65 admitted currencies, with1,000 NFTs. Older\nprofiles retain their own33/32 LP and17/65 royalty bounds. Royalty admission\ndoes not make a currency a contribution or LP asset.'),

('checkpoint design may be needed as history grows.', 'checkpoint design is still needed for fresh7 as history grows. Checkpoint1 is\nexplicit6-only; accounting7 rejects it rather than fabricating an exact-tree seed.')])

edit('EARNINGS_CHECKPOINTS.md',[

('still uses full replay. Fresh source supports explicit accounting6/custody5/\nfee-intake1 only, without predecessor lineage. Public deployments remain blocked.','still uses full replay. Checkpoint1 supports explicit historical accounting6/\ncustody5/fee-intake1 only, without predecessor lineage. Public deployments remain blocked.\n\nAccounting7/LP-allocation1 uses complete bounded raw replay and explicitly rejects\ncheckpoint1 before restoring any seed. Exact-LP checkpoint2 remains open: it must\npreserve both assets, every tree pending/high-low book, direct whole credits and\nimmutable ordinals, with source/configuration/canonical reconciliation. No format2\nartifact, builder, automatic conversion, pruning or live rollout is implemented.'),

('Fresh royalty4 also retains','Royalty4 on that explicit6 profile also retains')])

edit('FRONTEND_LIFECYCLE.md',[

('selects `accounting_version: 4`, `fee_intake_version: 1`, direct governance V2\nand `ZZZ_CANONICAL_SAME_CHAIN_ROYALTY_OPENING_V7`. Its Position codec has eight\nwords and terminal Exited5 in addition to Dormant3/Parked4. Legacy accounting1/2/3\nreaders keep their original profile; no old journal is upgraded or reinterpreted.\nExisting schema-1\nconfigurations fail closed. Add independently reviewed runtime/address pins for\n`contracts.handoff` and `contracts.vault_canonical`, using the same object format\nas the other six contracts, plus the fixed `contracts.principal_exit` runtime pin.\nNine distinct contracts are required for accounting4; historical accounting3\nretains its eight-pin configuration. Every request\nchecks their runtime hashes and sealed controller/module/helper ownership links.', 'selects `accounting_version:7`, explicit custody5/ProtocolPolicy1/fee-intake1,\noriginal-currency royalty reporting5, LP-allocation1 and\n`ZZZ_CANONICAL_SAME_CHAIN_EXACT_LP_V9`. The Position codec retains eight words\nand Exited5/Dormant3/Parked4. Require the complete independently reviewed runtime\ngraph in the [read API](FRONTEND_API.md#current-deployment-profile), including\nRewards.canonicalModule(), its fixed access/rewards parents and Handoff.moduleAt(3).\nEvery request checks runtime hashes and sealed module/helper ownership links.\nHistorical6/V8 and older readers retain their actual graphs; accounting4 has nine\nbase pins and accounting3 eight. No old runtime or journal is relabeled.\nExisting schema1 configuration fails closed.'),

('Accounting4 additionally reads','Accounting4–7 read'),('the old canonical transport does','the canonical transport does'),

('lineage fails closed; zero and partial totals are never substituted. Current V6 source\nand successor require accounting6; historicalV5 accounting5/4 andV4 accounting3', 'lineage fails closed; zero and partial totals are never substituted. Current V9 source\nand successor require accounting7/LP-allocation1; historical6/V8, V5 accounting5/4 andV4 accounting3'),

('Current verification is recorded separately in\nthe [architecture-pruning review](../reports/architecture-pruning-20261025/REVIEW.md);', 'Current exact-LP integration is recorded in\n[its scoped review](../reports/exact-lp-integration-20261106/REVIEW.md);')])

edit('FRONTEND_LINEAGE.md',[

('For fresh accounting6/portfolio2/canonical adaptable-policy V6, every configured\npredecessor must explicitly use accounting6 and its complete helper/runtime graph\ntoo.', 'For fresh accounting7/LP-allocation1/portfolio2/canonicalV9, every configured\npredecessor must explicitly use7/V9 and its complete helper/runtime graph,\nincluding the fixed Rewards canonical companion. Historical6/V8 stays separate;\nits index/fraction state is not translated into exact7 trees.'),

('Declare its actual4 or5 capability with accounting6;', 'Declare5 with accounting7, or its actual4/5 with historical6;'),

('Fresh profile6/V6 requires6 for every predecessor;', 'Fresh profile7/V9 requires7 for every predecessor; historical6/V8 requires6;'),

('Complete fresh6 address/runtime graph, including `principal_exit` plus ProtocolPolicy1/Portfolio2/Manager/math/physical executor/core bindings.', 'Complete fresh7 graph, including `rewards_canonical`, `principal_exit`, ProtocolPolicy1/Portfolio2/Manager/math/physical executor/core bindings.'),

('Fresh accounting5/6 predecessor inventories','Fresh accounting5/6/7 predecessor inventories'),

('Every fresh V8 predecessor must declare its own royalty_reporting schema5 and','Every fresh V9 predecessor must declare its own royalty_reporting schema5 and'),

('owner unpaid rights; imports are not new earnings.', 'owner unpaid rights; imports are not new earnings. Historical6/V8 retains its\nexplicit declaration too. Fresh7 full raw replay preserves pending whole LP units,\nhigh/low fairness phase and direct credits across verified epochs, without\nrecrediting import events. Checkpoint1 cannot seed that state.')])

edit('FRONTEND_TRANSACTIONS.md',[

('Fresh6 dormant mint','Fresh7 dormant mint'),('Fresh6 provenance','Fresh7 provenance'),

('allowed for royalties and, under explicit accounting 2/3/4, native LP rewards.', 'allowed for royalties and, under explicit native accounting2–7, native LP rewards.'),

('The read configuration pins the canonical chain, deployment anchor, nine core\ncontract runtimes/helper bindings and admitted reward assets.', 'The read configuration pins the canonical chain, deployment anchor, complete\nselected contract/helper graph and admitted reward assets. Fresh7 also binds\nLP-allocation1 and the immutable Rewards canonical companion; old6/V8 remains\na separate profile.'),

('For accounting3/4 claims,','For accounting3–7 claims,'),

('Accounting4 requires the additional pinned `principal_exit` module, custody3 and\nholder-exit canonical V8.', 'Fresh7 requires pinned `principal_exit`, custody5 and canonicalV9. Historical4\nretains its own custody3/canonicalV5 profile.'),

('The read-service pins (nine for accounting4, eight for historical accounting3) do not authenticate Entry, Registry, source', 'The selected read-service graph alone does not authenticate Entry, Registry, source'),

('admission, Oracle and conversion routes. Activation requires those additional','admission and dual Oracle policies. Activation requires those additional')])

edit('FACTORY_CODE_STORAGE.md',[

('Use the explicit **schema15** deployment inventory; schema14 retains the prior\nsource scope for historical inspection. Format2/data payload is unchanged. Keep **18 logical callable', 'Use the explicit **schema16** deployment inventory. Schema15 is archived exactly\nfor historical inspection. Code-storage FORMAT2 is unchanged, but fresh payload3\nhas separate source-owned bytes/pins; never substitute historical payload2. Keep **19 logical callable'),

('module records,18 helper records and2 code-data records','module records,19 helper records and2 code-data records'),

('Royalty settlement4/recovery2, reporting5, accounting6 and canonicalV8 remain\nseparate unchanged behavior/wire identities. Schema14 and older runtime/config', 'Royalty settlement4/recovery2 and reporting5 remain unchanged. Fresh accounting7/\nLP-allocation1/canonicalV9 and its fixed Rewards canonical companion are separate\nidentities. Schema15 and older runtime/config'),

('bound schema15 constructor/release','bound schema16 constructor/release'),

('The preserved historical schema14 source artifact pins the closed normal compiler output:', 'The current payload3 artifact `config/factory-code-storage-v3.json` and\n`zzz_ops.factory_code_v3` bind the reviewed87-source compiler input and the\nwhole25,522-byte creation hash\n`0x0b5b619ca10d338f29e7a76fd3f9069b2e034864112bbd3101bbc20a279c50aa`.\nIts part0 is unchanged from payload2; part1 metadata differs. Artifact payload3\nis not CODE_STORAGE_VERSION3: the runtime format remains2.\n\nThe preserved historical schema14/15 payload2 artifact pins its own compiler output:'),

('authenticate the full schema15','authenticate the full schema16'),

('[current profile](POSITION_V6.md)','[current profile](POSITION_V7.md)')])

edit('CLAIM_PLANNING.md',[

('Public signing remains disabled; the shared browser signer remains Anvil-only.', 'Public signing remains disabled; the shared browser signer remains Anvil-only.\nFresh7 admission authenticates accounting7/LP-allocation1/canonicalV9 and the\nfixed Rewards canonical companion. LP funded claims are exact whole units in\nETH or fixed ZZZ; original royalty currencies remain separate. The schema1\nplanner/router selection shape is unchanged; no historical6 runtime is relabeled.'),

('at the same block hash**. Some of those settings are configurable across blocks.', 'at the same block hash**. This includes the exact LP capability and typed\ncanonical-module parent links, not tree balances or claimable components. Some\nof those settings are configurable across blocks.')])

edit('EARNINGS_HISTORY.md',[

('candidate uses accounting6/portfolio2, fee intake1 and compatible parked\nsame-chain canonical V8.', 'candidate uses accounting7/exact LP1/portfolio2, fee intake1 and compatible\nparked same-chain canonicalV9.'),

('per bucket/asset, not duplicate income streams. Explicit historical4 and3 readers', 'per bucket/asset, not duplicate income streams. Explicit historical6/V8 and older readers'),

('## Optional checkpoint1 milestone\n\nThe fresh accounting6/custody5/fee-intake1 earnings path', '## Exact LP accounting and historical checkpoints\n\nFresh7 replays actual `ShareWeightSynchronized` and\n`CollectiveWeightSynchronized` events using immutable mint ordinals. Old pending\nETH/ZZZ rights settle before each weight mutation. `SharesAdded` and\n`MembershipActivated` acknowledge those changes; they do not apply weights twice.\nA missing synchronization/acknowledgment, wrong old weight or wrong denominator\nrejects the report. One global equal-weight tree and at most four bucket share\ntrees assign whole units; high/low phase is rounding fairness, not a fractional\nclaim reserve. Claims and LP conversions mutate balances without new income.\n\nAt each pinned epoch the replay reconciles `allocationTree`, `directLiabilities`,\nfunded liabilities, orphaned money and selected `claimableComponents`. V9 imports\npreserve pending whole units/phase/direct credits, not a flattened index.\nFull raw history is required on7; checkpoint1 is rejected before restoring state.\nExact-LP checkpoint2 remains open for scalable history.\n\nThe historical accounting6/custody5/fee-intake1 earnings path'),

('Current accounting6 has no external','Current accounting7 has no external'),

("One replay per epoch handles the selected NFTs together, preserving each NFT's\nfractions before summing whole units.","One replay per epoch handles the selected NFTs together, preserving exact7\nwhole-unit books or the explicitly selected historical6 fractions before summing."),

('but include ledger rounding dust. They need not equal per-NFT whole-unit sums.', 'and preserve every allocated whole unit on7. Historical indexed profiles may\nretain fractional rounding reserves; those semantics are not applied to7.'),

('Amounts credited to the holder ledgers; integer index dust can make their sum exceed the sum of immediately claimable whole units', 'Whole units credited to holder trees on7; historical indexed profiles may retain fractional reserves'),

('LP earnings reconstructed from their 1e36 indexes/fractions; fresh royalties from exact ticket credits, with no royalty fractions', 'Exact7 whole LP units and royalty4 ticket credits; historical6 LP indexes/fractions remain explicit'),

('An LP fractional unit enters an NFT\'s period when its carry becomes a whole raw\nunit. Fresh royalty4 assigns whole units at allocation time without a fractional reserve.', 'Exact7 LP units and royalty4 units enter NFT income at allocation, without a\nfractional monetary reserve. Historical indexed LP units enter the period when\ntheir fractional carry first becomes payable.'),

('Royalties converted from a stablecoin into ETH remain earnings in the original', 'Historical royalties converted from a stablecoin into ETH remain earnings in the original'),

('source/output amounts and lifetime claims for payouts.', 'source/output amounts and lifetime claims for payouts. Fresh royalty4 has no\nroyalty swaps; LP conversion remains a separate non-income operation.')])

print('Updated nine source-bound backend guides; no runtime/service change')

