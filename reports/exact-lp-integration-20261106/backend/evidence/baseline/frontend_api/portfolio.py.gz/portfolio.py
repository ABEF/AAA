"""Bounded wallet totals at one canonical snapshot, independent of card pagination.

Clients must collect every ordered chunk of this inventory before displaying a
total. No rolling latest-state sum, balance cache, signing or partial total.
"""
import hashlib
from frontend_api.service import ProjectionError, ZERO, _bool
from frontend_api.history import HistoryError
from frontend_api.custody import read as read_custody
from zzz_ops.abi import address
from zzz_ops.errors import RpcError, WorkLimit
from zzz_ops.work_budget import expire_at

CHUNK_SIZE=16


def read(p, wallet_address, block_number, offset):
    wallet=address(wallet_address)
    if type(block_number) is not int or type(offset) is not int or not 0<=offset<1000 or offset%CHUNK_SIZE:
        raise ValueError('Invalid wallet summary cursor')
    if p.history is None:raise HistoryError('Complete indexed ownership is required')
    safe,head,_=p._snapshot()
    if not p.start<=block_number<=safe['number']:raise ProjectionError('Summary block is not confirmed')
    header=p._header(hex(block_number));p._fresh(header)
    expire_at(header['timestamp']+p.max_age,p.clock)
    block={'blockHash':header['hash'],'requireCanonical':True}
    life=p._verify_deployment(block)
    # Currency failure must not fabricate a total, nor block unrelated ETH reads.
    lp,royalties=p._admitted(block,asset_health={})
    history=p._history_snapshot(header,block,lp,royalties)
    ids=sorted(i for i,owner in history.owners.items() if owner==wallet)
    count=p._uint('nft','balanceOf(address)',wallet,block=block)
    if count!=len(ids) or count>1000:raise HistoryError('Wallet inventory differs from canonical balance')
    if offset>=count and not (offset==0 and count==0):raise ValueError('Cursor is outside wallet inventory')
    selected=ids[offset:offset+CHUNK_SIZE]
    total_lp=0;total_eth=0;lp_ok=True;eth_ok=ZERO in lp and ZERO in royalties
    verified_buckets=set()
    custody_buckets={}
    custody_shares={}
    for identifier in selected:
        if p._addr('nft','ownerOf(uint256)',identifier,block=block)!=wallet:
            raise HistoryError('Wallet ownership differs from indexed snapshot')
        # In the fixed current ledger, weight zero means this NFT has never
        # activated; eligibility is permanent. Read actual views anyway so an
        # unavailable or contradictory response is never replaced with zero.
        inactive=False
        if p.accounting_version in (3,4,5,6):
            weight=p._uint('royalties','weightOf(uint256)',identifier,block=block)
            if weight>3:raise ProjectionError('Wallet NFT royalty weight exceeds the reviewed bound')
            inactive=weight==0
        status=None
        if p.accounting_version in (3,4,5,6):
            status=p._uint('vault','nftStatus(uint256)',identifier,block=block)
            limit=6 if p.accounting_version in (4,5,6) else 5
            if type(status) is not int or not 1<=status<limit:
                raise ProjectionError('Wallet NFT has unsupported canonical custody')
            if (status==p.dormant_status)!=inactive:
                raise ProjectionError('Wallet custody and royalty eligibility disagree')
        exited = p.accounting_version in (4,5,6) and status == 5
        if p.accounting_version in (3,4,5,6):
            bucket=p._uint('vault','nftBucket(uint256)',identifier,block=block)
            shares=p._uint('vault','sharesOf(uint256)',identifier,block=block)
            if (shares>0)!=(bucket>0) or inactive!=(shares==0):
                raise ProjectionError('Wallet custody and shares disagree')
            read_custody(p,status,bucket,shares,block,cache=custody_buckets,totals=custody_shares)
        if p.accounting_version in (5,6) and status == 1:
            if bucket not in verified_buckets:
                from frontend_api.portfolio_v5 import read_bucket as read_v5
                from frontend_api.portfolio_v6 import read_bucket as read_v6
                read_bucket = read_v6 if p.accounting_version == 6 else read_v5
                read_bucket(p,bucket,block);verified_buckets.add(bucket)
        # Keep each metric independent: unreadable LP never becomes a zero sum.
        try:
            value=p._call(p.contracts['nft'].address,'currentLPValue(uint256)',identifier,block=block,words=2)
            available=_bool(value[0]);amount=int(value[1],16)
            if not available and amount:raise ProjectionError('Unavailable LP contains a value')
            if inactive and available and amount:raise ProjectionError('Inactive NFT has attached LP value')
            if status is not None and status not in (1,p.dormant_status) and not exited and available:
                raise ProjectionError('Wallet custody cannot report an active LP valuation')
            if status is not None and status==p.dormant_status and (not available or amount):
                raise ProjectionError('Dormant wallet NFT must have verified zero LP')
            if exited and (not available or amount or not life['lp_exit_started']):
                raise ProjectionError('Exited NFT must have verified zero remaining LP')
            lp_ok=lp_ok and available;total_lp+=amount
        except (WorkLimit,ProjectionError):raise
        except RpcError:lp_ok=False
        if eth_ok:
            try:
                amount=sum(p._uint(role,'claimable(uint256,address)',identifier,ZERO,block=block)
                           for role in ('rewards','royalties'))
                if inactive and amount:raise ProjectionError('Inactive NFT has native reward entitlement')
                total_eth+=amount
            except (WorkLimit,ProjectionError):raise
            except RpcError:eth_ok=False
    p._finish(header)
    digest=hashlib.sha256(','.join(map(str,ids)).encode('ascii')).hexdigest()
    return dict(schema=1,chain_id=p.chain,wallet=wallet,nft_contract=p.contracts['nft'].address,
        inventory_sha256=digest,count=count,offset=offset,token_ids=list(map(str,selected)),
        next_offset=offset+len(selected) if offset+len(selected)<count else None,chunk_size=CHUNK_SIZE,
        lp_usd_18=str(total_lp) if lp_ok else None,claimable_eth_wei=str(total_eth) if eth_ok else None,
        lifecycle=life,provenance=dict(block_number=header['number'],block_hash=header['hash'],
            block_timestamp=header['timestamp'],observed_head=head,confirmations=p.confirmations,
            configuration_sha256=p.identity,finality='confirmation_depth_only'),
        scope='Chunk only. Sum all chunks of the same inventory and block before displaying wallet totals. '
              'ETH is funded LP plus royalties; unconverted source currencies and historical earnings are excluded.')
