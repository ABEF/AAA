import sys,json,hashlib,time,unittest
from pathlib import Path
ROOT=Path(r"C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2")
sys.path.insert(0,str(ROOT))
E=Path(r"C:\Users\Ali\.codex\visualizations\2026\10\14\01a13899-2be7-76f2-a5d0-72e4804c67b9\exact-lp-integration-20261106\services-4e8d")
modules=['exact_lp_backend', 'exact_lp_profile7', 'exact_lp_inventory', 'frontend_policy_v6', 'keeper_policy_v6', 'earnings', 'wallet_earnings', 'earnings_checkpoints', 'frontend_activation', 'current_activation_profile', 'typed_v4_activation', 'portfolio_activation_bindings', 'frontend_transactions', 'claim_planner', 'portfolio_price_outage', 'frontend_lifecycle', 'frontend_lineage', 'market_lifecycle_projection', 'market_lifecycle_keeper', 'keeper_standalone_harvest_review', 'keeper_harvest_coalescing', 'keeper_late_lp_review', 'keeper_operation_review', 'keeper_review_retry', 'royalties_in_kind', 'exact_royalty_backend', 'exact_royalty_profile', 'factory_code_profile', 'residual_reinvest_profile', 'production_preflight_cli', 'mint_integration_qualification', 'production_v6', 'production_config']
def flatten(x):
 for t in x:
  if isinstance(t,unittest.TestSuite):yield from flatten(t)
  else:yield t
seen={}
for m in modules:
 for t in flatten(unittest.defaultTestLoader.loadTestsFromName('tests_python.test_'+m)):seen[t.id()]=t
sources={str(p.relative_to(ROOT)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for d in ('frontend_api','keeper','zzz_ops') for p in (ROOT/d).glob('*.py')}
(E/'affected-stage1-input.json').write_text(json.dumps(dict(methods=sorted(seen),source_sha256=sources),indent=2))
with (E/'affected-stage1.log').open('w',encoding='utf8') as log:r=unittest.TextTestRunner(log,verbosity=2).run(unittest.TestSuite(seen.values()))
(E/'affected-stage1-result.json').write_text(json.dumps(dict(count=r.testsRun,unique_methods=len(seen),failures=[(t.id(),s) for t,s in r.failures],errors=[(t.id(),s) for t,s in r.errors],skipped=[(t.id(),s) for t,s in r.skipped]),indent=2))
print(json.dumps(dict(count=r.testsRun,unique_methods=len(seen),failures=len(r.failures),errors=len(r.errors),skipped=len(r.skipped))))
sys.exit(not r.wasSuccessful())
