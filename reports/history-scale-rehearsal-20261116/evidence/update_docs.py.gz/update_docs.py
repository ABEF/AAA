import difflib, json, pathlib, subprocess, sys

R=pathlib.Path(r'C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
E=pathlib.Path(__file__).resolve().parent
B=json.loads((E/'BASELINE.json').read_bytes())
data=json.loads((E/'run-03/result.json').read_bytes())
assert data['successful'] and data['wallet_coverage_nfts']=={'source':1000,'restored':1000}
FAMILY='history-scale-rehearsal-20261116'
def original(name): return (E/'original-docs'/B['archived_docs'][name]).read_bytes()
def normalize(raw): return raw.decode('utf-8').replace('\r\n','\n')
def write(name,text):
    old=original(name); oldlines=old.splitlines(keepends=True); newlines=text.splitlines(keepends=True)
    prior=[line.decode('utf-8').rstrip('\r\n') for line in oldlines]
    after=[line.rstrip('\r\n') for line in newlines]
    same={}
    for a,b,n in difflib.SequenceMatcher(a=prior,b=after,autojunk=False).get_matching_blocks():
        for j in range(n):same[b+j]=oldlines[a+j]
    (R/name).write_bytes(b''.join(same.get(i,line.encode('utf-8')) for i,line in enumerate(newlines)))

for name in ('AGENTS.md','PROJECT_CONTEXT.md','README.md','docs/WORK_HANDOFF.md',
             'docs/IMPLEMENTATION_STATUS.md','docs/ROADMAP.md','docs/AUDIT_FINDINGS.md','reports/README.md'):
    text=normalize(original(name)); old=text.split('\n\n',2)[1]
    assert old.startswith('Current offline tooling includes')
    prefix='../' if name.startswith(('docs/','reports/')) else ''
    new=(f'The [isolated 1,000-NFT history rehearsal]({prefix}reports/{FAMILY}/REVIEW.md) verifies exact earnings, claims,\n'
         'conversions and recovery across three controlled accounting7/mint2 epochs:\n'
         '900 active/100 dormant NFTs, the full raw 24-hour window and nonzero LP phase.\n'
         'All source/restored rows and checkpoint/review bytes match; bounded wallet\n'
         f'reads cover all 1,000 NFTs separately in each copy ({data["wallet_chunks_per_copy"]} chunks per copy).\n'
         'The default 4,096-call checkpoint refusal is retained. The positive offline\n'
         'build/import uses the existing explicit 65,536-call allowance, with defaults,\n'
         'HTTP limits, codecs and all production sources unchanged. This is controlled\n'
         'local SQL/replay/recovery evidence, not provider/EVM, maximum-lifetime, host or\n'
         'off-host qualification. Earlier checkpoint/import/backup/deployment planners\n'
         'remain unsigned and unadopted. Existing chains, databases, journals, signer,\n'
         'sites/services and the user-paused heartbeat are unchanged.')
    write(name,text.replace(old,new,1))

manual=normalize(original('docs/OPERATOR_MANUAL.md'))
needle='### Serve processed earnings and current-price values'
addition=f'''#### Collection-scale history rehearsal

The [controlled 1,000-NFT record](../reports/{FAMILY}/REVIEW.md) checks
three same-chain epochs, 900 active/100 dormant NFTs, exact LP/royalty units,
claims, conversions, the full 24-hour boundary, and backup/restore. It uses NEW
synthetic databases and controlled chain observations, never your installed DBs.

| Tool/action | Required inputs | Example | Effect |
| --- | --- | --- | --- |
| Rehearse isolated history recovery | A NEW output directory under an existing owner-controlled parent | `python -m tests_python.history_scale_rehearsal --output /review/new-scale-run` | Verify bounded synthetic recovery |

Keep every failed/partial output. The recorded default checkpoint refusal uses
4,096 reads. Positive offline construction explicitly uses the already-supported
65,536-call ceiling and unchanged 60-second deadline; this changes no default or
HTTP limit. Normal NFT/wallet/collection reads retain 25 seconds/1,024 calls,
and wallet chunks stay at most 16 NFTs. The fixture's history setting is 10,000
events; this is not a new production default. A pinned prior identical-workload
refusal can be reused with the rehearsal's paired `--prior-refusal` and
`--prior-refusal-sha256` arguments; it remains earlier source-scoped evidence.

Do not copy the synthetic addresses, configs or timing into production. Local
getter caching removes repeated fixture scans; it is not a live RPC cache or
latency approval. Select actual offline budgets only after measuring the real
provider, admission work, posts and latency. Keep existing bounds and fail closed
if the workload cannot finish. Review restored paths and canonical coverage before
separately authorized adoption. Off-host/Unix, maximal currencies/buckets/lineage,
lifetime history and independent operating approval remain open.

'''
assert manual.count(needle)==1
write('docs/OPERATOR_MANUAL.md',manual.replace(needle,addition+needle,1))

for name in ('docs/HISTORY_RECOVERY.md','docs/EARNINGS_CHECKPOINTS.md'):
    text=normalize(original(name))
    text+=f'''\n## Controlled collection-scale evidence

The [1,000-NFT rehearsal](../reports/{FAMILY}/REVIEW.md)
passes exact checkpoint2-to-3 prefix import, backup/verification/new-file restore,
independent whole-unit accounting and complete per-copy wallet coverage. It spans
three controlled deployments, 900 active/100 dormant NFTs, 7,757 raw logs and
346,800 chain seconds, including receipts before/at/after the day's exclusive
lower boundary. Nonzero high/low LP allocation phase is retained.

The original default 4,096-read refusal is retained; positive offline build/import
uses explicit existing 65,536-call settings under the unchanged 60-second deadline.
HTTP defaults, 16-NFT chunks, 32MiB checkpoint, codec/event/graph/currency bounds
and recovery defaults remain unchanged. The rehearsal uses synthetic chain,
getter and lifecycle observations; local timing excludes real-provider posts,
network latency and complete admission cost. It does not qualify maximum lifetime
history, all currencies/buckets/epochs, Unix/off-host restore or deployment.
See the [operator procedure](OPERATOR_MANUAL.md#collection-scale-history-rehearsal).
'''
    write(name,text)

ledger=json.loads(original('docs/project-todo.json'))
for area in ledger['areas']:
    for task in area['tasks']:
        if task['id'] not in ('financial-history','host-services'): continue
        assert task['status']=='progress'
        task['acceptance'].append(
            f'[Controlled 1,000-NFT history recovery](reports/{FAMILY}/REVIEW.md): '
            f'900 active/100 dormant, three accounting7/mint2 epochs, 7,757 logs and 346,800 chain seconds; '
            f'independent exact LP/royalty earned/current-right/claim/conversion arithmetic, nonzero high/low phase, '
            f'full86400-second boundary and source/restored row/checkpoint/review equality pass. '
            f'{data["wallet_chunks_per_copy"]} bounded wallet chunks per copy cover every NFT with exact inventory identities; '
            f'default HTTP25s/1024calls/16-NFT chunks and all production sources/limits stay. '
            f'Original4096-call refusal is explicitly reused; positive offline build/import uses existing explicit65536-call/60s allowance. '
            f'Initial uncached-fixture60s failure and Windows directory-name collision remain evidence; only new rehearsal fixtures change. '
            f'Controlled SQL/replay/recovery qualification is not actual provider posts/latency, archive completeness, maximum lifetime/all-currency/all-bucket state, Unix/off-host or operating approval. '
            f'No unchanged suites, contracts/compiler, external RPC, existing DB/Anvil/journal/site/service/signer/heartbeat action.')
        task['text'] += ' A controlled 1,000-NFT/three-epoch recovery rehearsal now verifies exact local results and bounded chunk coverage; actual provider and lifetime/host qualification remain open.'
write('docs/project-todo.json',json.dumps(ledger,indent=2,ensure_ascii=False)+'\n')

index=normalize(original('docs/README.md'))
index+=f'\n[Controlled 1,000-NFT history recovery evidence](../reports/{FAMILY}/REVIEW.md) records finite local scale, exact accounting, unchanged budgets and remaining operating qualification.\n'
write('docs/README.md',index)
subprocess.run([sys.executable,'scripts/sync-project-todo.py'],cwd=R,check=True)
write('TODO.md',normalize((R/'TODO.md').read_bytes()))
print(json.dumps({'docs_updated':14,'tasks_remain_progress':['financial-history','host-services']}))
