import ast, gzip, hashlib, json, pathlib, subprocess, sys, zipfile

R=pathlib.Path(r'C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
sys.path.insert(0,str(R))
E=pathlib.Path(__file__).resolve().parent
P=R/'reports/history-scale-rehearsal-20261116'
B=json.loads((E/'BASELINE.json').read_bytes())
allowed=set(B['archived_docs'])
changed=[name for name,pin in B['files'].items() if hashlib.sha256((R/name).read_bytes()).hexdigest()!=pin]
assert set(changed)<=allowed,changed
protected=['reports/source-checks.json','scripts/run-fork-checks.py','tests_python/test_fork_runner.py','tests_python/test_frontend_history.py']
for name in protected: assert hashlib.sha256((R/name).read_bytes()).hexdigest()==B['files'][name]
for name in (n for n in B['files'] if n.endswith('.py') or n.startswith('src/') and n.endswith('.sol')):
    assert hashlib.sha256((R/name).read_bytes()).hexdigest()==B['files'][name]
final=(R/'tests_python/history_scale_rehearsal.py').read_bytes()
assert hashlib.sha256(final).hexdigest()=='1510b781068d73ad0ff8de3a42e9161e9a167eb92651684a75b31c1571a6a84d'
assert final==(E/'harness-source-03.py').read_bytes()
tree=ast.parse(final)
assert not [n.name for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]
from frontend_api.earnings_checkpoint_v3 import sources
pins=json.loads((E/'RUN_SOURCE_PINS.json').read_bytes())
assert sources()==pins['semantic_lf_sha256']
result=json.loads((E/'run-03/result.json').read_bytes()); assert result['successful']
stage=json.loads((E/'rehearsal-03.json').read_bytes());assert stage['exit_code']==0
run=E/'run-03'
manifest=json.loads((run/'bundle/manifest.json').read_bytes())
separate=[]
for n in range(3):
    paths=[run/'fixture-001'/f'epoch-{n}.sqlite',run/'bundle/databases'/f'{n:03d}.sqlite',run/'restored/databases'/f'{n:03d}.sqlite']
    identities=[(p.stat().st_dev,p.stat().st_ino) for p in paths]
    assert len(set(identities))==3
    separate.append({'epoch':n,'distinct_file_identities':True})
preserve={'baseline_head':B['head'],'baseline_sha256':hashlib.sha256((E/'BASELINE.json').read_bytes()).hexdigest(),
    'old_tracked_files':len(B['files']),'permitted_changed_docs':sorted(changed),
    'existing_python_files_unchanged':sum(n.endswith('.py') for n in B['files']),
    'solidity_files_unchanged':sum(n.startswith('src/') and n.endswith('.sol') for n in B['files']),
    'historical_report_files_unchanged':sum(n.startswith('reports/') and n!='reports/README.md' for n in B['files']),
    'semantic_sources_unchanged':len(sources()),'protected_dirty_files':{n:B['files'][n] for n in protected},
    'separate_source_bundle_restored_files':separate,'old_tests_run':False,'external_network_or_chain_action':False}
(E/'PRESERVATION.json').write_text(json.dumps(preserve,indent=2)+'\n',encoding='utf-8')
finalpins={'harness_raw_sha256':hashlib.sha256(final).hexdigest(),
    'harness_ast_sha256':hashlib.sha256(ast.dump(tree,include_attributes=False).encode()).hexdigest(),
    'semantic_lf_sha256':sources(),'old_test_methods_selected':[],
    'final_stage_record_sha256':hashlib.sha256((E/'rehearsal-03.json').read_bytes()).hexdigest(),
    'final_result_sha256':hashlib.sha256((run/'result.json').read_bytes()).hexdigest()}
(E/'FINAL_SOURCE_PINS.json').write_text(json.dumps(finalpins,indent=2)+'\n',encoding='utf-8')
entries=[]; (P/'evidence').mkdir(exist_ok=True)
names=['BASELINE.json','RUN_SOURCE_PINS.json','PRESERVATION.json','FINAL_SOURCE_PINS.json',
    'INDEPENDENT_LIMITS_REVIEW.json','INDEPENDENT_LIMITS_POSTREVIEW.json','FINAL_HARNESS_SCOPE_REVIEW.json',
    'harness-source-01.py','harness-source-02.py','harness-source-03.py',
    'baseline.py','run_stage.py','update_docs.py','finalize_evidence.py',
    'rehearsal-01.json','rehearsal-01.log','run-01/result.json',
    'rehearsal-02.json','rehearsal-02.log','run-02/result.json',
    'rehearsal-03.json','rehearsal-03.log','run-03/result.json']
for name in names:
    raw=(E/name).read_bytes(); dest='evidence/'+name.replace('/','--')+'.gz'; compressed=gzip.compress(raw,mtime=0)
    (P/dest).write_bytes(compressed)
    assert gzip.decompress(compressed)==raw
    entries.append({'source':name,'path':dest,'bytes':len(compressed),'sha256':hashlib.sha256(compressed).hexdigest(),
                    'original_bytes':len(raw),'original_sha256':hashlib.sha256(raw).hexdigest()})
members=[]; archive=P/'evidence/final-run.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for file in sorted(run.rglob('*')):
        if not file.is_file():continue
        name=file.relative_to(run).as_posix(); raw=file.read_bytes()
        info=zipfile.ZipInfo(name,(2026,11,16,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
        z.writestr(info,raw)
        members.append({'path':name,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
with zipfile.ZipFile(archive) as z:
    assert z.namelist()==[x['path'] for x in members]
    for row in members:assert hashlib.sha256(z.read(row['path'])).hexdigest()==row['sha256']
raw=archive.read_bytes()
entries.append({'source':'run-03','path':'evidence/final-run.zip','bytes':len(raw),
                'sha256':hashlib.sha256(raw).hexdigest(),'members':members})
(P/'EVIDENCE.json').write_text(json.dumps({'schema':1,'baseline_head':B['head'],'entries':entries},indent=2)+'\n',encoding='utf-8')
print(json.dumps({'preservation':preserve,'evidence_files':len(entries),'archive_bytes':len(raw),'final_stages':len(result['stages'])}))
