import datetime, hashlib, json, pathlib, subprocess

root = pathlib.Path(r'C:/Users/Ali/Desktop/2.x holas/Oto/zzz-protocol-v2-reviewed/zzz-protocol-v2')
out = pathlib.Path(__file__).resolve().parent
def git(*args):
    return subprocess.check_output(['git', *args], cwd=root).decode('utf-8')
files = git('ls-files', '-z').split('\0')
pins = {n: hashlib.sha256((root/n).read_bytes()).hexdigest() for n in files if n and (root/n).is_file()}
docs = ['AGENTS.md','PROJECT_CONTEXT.md','README.md','TODO.md','docs/WORK_HANDOFF.md',
        'docs/OPERATOR_MANUAL.md','docs/HISTORY_RECOVERY.md','docs/EARNINGS_CHECKPOINTS.md',
        'docs/project-todo.json','docs/IMPLEMENTATION_STATUS.md','docs/ROADMAP.md',
        'docs/AUDIT_FINDINGS.md','docs/README.md','reports/README.md']
archive = out/'original-docs'; archive.mkdir()
archived = {}
for name in docs:
    file = hashlib.sha256(name.encode()).hexdigest()+'.bin'
    (archive/file).write_bytes((root/name).read_bytes()); archived[name] = file
result = {'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'head':git('rev-parse','HEAD').strip(),'branch':git('branch','--show-current').strip(),
          'status':git('status','--porcelain=v1'), 'files':pins,'archived_docs':archived,
          'authorization':'Isolated1000NFT history recovery; exact accounting/full86400s/unchanged limits; no prior-suite or live actions.'}
(out/'BASELINE.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'head':result['head'],'branch':result['branch'],'tracked_files':len(pins),'archived_docs':len(archived)}))
